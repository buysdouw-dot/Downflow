// ─── AI Coaching Engine v2 ───────────────────────────────────────────────────
// Context-aware, behavior-model-driven coaching.
// Drop-in OpenAI upgrade: swap localCoach() for openaiCoach() at any time.
// ─────────────────────────────────────────────────────────────────────────────

// ── Pattern detection ─────────────────────────────────────────────────────────
export function detectDropPattern(weekScores) {
  if (!weekScores || weekScores.length < 3) return 'insufficient_data';

  const redDays = weekScores.filter(s => s < 25).length;
  const greenDays = weekScores.filter(s => s >= 40).length;
  const morningDrop = weekScores.slice(0, 2).every(s => s < 25); // Mon/Tue low
  const lateDrop = weekScores.slice(-2).every(s => s < 25);      // Fri/Sat low
  const midweekDrop = weekScores.slice(2, 4).every(s => s < 25); // Wed/Thu low

  if (redDays >= 5) return 'chronic_underperformance';
  if (redDays >= 3 && greenDays <= 1) return 'inconsistent_high_risk';
  if (morningDrop) return 'slow_starter';
  if (lateDrop) return 'week_fade';
  if (midweekDrop) return 'midweek_slump';
  if (greenDays >= 5) return 'elite_consistent';
  if (greenDays >= 3) return 'building_momentum';
  return 'erratic';
}

export function calcStreak(weekScores, target = 40) {
  let streak = 0;
  for (let i = weekScores.length - 1; i >= 0; i--) {
    if (weekScores[i] >= target) streak++;
    else break;
  }
  return streak;
}

// ── Coaching message library (deep, context-specific) ────────────────────────
const COACHING_LIBRARY = {
  // By drop pattern
  patterns: {
    chronic_underperformance: {
      insight: 'Consistent underperformance means the system is misaligned, not broken.',
      action: 'Reset to 3 non-negotiable tasks. Complete only those for 3 days.',
      warning: 'If this continues 2 more days, performance gap becomes a habit.',
    },
    inconsistent_high_risk: {
      insight: 'You spike but can\'t maintain. Energy management is the missing variable.',
      action: 'Pick your 2 highest-value tasks and do only those before anything else.',
      warning: 'Inconsistency destroys compounding. Each bad day resets the trust your system builds.',
    },
    slow_starter: {
      insight: 'You lose the most points in the morning. Mornings set your trajectory.',
      action: 'Do 1 outreach before you open anything else tomorrow.',
      warning: null,
    },
    week_fade: {
      insight: 'You fade Thursday–Friday. Your energy doesn\'t match your schedule.',
      action: 'Front-load effort early in the week. Friday is for follow-ups only.',
      warning: 'Losing the end of the week costs you 30%+ of your weekly volume.',
    },
    midweek_slump: {
      insight: 'Wednesday is killing your momentum. Classic slump point.',
      action: 'Schedule your highest-energy task for Wed at 9AM. Protect that block.',
      warning: null,
    },
    elite_consistent: {
      insight: 'You are one of the top performers. Now focus on quality, not just volume.',
      action: 'Target your 5+ point tasks exclusively until you hit target.',
      warning: null,
    },
    building_momentum: {
      insight: 'Good trend. 3+ green days means you\'re building a real system.',
      action: 'Stack one more green day. Consistency compounds faster than intensity.',
      warning: null,
    },
    erratic: {
      insight: 'Your output pattern is unpredictable — spikes without system.',
      action: 'Define 3 non-negotiable daily actions. Do them first, every day.',
      warning: 'Erratic output is a performance red flag in competitive environments.',
    },
    insufficient_data: {
      insight: 'Not enough data yet — keep logging every action.',
      action: 'Focus on completing today\'s minimum required actions.',
      warning: null,
    },
  },

  // By score threshold (high/med/low)
  scoreContext: {
    high: [
      { insight: 'You\'re executing at elite level today.', action: 'Maintain tempo — you\'re setting the pace.', warning: null },
      { insight: 'Peak output achieved. Every action above this is extra compounding.', action: 'Push one more closing action before end of day.', warning: null },
    ],
    medium: [
      { insight: 'You\'re tracking well. One strong push and you\'re in the green.', action: 'Prioritize your highest-point task in the next 30 minutes.', warning: null },
      { insight: 'Solid execution. Close the gap before the day ends.', action: 'Do 2 high-value actions now before distractions arrive.', warning: null },
    ],
    low: [
      { insight: 'Below threshold. This is a critical window to recover.', action: 'Log 3 actions in the next 15 minutes. No decisions — just do them.', warning: 'RED today means RED streak starts. Break it now.' },
      { insight: 'You\'re falling behind pace. Small actions add up fast.', action: 'One action per 10 minutes for the next 30 minutes.', warning: 'Two more RED days triggers a recovery protocol.' },
    ],
  },

  // By streak
  streakMessages: {
    0: 'No streak active. Today is day 1 — start now.',
    1: 'Streak: 1 day. Real habits need 3+ consecutive days to stick.',
    2: 'Streak: 2 days. One more and you have your first real chain.',
    3: 'Streak: 3 days. The chain is forming. Don\'t break it.',
    4: 'Streak: 4 days. You\'re in the compounding window.',
    5: '5-day streak. This is where results begin to show.',
    7: '7-day streak. One full week of execution. Keep going.',
  },

  // By role
  roleContext: {
    admin: 'As a team lead, your consistency sets the standard others follow.',
    manager: 'Your execution rate directly impacts what you can ask from your team.',
    user: 'Your daily actions are your most important performance asset.',
  },

  // Task-category specific
  taskInsights: {
    Outreach:      'Outreach is the lifeblood of pipeline. Volume here multiplies everything downstream.',
    Conversation:  'Every conversation is a conversion opportunity. Quality > speed here.',
    'Follow-Up':   '80% of sales close after the 5th follow-up. You are always ahead of those who quit.',
    Closing:       'Closing is a skill built by attempting it, not waiting for perfect conditions.',
    Cardio:        'Cardio is your base. Every session builds the capacity for more tomorrow.',
    Strength:      'Strength is accumulated slowly and lost fast. Today matters.',
    Recovery:      'Recovery is not passive. It\'s the work that unlocks future performance.',
    Nutrition:     'You perform at the level you fuel. Nutrition is a daily decision.',
    Study:         'Every hour of deep study compounds. You\'re building capability, not just content.',
    Attendance:    'Showing up is the non-negotiable. Everything else follows from presence.',
    Deliverables:  'Completing and submitting is what separates learning from achieving.',
    Collaboration: 'Group work multiplies individual effort. Invest in others and it returns.',
    Admin:         'Admin work keeps the system clean. Clean systems produce better results.',
  },
};

// ── Main coaching function (local / rule-based context model) ─────────────────
export function coach(userContext) {
  const {
    role = 'user',
    score = 0,
    dailyTarget = 40,
    weekScores = [],
    lastTask = null,
    streak = 0,
  } = userContext;

  const dropPattern = detectDropPattern(weekScores);
  const pct = score / dailyTarget;
  const tier = pct >= 1 ? 'high' : pct >= 0.55 ? 'medium' : 'low';

  // Primary coaching from drop pattern
  const patternCoach = COACHING_LIBRARY.patterns[dropPattern];

  // Score context coaching
  const scoreArr = COACHING_LIBRARY.scoreContext[tier];
  const scoreCoach = scoreArr[Math.floor(Math.random() * scoreArr.length)];

  // Choose primary vs score based: use pattern if it has a warning, else blend
  const hasCritical = tier === 'low' && dropPattern !== 'elite_consistent';
  const primary = hasCritical ? patternCoach : scoreCoach;

  // Streak message
  const streakKey = streak >= 7 ? 7 : streak;
  const streakMsg = COACHING_LIBRARY.streakMessages[streakKey] ?? `Streak: ${streak} days. Keep building.`;

  // Role context
  const roleMsg = COACHING_LIBRARY.roleContext[role] ?? COACHING_LIBRARY.roleContext.user;

  // Task insight
  const taskInsight = lastTask?.category
    ? COACHING_LIBRARY.taskInsights[lastTask.category] ?? null
    : null;

  const remaining = Math.max(0, dailyTarget - score);
  const pctToTarget = Math.round((score / dailyTarget) * 100);

  return {
    // Core coaching message
    insight: primary.insight,
    action: primary.action,
    warning: primary.warning,

    // Supplemental context
    streakMessage: streakMsg,
    roleMessage: roleMsg,
    taskInsight,

    // Metadata
    dropPattern,
    tier,
    pctToTarget,
    remaining,
    streak,
    timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),

    // Tag for display
    tag: {
      high: 'Elite Execution',
      medium: 'On Track',
      low: dropPattern === 'chronic_underperformance' ? 'Critical' : 'Recovery Mode',
    }[tier],
  };
}

// ── OpenAI upgrade path ───────────────────────────────────────────────────────
// When ready, replace coach() calls with this function.
// Requires: VITE_OPENAI_API_KEY environment variable
//
// export async function openaiCoach(userContext) {
//   const { role, score, streak, dropPattern, dailyTarget } = userContext;
//   const prompt = `
// You are a behavioral execution coach.
// User: Role: ${role}, Score: ${score}/${dailyTarget}, Streak: ${streak} days, Drop pattern: ${dropPattern}
// Give:
// 1. One insight (under 20 words)
// 2. One action (under 20 words)
// 3. One warning if needed (under 20 words)
// Be direct. No fluff. Coach like a high-performance trainer.
// `;
//   const res = await fetch('https://api.openai.com/v1/chat/completions', {
//     method: 'POST',
//     headers: {
//       'Content-Type': 'application/json',
//       Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
//     },
//     body: JSON.stringify({
//       model: 'gpt-4o-mini',
//       messages: [{ role: 'user', content: prompt }],
//       max_tokens: 150,
//       temperature: 0.7,
//     }),
//   });
//   const data = await res.json();
//   return { ...parseOpenAIResponse(data), timestamp: new Date().toLocaleTimeString() };
// }
