/**
 * AI Memory Engine — True Personalization System
 * Builds a behavioral profile per user, persists in localStorage,
 * and provides adaptive coaching context.
 */

// ── Memory Schema ─────────────────────────────────────────────────────────────
const DEFAULT_PROFILE = {
  version: 2,
  behaviorProfile: {
    consistency:         'unknown',  // low | medium | high | unknown
    dropPattern:         'unknown',  // morning | evening | midweek | weekend | random | unknown
    responseToPressure:  'neutral',  // negative | neutral | positive
    paceType:            'unknown',  // fast-starter | slow-starter | steady | inconsistent
  },
  performanceHistory: [],   // [{ date, score, status, tasksCompleted }]
  lastActions:        [],   // last 10 action timestamps ISO strings
  coachingStyle:      null, // discipline | strategy | motivation | null (auto)
  streakRecord:       0,
  totalSessions:      0,
  joinedAt:           null,
  lastSeenAt:         null,
  insights:           [],   // generated text insights saved over time
};

// ── Storage helpers ───────────────────────────────────────────────────────────
function key(userId, tenantId) {
  return `be_memory_${tenantId}_${userId}`;
}

export function loadMemory(userId, tenantId) {
  try {
    const raw = localStorage.getItem(key(userId, tenantId));
    if (!raw) return { ...DEFAULT_PROFILE, userId, tenantId, joinedAt: new Date().toISOString() };
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw), userId, tenantId };
  } catch {
    return { ...DEFAULT_PROFILE, userId, tenantId };
  }
}

export function saveMemory(memory) {
  try {
    localStorage.setItem(key(memory.userId, memory.tenantId), JSON.stringify(memory));
  } catch {}
}

// ── Profile Builder ────────────────────────────────────────────────────────────
/**
 * updateMemory — call after each day's session ends or on login.
 * Ingests today's score/status + action timestamps, returns updated memory.
 */
export function updateMemory(memory, { score, status, tasksCompleted, actionTimestamps = [], streak = 0 }) {
  const today = new Date().toISOString().split('T')[0];
  const updated = { ...memory };

  // --- performance history (keep last 30 days) ---
  const existing = updated.performanceHistory.filter(h => h.date !== today);
  updated.performanceHistory = [
    ...existing,
    { date: today, score, status, tasksCompleted },
  ].slice(-30);

  // --- last actions (keep 20) ---
  updated.lastActions = [...(updated.lastActions ?? []), ...actionTimestamps].slice(-20);

  // --- streak record ---
  if (streak > (updated.streakRecord ?? 0)) updated.streakRecord = streak;

  // --- session count ---
  updated.totalSessions = (updated.totalSessions ?? 0) + 1;
  updated.lastSeenAt = new Date().toISOString();

  // --- derive behavioral profile ---
  updated.behaviorProfile = buildBehaviorProfile(updated);

  return updated;
}

function buildBehaviorProfile(memory) {
  const history = memory.performanceHistory ?? [];
  const profile = { ...(memory.behaviorProfile ?? DEFAULT_PROFILE.behaviorProfile) };

  if (history.length < 3) return profile; // need ≥3 data points

  // Consistency
  const scores   = history.map(h => h.score);
  const greenDays = history.filter(h => h.status === 'GREEN').length;
  const ratio     = greenDays / history.length;
  profile.consistency = ratio >= 0.7 ? 'high' : ratio >= 0.4 ? 'medium' : 'low';

  // Drop pattern — look at day-of-week distribution of red/yellow days
  const badDays = history.filter(h => h.status === 'RED' || h.status === 'YELLOW');
  if (badDays.length >= 2) {
    const dowCounts = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
    badDays.forEach(h => { const d = new Date(h.date).getDay(); dowCounts[d]++; });
    const maxDow = Object.entries(dowCounts).sort((a, b) => b[1] - a[1])[0];
    const dow = parseInt(maxDow[0]);
    if (dow === 1) profile.dropPattern = 'monday';
    else if (dow === 5 || dow === 4) profile.dropPattern = 'end-of-week';
    else if (dow === 0 || dow === 6) profile.dropPattern = 'weekend';
    else profile.dropPattern = 'midweek';
  }

  // Pace type — compare first-half vs second-half of week score
  if (history.length >= 7) {
    const recent = history.slice(-7);
    const firstHalf  = recent.slice(0, 3).reduce((s, h) => s + h.score, 0) / 3;
    const secondHalf = recent.slice(4).reduce((s, h) => s + h.score, 0) / 3;
    if (firstHalf < secondHalf * 0.75)      profile.paceType = 'slow-starter';
    else if (firstHalf > secondHalf * 1.25) profile.paceType = 'fast-starter';
    else profile.paceType = 'steady';
  }

  // Response to pressure — did scores improve after a RED day?
  let pressurePositive = 0, pressureNegative = 0;
  for (let i = 1; i < history.length; i++) {
    if (history[i - 1].status === 'RED') {
      if (history[i].score > history[i - 1].score) pressurePositive++;
      else pressureNegative++;
    }
  }
  if (pressurePositive + pressureNegative >= 2) {
    profile.responseToPressure =
      pressurePositive > pressureNegative ? 'positive' : 'negative';
  }

  return profile;
}

// ── Adaptive coaching context ─────────────────────────────────────────────────
/**
 * getMemoryInsight — returns a rich context object for the AI coach
 * to generate hyper-personalized messages.
 */
export function getMemoryInsight(memory) {
  const { behaviorProfile, performanceHistory, streakRecord, totalSessions, coachingStyle } = memory;
  const history = performanceHistory ?? [];
  const recent  = history.slice(-7);

  const avgScore  = recent.length ? Math.round(recent.reduce((s, h) => s + h.score, 0) / recent.length) : 0;
  const trend     = recent.length >= 3
    ? (recent.slice(-3).reduce((s, h) => s + h.score, 0) / 3) -
      (recent.slice(0, 3).reduce((s, h) => s + h.score, 0) / Math.max(3, recent.slice(0, 3).length))
    : 0;

  const isNewUser      = totalSessions <= 3;
  const isVeteran      = totalSessions >= 14;
  const hasLongHistory = history.length >= 14;

  return {
    behaviorProfile,
    avgScore,
    trend: trend > 3 ? 'improving' : trend < -3 ? 'declining' : 'stable',
    streakRecord: streakRecord ?? 0,
    totalSessions: totalSessions ?? 0,
    isNewUser,
    isVeteran,
    hasLongHistory,
    effectiveCoachStyle: coachingStyle ?? behaviorProfile?.responseToPressure === 'negative' ? 'motivation' : 'discipline',
    summary: buildMemorySummary(memory),
  };
}

function buildMemorySummary(memory) {
  const p = memory.behaviorProfile ?? {};
  const parts = [];

  if (p.consistency === 'high')   parts.push('consistently high performer');
  if (p.consistency === 'low')    parts.push('struggling with consistency');
  if (p.paceType === 'slow-starter') parts.push('tends to start slowly in the week');
  if (p.paceType === 'fast-starter') parts.push('starts strong but fades');
  if (p.dropPattern && p.dropPattern !== 'unknown') parts.push(`drops on ${p.dropPattern}`);
  if (p.responseToPressure === 'positive') parts.push('responds well to direct accountability');
  if (p.responseToPressure === 'negative') parts.push('benefits from encouragement over pressure');
  if ((memory.streakRecord ?? 0) >= 7) parts.push(`personal best streak: ${memory.streakRecord} days`);

  return parts.length ? parts.join('; ') : 'building behavioral data';
}

// ── Execution Card Generator ──────────────────────────────────────────────────
/**
 * generateExecutionCard — produces the viral shareable card data
 */
export function generateExecutionCard(userId, userName, tenantName, score, status, streak, rank, totalUsers) {
  const emoji  = status === 'GREEN' ? '🟢' : status === 'YELLOW' ? '🟡' : '🔴';
  const flame  = streak >= 5 ? '🔥' : streak >= 3 ? '✨' : '';
  const rankTx = rank <= 3 ? `#${rank} on the leaderboard` : `ranked #${rank} of ${totalUsers}`;

  return {
    userId,
    userName,
    tenantName,
    score,
    status,
    streak,
    rank,
    totalUsers,
    emoji,
    generatedAt: new Date().toISOString(),
    shareText: `${emoji} ${flame} My Behavior Engine score today: ${score} pts\n📈 Status: ${status} · Streak: ${streak} days · ${rankTx}\n\nTrack your team's daily execution → behaviorengine.io`,
    whatsAppText: encodeURIComponent(
      `${emoji} ${flame} My execution score today: *${score} pts* (${status})\n📈 Streak: ${streak} days | ${rankTx} @ ${tenantName}\n\n👉 Track your team: behaviorengine.io`
    ),
    linkedInText: encodeURIComponent(
      `Tracking daily execution with Behavior Engine.\n\n${emoji} Score: ${score} | Status: ${status} | Streak: ${streak} days\n\nTeams that measure behavior change it. #execution #performance #habits`
    ),
  };
}
