// ─── Behavior Engine Core Logic ───────────────────────────────────────────────

export const STATUS = {
  GREEN: 'GREEN',
  YELLOW: 'YELLOW',
  RED: 'RED',
};

export function getStatus(score) {
  if (score >= 40) return STATUS.GREEN;
  if (score >= 25) return STATUS.YELLOW;
  return STATUS.RED;
}

export function needsRecovery(recentScores) {
  return recentScores.filter((s) => s < 25).length >= 2;
}

export function getStatusConfig(status) {
  const configs = {
    GREEN: {
      label: 'On Track',
      color: 'text-green-400',
      bg: 'bg-green-400/10',
      border: 'border-green-400/30',
      glow: 'glow-green',
      bar: 'bg-green-400',
      hex: '#22c55e',
    },
    YELLOW: {
      label: 'At Risk',
      color: 'text-yellow-400',
      bg: 'bg-yellow-400/10',
      border: 'border-yellow-400/30',
      glow: 'glow-yellow',
      bar: 'bg-yellow-400',
      hex: '#eab308',
    },
    RED: {
      label: 'Critical',
      color: 'text-red-400',
      bg: 'bg-red-400/10',
      border: 'border-red-400/30',
      glow: 'glow-red',
      bar: 'bg-red-400',
      hex: '#ef4444',
    },
  };
  return configs[status] ?? configs.RED;
}

export function calcProgress(score, dailyTarget = 40) {
  return Math.min(100, Math.round((score / dailyTarget) * 100));
}

export function getRecoveryMessage(status, name) {
  if (status === STATUS.GREEN)
    return `${name} is operating at peak performance. Keep the momentum.`;
  if (status === STATUS.YELLOW)
    return `${name} needs a push. ${40 - (name.length % 5)} points to reach target.`;
  return `Recovery protocol active. ${name} must log actions to break out of RED.`;
}
