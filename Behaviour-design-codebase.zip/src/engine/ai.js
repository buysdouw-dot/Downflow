// ─── AI Feedback Engine ────────────────────────────────────────────────────
// Pluggable: swap generateFeedback() for a real LLM call (OpenAI, Claude, etc.)

const FEEDBACK_LIBRARY = {
  high: [
    { msg: 'Elite execution. You\'re in the top tier today.', tag: 'Elite' },
    { msg: 'Exceptional output. This is what peak performance looks like.', tag: 'Peak' },
    { msg: 'Maximum effort delivered. Maintain this standard.', tag: 'Max Output' },
    { msg: 'You\'re setting the pace. Others are watching you.', tag: 'Pace-Setter' },
  ],
  good: [
    { msg: 'Solid execution. One more push and you hit target.', tag: 'On Track' },
    { msg: 'Good momentum. Focus on high-value actions to close the gap.', tag: 'Momentum' },
    { msg: 'You\'re building consistency. Don\'t break the chain.', tag: 'Building' },
    { msg: 'Progress logged. Prioritize your 5+ point tasks now.', tag: 'Prioritize' },
  ],
  low: [
    { msg: 'Activity below threshold. Increase output now.', tag: 'Increase Output' },
    { msg: 'You\'re behind. Two high-value actions will get you back on track.', tag: 'Recovery' },
    { msg: 'Warning: RED zone. Immediate action required.', tag: 'Critical' },
    { msg: 'System detects low engagement. Log 3 actions to recover.', tag: 'Engage' },
  ],
  task: {
    Outreach:    'Outreach drives pipeline. Volume matters here.',
    Conversion:  'Conversion actions multiply your impact.',
    Admin:       'Admin keeps the system running — don\'t skip it.',
    Cardio:      'Cardio builds your base. Consistency is the game.',
    Strength:    'Strength sessions compound over time.',
    Recovery:    'Recovery is productive. Your future self thanks you.',
    Nutrition:   'Fuel properly — performance starts before training.',
    Study:       'Deep study sessions are your highest-leverage hours.',
    Attendance:  'Show up. Attendance is the first commitment.',
    Deliverables:'Deliverables prove progress. Submit and move.',
    Collaboration:'Collaboration amplifies your results.',
  },
};

export function generateFeedback(score, lastTask, dailyTarget = 40) {
  let base;
  if (score >= dailyTarget) {
    base = FEEDBACK_LIBRARY.high[Math.floor(Math.random() * FEEDBACK_LIBRARY.high.length)];
  } else if (score >= dailyTarget * 0.6) {
    base = FEEDBACK_LIBRARY.good[Math.floor(Math.random() * FEEDBACK_LIBRARY.good.length)];
  } else {
    base = FEEDBACK_LIBRARY.low[Math.floor(Math.random() * FEEDBACK_LIBRARY.low.length)];
  }

  const taskInsight = lastTask?.category
    ? FEEDBACK_LIBRARY.task[lastTask.category] ?? 'Keep logging consistent actions.'
    : null;

  const pctToTarget = Math.round((score / dailyTarget) * 100);
  const remaining = Math.max(0, dailyTarget - score);

  return {
    message: base.msg,
    tag: base.tag,
    taskInsight,
    pctToTarget,
    remaining,
    timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
  };
}

export function getMotivationalQuote(status) {
  const quotes = {
    GREEN: [
      '"Excellence is not a destination; it\'s a continuous journey." — Brian Tracy',
      '"You don\'t rise to the level of your goals, you fall to the level of your systems." — James Clear',
      '"Success is the product of daily habits." — James Clear',
    ],
    YELLOW: [
      '"You are always one decision away from a totally different life."',
      '"The secret of getting ahead is getting started." — Mark Twain',
      '"Push yourself because no one else is going to do it for you."',
    ],
    RED: [
      '"The comeback is always stronger than the setback."',
      '"It\'s not about how hard you hit. It\'s about how hard you can get hit and keep moving." — Rocky',
      '"Every champion was once a contender that refused to give up." — Rocky Balboa',
    ],
  };
  const arr = quotes[status] ?? quotes.YELLOW;
  return arr[Math.floor(Math.random() * arr.length)];
}
