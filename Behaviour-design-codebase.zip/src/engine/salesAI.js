// ─── Sales Execution Engine — AI Feedback ─────────────────────────────────────
// Per-action-type feedback logic as specified in the Sales Plugin blueprint.

export function salesFeedback(actionType, countToday, totalScore, dailyTarget = 40) {
  // Per-action-type logic (from spec)
  if (actionType === 'outreach') {
    if (countToday < 5)
      return { msg: 'Increase volume. You\'re under target. Send more messages.', tag: 'Volume Alert', urgency: 'red' };
    if (countToday < 10)
      return { msg: 'Good start on outreach. Keep pushing — volume is your pipeline.', tag: 'Build Pipeline', urgency: 'yellow' };
    if (countToday < 20)
      return { msg: `${countToday} outreach done. ${20 - countToday} more to hit the 20-message target.`, tag: 'On Target', urgency: 'yellow' };
    return { msg: 'Outreach target crushed. Now convert those responses into conversations.', tag: 'Outreach Done', urgency: 'green' };
  }

  if (actionType === 'conversation') {
    if (countToday < 2)
      return { msg: 'Focus on starting real conversations. Messages alone don\'t close deals.', tag: 'Start Talking', urgency: 'red' };
    if (countToday < 5)
      return { msg: `${countToday} conversations started. Target is 5 — keep asking questions.`, tag: 'Good Progress', urgency: 'yellow' };
    return { msg: 'Conversation target hit. You\'re creating real buying opportunities.', tag: 'Conversations Done', urgency: 'green' };
  }

  if (actionType === 'follow_up') {
    if (countToday < 1)
      return { msg: '80% of sales happen after the 5th follow-up. Start following up.', tag: 'Follow Up Now', urgency: 'red' };
    return { msg: 'Good. Don\'t let leads go cold — stay on their radar.', tag: 'Consistent', urgency: 'green' };
  }

  if (actionType === 'closing') {
    return { msg: 'Push confidently. Don\'t wait for perfect timing. Ask for the close.', tag: 'Close It', urgency: 'green' };
  }

  // Generic score-based feedback
  if (totalScore >= dailyTarget)
    return { msg: 'Daily target achieved. Maintain this standard every day.', tag: 'Elite', urgency: 'green' };
  if (totalScore >= dailyTarget * 0.6)
    return { msg: 'Good momentum. Prioritize closing and conversation actions.', tag: 'On Track', urgency: 'yellow' };
  return { msg: 'Activity below threshold. One action at a time — just start.', tag: 'Increase Output', urgency: 'red' };
}

export function getRecoveryTask(todayCounts, salesRules) {
  // Return the most urgent recovery task based on what's missing
  if ((todayCounts.outreach ?? 0) < 3) {
    return {
      actionType: 'outreach',
      label: 'Send 1 outreach message',
      urgencyMsg: 'Outreach is your pipeline. Send one message using the script below.',
    };
  }
  if ((todayCounts.conversation ?? 0) < 1) {
    return {
      actionType: 'conversation',
      label: 'Start 1 conversation',
      urgencyMsg: 'You have zero conversations today. One question can change everything.',
    };
  }
  if ((todayCounts.follow_up ?? 0) < 1) {
    return {
      actionType: 'follow_up',
      label: 'Follow up with 1 lead',
      urgencyMsg: 'One follow-up message. Copy the script and send it now.',
    };
  }
  if ((todayCounts.closing ?? 0) < 1) {
    return {
      actionType: 'closing',
      label: 'Attempt 1 close',
      urgencyMsg: 'You haven\'t attempted a close today. Ask for it.',
    };
  }
  return null;
}

export function getDailyStatus(todayCounts, salesRules) {
  const checks = [
    { key: 'outreach',     min: salesRules.minOutreach,      label: 'Outreach',      count: todayCounts.outreach ?? 0 },
    { key: 'conversation', min: salesRules.minConversations,  label: 'Conversations', count: todayCounts.conversation ?? 0 },
    { key: 'follow_up',    min: salesRules.minFollowUps,      label: 'Follow-Ups',    count: todayCounts.follow_up ?? 0 },
    { key: 'closing',      min: salesRules.minClosing,        label: 'Closes',        count: todayCounts.closing ?? 0 },
  ];
  return checks.map((c) => ({
    ...c,
    pct: Math.min(100, Math.round((c.count / c.min) * 100)),
    met: c.count >= c.min,
  }));
}
