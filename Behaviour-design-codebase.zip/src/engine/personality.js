// ─── AI Coach Personality System ─────────────────────────────────────────────
// Your moat: adaptive personality coaching with behavioral memory per user.
// Three coach archetypes × 8 drop patterns × score tiers = unique responses.
// ─────────────────────────────────────────────────────────────────────────────

// ── Personality definitions ───────────────────────────────────────────────────
export const COACH_PERSONALITIES = {
  discipline: {
    id: 'discipline',
    name: 'The Disciplinarian',
    emoji: '🔥',
    tagline: 'No excuses. Execute or fall behind.',
    description: 'Direct, strict, zero-tolerance for drift. Pushes hard. Best for high-performers who need accountability, not comfort.',
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/20',
    glow: 'shadow-red-500/20',
    accent: '#ef4444',
    tone: 'strict',
  },
  strategy: {
    id: 'strategy',
    name: 'The Strategist',
    emoji: '🧠',
    tagline: 'Analyze. Adjust. Execute precisely.',
    description: 'Analytical, structured, data-driven. Identifies patterns and prescribes tactical changes. Best for thinkers who respond to logic.',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    glow: 'shadow-indigo-500/20',
    accent: '#6366f1',
    tone: 'analytical',
  },
  motivation: {
    id: 'motivation',
    name: 'The Motivator',
    emoji: '⚡',
    tagline: 'Every action builds the life you want.',
    description: 'Warm, energizing, momentum-focused. Celebrates progress. Builds confidence. Best for users who need emotional fuel and positive reinforcement.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    glow: 'shadow-emerald-500/20',
    accent: '#10b981',
    tone: 'motivational',
  },
};

// ── Personality memory model (stored per-user preference) ────────────────────
export const DEFAULT_PERSONALITY = 'discipline';

export function getPersonality(personalityId) {
  return COACH_PERSONALITIES[personalityId] ?? COACH_PERSONALITIES[DEFAULT_PERSONALITY];
}

// ── Personality-driven message library ────────────────────────────────────────
const PERSONALITY_MESSAGES = {
  discipline: {
    // By drop pattern
    patterns: {
      chronic_underperformance: {
        insight: 'Chronic underperformance is a choice. Own it and fix it today.',
        action: 'Do 3 actions right now. Not later. Right now.',
        warning: 'You are building a failure habit. Stop it today or it compounds.',
      },
      inconsistent_high_risk: {
        insight: 'Inconsistency is unreliability. Spikes don\'t build careers — systems do.',
        action: 'Pick 2 tasks. Commit. Do them before anything else.',
        warning: 'Your pattern is showing. Others are watching the leaderboard.',
      },
      slow_starter: {
        insight: 'Every morning you waste is a morning the competition uses.',
        action: 'Do 1 outreach before you open any other app. No exceptions.',
        warning: null,
      },
      week_fade: {
        insight: 'Fading at the end of the week is weakness. Winners finish strong.',
        action: 'Treat Friday like Monday. Log your full minimum before you stop.',
        warning: 'This pattern is costing you 30% of weekly output.',
      },
      midweek_slump: {
        insight: 'Wednesday is where winners separate from average. Which are you?',
        action: 'Block 9–10AM Wed for your most critical task. No meetings. No excuses.',
        warning: null,
      },
      elite_consistent: {
        insight: 'Good. Now push harder. Consistency is the floor, not the ceiling.',
        action: 'Today, beat your personal best. Set a new standard.',
        warning: null,
      },
      building_momentum: {
        insight: 'Progress noted. Don\'t get comfortable — comfort kills momentum.',
        action: 'Stack another green day. The only acceptable outcome is consistency.',
        warning: null,
      },
      erratic: {
        insight: 'Erratic output means no system. Systems beat willpower every time.',
        action: 'Define your 3 non-negotiables. Do them. Every day. No exceptions.',
        warning: 'Random effort produces random results. Build the system.',
      },
      insufficient_data: {
        insight: 'Inaction is a decision. You\'re deciding to fail right now.',
        action: 'Log your first action this minute. The clock is running.',
        warning: null,
      },
    },
    scoreContext: {
      high: [
        { insight: 'Target hit. Keep going. Excellence isn\'t a goal, it\'s a standard.', action: 'Push past target. Every extra rep counts.', warning: null },
        { insight: 'Green. Don\'t stop. Compound advantage daily.', action: 'One more push before you close today.', warning: null },
      ],
      medium: [
        { insight: 'Halfway there. No excuses for not finishing.', action: 'Drop everything. Hit your minimum. Now.', warning: null },
        { insight: 'You\'re tracking. Don\'t drift. Finish strong.', action: 'Two high-value actions close the gap. Execute.', warning: null },
      ],
      low: [
        { insight: 'You are below threshold. This is unacceptable. Move.', action: 'Log 3 actions in the next 10 minutes. No negotiation.', warning: 'Two more RED days and you drop off the team\'s top 3.' },
        { insight: 'Below minimum. Others are pulling ahead while you hesitate.', action: '15 minutes. Maximum output. Go.', warning: 'Inaction today becomes habit tomorrow.' },
      ],
    },
    streakBonus: {
      0: 'No streak. You broke it. Start again — right now.',
      1: 'Day 1. Prove it\'s not a fluke.',
      3: '3 days. Now make it 7. Don\'t get soft.',
      5: '5-day streak. Don\'t waste it. Keep going.',
      7: 'Week streak. Rare. Protect it with your output today.',
    },
  },

  strategy: {
    patterns: {
      chronic_underperformance: {
        insight: 'Data shows a persistent execution gap. The issue is structural, not motivational.',
        action: 'Audit your task list. Remove low-value activities. Focus only on 5+ point tasks.',
        warning: 'This pattern over 7+ days statistically predicts continued underperformance.',
      },
      inconsistent_high_risk: {
        insight: 'High variance output indicates no system. Your best days aren\'t replicable yet.',
        action: 'Document what you did on your best day. Replicate that structure daily.',
        warning: 'Variance is the enemy of compounding. You need consistent volume, not peak spikes.',
      },
      slow_starter: {
        insight: 'Analysis shows your lowest output window is 8–10AM. That\'s where the fix is.',
        action: 'Front-load 1 high-value action before any meeting or communication.',
        warning: null,
      },
      week_fade: {
        insight: 'Your Thurs/Fri data shows significant output decline. Energy management issue.',
        action: 'Redistribute volume earlier in the week. Front-load Mon–Wed intensity.',
        warning: 'Losing the end of week costs approximately 28% of weekly point potential.',
      },
      midweek_slump: {
        insight: 'Wednesday is statistically your lowest day. Classic motivational valley.',
        action: 'Pre-schedule your highest ROI task for Wednesday morning. Don\'t decide in the moment.',
        warning: null,
      },
      elite_consistent: {
        insight: '5+ green days. You\'re in execution mode. Now optimize for quality over quantity.',
        action: 'Audit which task type produces the most downstream value. Double down on that.',
        warning: null,
      },
      building_momentum: {
        insight: '3-day positive trend. Momentum is building. Now systematize it.',
        action: 'Define your minimum viable daily output. Never fall below it.',
        warning: null,
      },
      erratic: {
        insight: 'High output variance without a clear pattern. No system detected.',
        action: 'Time-block your 3 core tasks for 9AM daily. Remove all decision-making from execution.',
        warning: 'Unpredictable output is a performance liability in team environments.',
      },
      insufficient_data: {
        insight: 'Insufficient data to generate pattern analysis. Need 3+ active days.',
        action: 'Log all actions today to establish a baseline for AI analysis.',
        warning: null,
      },
    },
    scoreContext: {
      high: [
        { insight: 'Peak performance range. Efficiency is high. Optimize task sequencing next.', action: 'Review which task category generated the most points. Prioritize it tomorrow.', warning: null },
        { insight: 'Green zone maintained. Analyze your top 3 tasks and replicate the pattern.', action: 'Log your strategy for today as a template.', warning: null },
      ],
      medium: [
        { insight: 'Above 55% of target. The gap is closable in one focused session.', action: 'Calculate remaining points needed. Do the highest-value task that covers it fastest.', warning: null },
        { insight: 'Mid-range score. High-value tasks now have maximum ROI on your time.', action: 'One 6-point action gets you closer than six 1-point actions. Choose accordingly.', warning: null },
      ],
      low: [
        { insight: 'Below 40% of target. Recovery requires immediate high-volume action.', action: 'Switch to rapid-fire mode. Minimum 1-point tasks every 5 minutes for 30 mins.', warning: 'RED status 2+ days triggers a 7-day pattern that\'s hard to reverse statistically.' },
        { insight: 'Execution rate critically low. Pattern analysis shows intervention needed.', action: 'Focus on your single highest-point task. Ignore everything else until it\'s done.', warning: null },
      ],
    },
    streakBonus: {
      0: 'Streak broken. Analyze what disrupted it. Fix the root cause.',
      1: 'Day 1 reset. Consistent execution for 3 days will re-establish the baseline.',
      3: '3-day streak. Statistical inflection point. Consistency compounds from here.',
      5: '5 consecutive days. Pattern is becoming systematic. Don\'t vary the formula.',
      7: '7-day streak. Peak execution pattern confirmed. Protect the system.',
    },
  },

  motivation: {
    patterns: {
      chronic_underperformance: {
        insight: 'Every champion has their hardest stretch. This is yours. The comeback starts now.',
        action: 'One small action. That\'s all. Just one. The momentum builds from there.',
        warning: 'You\'ve got more in you than this data shows. Prove it today.',
      },
      inconsistent_high_risk: {
        insight: 'You\'ve shown what you\'re capable of on your good days. Make today one of those.',
        action: 'Remember your best day? Set that as your intention today. You can do it again.',
        warning: null,
      },
      slow_starter: {
        insight: 'Your energy builds through the day — great! Use that. But start something small first.',
        action: 'One tiny action before 10AM ignites the rest of the day. Try it and see.',
        warning: null,
      },
      week_fade: {
        insight: 'You give so much early in the week. Save just a little of that fire for Friday.',
        action: 'Finish this week strong. Friday you are your future self will thank you.',
        warning: null,
      },
      midweek_slump: {
        insight: 'Wednesday slump is real for everyone. You\'re not alone — and you can beat it.',
        action: 'Put on your best playlist and do just 2 actions. The energy will follow.',
        warning: null,
      },
      elite_consistent: {
        insight: 'You are inspiring. Seriously — your consistency is what elite looks like.',
        action: 'You\'re in your zone. Keep going. The streak is yours to build.',
        warning: null,
      },
      building_momentum: {
        insight: 'Look at that trend! You\'re building something real here. Keep the chain going.',
        action: 'Don\'t break the streak. One more green day and it becomes habit.',
        warning: null,
      },
      erratic: {
        insight: 'Some days are wild — that\'s life. The key is getting back up every single time.',
        action: 'Reset. Take a breath. Three actions today and you\'re back on track.',
        warning: null,
      },
      insufficient_data: {
        insight: 'Every journey starts with a first step. You\'re at the beginning of something great.',
        action: 'Log your very first action today. That\'s all you need to do right now.',
        warning: null,
      },
    },
    scoreContext: {
      high: [
        { insight: 'You\'re absolutely crushing it today. This is what peak performance feels like!', action: 'Keep this energy — you\'re setting a standard your future self will be proud of.', warning: null },
        { insight: 'Target hit! That\'s not just points — that\'s proof of who you are.', action: 'Every action above target is a gift to tomorrow\'s performance.', warning: null },
      ],
      medium: [
        { insight: 'More than halfway there! You\'ve got this — the finish line is close.', action: 'Two strong actions and you\'re in the green. You\'ve done harder things than this.', warning: null },
        { insight: 'Solid progress! Keep that energy and push it over the line.', action: 'Pick your favorite task from the list and knock it out right now.', warning: null },
      ],
      low: [
        { insight: 'Today hasn\'t started yet — it can still be incredible. The score can change.', action: 'Start with just 1 action. Then another. You\'d be amazed how fast it builds.', warning: null },
        { insight: 'Low score doesn\'t mean bad day — it means opportunity. Let\'s close that gap.', action: '10 minutes of focused action can completely change where this day ends up.', warning: null },
      ],
    },
    streakBonus: {
      0: 'New streak starts today. And this one\'s going to be your best one yet.',
      1: 'Day 1! The most important step is always the first. You\'re on your way.',
      3: '3-day streak! You\'re building something real. Feel that momentum.',
      5: '5 days straight! You\'re not just performing — you\'re becoming consistent.',
      7: 'A full week! You have proven to yourself what you\'re capable of. Now week 2.',
    },
  },
};

// ── Personality-aware coach function ─────────────────────────────────────────
export function coachWithPersonality(userContext, personalityId = DEFAULT_PERSONALITY) {
  const {
    role = 'user',
    score = 0,
    dailyTarget = 40,
    weekScores = [],
    lastTask = null,
    streak = 0,
    dropPattern = 'insufficient_data',
  } = userContext;

  const personality = getPersonality(personalityId);
  const messages = PERSONALITY_MESSAGES[personalityId] ?? PERSONALITY_MESSAGES[DEFAULT_PERSONALITY];

  const pct = score / dailyTarget;
  const tier = pct >= 1 ? 'high' : pct >= 0.55 ? 'medium' : 'low';

  // Primary coaching from drop pattern
  const patternMsg = messages.patterns[dropPattern] ?? messages.patterns.insufficient_data;

  // Score context
  const scoreArr = messages.scoreContext[tier];
  const scoreMsg = scoreArr[Math.floor(Math.random() * scoreArr.length)];

  // Choose: use pattern if it has warning (critical), else score context
  const hasCritical = tier === 'low' && dropPattern !== 'elite_consistent';
  const primary = hasCritical ? patternMsg : scoreMsg;

  // Streak message (find closest threshold)
  const streakThresholds = [0, 1, 3, 5, 7];
  const streakKey = streakThresholds.filter(t => streak >= t).pop() ?? 0;
  const streakMsg = messages.streakBonus[streakKey]
    ?? `${streak}-day streak. Keep the system running.`;

  // Task insight (personality-flavored)
  const TASK_INSIGHTS = {
    discipline: {
      Outreach: 'Outreach volume is the only metric that matters. Double it.',
      Conversation: 'Every conversation is a close attempt. Treat it that way.',
      'Follow-Up': 'No follow-up = dead deal. Log it and move.',
      Closing: 'Close or learn why not. Both are valuable. Neither is optional.',
      Cardio: 'Physical output demands physical investment. No excuses.',
      Strength: 'Strength is earned through consistency. Miss sessions, miss gains.',
      Recovery: 'Recovery is mandatory maintenance, not optional.',
      Nutrition: 'Fuel is performance input. Control it.',
      Study: 'Knowing and not applying is the same as not knowing. Study to execute.',
      Attendance: 'Presence is non-negotiable. Be there.',
      Deliverables: 'Submit on time or explain why. No silent failures.',
      Collaboration: 'Your team needs you sharp and present.',
      Admin: 'Admin is how systems stay clean. Don\'t let it pile up.',
    },
    strategy: {
      Outreach: 'Outreach is a numbers game with quality filters. Optimize message + volume.',
      Conversation: 'Track conversion: outreach → conversation. That ratio is your leverage point.',
      'Follow-Up': 'Follow-ups have a 5× higher close rate than first contact. Max them.',
      Closing: 'Study your close language. Small wording changes produce large conversion shifts.',
      Cardio: 'Aerobic base determines sustainable daily energy. Prioritize this.',
      Strength: 'Progressive overload is the system. Trust the accumulation.',
      Recovery: 'Recovery quality directly determines next-day performance output.',
      Nutrition: 'Fuel timing around execution windows maximizes cognitive performance.',
      Study: 'Spaced repetition yields 2× retention. Apply it systematically.',
      Attendance: 'Each session = input data. Miss one and the system is incomplete.',
      Deliverables: 'On-time delivery signals reliability. Reliability builds compounding trust.',
      Collaboration: 'Collaborative tasks generate institutional knowledge. Invest accordingly.',
      Admin: 'Clean admin = clean systems = faster decision-making.',
    },
    motivation: {
      Outreach: 'Every message you send could change someone\'s day — and yours.',
      Conversation: 'Real conversations build real relationships. You\'re not selling, you\'re connecting.',
      'Follow-Up': 'Following up shows you care. People buy from people who care.',
      Closing: 'A close is just asking for what both parties want. You\'ve earned this ask.',
      Cardio: 'This session is an investment in the version of you that shows up tomorrow.',
      Strength: 'Every rep is proof of who you\'re becoming. Feel that.',
      Recovery: 'Taking care of yourself IS performance. You deserve this.',
      Nutrition: 'Good fuel = good energy = good days. You\'re worth it.',
      Study: 'Every page is a step toward the version of you who knows more.',
      Attendance: 'Showing up is the hardest part. You\'re already winning.',
      Deliverables: 'You finishing this shows you keep your word. That\'s character.',
      Collaboration: 'What you give to others comes back multiplied.',
      Admin: 'Taking care of the details shows you care about your craft.',
    },
  };

  const taskInsight = lastTask?.category
    ? (TASK_INSIGHTS[personalityId]?.[lastTask.category] ?? null)
    : null;

  return {
    // Coaching content
    insight: primary.insight,
    action: primary.action,
    warning: primary.warning,
    streakMessage: streakMsg,
    taskInsight,

    // Personality metadata
    personalityId,
    personalityName: personality.name,
    personalityEmoji: personality.emoji,
    personalityColor: personality.color,

    // Context data
    dropPattern,
    tier,
    pctToTarget: Math.round((score / dailyTarget) * 100),
    remaining: Math.max(0, dailyTarget - score),
    streak,
    tag: {
      discipline: { high: 'Elite', medium: 'On Track', low: 'Unacceptable' }[tier],
      strategy:   { high: 'Optimal', medium: 'Tracking', low: 'Critical Gap' }[tier],
      motivation: { high: 'Crushing It!', medium: 'Building!', low: 'Start Now' }[tier],
    }[personalityId] ?? 'Go',
    timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
  };
}

// ── Personality auto-detection (smart default based on user data) ─────────────
export function suggestPersonality(weekScores, role) {
  if (!weekScores || weekScores.length < 3) return 'motivation';
  const greenDays = weekScores.filter(s => s >= 40).length;
  const redDays   = weekScores.filter(s => s < 25).length;
  if (greenDays >= 5) return 'strategy';        // high performer → optimize
  if (redDays >= 3)   return 'discipline';      // struggling → tough love
  if (role === 'admin' || role === 'manager') return 'strategy';
  return 'motivation';
}
