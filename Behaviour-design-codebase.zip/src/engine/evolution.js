/**
 * AI Evolution Engine — Self-Improving Behavior System
 * Observe → Analyze → Adapt → Re-test → Improve
 *
 * Builds per-user behavioral intelligence that evolves with every session.
 */

// ── Evolution State Schema ────────────────────────────────────────────────────
const DEFAULT_STATE = {
  version: 1,
  userId: null,
  tenantId: null,

  // Observed metrics (raw data)
  observations: {
    totalSessions:          0,
    totalActionsLogged:     0,
    missedDays:             0,
    consecutiveActive:      0,
    avgResponseTime:        null, // minutes from day start to first log
    taskCompletionRates:    {},   // { taskId: { attempts, completions } }
    feedbackReactions:      {},   // { messageHash: 'positive' | 'negative' | 'ignored' }
    hourlyActivity:         {},   // { '09': 5, '14': 12, ... } count of actions by hour
  },

  // Derived profile (updated after each session)
  profile: {
    consistencyScore:     0,    // 0–100
    dropPattern:          null, // 'morning' | 'evening' | 'monday' | 'end-of-week' | 'random'
    bestPerformingTime:   null, // 'morning' | 'afternoon' | 'evening'
    weakestBehaviorArea:  null, // task category with lowest completion rate
    responseToFeedback:   null, // 'responsive' | 'resistant' | 'neutral'
    paceProfile:          null, // 'fast-starter' | 'slow-starter' | 'steady'
    taskDifficulty:       'normal', // 'reduce' | 'normal' | 'increase'
  },

  // Evolution decisions (what the AI has adapted)
  adaptations: {
    coachingToneAdjusted: false,
    taskSizeReduced:      false,
    taskSizeIncreased:    false,
    timingRecommended:    null,
    currentDifficulty:    'normal', // 'reduced' | 'normal' | 'elevated'
    lastAdaptedAt:        null,
  },

  // Evolution log (what changed and why)
  evolutionLog: [], // [{ date, type, reason, change }]

  updatedAt: null,
};

// ── Storage ───────────────────────────────────────────────────────────────────
function eKey(userId, tenantId) {
  return `be_evolution_${tenantId}_${userId}`;
}

export function loadEvolution(userId, tenantId) {
  try {
    const raw = localStorage.getItem(eKey(userId, tenantId));
    if (!raw) return { ...DEFAULT_STATE, userId, tenantId };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_STATE, ...parsed, userId, tenantId };
  } catch {
    return { ...DEFAULT_STATE, userId, tenantId };
  }
}

export function saveEvolution(state) {
  try {
    localStorage.setItem(eKey(state.userId, state.tenantId), JSON.stringify({
      ...state,
      updatedAt: new Date().toISOString(),
    }));
  } catch {}
}

// ── STEP 1: Observe ───────────────────────────────────────────────────────────
/**
 * observeSession — call after each completed session.
 * Records raw behavioral data.
 */
export function observeSession(state, {
  actionsLogged,
  missedToday,
  actionTimestamps = [],
  taskResults = [], // [{ taskId, category, completed }]
  feedbackShown = null,
  feedbackReaction = null, // 'positive' | 'negative' | 'ignored'
}) {
  const next = structuredClone ? structuredClone(state) : JSON.parse(JSON.stringify(state));
  const obs  = next.observations;

  obs.totalSessions += 1;
  obs.totalActionsLogged += actionsLogged;
  if (missedToday) obs.missedDays += 1;
  else obs.consecutiveActive += 1;

  // Hourly activity
  actionTimestamps.forEach(ts => {
    const hour = new Date(ts).getHours().toString().padStart(2, '0');
    obs.hourlyActivity[hour] = (obs.hourlyActivity[hour] ?? 0) + 1;
  });

  // Response time (first action of the day)
  if (actionTimestamps.length > 0) {
    const firstAction = new Date(actionTimestamps[0]);
    const dayStart    = new Date(firstAction);
    dayStart.setHours(0, 0, 0, 0);
    const responseMinutes = Math.round((firstAction - dayStart) / 60000);
    obs.avgResponseTime = obs.avgResponseTime == null
      ? responseMinutes
      : Math.round((obs.avgResponseTime * 0.7) + (responseMinutes * 0.3)); // rolling avg
  }

  // Task completion rates
  taskResults.forEach(({ taskId, category, completed }) => {
    const key = category ?? taskId;
    if (!obs.taskCompletionRates[key]) obs.taskCompletionRates[key] = { attempts: 0, completions: 0 };
    obs.taskCompletionRates[key].attempts += 1;
    if (completed) obs.taskCompletionRates[key].completions += 1;
  });

  // Feedback reactions
  if (feedbackShown && feedbackReaction) {
    const hash = feedbackShown.slice(0, 30);
    obs.feedbackReactions[hash] = feedbackReaction;
  }

  return next;
}

// ── STEP 2: Analyze ───────────────────────────────────────────────────────────
/**
 * analyzeProfile — derives the behavioral profile from observations.
 */
export function analyzeProfile(state) {
  const next = structuredClone ? structuredClone(state) : JSON.parse(JSON.stringify(state));
  const obs  = next.observations;
  const prof = next.profile;

  // Consistency score (0–100)
  if (obs.totalSessions > 0) {
    const activeDays = obs.totalSessions - obs.missedDays;
    prof.consistencyScore = Math.round((activeDays / obs.totalSessions) * 100);
  }

  // Best performing time (from hourly activity)
  if (Object.keys(obs.hourlyActivity).length > 0) {
    const hours  = Object.entries(obs.hourlyActivity).sort((a, b) => b[1] - a[1]);
    const topHour = parseInt(hours[0][0]);
    if (topHour < 12)      prof.bestPerformingTime = 'morning';
    else if (topHour < 17) prof.bestPerformingTime = 'afternoon';
    else                   prof.bestPerformingTime = 'evening';
  }

  // Weakest behavior area
  const rates = Object.entries(obs.taskCompletionRates);
  if (rates.length > 0) {
    const sorted = rates
      .filter(([, v]) => v.attempts >= 2)
      .sort((a, b) => (a[1].completions / a[1].attempts) - (b[1].completions / b[1].attempts));
    if (sorted.length > 0) prof.weakestBehaviorArea = sorted[0][0];
  }

  // Drop pattern (response time > 3pm average = evening person who drops)
  if (obs.avgResponseTime != null) {
    if (obs.avgResponseTime > 14 * 60)       prof.dropPattern = 'morning';
    else if (obs.avgResponseTime < 9 * 60)   prof.dropPattern = 'evening'; // starts too early, drops off
    else                                      prof.dropPattern = 'random';
  }

  // Feedback responsiveness
  const reactions = Object.values(obs.feedbackReactions);
  if (reactions.length >= 3) {
    const positive = reactions.filter(r => r === 'positive').length;
    const negative = reactions.filter(r => r === 'negative').length;
    if (positive > negative * 2)    prof.responseToFeedback = 'responsive';
    else if (negative > positive)   prof.responseToFeedback = 'resistant';
    else                            prof.responseToFeedback = 'neutral';
  }

  // Pace profile
  const cs = prof.consistencyScore;
  if (obs.avgResponseTime != null && obs.avgResponseTime < 7 * 60) prof.paceProfile = 'fast-starter';
  else if (cs < 40) prof.paceProfile = 'slow-starter';
  else              prof.paceProfile = 'steady';

  // Task difficulty recommendation
  if (cs >= 80) prof.taskDifficulty = 'increase';
  else if (cs < 30) prof.taskDifficulty = 'reduce';
  else              prof.taskDifficulty = 'normal';

  return next;
}

// ── STEP 3: Adapt ─────────────────────────────────────────────────────────────
/**
 * evolveAI — the core adaptation function.
 * Returns an adaptation object + updated state with evolution log.
 */
export function evolveAI(state) {
  const analyzed = analyzeProfile(state);
  const next     = structuredClone ? structuredClone(analyzed) : JSON.parse(JSON.stringify(analyzed));
  const prof     = next.profile;
  const obs      = next.observations;
  const log      = [];

  const adaptations = { ...next.adaptations, lastAdaptedAt: new Date().toISOString() };

  // Rule 1: Low consistency → reduce task load
  if (prof.consistencyScore < 30 && !adaptations.taskSizeReduced) {
    adaptations.taskSizeReduced  = true;
    adaptations.taskSizeIncreased= false;
    adaptations.currentDifficulty= 'reduced';
    log.push({ date: new Date().toISOString(), type: 'task_size', reason: 'consistency < 30%', change: 'Reduced daily task count to 1–2 actions. Focus on habit formation first.' });
  }

  // Rule 2: High consistency → increase challenge
  if (prof.consistencyScore >= 80 && !adaptations.taskSizeIncreased) {
    adaptations.taskSizeIncreased = true;
    adaptations.taskSizeReduced   = false;
    adaptations.currentDifficulty = 'elevated';
    log.push({ date: new Date().toISOString(), type: 'task_size', reason: 'consistency ≥ 80%', change: 'Increased daily target. High performer — push toward breakthrough output.' });
  }

  // Rule 3: Morning drop pattern → recommend afternoon/evening start
  if (prof.dropPattern === 'morning' && !adaptations.timingRecommended) {
    adaptations.timingRecommended = 'afternoon';
    log.push({ date: new Date().toISOString(), type: 'timing', reason: 'avg first action after 2pm', change: 'Recommended: move first task to afternoon. User performs better later in day.' });
  }

  // Rule 4: Resistant to feedback → switch coaching tone
  if (prof.responseToFeedback === 'resistant' && !adaptations.coachingToneAdjusted) {
    adaptations.coachingToneAdjusted = true;
    log.push({ date: new Date().toISOString(), type: 'coaching_tone', reason: 'negative feedback reactions', change: 'Switched from direct coaching to supportive/motivational tone. Resistance detected.' });
  }

  next.adaptations = adaptations;
  next.evolutionLog = [...(next.evolutionLog ?? []), ...log].slice(-20); // keep last 20

  return { state: next, adaptations, evolutionLog: log };
}

// ── Adaptation Messages ───────────────────────────────────────────────────────
/**
 * getAdaptationMessage — returns a human-readable adaptation message for the UI.
 */
export function getAdaptationMessage(state) {
  const { profile, adaptations, observations } = state;
  const messages = [];

  if (adaptations.currentDifficulty === 'reduced') {
    messages.push({
      type: 'adapt',
      icon: '🎯',
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/10',
      border: 'border-yellow-500/20',
      title: 'Task Load Reduced',
      body: 'Your consistency is building. The AI cut your daily tasks to 1–2 to help you lock in the habit first.',
    });
  }

  if (adaptations.currentDifficulty === 'elevated') {
    messages.push({
      type: 'adapt',
      icon: '⚡',
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/20',
      title: 'Challenge Level Increased',
      body: 'High consistency detected. Your daily target has been raised. You are performing — keep pushing.',
    });
  }

  if (adaptations.timingRecommended === 'afternoon') {
    messages.push({
      type: 'timing',
      icon: '🕐',
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/20',
      title: 'Timing Optimized',
      body: `You perform better in the ${profile.bestPerformingTime ?? 'afternoon'}. The AI now prioritizes your tasks for that window.`,
    });
  }

  if (adaptations.coachingToneAdjusted) {
    messages.push({
      type: 'tone',
      icon: '🤝',
      color: 'text-indigo-400',
      bg: 'bg-indigo-500/10',
      border: 'border-indigo-500/20',
      title: 'Coaching Style Adapted',
      body: 'The AI detected resistance to direct pressure. Your coach has switched to a supportive, motivational approach.',
    });
  }

  if (profile.weakestBehaviorArea) {
    messages.push({
      type: 'weakness',
      icon: '🔍',
      color: 'text-purple-400',
      bg: 'bg-purple-500/10',
      border: 'border-purple-500/20',
      title: `Weakness Identified: ${profile.weakestBehaviorArea}`,
      body: `This is where you drop most often. The AI will give you extra coaching prompts in this area going forward.`,
    });
  }

  return messages;
}

// ── Summary ───────────────────────────────────────────────────────────────────
export function getEvolutionSummary(state) {
  const { profile, observations, adaptations } = state;
  return {
    consistencyScore:    profile.consistencyScore,
    dropPattern:         profile.dropPattern,
    bestTime:            profile.bestPerformingTime,
    weakArea:            profile.weakestBehaviorArea,
    feedbackStyle:       profile.responseToFeedback,
    paceProfile:         profile.paceProfile,
    taskDifficulty:      adaptations.currentDifficulty,
    totalSessions:       observations.totalSessions,
    totalActionsLogged:  observations.totalActionsLogged,
    adaptationsApplied:  Object.values(adaptations).filter(v => v === true).length,
    evolutionLogCount:   state.evolutionLog?.length ?? 0,
  };
}
