/**
 * Multi-Agent AI System — Self-Optimizing Team Intelligence
 * 4 specialized agents + Orchestrator
 *
 * Agent 1: Coach Agent    — feedback, motivation, tone adjustment
 * Agent 2: Analyst Agent  — pattern detection, trend analysis, gap calculation
 * Agent 3: Risk Agent     — drop-off prediction, inactivity detection, alerts
 * Agent 4: Performance Agent — task difficulty optimization, workload balance
 */

// ── Types / Schemas ───────────────────────────────────────────────────────────
/**
 * UserData shape expected by all agents:
 * {
 *   userId, name, score, weekScores, streak, status,
 *   role, consistencyPct, dropPattern, personalityId,
 *   lastActiveAt, tasksCompleted, tasksTotal,
 *   teamRank, teamSize, target,
 * }
 */

// ── AGENT 1: Coach Agent ──────────────────────────────────────────────────────
export function coachAgent(userData) {
  const { score, weekScores = [], streak, status, consistencyPct = 50, dropPattern, personalityId, target = 40 } = userData;
  const pct = Math.round((score / target) * 100);

  // Detect recent trend
  const recent3 = weekScores.slice(-3);
  const trend   = recent3.length >= 2
    ? recent3[recent3.length - 1] - recent3[0]
    : 0;

  // Tone selection based on personality + status
  const tones = {
    discipline: {
      GREEN:  { message: 'Execution confirmed. Maintain this pace or raise the bar.',      action: 'Add 2 extra outreach touches before EOD.',         tone: 'direct'      },
      YELLOW: { message: 'Below standard. You know what\'s expected.',                     action: 'Complete the 3 tasks you skipped this morning.',    tone: 'firm'        },
      RED:    { message: 'Unacceptable. This pattern ends today.',                         action: '1 hour. Maximum focus. No excuses.',                tone: 'confrontational' },
    },
    strategy: {
      GREEN:  { message: `${pct}% of target. On track. Optimize for quality now.`,        action: 'Identify the 1 action with highest conversion today.', tone: 'analytical'  },
      YELLOW: { message: `${pct}% of target — ${target - score} pts to GREEN.`,           action: 'Diagnose: was it volume, timing, or energy?',       tone: 'diagnostic'  },
      RED:    { message: 'Data shows a systemic gap. Pattern needs intervention.',         action: 'Reset baseline: 1 task, log it, rebuild from there.', tone: 'clinical'    },
    },
    motivation: {
      GREEN:  { message: 'You showed up. That\'s what separates you.',                    action: 'Celebrate this — then go 1% further tomorrow.',     tone: 'affirming'   },
      YELLOW: { message: 'You\'re close. More than you think.',                           action: 'One more action. Just one. Do it now.',             tone: 'encouraging' },
      RED:    { message: 'This isn\'t failure — it\'s data. What can you change right now?', action: 'Start with 1 small win. Momentum follows action.', tone: 'compassionate' },
    },
  };

  const personality = tones[personalityId] ?? tones.discipline;
  const response    = personality[status] ?? personality.YELLOW;

  // Streak coaching overlay
  let streakNote = null;
  if (streak >= 7)  streakNote = `🔥 ${streak}-day streak. You're in rare company. Protect it.`;
  if (streak === 0 && status === 'RED') streakNote = 'Streak broken. Today is day 1 of the next run.';
  if (streak === 1) streakNote = 'Streak started. One more day and the habit begins to form.';

  return {
    agentId:    'coach',
    agentName:  'Coach Agent',
    agentEmoji: '🎯',
    status:     'active',
    message:    response.message,
    action:     response.action,
    tone:       response.tone,
    streakNote,
    trend:      trend > 3 ? 'improving' : trend < -3 ? 'declining' : 'stable',
    confidence: Math.min(95, 60 + (weekScores.filter(s => s > 0).length * 5)),
    timestamp:  new Date().toISOString(),
  };
}

// ── AGENT 2: Analyst Agent ────────────────────────────────────────────────────
export function analystAgent(userData) {
  const { weekScores = [], score, target = 40, consistencyPct = 50, teamRank, teamSize, tasksCompleted = 0, tasksTotal = 1 } = userData;

  const avg7Day  = weekScores.length
    ? Math.round(weekScores.reduce((s, v) => s + v, 0) / weekScores.length)
    : score;

  const greenDays  = weekScores.filter(s => s >= target).length;
  const yellowDays = weekScores.filter(s => s >= target * 0.5 && s < target).length;
  const redDays    = weekScores.filter(s => s < target * 0.5).length;

  const completionRate = tasksTotal > 0 ? Math.round((tasksCompleted / tasksTotal) * 100) : 0;

  // Performance gap
  const gap = target - score;
  const gapSeverity = gap <= 0 ? 'none' : gap <= 10 ? 'minor' : gap <= 25 ? 'moderate' : 'critical';

  // Trend analysis (linear regression approximation)
  const n = weekScores.length;
  let trendSlope = 0;
  if (n >= 3) {
    const sumX  = weekScores.reduce((s, _, i) => s + i, 0);
    const sumY  = weekScores.reduce((s, v) => s + v, 0);
    const sumXY = weekScores.reduce((s, v, i) => s + i * v, 0);
    const sumX2 = weekScores.reduce((s, _, i) => s + i * i, 0);
    trendSlope  = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  }

  const insights = [];
  if (trendSlope > 2)  insights.push('Positive momentum — scores improving day over day');
  if (trendSlope < -2) insights.push('Declining trend — scores dropping over the week');
  if (redDays >= 3)    insights.push('Chronic underperformance — 3+ RED days this week');
  if (greenDays >= 5)  insights.push('Exceptional week — 5+ GREEN days achieved');
  if (teamRank === 1)  insights.push('Top performer on the team — maintain this standard');
  if (teamRank >= teamSize * 0.8) insights.push('Bottom 20% of team — significant execution gap');
  if (completionRate < 40) insights.push('Low task completion rate — volume is the bottleneck');

  return {
    agentId:     'analyst',
    agentName:   'Analyst Agent',
    agentEmoji:  '📊',
    status:      'active',
    avg7Day,
    greenDays,
    yellowDays,
    redDays,
    trendSlope:  Math.round(trendSlope * 10) / 10,
    trendDir:    trendSlope > 1 ? 'up' : trendSlope < -1 ? 'down' : 'flat',
    completionRate,
    gap,
    gapSeverity,
    teamPercentile: teamSize > 0 ? Math.round(((teamSize - teamRank) / teamSize) * 100) : 50,
    insights,
    confidence:  Math.min(90, 40 + n * 8),
    timestamp:   new Date().toISOString(),
  };
}

// ── AGENT 3: Risk Agent ───────────────────────────────────────────────────────
export function riskAgent(userData) {
  const { weekScores = [], streak, status, lastActiveAt, score, consistencyPct = 50, target = 40 } = userData;

  // Hours since last active
  const hoursSince = lastActiveAt
    ? Math.round((Date.now() - new Date(lastActiveAt)) / 3600000)
    : 0;

  // Risk scoring (0–100)
  let riskScore = 0;
  const factors = [];

  if (streak === 0)                        { riskScore += 25; factors.push('Streak broken — re-engagement risk'); }
  if (status === 'RED')                    { riskScore += 30; factors.push('RED status today'); }
  if (weekScores.filter(s => s === 0).length >= 2) { riskScore += 20; factors.push('2+ missed days this week'); }
  if (consistencyPct < 30)                 { riskScore += 15; factors.push('Consistency below 30%'); }
  if (hoursSince >= 48)                    { riskScore += 25; factors.push('48h+ inactivity detected'); }
  if (weekScores.length >= 3) {
    const last3 = weekScores.slice(-3);
    if (last3.every((s, i) => i === 0 || s <= last3[i - 1])) { riskScore += 15; factors.push('3-day declining streak'); }
  }

  const riskLevel = riskScore >= 60 ? 'critical' : riskScore >= 35 ? 'high' : riskScore >= 15 ? 'medium' : 'low';

  const alerts = [];
  if (riskLevel === 'critical') alerts.push({ type: 'churn',      msg: 'User at serious churn risk — immediate intervention needed',        urgency: 'red'    });
  if (riskLevel === 'high')     alerts.push({ type: 'drop',       msg: 'Declining engagement — re-engagement message recommended',          urgency: 'orange' });
  if (hoursSince >= 24)         alerts.push({ type: 'inactive',   msg: `${hoursSince}h since last login — send check-in nudge`,             urgency: 'yellow' });
  if (streak === 0 && status !== 'GREEN') alerts.push({ type: 'streak', msg: 'Streak recovery window — first 24h are critical',             urgency: 'yellow' });

  const reEngageScript = riskLevel === 'critical'
    ? '"Hey — you haven\'t logged today and your streak is broken. 5 minutes to get back on track. What\'s holding you back?"'
    : riskLevel === 'high'
    ? '"Quick check-in: you\'re falling behind your own pace from last week. One task right now gets you back."'
    : '"Your team is executing without you today. 60 seconds to log your first action."';

  return {
    agentId:      'risk',
    agentName:    'Risk Agent',
    agentEmoji:   '⚠️',
    status:       'active',
    riskScore:    Math.min(100, riskScore),
    riskLevel,
    factors,
    alerts,
    reEngageScript,
    hoursSinceActive: hoursSince,
    recommendIntervention: riskLevel === 'critical' || riskLevel === 'high',
    confidence:   Math.min(88, 55 + weekScores.filter(s => s > 0).length * 6),
    timestamp:    new Date().toISOString(),
  };
}

// ── AGENT 4: Performance Agent ────────────────────────────────────────────────
export function performanceAgent(userData) {
  const { weekScores = [], score, target = 40, consistencyPct = 50, streak, tasksTotal = 8 } = userData;

  const avg = weekScores.length
    ? weekScores.reduce((s, v) => s + v, 0) / weekScores.length
    : score;

  // Difficulty recommendation
  let difficultyAdj = 'maintain';
  let newTarget = target;
  let taskLoadAdj = 'maintain';

  if (consistencyPct >= 80 && avg >= target * 0.9) {
    difficultyAdj = 'increase';
    newTarget     = Math.round(target * 1.15);
    taskLoadAdj   = 'increase';
  } else if (consistencyPct < 30 || avg < target * 0.4) {
    difficultyAdj = 'reduce';
    newTarget     = Math.round(target * 0.75);
    taskLoadAdj   = 'reduce';
  }

  // Workload balance
  const optimalTaskCount = taskLoadAdj === 'increase' ? Math.min(12, tasksTotal + 2) :
                           taskLoadAdj === 'reduce'   ? Math.max(3,  tasksTotal - 2) : tasksTotal;

  // Peak performance window (based on streak pattern)
  const peakWindow = streak >= 3 ? 'current momentum' : avg > target * 0.7 ? 'afternoon' : 'morning reset';

  const recommendations = [];
  if (difficultyAdj === 'increase') recommendations.push(`Raise daily target to ${newTarget} pts — user is ready for next level`);
  if (difficultyAdj === 'reduce')   recommendations.push(`Lower target to ${newTarget} pts — build consistency first`);
  if (taskLoadAdj === 'reduce')     recommendations.push(`Reduce to ${optimalTaskCount} daily tasks — prevent overwhelm`);
  if (taskLoadAdj === 'increase')   recommendations.push(`Add ${optimalTaskCount - tasksTotal} stretch tasks — capacity exists`);
  if (streak >= 7)                  recommendations.push('Streak bonus: unlock advanced tasks — reward consistency');
  if (consistencyPct < 40)          recommendations.push('Focus on 1 task only until consistency > 40%');

  return {
    agentId:          'performance',
    agentName:        'Performance Agent',
    agentEmoji:       '🚀',
    status:           'active',
    difficultyAdj,
    currentTarget:    target,
    recommendedTarget: newTarget,
    taskLoadAdj,
    currentTasks:     tasksTotal,
    optimalTasks:     optimalTaskCount,
    peakWindow,
    recommendations,
    readinessScore:   Math.round((consistencyPct * 0.4) + (Math.min(100, (avg / target) * 100) * 0.6)),
    confidence:       Math.min(85, 45 + weekScores.filter(s => s > 0).length * 7),
    timestamp:        new Date().toISOString(),
  };
}

// ── ORCHESTRATOR ──────────────────────────────────────────────────────────────
/**
 * runAgents — runs all 4 agents and returns a unified intelligence report.
 * Also applies the self-improvement loop: each run refines agent weights.
 */
export function runAgents(userData, agentWeights = {}) {
  const coach       = coachAgent(userData);
  const analysis    = analystAgent(userData);
  const risk        = riskAgent(userData);
  const performance = performanceAgent(userData);

  // Orchestrator synthesizes a priority action
  let priorityAction, priorityAgent, alertLevel;

  if (risk.riskLevel === 'critical') {
    priorityAction = risk.reEngageScript;
    priorityAgent  = 'risk';
    alertLevel     = 'critical';
  } else if (risk.riskLevel === 'high') {
    priorityAction = coach.action;
    priorityAgent  = 'coach';
    alertLevel     = 'high';
  } else if (analysis.trendDir === 'up' && performance.difficultyAdj === 'increase') {
    priorityAction = performance.recommendations[0];
    priorityAgent  = 'performance';
    alertLevel     = 'opportunity';
  } else {
    priorityAction = coach.action;
    priorityAgent  = 'coach';
    alertLevel     = 'normal';
  }

  // Self-improvement: update agent confidence weights based on prior accuracy
  const updatedWeights = {
    coach:       (agentWeights.coach       ?? 1.0),
    analyst:     (agentWeights.analyst     ?? 1.0),
    risk:        (agentWeights.risk        ?? 1.0),
    performance: (agentWeights.performance ?? 1.0),
  };

  return {
    orchestrator: {
      priorityAction,
      priorityAgent,
      alertLevel,
      systemHealth: risk.riskScore < 20 && analysis.trendDir !== 'down' ? 'healthy' : risk.riskScore > 60 ? 'at-risk' : 'monitor',
      runAt: new Date().toISOString(),
    },
    agents: { coach, analyst: analysis, risk, performance },
    agentWeights: updatedWeights,
  };
}

// ── Agent persistence ─────────────────────────────────────────────────────────
export function loadAgentState(userId) {
  try {
    const raw = localStorage.getItem(`be_agents_${userId}`);
    return raw ? JSON.parse(raw) : { weights: {}, history: [] };
  } catch { return { weights: {}, history: [] }; }
}

export function saveAgentState(userId, state) {
  try { localStorage.setItem(`be_agents_${userId}`, JSON.stringify(state)); } catch {}
}
