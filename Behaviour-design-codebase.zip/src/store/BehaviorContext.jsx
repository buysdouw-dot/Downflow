import { createContext, useContext, useState, useCallback, useMemo } from 'react';
import { plugins, makeInitialLogs } from './data';
import { getStatus } from '../engine/core';
import { detectDropPattern, calcStreak } from '../engine/coach';
import { coachWithPersonality, suggestPersonality, DEFAULT_PERSONALITY } from '../engine/personality';
import { useAuth } from './AuthContext';

const BehaviorContext = createContext(null);
const todayStr = () => new Date().toISOString().split('T')[0];

// Per-user personality preference (persisted in localStorage)
function loadPersonality(userId) {
  try { return localStorage.getItem(`be_personality_${userId}`) || DEFAULT_PERSONALITY; } catch { return DEFAULT_PERSONALITY; }
}
function savePersonality(userId, p) {
  try { localStorage.setItem(`be_personality_${userId}`, p); } catch {}
}

export function BehaviorProvider({ children }) {
  const { user, allUsersInTenant, tenantInfo } = useAuth();
  const tenantPlugin = tenantInfo?.plugin ?? 'sales';

  const [logs, setLogs] = useState(() => makeInitialLogs());
  const [feedback, setFeedback] = useState(null);
  const [personalityId, setPersonalityId] = useState(() => loadPersonality(user?.id));

  const changePersonality = useCallback((newPersonality) => {
    setPersonalityId(newPersonality);
    if (user?.id) savePersonality(user.id, newPersonality);
  }, [user?.id]);

  const _getScoreForDay = useCallback(
    (allLogs, userId, date) =>
      allLogs.filter(l => l.userId === userId && l.date === date)
             .reduce((sum, l) => sum + l.points, 0),
    []
  );

  const _getWeekScoresRaw = useCallback(
    (allLogs, userId) => {
      const result = [];
      for (let d = 6; d >= 0; d--) {
        const date = new Date();
        date.setDate(date.getDate() - d);
        const dateStr = date.toISOString().split('T')[0];
        result.push(_getScoreForDay(allLogs, userId, dateStr));
      }
      return result;
    },
    [_getScoreForDay]
  );

  const logAction = useCallback(
    (userId, task) => {
      setLogs((prev) => {
        const newLogs = [
          ...prev,
          {
            id: `${userId}-${Date.now()}`,
            userId,
            taskId: task.id,
            taskName: task.name,
            taskCategory: task.category,
            points: task.points,
            date: todayStr(),
            timestamp: new Date().toISOString(),
          },
        ];

        const plug = plugins[tenantPlugin];
        const target = plug?.dailyTarget ?? 40;
        const todayScore = newLogs
          .filter(l => l.userId === userId && l.date === todayStr())
          .reduce((sum, l) => sum + l.points, 0);

        const weekScores = _getWeekScoresRaw(newLogs, userId);
        const streak = calcStreak(weekScores, target);
        const dropPattern = detectDropPattern(weekScores);
        const userRecord = allUsersInTenant.find(u => u.id === userId);

        const coachResult = coachWithPersonality({
          role: userRecord?.role ?? 'user',
          score: todayScore,
          dailyTarget: target,
          weekScores,
          lastTask: task,
          streak,
          dropPattern,
        }, personalityId);

        setFeedback(coachResult);
        return newLogs;
      });
    },
    [tenantPlugin, allUsersInTenant, _getWeekScoresRaw, personalityId]
  );

  const dismissFeedback = useCallback(() => setFeedback(null), []);

  const getScoreForDay = useCallback(
    (userId, date) => _getScoreForDay(logs, userId, date),
    [logs, _getScoreForDay]
  );

  const getTodayScore = useCallback(
    (userId) => getScoreForDay(userId, todayStr()),
    [getScoreForDay]
  );

  const getWeekScores = useCallback(
    (userId) => {
      const result = [];
      for (let d = 6; d >= 0; d--) {
        const date = new Date();
        date.setDate(date.getDate() - d);
        const dateStr = date.toISOString().split('T')[0];
        result.push({
          date: dateStr,
          label: date.toLocaleDateString('en-US', { weekday: 'short' }),
          score: getScoreForDay(userId, dateStr),
        });
      }
      return result;
    },
    [getScoreForDay]
  );

  const getTodayLogs = useCallback(
    (userId) => logs.filter(l => l.userId === userId && l.date === todayStr()),
    [logs]
  );

  const leaderboard = useMemo(() => {
    return allUsersInTenant
      .map((u) => {
        const score = getTodayScore(u.id);
        const weekScores = getWeekScores(u.id).map(d => d.score);
        const avg = Math.round(weekScores.reduce((a, b) => a + b, 0) / 7);
        const plug = plugins[tenantPlugin];
        const streak = calcStreak(weekScores, plug?.dailyTarget ?? 40);
        const dropPattern = detectDropPattern(weekScores);
        return {
          ...u,
          score,
          avg,
          streak,
          dropPattern,
          status: getStatus(score),
          dailyTarget: plug?.dailyTarget ?? 40,
          pluginName: plug?.name ?? '',
          pluginIcon: plug?.icon ?? '',
        };
      })
      .sort((a, b) => b.score - a.score)
      .map((u, i) => ({ ...u, rank: i + 1 }));
  }, [allUsersInTenant, getTodayScore, getWeekScores, tenantPlugin]);

  const value = {
    logs,
    plugins,
    activeUserId: user?.id,
    activePlugin: tenantPlugin,
    logAction,
    feedback,
    dismissFeedback,
    getTodayScore,
    getWeekScores,
    getTodayLogs,
    leaderboard,
    personalityId,
    changePersonality,
  };

  return <BehaviorContext.Provider value={value}>{children}</BehaviorContext.Provider>;
}

export const useBehavior = () => {
  const ctx = useContext(BehaviorContext);
  if (!ctx) throw new Error('useBehavior must be used within BehaviorProvider');
  return ctx;
};
