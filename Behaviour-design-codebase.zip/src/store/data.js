// ─── Mock Data Store ─────────────────────────────────────────────────────────

// ── Sales Execution Engine — Scripts ─────────────────────────────────────────
export const salesScripts = {
  outreach: {
    title: 'Outreach Script',
    icon: '📩',
    script: "Hi [Name], quick question — are you currently open to improving [result]?",
    tip: 'Keep it short. One sentence. A question always beats a pitch.',
    recoveryScript: "Hi, quick question — got 30 seconds?",
  },
  conversation: {
    title: 'Conversation Script',
    icon: '💬',
    script: "Got you. What's your biggest challenge right now with [problem]?",
    tip: 'Ask, then shut up. The goal is to get them talking, not you.',
    recoveryScript: "What's the main thing slowing you down right now?",
  },
  follow_up: {
    title: 'Follow-Up Script',
    icon: '🔁',
    script: "Hey, just checking — did you get a chance to think about what we discussed?",
    tip: "80% of sales happen after the 5th follow-up. Don't stop.",
    recoveryScript: "Still thinking about it? No pressure — just wanted to stay on your radar.",
  },
  closing: {
    title: 'Closing Script',
    icon: '💰',
    script: "Based on what you said, this can help you achieve [result]. Would you like to move forward?",
    tip: "Ask for the close directly. Silence after asking is power.",
    recoveryScript: "What would need to be true for this to be a yes?",
  },
};

// ── Sales Execution Engine — Daily Targets & Rules ───────────────────────────
export const salesRules = {
  minOutreach:     20,
  minConversations: 5,
  minFollowUps:     2,
  minClosing:       1,
};

// ── Plugin Registry ──────────────────────────────────────────────────────────
export const plugins = {
  sales: {
    name: 'Sales Execution Engine',
    shortName: 'Sales',
    icon: '💼',
    color: '#6366f1',
    description: 'A system that forces daily actions that generate sales.',
    rules: salesRules,
    tasks: [
      { id: 'se1', name: 'Send outreach message',      points: 1, category: 'Outreach',      actionType: 'outreach',     dailyMin: 20 },
      { id: 'se2', name: 'Start a conversation',       points: 3, category: 'Conversation',   actionType: 'conversation', dailyMin: 5  },
      { id: 'se3', name: 'Follow up with a lead',      points: 2, category: 'Follow-Up',      actionType: 'follow_up',    dailyMin: 2  },
      { id: 'se4', name: 'Attempt a close',            points: 5, category: 'Closing',        actionType: 'closing',      dailyMin: 1  },
      { id: 'se5', name: 'CRM update',                 points: 1, category: 'Admin',          actionType: null,           dailyMin: 0  },
      { id: 'se6', name: 'Prospecting session (30min)',points: 4, category: 'Outreach',       actionType: 'outreach',     dailyMin: 0  },
      { id: 'se7', name: 'Proposal sent',              points: 6, category: 'Closing',        actionType: 'closing',      dailyMin: 0  },
      { id: 'se8', name: 'LinkedIn connection',        points: 2, category: 'Outreach',       actionType: 'outreach',     dailyMin: 0  },
    ],
    dailyTarget: 40,
  },
  fitness: {
    name: 'Fitness',
    icon: '🏋️',
    color: '#10b981',
    tasks: [
      { id: 'f1', name: 'Morning run (5km)',   points: 8,  category: 'Cardio'    },
      { id: 'f2', name: 'Weight training',     points: 10, category: 'Strength'  },
      { id: 'f3', name: 'Stretching / mobility', points: 3, category: 'Recovery' },
      { id: 'f4', name: 'Meal prep',           points: 4,  category: 'Nutrition' },
      { id: 'f5', name: 'Hydration goal met',  points: 2,  category: 'Nutrition' },
      { id: 'f6', name: 'Sleep 8 hours',       points: 5,  category: 'Recovery'  },
      { id: 'f7', name: 'HIIT session',        points: 9,  category: 'Cardio'    },
      { id: 'f8', name: 'Cold shower',         points: 2,  category: 'Recovery'  },
    ],
    dailyTarget: 40,
  },
  school: {
    name: 'School',
    icon: '🎓',
    color: '#f59e0b',
    tasks: [
      { id: 's1', name: 'Read chapter / notes',   points: 4, category: 'Study'         },
      { id: 's2', name: 'Practice problems',       points: 5, category: 'Study'         },
      { id: 's3', name: 'Attend lecture',          points: 6, category: 'Attendance'    },
      { id: 's4', name: 'Assignment submitted',    points: 8, category: 'Deliverables'  },
      { id: 's5', name: 'Group study session',     points: 5, category: 'Collaboration' },
      { id: 's6', name: 'Flashcard review',        points: 3, category: 'Study'         },
      { id: 's7', name: 'Research / deep reading', points: 6, category: 'Study'         },
      { id: 's8', name: 'Office hours attended',   points: 4, category: 'Collaboration' },
    ],
    dailyTarget: 35,
  },
};

// ── Tenant-mapped user IDs for seed logs ─────────────────────────────────────
const TENANT_USERS = {
  sales:   [1, 4, 7],
  fitness: [2, 5],
  school:  [3, 6],
};

const TENANT_PLUGINS = {
  sales: 'sales',
  fitness: 'fitness',
  school: 'school',
};

// ── Generate 7 days of seed logs for all tenants ─────────────────────────────
export function makeInitialLogs() {
  const logs = [];
  const today = new Date();

  Object.entries(TENANT_USERS).forEach(([tenant, userIds]) => {
    const plugKey = TENANT_PLUGINS[tenant];
    const plug = plugins[plugKey];

    userIds.forEach((userId) => {
      for (let d = 6; d >= 0; d--) {
        const date = new Date(today);
        date.setDate(today.getDate() - d);
        const dayStr = date.toISOString().split('T')[0];
        const count = 3 + Math.floor(Math.random() * 5);
        for (let i = 0; i < count; i++) {
          const task = plug.tasks[Math.floor(Math.random() * plug.tasks.length)];
          logs.push({
            id: `${userId}-${dayStr}-${i}`,
            userId,
            taskId: task.id,
            taskName: task.name,
            taskCategory: task.category,
            points: task.points,
            date: dayStr,
            timestamp: new Date(date.getTime() + i * 600000).toISOString(),
          });
        }
      }
    });
  });
  return logs;
}
