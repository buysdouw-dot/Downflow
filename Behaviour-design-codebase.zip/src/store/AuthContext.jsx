import { createContext, useContext, useState, useCallback } from 'react';

const AuthContext = createContext(null);

// ── Simulated user database (multi-tenant) ───────────────────────────────────
// ── Role-based permissions map ────────────────────────────────────────────────
const ROLE_PERMISSIONS = {
  admin: [
    'view_dashboard', 'assign_tasks', 'view_analytics', 'view_admin',
    'manage_users', 'manage_billing', 'manage_plugins', 'view_leaderboard',
  ],
  manager: [
    'view_dashboard', 'assign_tasks', 'view_analytics', 'view_leaderboard',
  ],
  user: [
    'view_dashboard', 'view_leaderboard',
  ],
};

const USERS_DB = [
  { id: 1, name: 'Alex Rivera',   email: 'alex@sales.co',   password: 'demo123', role: 'admin',  tenant: 'sales',   avatar: 'AR', title: 'SDR Lead' },
  { id: 2, name: 'Jamie Chen',    email: 'jamie@fitness.io', password: 'demo123', role: 'user',   tenant: 'fitness', avatar: 'JC', title: 'Head Trainer' },
  { id: 3, name: 'Morgan Davis',  email: 'morgan@school.edu',password: 'demo123', role: 'user',   tenant: 'school',  avatar: 'MD', title: 'Student' },
  { id: 4, name: 'Sam Okafor',    email: 'sam@sales.co',     password: 'demo123', role: 'user',   tenant: 'sales',   avatar: 'SO', title: 'Account Exec' },
  { id: 5, name: 'Taylor Kim',    email: 'taylor@fitness.io',password: 'demo123', role: 'user',   tenant: 'fitness', avatar: 'TK', title: 'Athlete' },
  { id: 6, name: 'Jordan Lee',    email: 'jordan@school.edu',password: 'demo123', role: 'admin',  tenant: 'school',  avatar: 'JL', title: 'Instructor' },
  { id: 7, name: 'Casey Nguyen',  email: 'casey@sales.co',   password: 'demo123', role: 'manager',tenant: 'sales',   avatar: 'CN', title: 'Sales Manager' },
];

const TENANTS = {
  sales:   { name: 'NovaSales Inc.',    icon: '💼', color: '#6366f1', plugin: 'sales'   },
  fitness: { name: 'PeakFit Studio',    icon: '🏋️', color: '#10b981', plugin: 'fitness' },
  school:  { name: 'Apex Academy',      icon: '🎓', color: '#f59e0b', plugin: 'school'  },
};

function makeToken(user) {
  return btoa(JSON.stringify({ id: user.id, tenant: user.tenant, role: user.role, exp: Date.now() + 86400000 * 30 })); // 30-day expiry
}

function parseToken(token) {
  try { return JSON.parse(atob(token)); } catch { return null; }
}

export function AuthProvider({ children }) {
  const [session, setSession] = useState(() => {
    const stored = localStorage.getItem('be_token');
    if (!stored) return null;
    const payload = parseToken(stored);
    if (!payload || payload.exp < Date.now()) { localStorage.removeItem('be_token'); return null; }
    const user = USERS_DB.find((u) => u.id === payload.id);
    return user ? { user, token: stored } : null;
  });

  const [authError, setAuthError] = useState('');

  const login = useCallback((email, password) => {
    setAuthError('');
    const user = USERS_DB.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user || user.password !== password) {
      setAuthError('Invalid email or password.');
      return false;
    }
    const token = makeToken(user);
    localStorage.setItem('be_token', token);
    setSession({ user, token });
    return true;
  }, []);

  const register = useCallback((name, email, password, tenant) => {
    setAuthError('');
    if (USERS_DB.find((u) => u.email.toLowerCase() === email.toLowerCase())) {
      setAuthError('Email already registered.');
      return false;
    }
    const initials = name.trim().split(' ').map((p) => p[0]).join('').toUpperCase().slice(0, 2);
    const newUser = {
      id: Date.now(),
      name,
      email,
      password,
      role: 'user',
      tenant,
      avatar: initials,
      title: 'Member',
    };
    USERS_DB.push(newUser);
    const token = makeToken(newUser);
    localStorage.setItem('be_token', token);
    setSession({ user: newUser, token });
    return true;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('be_token');
    setSession(null);
  }, []);

  const permissions = session ? (ROLE_PERMISSIONS[session.user.role] ?? []) : [];
  const can = (permission) => permissions.includes(permission);

  const value = {
    user: session?.user ?? null,
    token: session?.token ?? null,
    isAuthenticated: !!session,
    authError,
    setAuthError,
    login,
    register,
    logout,
    tenants: TENANTS,
    tenantInfo: session ? TENANTS[session.user.tenant] : null,
    allUsersInTenant: session
      ? USERS_DB.filter((u) => u.tenant === session.user.tenant)
      : [],
    permissions,
    can,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be inside AuthProvider');
  return ctx;
};
