import { createContext, useContext, useState, useCallback, useEffect } from 'react';

const NotificationsContext = createContext(null);

// ── Notification templates ────────────────────────────────────────────────────
const TEMPLATES = {
  morning_kickoff: {
    id: 'morning_kickoff',
    title: '🚀 Execution starts now',
    body: 'Your daily score is 0. Open the Sales Engine and send your first outreach.',
    time: '08:00',
    type: 'trigger',
    category: 'Daily Loop',
    enabled: true,
  },
  midday_check: {
    id: 'midday_check',
    title: '⚡ Midday check-in',
    body: 'Halfway through the day. Check your score. Are you on track for GREEN?',
    time: '12:00',
    type: 'trigger',
    category: 'Daily Loop',
    enabled: true,
  },
  afternoon_push: {
    id: 'afternoon_push',
    title: '💬 Start a conversation',
    body: 'Conversations create pipeline. Have you started 5 today? Use the script.',
    time: '14:00',
    type: 'trigger',
    category: 'Daily Loop',
    enabled: true,
  },
  closing_window: {
    id: 'closing_window',
    title: '💰 Closing window open',
    body: 'Best time to attempt a close is 15:00–17:00. Don\'t let today end without asking.',
    time: '15:00',
    type: 'trigger',
    category: 'Sales',
    enabled: true,
  },
  eod_summary: {
    id: 'eod_summary',
    title: '📊 End-of-day report',
    body: 'How did you finish? Log your remaining actions before the day closes.',
    time: '17:00',
    type: 'trigger',
    category: 'Daily Loop',
    enabled: true,
  },
  recovery_alert: {
    id: 'recovery_alert',
    title: '🔴 Recovery Protocol',
    body: 'You\'ve been RED for 2 days. Send 1 message right now. Use the recovery script.',
    time: null,
    type: 'behavioral',
    category: 'Recovery',
    enabled: true,
  },
  streak_praise: {
    id: 'streak_praise',
    title: '🔥 Streak maintained',
    body: 'You\'ve hit GREEN 3 days in a row. Keep the chain unbroken.',
    time: null,
    type: 'behavioral',
    category: 'Motivation',
    enabled: true,
  },
  leaderboard_alert: {
    id: 'leaderboard_alert',
    title: '📈 Leaderboard update',
    body: 'Someone just moved ahead of you. Your current rank: #2.',
    time: null,
    type: 'social',
    category: 'Leaderboard',
    enabled: true,
  },
  follow_up_reminder: {
    id: 'follow_up_reminder',
    title: '🔁 Follow-up due',
    body: '80% of sales happen after the 5th follow-up. Who hasn\'t heard from you today?',
    time: '10:30',
    type: 'trigger',
    category: 'Sales',
    enabled: false,
  },
  weekly_review: {
    id: 'weekly_review',
    title: '📆 Weekly performance review',
    body: 'Your 7-day report is ready. Check your score trend and plan next week.',
    time: '09:00',
    type: 'trigger',
    category: 'Weekly',
    enabled: true,
  },
};

// ── Simulate a feed of received notifications ─────────────────────────────────
function makeInitialFeed() {
  const now = new Date();
  return [
    {
      id: 'n1',
      ...TEMPLATES.morning_kickoff,
      receivedAt: new Date(now.getTime() - 2 * 3600000).toISOString(),
      read: true,
      action: '/sales',
    },
    {
      id: 'n2',
      ...TEMPLATES.leaderboard_alert,
      body: 'Alex moved to #1 on the leaderboard. You\'re at #2 — 8 pts behind.',
      receivedAt: new Date(now.getTime() - 90 * 60000).toISOString(),
      read: false,
      action: '/leaderboard',
    },
    {
      id: 'n3',
      ...TEMPLATES.midday_check,
      body: 'Midday check: your score is 17. You need 23 more to hit GREEN. Keep going.',
      receivedAt: new Date(now.getTime() - 60 * 60000).toISOString(),
      read: false,
      action: '/sales',
    },
    {
      id: 'n4',
      ...TEMPLATES.closing_window,
      receivedAt: new Date(now.getTime() - 30 * 60000).toISOString(),
      read: false,
      action: '/sales',
    },
    {
      id: 'n5',
      ...TEMPLATES.streak_praise,
      body: 'GREEN 3 days in a row. You\'re in the top 10% of users this week.',
      receivedAt: new Date(now.getTime() - 5 * 60000).toISOString(),
      read: false,
      action: '/',
    },
  ];
}

export function NotificationsProvider({ children }) {
  const [notifications, setNotifications] = useState(() => makeInitialFeed());
  const [schedule, setSchedule] = useState(() =>
    Object.values(TEMPLATES).filter((t) => t.type === 'trigger' || t.type === 'behavioral')
  );
  const [permission, setPermission] = useState('granted'); // simulated

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markRead = useCallback((id) => {
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n));
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const dismiss = useCallback((id) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const pushNotification = useCallback((templateId, override = {}) => {
    const template = TEMPLATES[templateId];
    if (!template) return;
    setNotifications((prev) => [{
      ...template,
      ...override,
      id: `n-${Date.now()}`,
      receivedAt: new Date().toISOString(),
      read: false,
    }, ...prev]);
  }, []);

  const toggleSchedule = useCallback((id) => {
    setSchedule((prev) => prev.map((s) => s.id === id ? { ...s, enabled: !s.enabled } : s));
  }, []);

  // Simulate a notification arriving every 45 seconds (demo)
  useEffect(() => {
    const demos = ['afternoon_push', 'follow_up_reminder', 'eod_summary'];
    let idx = 0;
    const interval = setInterval(() => {
      const tmpl = demos[idx % demos.length];
      pushNotification(tmpl);
      idx++;
    }, 45000);
    return () => clearInterval(interval);
  }, [pushNotification]);

  const value = {
    notifications,
    schedule,
    unreadCount,
    permission,
    markRead,
    markAllRead,
    dismiss,
    pushNotification,
    toggleSchedule,
    templates: TEMPLATES,
  };

  return <NotificationsContext.Provider value={value}>{children}</NotificationsContext.Provider>;
}

export const useNotifications = () => {
  const ctx = useContext(NotificationsContext);
  if (!ctx) throw new Error('useNotifications must be inside NotificationsProvider');
  return ctx;
};
