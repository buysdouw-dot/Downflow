import { getStatus, getStatusConfig, calcProgress } from '../engine/core';

export default function ScoreRing({ score, target = 40, size = 120 }) {
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const pct = calcProgress(score, target);
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={6} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={cfg.hex}
          strokeWidth={6}
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circ - dash}`}
          style={{ transition: 'stroke-dasharray 0.8s ease', filter: `drop-shadow(0 0 6px ${cfg.hex}88)` }}
        />
      </svg>
      <div className="absolute text-center">
        <p className={`font-bold leading-none ${size >= 120 ? 'text-3xl' : 'text-xl'} ${cfg.color}`}>{score}</p>
        <p className="text-white/30 text-xs mt-1">/{target}</p>
      </div>
    </div>
  );
}
