import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard, CheckSquare, BarChart2, Trophy, Zap,
  LogOut, Shield, ChevronDown, Bell, TrendingUp,
  Puzzle, CreditCard, Activity, Server, DollarSign,
  Phone, Star, Users, Bot, Share2, Play, Brain,
  Rocket, Briefcase, Cpu, Network, GitBranch,
  Radio, Flag, MessageSquare, TrendingUp as Revenue,
  GitMerge, Sliders, Infinity, Copy, BarChart2 as PitchIcon, Target, BrainCircuit,
  FileCode, CalendarDays, PhoneCall, Sparkles,
  Archive, Cloud, TrendingUp as Scale, Bot as AgentBot,
  GitCommit, Flame, Building2, Cpu as CpuV5,
  PackageOpen, Bot as AgentBot2, BadgeDollarSign, Clapperboard,
  FolderGit2, Rocket as Rocket2, Megaphone, Infinity as InfV6,
  PackageCheck, TrendingUp as ViralIcon, BrainCircuit as AgentOS, Globe as EntGlobe,
  Lightbulb, MonitorPlay, CalendarCheck, FolderGit, BookOpen, HandshakeIcon,
} from 'lucide-react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus, getStatusConfig } from '../engine/core';
import FeedbackToast from './FeedbackToast';
import MobileNav from './MobileNav';
import { useNotifications } from '../store/NotificationsContext';
import { useNavigate } from 'react-router-dom';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/tasks', icon: CheckSquare, label: 'Tasks' },
  { to: '/score', icon: BarChart2, label: 'Score' },
  { to: '/leaderboard', icon: Trophy, label: 'Leaderboard' },
  { to: '/sales', icon: TrendingUp, label: 'Sales Engine', badge: '💼' },
  { to: '/crm',   icon: Users,     label: 'CRM Pipeline' },
  { to: '/plugins', icon: Puzzle,  label: 'Plugins' },
  { divider: true, label: 'DOCUMENTS' },
  { to: '/business-plan',   icon: BookOpen,      label: 'Business Plan',    badge: '📄', highlight: true },
  { to: '/funding-proposal',icon: HandshakeIcon, label: 'Funding Proposal', badge: '💰', highlight: true },
];

const adminNavItems = [
  { to: '/admin',     icon: Shield,      label: 'Admin Dashboard' },
  { to: '/analytics', icon: Activity,    label: 'Analytics'       },
  { to: '/billing',   icon: CreditCard,  label: 'Billing'         },
  { to: '/deploy',    icon: Server,      label: 'Deploy Guide'    },
  { to: '/strategy',  icon: DollarSign,  label: '$1K Strategy'    },
  { to: '/scripts',   icon: Phone,       label: 'Sales Scripts'   },
  { to: '/pitch',     icon: Star,        label: 'Pitch Deck'      },
  { to: '/coach',     icon: Bot,         label: 'AI Coach Style'  },
  { to: '/growth',    icon: Share2,      label: 'Viral Growth'    },
  { to: '/demo',      icon: Play,        label: 'Investor Demo'   },
  { to: '/memory',     icon: Brain,       label: 'Memory Engine'   },
  { to: '/sprint',     icon: Rocket,      label: '100 Users Sprint' },
  { to: '/sales-deck', icon: Briefcase,   label: 'Corp Sales Deck'  },
  { to: '/evolution',  icon: Cpu,         label: 'AI Evolution'     },
  { to: '/auto-crm',  icon: GitBranch,   label: 'Auto CRM'         },
  { to: '/agents',    icon: Network,     label: 'Multi-Agent AI'   },
  { to: '/pulse',     icon: Radio,       label: 'Team Pulse'       },
  { to: '/goals',     icon: Flag,        label: 'OKR Goals'        },
  { to: '/chat',      icon: MessageSquare, label: 'AI Chat Coach'  },
  { to: '/revenue',   icon: Revenue,     label: 'Revenue Tracker'  },
  { to: '/repo',      icon: GitMerge,    label: 'Prod Repo'        },
  { to: '/scale',     icon: Sliders,     label: 'Growth Engine'    },
  { to: '/pricing',   icon: DollarSign,  label: 'Pricing Optimizer'},
  { to: '/autonomous',icon: Infinity,    label: 'Autonomous AI'    },
  { to: '/copy-repo', icon: Copy,        label: 'Copy-Paste Repo'  },
  { to: '/pitch-demo',icon: PitchIcon,   label: 'Investor Pitch'   },
  { to: '/ten-k',     icon: Target,      label: '$10K Plan'         },
  { to: '/ai-v2',     icon: BrainCircuit, label: 'AI v2 Autonomous' },
  { to: '/repo-full', icon: FileCode,     label: 'Full Repo (Clean)' },
  { to: '/acquire',   icon: CalendarDays, label: '30-Day Acquisition'},
  { to: '/closing',   icon: PhoneCall,    label: 'Closing CRM'       },
  { to: '/ai-v3',      icon: Sparkles,   label: 'AI v3 Autonomous'   },
  { to: '/zip-repo',   icon: Archive,    label: 'ZIP Repo (Full)'    },
  { to: '/live-deploy',icon: Cloud,      label: 'Deploy Walkthrough' },
  { to: '/rev-scale',  icon: Scale,      label: '$100K/mo Model'     },
  { to: '/ai-v4',      icon: AgentBot,   label: 'AI v4 Agent Company'},
  { to: '/git-commits',icon: GitCommit,  label: 'Commit-by-Commit'   },
  { to: '/growth-90',  icon: Flame,      label: '90-Day Growth Plan'  },
  { to: '/enterprise', icon: Building2,  label: 'Enterprise Sales'    },
  { to: '/ai-v5',      icon: CpuV5,        label: 'AI v5 Autonomous'    },
  { to: '/full-repo',  icon: PackageOpen,  label: 'Full Repo (All Files)' },
  { to: '/agent-code', icon: AgentBot2,    label: 'Agent Codebase'       },
  { to: '/100k-plan',  icon: BadgeDollarSign, label: '$100K Execution Plan' },
  { to: '/pitch-demo', icon: Clapperboard,      label: 'Investor Demo'           },
  { to: '/repo-clean', icon: FolderGit2,        label: 'Repo Export (Clean)'     },
  { to: '/first-1k',   icon: Rocket2,           label: '1000 Users Plan'         },
  { to: '/ent-auto',   icon: Megaphone,         label: 'Enterprise Automation'   },
  { to: '/auto-v6',      icon: InfV6,         label: 'Autonomous v6'           },
  { to: '/deploy-repo',    icon: PackageCheck,  label: 'Deployable Repo'         },
  { to: '/stripe-billing', icon: CreditCard,    label: 'Stripe Billing'          },
  { to: '/viral-loop',     icon: ViralIcon,     label: 'Viral Loop Engine'       },
  { to: '/ai-agent-os',    icon: AgentOS,       label: 'AI Agent OS'             },
  { to: '/enterprise-mt',  icon: EntGlobe,      label: 'Enterprise Multi-Tenant' },
  { to: '/auto-v7',        icon: Lightbulb,     label: 'Autonomous AI v7',      badge: '🆕' },
  { to: '/pitch-live',     icon: MonitorPlay,   label: 'Investor Pitch Live',   badge: '🆕' },
  { to: '/100k-playbook',  icon: CalendarCheck, label: '$100K Playbook',        badge: '🆕' },
  { to: '/deploy-ready',   icon: FolderGit,     label: 'Deploy-Ready Repo',     badge: '🆕' },
];

const AVATAR_BG = [
  'from-indigo-500 to-purple-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-pink-500 to-rose-600',
  'from-cyan-500 to-blue-600',
  'from-violet-500 to-purple-600',
  'from-fuchsia-500 to-pink-600',
];

export default function Layout({ children }) {
  const { getTodayScore, activeUserId, activePlugin, plugins } = useBehavior();
  const { user, logout, tenantInfo, can } = useAuth();
  const { unreadCount } = useNotifications();
  const navigate = useNavigate();

  const score = getTodayScore(activeUserId);
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const plug = plugins[activePlugin];
  const avatarBg = AVATAR_BG[(user?.id ?? 1) % AVATAR_BG.length];

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar — hidden on mobile */}
      <aside className="hidden lg:flex w-64 flex-col border-r border-white/8 bg-[#0b0f1a] shrink-0 select-none">

        {/* Brand + Tenant */}
        <div className="px-5 py-4 border-b border-white/8">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center shrink-0">
              <Zap size={15} className="text-indigo-400" />
            </div>
            <div>
              <p className="text-white font-bold text-sm leading-none">Behavior Engine</p>
              <p className="text-white/30 text-[10px] mt-0.5">Human Performance OS</p>
            </div>
          </div>
          {tenantInfo && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/4 border border-white/6">
              <span className="text-sm">{tenantInfo.icon}</span>
              <p className="text-white/70 text-[11px] font-medium truncate flex-1">{tenantInfo.name}</p>
              {user?.role === 'admin' && (
                <span className="flex items-center gap-0.5 text-[9px] font-bold text-indigo-400 bg-indigo-500/15 px-1.5 py-0.5 rounded-full border border-indigo-500/20 whitespace-nowrap">
                  <Shield size={8} /> Admin
                </span>
              )}
              {user?.role === 'manager' && (
                <span className="text-[9px] font-bold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded-full border border-amber-500/20">
                  Mgr
                </span>
              )}
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto scrollbar-hide">
          {navItems.map((item) => {
            // Divider / section header
            if (item.divider) {
              return (
                <div key={item.label} className="pt-3 pb-1">
                  <p className="px-3 text-[9px] font-bold text-white/20 uppercase tracking-widest">{item.label}</p>
                </div>
              );
            }
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/20'
                      : item.highlight
                        ? 'text-white/70 hover:text-white bg-indigo-500/8 border border-indigo-500/15 hover:bg-indigo-500/15'
                        : 'text-white/45 hover:text-white/75 hover:bg-white/4'
                  }`
                }
              >
                <Icon size={16} />
                <span className="flex-1">{item.label}</span>
                {item.badge && <span className="text-sm leading-none">{item.badge}</span>}
              </NavLink>
            );
          })}

          {/* Admin section — only for admins/managers */}
          {can('view_admin') && (
            <>
              <div className="pt-3 pb-1">
                <p className="px-3 text-[9px] font-bold text-white/20 uppercase tracking-widest flex items-center gap-1.5">
                  <Shield size={9} /> Admin
                </p>
              </div>
              {adminNavItems.map(({ to, icon: Icon, label }) => (
                <NavLink
                  key={to}
                  to={to}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/20'
                        : 'text-white/35 hover:text-white/60 hover:bg-white/4'
                    }`
                  }
                >
                  <Icon size={16} />
                  <span className="flex-1">{label}</span>
                </NavLink>
              ))}
            </>
          )}
        </nav>

        {/* Today score card */}
        <div className="mx-3 mb-3">
          <div className={`p-3 rounded-xl glass border ${cfg.border} ${cfg.glow}`}>
            <div className="flex items-center justify-between mb-1.5">
              <p className="text-white/35 text-[10px] uppercase tracking-widest">Today</p>
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${cfg.bg} ${cfg.color}`}>
                {cfg.label}
              </span>
            </div>
            <div className="flex items-end gap-1 mb-1.5">
              <span className={`text-2xl font-bold leading-none ${cfg.color}`}>{score}</span>
              <span className="text-white/25 text-xs pb-0.5">/{plug?.dailyTarget ?? 40} pts</span>
            </div>
            <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-700 ${cfg.bar}`}
                style={{ width: `${Math.min(100, (score / (plug?.dailyTarget ?? 40)) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* User footer */}
        <div className="mx-3 mb-4 p-3 rounded-xl glass flex items-center gap-2.5">
          <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarBg} flex items-center justify-center text-xs font-bold text-white shrink-0`}>
            {user?.avatar}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-xs font-medium truncate">{user?.name}</p>
            <p className="text-white/35 text-[10px] truncate">{user?.title ?? user?.role}</p>
          </div>
          <button onClick={logout} title="Sign out" className="text-white/25 hover:text-red-400 transition-colors p-1 rounded">
            <LogOut size={14} />
          </button>
        </div>
      </aside>

      {/* Right side */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar — desktop only */}
        <header className="hidden lg:flex h-12 border-b border-white/6 bg-[#070b14]/80 backdrop-blur-sm items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-1.5">
            <span className="text-white/25 text-xs">{plug?.icon}</span>
            <span className="text-white/40 text-xs font-medium">{plug?.name} Plugin</span>
            <span className="text-white/15 text-xs mx-1.5">·</span>
            <span className="text-white/25 text-xs">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/notifications')} className="w-7 h-7 rounded-lg glass flex items-center justify-center text-white/30 hover:text-white/60 transition-colors relative">
              <Bell size={13} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-indigo-500 border border-[#070b14] flex items-center justify-center text-[8px] font-bold text-white">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
            <div className="flex items-center gap-1.5 cursor-default">
              <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${avatarBg} flex items-center justify-center text-[9px] font-bold text-white`}>
                {user?.avatar}
              </div>
              <span className="text-white/40 text-xs">{user?.name?.split(' ')[0]}</span>
              <ChevronDown size={11} className="text-white/25" />
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto scrollbar-hide pb-16 lg:pb-0">
          {children}
        </main>
      </div>

      <MobileNav />
      <FeedbackToast />
    </div>
  );
}
