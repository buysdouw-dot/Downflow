import { getStatusConfig } from '../engine/core';

export default function StatusBadge({ status, size = 'sm' }) {
  const cfg = getStatusConfig(status);
  const sizes = {
    xs: 'text-[10px] px-1.5 py-0.5',
    sm: 'text-xs px-2 py-1',
    md: 'text-sm px-3 py-1.5',
  };
  return (
    <span className={`inline-flex items-center font-semibold rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border} ${sizes[size]}`}>
      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${cfg.bar}`} />
      {cfg.label}
    </span>
  );
}
