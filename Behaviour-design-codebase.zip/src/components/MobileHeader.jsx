import { Bell, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../store/AuthContext';
import { useBehavior } from '../store/BehaviorContext';
import { useNotifications } from '../store/NotificationsContext';
import { getStatus, getStatusConfig } from '../engine/core';

const AVATAR_BG = [
  'from-indigo-500 to-purple-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-pink-500 to-rose-600',
  'from-cyan-500 to-blue-600',
];

export default function MobileHeader({ title, back = false, right }) {
  const { user } = useAuth();
  const { getTodayScore, activeUserId, activePlugin, plugins } = useBehavior();
  const { unreadCount } = useNotifications();
  const navigate = useNavigate();
  const score = getTodayScore(activeUserId);
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const avatarBg = AVATAR_BG[(user?.id ?? 1) % AVATAR_BG.length];
  const plug = plugins[activePlugin];

  return (
    <header className="flex items-center justify-between px-4 py-3 border-b border-white/6 bg-[#0b0f1a]/90 backdrop-blur-sm sticky top-0 z-30 lg:hidden">
      <div className="flex items-center gap-3">
        {back && (
          <button onClick={() => navigate(-1)} className="text-white/40 hover:text-white/70 mr-1">
            <ChevronLeft size={20} />
          </button>
        )}
        {title ? (
          <p className="text-white font-bold text-base">{title}</p>
        ) : (
          <div className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full bg-gradient-to-br ${avatarBg} flex items-center justify-center text-xs font-bold text-white`}>
              {user?.avatar}
            </div>
            <div>
              <p className="text-white text-sm font-semibold leading-none">{user?.name?.split(' ')[0]}</p>
              <p className="text-white/30 text-[10px]">{plug?.icon} {plug?.name}</p>
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2.5">
        {/* Score pill */}
        <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${cfg.bg} border ${cfg.border}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${cfg.bar}`} />
          <span className={`text-xs font-bold ${cfg.color}`}>{score} pts</span>
        </div>

        <button
          onClick={() => navigate('/notifications')}
          className="relative w-8 h-8 rounded-xl glass flex items-center justify-center text-white/30 hover:text-white/60 transition-colors"
        >
          <Bell size={15} />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-indigo-500 border border-[#0b0f1a] flex items-center justify-center text-[8px] font-bold text-white">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {right}
      </div>
    </header>
  );
}
