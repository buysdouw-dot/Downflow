import { useEffect } from 'react';
import { X, Bot, Zap, TrendingUp, AlertTriangle, Flame } from 'lucide-react';
import { useBehavior } from '../store/BehaviorContext';
import { getStatusConfig, getStatus } from '../engine/core';
import { getPersonality } from '../engine/personality';

export default function FeedbackToast() {
  const { feedback, dismissFeedback, getTodayScore, activeUserId, personalityId } = useBehavior();

  useEffect(() => {
    if (!feedback) return;
    const t = setTimeout(dismissFeedback, 9000);
    return () => clearTimeout(t);
  }, [feedback, dismissFeedback]);

  if (!feedback) return null;

  const score = getTodayScore(activeUserId);
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const personality = getPersonality(feedback.personalityId ?? personalityId);

  // Personality-specific accent colors for the toast header
  const pColors = {
    discipline: { border: 'border-red-500/25',    bg: 'bg-red-500/10',    color: 'text-red-400',    bar: 'bg-red-500'    },
    strategy:   { border: 'border-indigo-500/25', bg: 'bg-indigo-500/10', color: 'text-indigo-400', bar: 'bg-indigo-500' },
    motivation: { border: 'border-emerald-500/25',bg: 'bg-emerald-500/10',color: 'text-emerald-400',bar: 'bg-emerald-500'},
  };
  const pc = pColors[personality.id] ?? pColors.discipline;

  return (
    <div
      className={`fixed bottom-20 lg:bottom-6 right-4 lg:right-6 z-50 w-[calc(100vw-2rem)] max-w-sm glass rounded-2xl border ${pc.border} shadow-2xl overflow-hidden`}
      style={{ animation: 'slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1)' }}
    >
      <div className={`h-0.5 ${pc.bar} transition-all duration-1000`} style={{ width: `${feedback.pctToTarget}%` }} />

      <div className="p-4 space-y-3">
        <div className="flex items-start gap-3">
          <div className={`w-9 h-9 rounded-xl ${pc.bg} border ${pc.border} flex items-center justify-center shrink-0 text-base`}>
            {personality.emoji}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className={`text-[10px] font-bold uppercase tracking-widest ${pc.color}`}>{personality.name}</p>
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${pc.bg} ${pc.color} border ${pc.border}`}>
                {feedback.tag}
              </span>
            </div>
          </div>
          <button onClick={dismissFeedback} className="text-white/25 hover:text-white/60 transition-colors shrink-0 mt-0.5">
            <X size={13} />
          </button>
        </div>

        <p className="text-white font-semibold text-sm leading-snug">{feedback.insight}</p>

        <div className={`flex items-start gap-2 px-3 py-2 rounded-xl ${pc.bg} border ${pc.border}`}>
          <Zap size={11} className={`${pc.color} mt-0.5 shrink-0`} />
          <p className={`text-xs ${pc.color} font-medium leading-snug`}>{feedback.action}</p>
        </div>

        {feedback.warning && (
          <div className="flex items-start gap-2 px-3 py-2 rounded-xl bg-red-500/8 border border-red-500/20">
            <AlertTriangle size={11} className="text-red-400 mt-0.5 shrink-0" />
            <p className="text-xs text-red-300/80 leading-snug">{feedback.warning}</p>
          </div>
        )}

        {feedback.taskInsight && (
          <p className="text-white/35 text-xs leading-snug border-t border-white/6 pt-2">{feedback.taskInsight}</p>
        )}

        <div className="flex items-center gap-3 pt-0.5">
          {feedback.streak > 0 && (
            <div className="flex items-center gap-1">
              <Flame size={10} className="text-orange-400" />
              <span className="text-orange-400/70 text-[10px]">{feedback.streak}d streak</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            <TrendingUp size={10} className="text-white/25" />
            <span className="text-white/25 text-[10px]">{feedback.pctToTarget}% to target</span>
          </div>
          {feedback.remaining > 0 && (
            <span className="text-white/20 text-[10px]">{feedback.remaining} pts left</span>
          )}
          <span className="ml-auto text-white/20 text-[10px]">{feedback.timestamp}</span>
        </div>
      </div>

      <style>{`
        @keyframes slideUp {
          from { transform: translateY(20px); opacity: 0; }
          to   { transform: translateY(0);    opacity: 1; }
        }
      `}</style>
    </div>
  );
}
