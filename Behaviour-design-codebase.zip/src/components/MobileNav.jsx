import { NavLink } from 'react-router-dom';
import { LayoutDashboard, CheckSquare, Trophy, TrendingUp, User, Puzzle } from 'lucide-react';

const mobileItems = [
  { to: '/',            icon: LayoutDashboard, label: 'Home'       },
  { to: '/tasks',       icon: CheckSquare,     label: 'Tasks'      },
  { to: '/sales',       icon: TrendingUp,      label: 'Sales'      },
  { to: '/plugins',     icon: Puzzle,          label: 'Plugins'    },
  { to: '/profile',     icon: User,            label: 'Profile'    },
];

export default function MobileNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/8 bg-[#0b0f1a]/95 backdrop-blur-xl px-2 pb-safe lg:hidden">
      <div className="flex items-center justify-around h-16">
        {mobileItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all ${
                isActive ? 'text-indigo-400' : 'text-white/35 hover:text-white/60'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <div className={`relative ${isActive ? 'scale-110' : ''} transition-transform`}>
                  <Icon size={20} strokeWidth={isActive ? 2.5 : 1.8} />
                  {isActive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-indigo-400" />
                  )}
                </div>
                <span className={`text-[9px] font-medium ${isActive ? 'text-indigo-400' : 'text-white/25'}`}>
                  {label}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
