import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './store/AuthContext';
import { BehaviorProvider } from './store/BehaviorContext';
import { NotificationsProvider } from './store/NotificationsContext';
import Layout from './components/Layout';
import AuthPage from './pages/AuthPage';
import Onboarding from './pages/Onboarding';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import Tasks from './pages/Tasks';
import Score from './pages/Score';
import Leaderboard from './pages/Leaderboard';
import SalesPlugin from './pages/SalesPlugin';
import Notifications from './pages/Notifications';
import Profile from './pages/Profile';
import AdminDashboard from './pages/AdminDashboard';
import Analytics from './pages/Analytics';
import Billing from './pages/Billing';
import PluginMarketplace from './pages/PluginMarketplace';
import DeploymentGuide from './pages/DeploymentGuide';
import SaaSStrategy from './pages/SaaSStrategy';
import SalesScript from './pages/SalesScript';
import PitchDeck from './pages/PitchDeck';
import CRM from './pages/CRM';
import CoachPersonality from './pages/CoachPersonality';
import ViralGrowth from './pages/ViralGrowth';
import AutoOnboarding from './pages/AutoOnboarding';
import InvestorDemo from './pages/InvestorDemo';
import MemoryEngine from './pages/MemoryEngine';
import GrowthSprint from './pages/GrowthSprint';
import PixelOnboarding from './pages/PixelOnboarding';
import CorpSalesDeck from './pages/CorpSalesDeck';
import AIEvolution from './pages/AIEvolution';
import AutoCRM from './pages/AutoCRM';
import MultiAgent from './pages/MultiAgent';
import RealtimePulse from './pages/RealtimePulse';
import GoalEngine from './pages/GoalEngine';
import AIChatCoach from './pages/AIChatCoach';
import RevenueTracker from './pages/RevenueTracker';
import ProductionRepo from './pages/ProductionRepo';
import GrowthEngine from './pages/GrowthEngine';
import PricingOptimizer from './pages/PricingOptimizer';
import AutonomousAI from './pages/AutonomousAI';
import CopyPasteRepo from './pages/CopyPasteRepo';
import InvestorPitch from './pages/InvestorPitch';
import TenKPlan from './pages/TenKPlan';
import AIv2 from './pages/AIv2';
import RepoFull from './pages/RepoFull';
import AcquisitionPlan from './pages/AcquisitionPlan';
import ClosingCRM from './pages/ClosingCRM';
import AIv3 from './pages/AIv3';
import ZipRepo from './pages/ZipRepo';
import DeployWalkthrough from './pages/DeployWalkthrough';
import RevenueScale from './pages/RevenueScale';
import AIv4 from './pages/AIv4';
import GitCommitRepo from './pages/GitCommitRepo';
import GrowthDomination from './pages/GrowthDomination';
import EnterpriseSales from './pages/EnterpriseSales';
import AIv5 from './pages/AIv5';
import FullCopyRepo from './pages/FullCopyRepo';
import AgentCodebase from './pages/AgentCodebase';
import HundredKPlan from './pages/HundredKPlan';
import PitchDemo from './pages/PitchDemo';
import RepoClean from './pages/RepoClean';
import FirstThousand from './pages/FirstThousand';
import EnterpriseAuto from './pages/EnterpriseAuto';
import AutonomousV6 from './pages/AutonomousV6';
import DeployableRepo from './pages/DeployableRepo';
import StripeBilling from './pages/StripeBilling';
import ViralLoop from './pages/ViralLoop';
import AIAgentOS from './pages/AIAgentOS';
import EnterpriseMultiTenant from './pages/EnterpriseMultiTenant';
import AutonomousV7 from './pages/AutonomousV7';
import InvestorPitchLive from './pages/InvestorPitchLive';
import HundredKPlaybook from './pages/HundredKPlaybook';
import DeployReadyRepo from './pages/DeployReadyRepo';
import BusinessPlan from './pages/BusinessPlan';
import FundingProposal from './pages/FundingProposal';

function AdminRoute({ children }) {
  const { can } = useAuth();
  return can('view_admin') ? children : <Navigate to="/" replace />;
}

function AppRoutes() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) return (
    <Routes>
      <Route path="/"           element={<LandingPage />} />
      <Route path="/onboarding" element={<Onboarding />}     />
      <Route path="/start"      element={<AutoOnboarding />}    />
      <Route path="/onboard"    element={<PixelOnboarding />}  />
      <Route path="/login"      element={<AuthPage />}    />
      <Route path="*"           element={<LandingPage />} />
    </Routes>
  );

  return (
    <BehaviorProvider>
      <NotificationsProvider>
        <Layout>
          <Routes>
            <Route path="/"              element={<Dashboard />}         />
            <Route path="/tasks"         element={<Tasks />}             />
            <Route path="/score"         element={<Score />}             />
            <Route path="/leaderboard"   element={<Leaderboard />}       />
            <Route path="/sales"         element={<SalesPlugin />}       />
            <Route path="/notifications" element={<Notifications />}     />
            <Route path="/profile"       element={<Profile />}           />
            <Route path="/plugins"       element={<PluginMarketplace />} />
            <Route path="/deploy"        element={<DeploymentGuide />}   />
            <Route path="/strategy"      element={<SaaSStrategy />}      />
            <Route path="/scripts"       element={<SalesScript />}       />
            <Route path="/pitch"         element={<PitchDeck />}         />
            <Route path="/crm"           element={<CRM />}               />
            <Route path="/coach"         element={<CoachPersonality />}  />
            <Route path="/growth"        element={<ViralGrowth />}       />
            <Route path="/demo"          element={<InvestorDemo />}      />
            <Route path="/memory"        element={<MemoryEngine />}      />
            <Route path="/sprint"        element={<GrowthSprint />}      />
            <Route path="/sales-deck"    element={<CorpSalesDeck />}     />
            <Route path="/evolution"     element={<AIEvolution />}       />
            <Route path="/auto-crm"      element={<AutoCRM />}           />
            <Route path="/agents"        element={<MultiAgent />}        />
            <Route path="/pulse"         element={<RealtimePulse />}     />
            <Route path="/goals"         element={<GoalEngine />}        />
            <Route path="/chat"          element={<AIChatCoach />}       />
            <Route path="/revenue"       element={<RevenueTracker />}    />
            <Route path="/repo"          element={<ProductionRepo />}    />
            <Route path="/scale"         element={<GrowthEngine />}      />
            <Route path="/pricing"       element={<PricingOptimizer />}  />
            <Route path="/autonomous"    element={<AutonomousAI />}      />
            <Route path="/copy-repo"     element={<CopyPasteRepo />}     />
            <Route path="/pitch-demo"    element={<PitchDemo />}         />
            <Route path="/ten-k"         element={<TenKPlan />}          />
            <Route path="/ai-v2"         element={<AIv2 />}              />
            <Route path="/repo-full"     element={<RepoFull />}          />
            <Route path="/acquire"       element={<AcquisitionPlan />}   />
            <Route path="/closing"       element={<ClosingCRM />}        />
            <Route path="/ai-v3"         element={<AIv3 />}              />
            <Route path="/zip-repo"      element={<ZipRepo />}           />
            <Route path="/live-deploy"   element={<DeployWalkthrough />} />
            <Route path="/rev-scale"     element={<RevenueScale />}      />
            <Route path="/ai-v4"         element={<AIv4 />}              />
            <Route path="/git-commits"   element={<GitCommitRepo />}     />
            <Route path="/growth-90"     element={<GrowthDomination />}  />
            <Route path="/enterprise"    element={<EnterpriseSales />}   />
            <Route path="/ai-v5"         element={<AIv5 />}              />
            <Route path="/full-repo"     element={<FullCopyRepo />}      />
            <Route path="/agent-code"    element={<AgentCodebase />}     />
            <Route path="/100k-plan"     element={<HundredKPlan />}      />
            <Route path="/repo-clean"    element={<RepoClean />}         />
            <Route path="/first-1k"      element={<FirstThousand />}     />
            <Route path="/ent-auto"      element={<EnterpriseAuto />}    />
            <Route path="/auto-v6"          element={<AutonomousV6 />}      />
            <Route path="/deploy-repo"      element={<DeployableRepo />}         />
            <Route path="/stripe-billing"   element={<StripeBilling />}          />
            <Route path="/viral-loop"       element={<ViralLoop />}              />
            <Route path="/ai-agent-os"      element={<AIAgentOS />}              />
            <Route path="/enterprise-mt"    element={<EnterpriseMultiTenant />}  />
            <Route path="/auto-v7"          element={<AutonomousV7 />}           />
            <Route path="/pitch-live"       element={<InvestorPitchLive />}      />
            <Route path="/100k-playbook"    element={<HundredKPlaybook />}       />
            <Route path="/deploy-ready"     element={<DeployReadyRepo />}        />
            <Route path="/business-plan"    element={<BusinessPlan />}           />
            <Route path="/funding-proposal" element={<FundingProposal />}        />
            {/* Admin-only */}
            <Route path="/admin"     element={<AdminRoute><AdminDashboard /></AdminRoute>} />
            <Route path="/analytics" element={<AdminRoute><Analytics /></AdminRoute>}     />
            <Route path="/billing"   element={<AdminRoute><Billing /></AdminRoute>}       />
          </Routes>
        </Layout>
      </NotificationsProvider>
    </BehaviorProvider>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
