import { useState, useEffect, useRef } from 'react';
import {
  Share2, Users, Gift, TrendingUp, Copy, CheckCheck,
  ArrowRight, Zap, Link2, MessageSquare, Mail, Star,
  RefreshCw, Target, BarChart2, Code2, ChevronRight,
} from 'lucide-react';

// ── Loop stages ────────────────────────────────────────────────────────────────
const LOOP_STAGES = [
  { id: 'execute',  icon: Target,    label: 'User Executes',    desc: 'Completes tasks, hits 80%+ score',               color: 'bg-green-500'  },
  { id: 'score',    icon: Star,      label: 'Score Generated',  desc: 'System generates shareable execution score card', color: 'bg-amber-500'  },
  { id: 'share',    icon: Share2,    label: 'User Shares',      desc: 'Shares card to LinkedIn, WhatsApp, Twitter',     color: 'bg-blue-500'   },
  { id: 'click',    icon: Link2,     label: 'Friend Clicks',    desc: 'Lands on signup page with referral pre-filled',  color: 'bg-violet-500' },
  { id: 'join',     icon: Users,     label: 'New User Joins',   desc: 'Signs up, referrer earns $10 credit',            color: 'bg-pink-500'   },
  { id: 'loop',     icon: RefreshCw, label: 'Loop Repeats',     desc: 'New user executes → generates score → shares',  color: 'bg-green-500'  },
];

// ── Channel configs ────────────────────────────────────────────────────────────
const CHANNELS = [
  {
    id: 'linkedin',
    label: 'LinkedIn',
    icon: '🔵',
    template: `Just hit an {score}/100 execution score on Behavior Engine.\n\nTracked: {tasks_done} tasks completed today.\n\nIf you're serious about daily execution — join me:\n{referral_link}`,
    k: 0.31,
    note: 'Highest quality B2B leads. Post 3x/week for compounding reach.',
  },
  {
    id: 'whatsapp',
    label: 'WhatsApp',
    icon: '🟢',
    template: `Hey! I've been using Behavior Engine to track my execution.\nMy score today: {score}/100 ✅\n\nYou should try it — here's my referral link:\n{referral_link}`,
    k: 0.44,
    note: 'Highest conversion. 1-to-1 warm intros convert at 40%+.',
  },
  {
    id: 'twitter',
    label: 'Twitter/X',
    icon: '⚫',
    template: `Execution score: {score}/100 today.\n{tasks_done} tasks done.\n\nBuilding in public with @BehaviorEngine\n\nJoin me: {referral_link}`,
    k: 0.18,
    note: 'Lower conversion but massive reach. Tag relevant accounts.',
  },
  {
    id: 'email',
    label: 'Email',
    icon: '📧',
    template: `Subject: My execution score this week\n\nHey {name},\n\nBeen tracking my daily execution with Behavior Engine.\nThis week's average: {score}/100.\n\nThought you might find it useful — here's my referral link (you get 7 days free):\n{referral_link}\n\nLet me know if you try it.`,
    k: 0.22,
    note: 'Personal email to warm contacts. Highest trust, 1-to-1.',
  },
];

// ── Referral code snippets ────────────────────────────────────────────────────
const CODE = {
  'referral-service.js': `const { createClient } = require('@supabase/supabase-js');
const db = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);

/**
 * generateReferralCode — deterministic 8-char code from userId
 */
function generateReferralCode(userId) {
  return userId.replace(/-/g, '').slice(0, 8).toUpperCase();
}

/**
 * recordReferral — called at signup when ?ref=CODE in URL
 */
async function recordReferral(newUserId, referralCode) {
  // Find referrer
  const { data: referrer } = await db
    .from('profiles')
    .select('id')
    .eq('referral_code', referralCode)
    .single();

  if (!referrer) return;

  // Log the referral
  await db.from('referrals').insert({
    referrer_id: referrer.id,
    referred_id: newUserId,
    status:      'pending',
  });

  console.log(\`[Referral] \${referrer.id} referred \${newUserId}\`);
}

/**
 * rewardReferral — called when referred user subscribes
 * Awards $10 credit to referrer
 */
async function rewardReferral(referredUserId) {
  const { data: ref } = await db
    .from('referrals')
    .select('*')
    .eq('referred_id', referredUserId)
    .eq('status', 'pending')
    .single();

  if (!ref) return;

  // Mark rewarded
  await db.from('referrals').update({ status: 'rewarded' }).eq('id', ref.id);

  // Add $10 credit to referrer (apply to next invoice via Stripe)
  const { data: referrer } = await db
    .from('profiles')
    .select('stripe_customer_id')
    .eq('id', ref.referrer_id)
    .single();

  if (referrer?.stripe_customer_id) {
    const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
    await stripe.customers.createBalanceTransaction(
      referrer.stripe_customer_id,
      { amount: -1000, currency: 'usd', description: 'Referral reward' }
    );
  }
}

module.exports = { generateReferralCode, recordReferral, rewardReferral };`,

  'supabase/referral-schema.sql': `-- Referral code on profiles
alter table public.profiles
  add column if not exists referral_code text unique,
  add column if not exists credits_cents int not null default 0;

-- Auto-generate referral code on profile creation
create or replace function public.set_referral_code()
returns trigger language plpgsql as $$
begin
  new.referral_code := upper(substring(replace(new.id::text, '-', '') from 1 for 8));
  return new;
end;
$$;

create trigger trg_set_referral_code
  before insert on public.profiles
  for each row execute procedure public.set_referral_code();

-- Referrals table
create table if not exists public.referrals (
  id           uuid primary key default gen_random_uuid(),
  referrer_id  uuid not null references public.profiles(id),
  referred_id  uuid not null references public.profiles(id),
  status       text not null default 'pending',  -- pending | rewarded | expired
  rewarded_at  timestamptz,
  created_at   timestamptz default now(),
  unique(referred_id)   -- one referrer per new user
);

-- Share events (track what gets shared for analytics)
create table if not exists public.share_events (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references public.profiles(id),
  channel    text not null,    -- linkedin | whatsapp | twitter | email
  score      int,
  created_at timestamptz default now()
);`,

  'viral-trigger.js': `/**
 * viralTriggers — fire after key user actions
 * Import and call from task completion + weekly report routes
 */

const TRIGGER_THRESHOLDS = {
  score_milestone: [50, 75, 90, 100],
  streak_days:     [3, 7, 14, 30],
  tasks_completed: [10, 50, 100],
};

function shouldTriggerShare(user) {
  const { score, streak, tasks_total } = user;

  // Score milestone
  if (TRIGGER_THRESHOLDS.score_milestone.includes(score))
    return { reason: 'score_milestone', message: \`You just hit \${score}/100!\` };

  // Streak
  if (TRIGGER_THRESHOLDS.streak_days.includes(streak))
    return { reason: 'streak', message: \`\${streak}-day execution streak!\` };

  // Volume
  if (TRIGGER_THRESHOLDS.tasks_completed.includes(tasks_total))
    return { reason: 'volume', message: \`\${tasks_total} tasks crushed!\` };

  return null;
}

/**
 * generateShareCard — data for frontend to render OG card
 */
function generateShareCard(user) {
  return {
    title:        'My Execution Score',
    score:        user.score,
    streak:       user.streak,
    tasks:        user.tasks_today,
    status:       user.score >= 80 ? 'ELITE' : user.score >= 60 ? 'ACTIVE' : 'BUILDING',
    referral_url: \`https://behaviorengine.app/join?ref=\${user.referral_code}\`,
    og_image_url: \`https://behaviorengine.app/api/og?score=\${user.score}&ref=\${user.referral_code}\`,
  };
}

module.exports = { shouldTriggerShare, generateShareCard };`,
};

// ── K-factor calculator state ─────────────────────────────────────────────────
const KF_DEFAULTS = { users: 100, shareRate: 40, clickRate: 25, convRate: 20 };

export default function ViralLoop() {
  const [tab,       setTab]      = useState('loop');
  const [channel,   setChannel]  = useState('whatsapp');
  const [codeFile,  setCodeFile] = useState('referral-service.js');
  const [copied,    setCopied]   = useState('');
  const [kf,        setKf]       = useState(KF_DEFAULTS);
  const [stage,     setStage]    = useState(0);
  const timerRef = useRef(null);

  // Animate loop stages
  useEffect(() => {
    if (tab !== 'loop') return;
    timerRef.current = setInterval(() => {
      setStage(s => (s + 1) % LOOP_STAGES.length);
    }, 1400);
    return () => clearInterval(timerRef.current);
  }, [tab]);

  function copy(key) {
    navigator.clipboard.writeText(CODE[key] || '');
    setCopied(key);
    setTimeout(() => setCopied(''), 1800);
  }

  // K-factor math
  const invitesPerUser = (kf.shareRate / 100) * 3.2; // avg 3.2 contacts per share
  const convPerUser    = invitesPerUser * (kf.clickRate / 100) * (kf.convRate / 100);
  const kFactor        = Math.round(convPerUser * 100) / 100;
  const monthlyGrowth  = kFactor >= 1
    ? 'Exponential (viral)'
    : `+${Math.round(kf.users * kFactor)} new users/cycle`;

  const TABS = [
    { id: 'loop',     label: 'Viral Loop'      },
    { id: 'channels', label: 'Share Templates' },
    { id: 'kfactor',  label: 'K-Factor Calc'   },
    { id: 'code',     label: 'Backend Code'    },
  ];

  const ch = CHANNELS.find(c => c.id === channel);

  return (
    <div className="min-h-screen bg-gray-950 text-white p-4 md:p-6">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="mb-6 flex items-start gap-4">
          <div className="p-2.5 bg-pink-900/40 rounded-xl border border-pink-700/50">
            <TrendingUp size={24} className="text-pink-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black">Viral Loop Engine</h1>
            <p className="text-gray-400 text-sm mt-0.5">
              Referral system + share triggers + K-factor optimizer
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-gray-900 p-1 rounded-xl w-fit border border-gray-800">
          {TABS.map(({ id, label }) => (
            <button key={id} onClick={() => setTab(id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition
                ${tab === id ? 'bg-pink-600 text-white' : 'text-gray-400 hover:text-white'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* ── VIRAL LOOP ── */}
        {tab === 'loop' && (
          <div className="space-y-6">
            {/* Animated loop */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-5">Live Loop Animation</p>
              <div className="flex flex-wrap items-center gap-2">
                {LOOP_STAGES.map(({ id, icon: Icon, label, color }, i) => (
                  <div key={id} className="flex items-center gap-2">
                    <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition-all duration-500
                      ${stage === i
                        ? `${color} border-transparent text-white scale-110 shadow-lg`
                        : 'bg-gray-800 border-gray-700 text-gray-400'}`}>
                      <Icon size={14} />
                      <span className="text-xs font-semibold whitespace-nowrap">{label}</span>
                    </div>
                    {i < LOOP_STAGES.length - 1 && (
                      <ArrowRight size={14} className="text-gray-600 flex-shrink-0" />
                    )}
                  </div>
                ))}
              </div>
              {/* Active stage detail */}
              <div className="mt-5 p-4 bg-gray-950 rounded-xl border border-gray-800 min-h-[52px]">
                <p className="text-sm text-gray-300">{LOOP_STAGES[stage].desc}</p>
              </div>
            </div>

            {/* Loop mechanics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                {
                  title: 'Trigger Points',
                  icon: Zap,
                  color: 'text-amber-400',
                  items: [
                    'Score hits milestone (50, 75, 90, 100)',
                    '3, 7, 14, 30-day streak reached',
                    '10, 50, 100 tasks completed',
                    'Weekly report generated',
                    'Plan upgrade completed',
                  ],
                },
                {
                  title: 'Share Channels',
                  icon: Share2,
                  color: 'text-blue-400',
                  items: [
                    'LinkedIn post (B2B leads)',
                    'WhatsApp direct (warm intros)',
                    'Twitter/X (reach)',
                    'Email to contacts',
                    'OG image card (auto-generated)',
                  ],
                },
                {
                  title: 'Reward System',
                  icon: Gift,
                  color: 'text-pink-400',
                  items: [
                    '$10 Stripe credit per referral',
                    'Applied to next invoice auto',
                    'Referrer dashboard with stats',
                    'Top referrer leaderboard',
                    'Bonus: 3 referrals = 1 free month',
                  ],
                },
              ].map(({ title, icon: Icon, color, items }) => (
                <div key={title} className="bg-gray-900 rounded-xl border border-gray-800 p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Icon size={15} className={color} />
                    <span className="font-semibold text-sm">{title}</span>
                  </div>
                  <ul className="space-y-1.5">
                    {items.map(item => (
                      <li key={item} className="flex items-start gap-2 text-xs text-gray-300">
                        <ChevronRight size={11} className="text-gray-600 mt-0.5 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── SHARE TEMPLATES ── */}
        {tab === 'channels' && (
          <div className="space-y-4">
            <div className="flex gap-2 flex-wrap">
              {CHANNELS.map(({ id, label, icon, k }) => (
                <button key={id} onClick={() => setChannel(id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border transition
                    ${channel === id
                      ? 'bg-pink-600 border-pink-500 text-white'
                      : 'bg-gray-900 border-gray-700 text-gray-400 hover:text-white'}`}>
                  <span>{icon}</span>
                  {label}
                  <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold
                    ${k >= 0.4 ? 'bg-green-700 text-green-200' : 'bg-gray-700 text-gray-300'}`}>
                    k={k}
                  </span>
                </button>
              ))}
            </div>

            {ch && (
              <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
                <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{ch.icon}</span>
                    <div>
                      <p className="font-semibold">{ch.label} Template</p>
                      <p className="text-xs text-gray-400">{ch.note}</p>
                    </div>
                  </div>
                  <button onClick={() => copy(ch.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-800
                               hover:bg-gray-700 text-xs transition">
                    {copied === ch.id ? <CheckCheck size={12} className="text-green-400"/> : <Copy size={12}/>}
                    Copy
                  </button>
                </div>
                <div className="p-5">
                  <pre className="text-sm text-gray-200 whitespace-pre-wrap leading-relaxed font-sans">
                    {ch.template}
                  </pre>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {['{score}', '{tasks_done}', '{referral_link}', '{name}'].map(v => (
                      <span key={v} className="px-2 py-0.5 bg-amber-900/30 border border-amber-700/40
                                               text-amber-300 text-xs font-mono rounded">
                        {v}
                      </span>
                    ))}
                    <span className="text-xs text-gray-500 self-center">← replace with user data</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── K-FACTOR ── */}
        {tab === 'kfactor' && (
          <div className="space-y-5 max-w-2xl">
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <h3 className="font-semibold mb-1">K-Factor Calculator</h3>
              <p className="text-xs text-gray-400 mb-5">
                K = invites_sent × click_rate × conversion_rate. K &gt; 1 = viral.
              </p>
              <div className="space-y-4">
                {[
                  { key: 'users',      label: 'Active users',           min: 10,   max: 10000, step: 10  },
                  { key: 'shareRate',  label: 'Share rate (%)',          min: 1,    max: 100,   step: 1   },
                  { key: 'clickRate',  label: 'Click-through rate (%)',  min: 1,    max: 100,   step: 1   },
                  { key: 'convRate',   label: 'Signup conversion (%)',   min: 1,    max: 100,   step: 1   },
                ].map(({ key, label, min, max, step }) => (
                  <div key={key}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-300">{label}</span>
                      <span className="text-white font-semibold">{kf[key]}{key !== 'users' ? '%' : ''}</span>
                    </div>
                    <input type="range" min={min} max={max} step={step} value={kf[key]}
                      onChange={e => setKf(prev => ({ ...prev, [key]: +e.target.value }))}
                      className="w-full accent-pink-500" />
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'K-Factor',        val: kFactor,       color: kFactor >= 1 ? 'text-green-400' : kFactor >= 0.5 ? 'text-amber-400' : 'text-red-400' },
                { label: 'Invites/user',    val: invitesPerUser.toFixed(2), color: 'text-white' },
                { label: 'New users/cycle', val: Math.round(kf.users * convPerUser), color: 'text-white' },
                { label: 'Growth mode',     val: kFactor >= 1 ? 'VIRAL' : 'LINEAR', color: kFactor >= 1 ? 'text-green-400' : 'text-amber-400' },
              ].map(({ label, val, color }) => (
                <div key={label} className="bg-gray-900 rounded-xl border border-gray-800 p-4 text-center">
                  <p className={`text-2xl font-black ${color}`}>{val}</p>
                  <p className="text-xs text-gray-500 mt-1">{label}</p>
                </div>
              ))}
            </div>

            <div className={`rounded-xl border p-4 text-sm
              ${kFactor >= 1 ? 'bg-green-900/20 border-green-700/40 text-green-200' :
                kFactor >= 0.5 ? 'bg-amber-900/20 border-amber-700/40 text-amber-200' :
                'bg-red-900/20 border-red-700/40 text-red-200'}`}>
              {kFactor >= 1 && 'Viral — each user brings more than 1 new user. Growth is compounding.'}
              {kFactor >= 0.5 && kFactor < 1 && 'Sub-viral but healthy. Focus on improving share rate and conversion.'}
              {kFactor < 0.5 && 'Needs work. Increase share triggers, improve landing page conversion, warm up channels.'}
            </div>
          </div>
        )}

        {/* ── CODE ── */}
        {tab === 'code' && (
          <div className="flex gap-4 h-[70vh]">
            <div className="w-52 flex-shrink-0 bg-gray-900 rounded-xl border border-gray-800 overflow-y-auto">
              <p className="px-3 py-2 text-xs text-gray-500 uppercase tracking-wider border-b border-gray-800">Files</p>
              {Object.keys(CODE).map(k => (
                <button key={k} onClick={() => setCodeFile(k)}
                  className={`w-full text-left px-3 py-2 text-xs font-mono transition
                    ${codeFile === k
                      ? 'bg-pink-900/40 text-pink-300 border-r-2 border-pink-500'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}>
                  {k}
                </button>
              ))}
            </div>
            <div className="flex-1 bg-gray-900 rounded-xl border border-gray-800 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
                <span className="text-sm font-mono text-gray-300">{codeFile}</span>
                <button onClick={() => copy(codeFile)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-800
                             hover:bg-gray-700 text-xs transition">
                  {copied === codeFile ? <CheckCheck size={12} className="text-green-400"/> : <Copy size={12}/>}
                  {copied === codeFile ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="flex-1 overflow-auto p-4 text-xs text-gray-300 font-mono leading-relaxed">
                {CODE[codeFile]}
              </pre>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
