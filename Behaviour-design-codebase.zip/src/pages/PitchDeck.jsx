import { useState } from 'react';
import {
  ChevronLeft, ChevronRight, Maximize2, Zap,
  TrendingUp, BarChart2, Users, DollarSign, Shield,
  Bot, Smartphone, Puzzle, Globe, Flame, Target,
  ArrowRight, CheckCircle2, Star,
} from 'lucide-react';
import MobileHeader from '../components/MobileHeader';

const SLIDES = [
  {
    id: 1,
    label: 'Title',
    color: 'from-indigo-600/20 to-purple-600/10',
    borderColor: 'border-indigo-500/20',
    render: () => (
      <div className="flex flex-col items-center justify-center h-full text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-indigo-500 flex items-center justify-center shadow-2xl shadow-indigo-500/40">
          <Zap size={28} className="text-white" />
        </div>
        <div>
          <h1 className="text-4xl lg:text-5xl font-black text-white mb-3 tracking-tight">Behavior Engine</h1>
          <p className="text-indigo-300 text-xl font-semibold mb-2">The Execution Operating System for Teams</p>
          <p className="text-white/35 text-base max-w-md mx-auto">
            We turn daily work into measurable, improvable, AI-coached behavior — for every team in every industry.
          </p>
        </div>
        <div className="flex items-center gap-6 pt-4">
          {[['Series A', 'Funding Stage'], ['$500K', 'Seed Ask'], ['Q3 2026', 'Target Close']].map(([v, l]) => (
            <div key={l} className="text-center">
              <p className="text-white font-black text-xl">{v}</p>
              <p className="text-white/30 text-xs">{l}</p>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 2,
    label: 'Problem',
    color: 'from-red-600/15 to-orange-600/8',
    borderColor: 'border-red-500/20',
    render: () => (
      <div className="h-full space-y-6">
        <div>
          <p className="text-red-400 text-xs font-bold uppercase tracking-widest mb-2">The Problem</p>
          <h2 className="text-3xl lg:text-4xl font-black text-white leading-tight">
            Teams don't fail because of knowledge.
            <br />
            <span className="text-red-400">They fail because of inconsistent execution.</span>
          </h2>
        </div>
        <div className="grid lg:grid-cols-2 gap-3 mt-4">
          {[
            { icon: '📉', stat: '67%', text: 'of sales reps miss quota due to poor daily activity habits', source: 'Salesforce Research' },
            { icon: '😤', stat: '82%', text: 'of managers cannot see who is actually executing daily', source: 'HBR 2024' },
            { icon: '🔁', stat: '$1.5T', text: 'lost annually in productivity from lack of consistent execution', source: 'McKinsey' },
            { icon: '🏳️', stat: '73%', text: 'of behavior change programs fail within 90 days without tracking', source: 'MIT Sloan' },
          ].map(({ icon, stat, text, source }) => (
            <div key={stat} className="p-4 rounded-2xl bg-red-500/6 border border-red-500/15">
              <div className="flex items-start gap-3">
                <span className="text-2xl">{icon}</span>
                <div>
                  <p className="text-red-400 font-black text-2xl leading-none mb-1">{stat}</p>
                  <p className="text-white/60 text-sm leading-snug">{text}</p>
                  <p className="text-white/20 text-[10px] mt-1">{source}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 3,
    label: 'Solution',
    color: 'from-indigo-600/15 to-purple-600/8',
    borderColor: 'border-indigo-500/20',
    render: () => (
      <div className="h-full space-y-6">
        <div>
          <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest mb-2">The Solution</p>
          <h2 className="text-3xl lg:text-4xl font-black text-white">
            We turn work into structured daily behavior.
          </h2>
          <p className="text-white/40 text-base mt-2">One system. Any team. Any industry.</p>
        </div>
        <div className="grid lg:grid-cols-2 gap-4">
          {[
            { icon: Target,    color: 'text-indigo-400', bg: 'bg-indigo-500/10', title: 'Assign Daily Tasks', desc: 'Pre-configured behavior plugins per industry. Sales, Operations, Education, and more.' },
            { icon: BarChart2, color: 'text-purple-400', bg: 'bg-purple-500/10', title: 'Track Real Execution', desc: 'Every action logged, timestamped, and scored. Managers see live execution rates.' },
            { icon: Flame,     color: 'text-orange-400', bg: 'bg-orange-500/10', title: 'Score Performance', desc: 'GREEN / YELLOW / RED status system. Streak tracking. 7-day pattern analysis.' },
            { icon: Bot,       color: 'text-emerald-400', bg: 'bg-emerald-500/10', title: 'AI Coaching Engine', desc: 'Context-aware coaching per user. Detects slow starters, week faders, chronic underperformers.' },
          ].map(({ icon: Icon, color, bg, title, desc }) => (
            <div key={title} className={`flex items-start gap-3 p-4 rounded-2xl ${bg} border border-white/6`}>
              <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center shrink-0`}>
                <Icon size={18} className={color} />
              </div>
              <div>
                <p className={`font-bold text-sm ${color} mb-0.5`}>{title}</p>
                <p className="text-white/50 text-xs leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 4,
    label: 'How It Works',
    color: 'from-cyan-600/10 to-indigo-600/10',
    borderColor: 'border-cyan-500/20',
    render: () => (
      <div className="h-full space-y-5">
        <div>
          <p className="text-cyan-400 text-xs font-bold uppercase tracking-widest mb-2">Product Flow</p>
          <h2 className="text-3xl font-black text-white">From signup to behavior change in 7 days.</h2>
        </div>
        <div className="space-y-3">
          {[
            { n: '01', title: 'Tenant Onboarding', sub: '< 10 min', desc: 'Company signs up, selects industry plugin, invites team members. Multi-tenant isolation from day 1.', color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
            { n: '02', title: 'Daily Action Logging', sub: 'One tap', desc: 'Team members log each action in the app. No forms, no reports. One tap = one logged behavior.', color: 'text-purple-400', bg: 'bg-purple-500/10' },
            { n: '03', title: 'AI Pattern Analysis', sub: 'Real-time', desc: 'Engine detects drop patterns, streak gaps, role-based performance. Generates specific coaching per user.', color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
            { n: '04', title: 'Admin Execution Dashboard', sub: 'Live', desc: 'Managers see execution rate, at-risk users, team trend charts. Weekly reviews become data-driven.', color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
          ].map(({ n, title, sub, desc, color, bg }) => (
            <div key={n} className={`flex items-start gap-4 p-4 rounded-xl ${bg} border border-white/6`}>
              <div className="flex-col items-center text-center shrink-0">
                <p className={`text-xl font-black font-mono ${color}`}>{n}</p>
                <p className={`text-[9px] font-bold ${color} opacity-60 whitespace-nowrap`}>{sub}</p>
              </div>
              <div className="flex-1">
                <p className={`text-sm font-bold ${color} mb-0.5`}>{title}</p>
                <p className="text-white/45 text-xs leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 5,
    label: 'Market',
    color: 'from-emerald-600/10 to-teal-600/8',
    borderColor: 'border-emerald-500/20',
    render: () => (
      <div className="h-full space-y-5">
        <div>
          <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-2">Market Opportunity</p>
          <h2 className="text-3xl font-black text-white">
            Every team is a potential customer.
          </h2>
        </div>
        <div className="grid lg:grid-cols-3 gap-3">
          {[
            { label: 'TAM', value: '$47B', sub: 'Global performance management software', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
            { label: 'SAM', value: '$8.2B', sub: 'SME + mid-market team execution tools', color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
            { label: 'SOM', value: '$320M', sub: 'Reachable within 3 years with current GTM', color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
          ].map(({ label, value, sub, color, bg, border }) => (
            <div key={label} className={`text-center p-5 rounded-2xl ${bg} border ${border}`}>
              <p className="text-white/30 text-xs font-bold uppercase tracking-widest mb-2">{label}</p>
              <p className={`text-4xl font-black ${color} mb-2`}>{value}</p>
              <p className="text-white/40 text-xs">{sub}</p>
            </div>
          ))}
        </div>
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest mb-2">Target Verticals</p>
          <div className="flex flex-wrap gap-2">
            {[
              { icon: '💼', label: 'Sales Teams', size: '12M+ globally' },
              { icon: '🎓', label: 'Education', size: '1.5B students' },
              { icon: '🚛', label: 'Operations', size: 'Every supply chain' },
              { icon: '🏋️', label: 'Fitness', size: '$96B industry' },
              { icon: '⚡', label: 'Engineering', size: '27M developers' },
              { icon: '🔧', label: 'Custom', size: 'Enterprise only' },
            ].map(({ icon, label, size }) => (
              <div key={label} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/4 border border-white/8">
                <span>{icon}</span>
                <div>
                  <p className="text-white/70 text-xs font-semibold">{label}</p>
                  <p className="text-white/25 text-[9px]">{size}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 6,
    label: 'Business Model',
    color: 'from-yellow-600/10 to-amber-600/8',
    borderColor: 'border-yellow-500/20',
    render: () => (
      <div className="h-full space-y-5">
        <div>
          <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest mb-2">Business Model</p>
          <h2 className="text-3xl font-black text-white">Multiple compounding revenue streams.</h2>
        </div>
        <div className="grid lg:grid-cols-3 gap-3">
          {[
            { label: 'SaaS Subscriptions', icon: DollarSign, color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', points: ['Starter $49/team/mo', 'Pro $99/team/mo', 'Enterprise custom', 'Per-user pricing at scale'], rev: 'Primary revenue' },
            { label: 'Plugin Marketplace', icon: Puzzle, color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20', points: ['Plugin subscription fees', '30% revenue share from 3rd party creators', 'Industry-specific bundles', 'Plugin API access'], rev: 'Platform revenue' },
            { label: 'Enterprise Licensing', icon: Shield, color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20', points: ['Custom plugin development', 'White-label licensing', 'API integrations', 'Dedicated success manager'], rev: 'High-ACV revenue' },
          ].map(({ label, icon: Icon, color, bg, border, points, rev }) => (
            <div key={label} className={`p-5 rounded-2xl ${bg} border ${border}`}>
              <div className="flex items-center gap-2.5 mb-3">
                <Icon size={16} className={color} />
                <p className={`font-bold text-sm ${color}`}>{label}</p>
              </div>
              <div className="space-y-1.5 mb-3">
                {points.map(p => (
                  <div key={p} className="flex items-center gap-2">
                    <CheckCircle2 size={9} className="text-green-400 shrink-0" />
                    <p className="text-white/55 text-xs">{p}</p>
                  </div>
                ))}
              </div>
              <div className={`text-[10px] font-bold px-2 py-1 rounded-lg ${bg} ${color} border ${border} inline-block`}>
                {rev}
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Avg Contract Value', value: '$1,200/yr', sub: 'per team' },
            { label: 'Gross Margin Target', value: '85%+', sub: 'SaaS benchmark' },
            { label: 'LTV / CAC Ratio', value: '8:1', sub: 'at scale' },
          ].map(({ label, value, sub }) => (
            <div key={label} className="text-center p-3 rounded-xl bg-white/3 border border-white/6">
              <p className="text-white font-black text-xl">{value}</p>
              <p className="text-white/30 text-xs">{label}</p>
              <p className="text-white/15 text-[9px]">{sub}</p>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 7,
    label: 'Traction',
    color: 'from-orange-600/10 to-pink-600/8',
    borderColor: 'border-orange-500/20',
    render: () => (
      <div className="h-full space-y-5">
        <div>
          <p className="text-orange-400 text-xs font-bold uppercase tracking-widest mb-2">Traction</p>
          <h2 className="text-3xl font-black text-white">Built, live, and running pilots.</h2>
        </div>
        <div className="grid lg:grid-cols-2 gap-3">
          {[
            { metric: '3 tenants', sub: 'Multi-tenant system live with Sales, Education, Fitness plugins', icon: Users, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
            { metric: '7 users', sub: 'Across 3 organizations in active pilot tracking', icon: Flame, color: 'text-orange-400', bg: 'bg-orange-500/10' },
            { metric: '6 plugins', sub: 'Marketplace modules: Sales, Fitness, School, Logistics, Dev, E-Commerce', icon: Puzzle, color: 'text-purple-400', bg: 'bg-purple-500/10' },
            { metric: 'AI live', sub: 'Behavior pattern detection: 8 drop patterns, streak analysis, role coaching', icon: Bot, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
          ].map(({ metric, sub, icon: Icon, color, bg }) => (
            <div key={metric} className={`flex items-center gap-4 p-4 rounded-2xl ${bg} border border-white/6`}>
              <Icon size={20} className={`${color} shrink-0`} />
              <div>
                <p className={`text-2xl font-black ${color}`}>{metric}</p>
                <p className="text-white/45 text-xs leading-snug">{sub}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="p-4 rounded-2xl bg-white/3 border border-white/6">
          <p className="text-white/25 text-[10px] uppercase tracking-widest mb-2">Product Completeness</p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { label: 'Core Engine', pct: 100 },
              { label: 'Multi-Tenant Auth', pct: 100 },
              { label: 'Plugin System', pct: 100 },
              { label: 'AI Coach', pct: 85 },
              { label: 'Admin Dashboard', pct: 100 },
              { label: 'Mobile UI', pct: 95 },
              { label: 'Billing (Stripe)', pct: 40 },
              { label: 'OpenAI API', pct: 30 },
            ].map(({ label, pct }) => (
              <div key={label}>
                <div className="flex items-center justify-between mb-1">
                  <p className="text-white/40 text-[10px]">{label}</p>
                  <p className="text-white/30 text-[10px] font-bold">{pct}%</p>
                </div>
                <div className="h-1 bg-white/8 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 8,
    label: 'Product',
    color: 'from-purple-600/10 to-indigo-600/8',
    borderColor: 'border-purple-500/20',
    render: () => (
      <div className="h-full space-y-5">
        <div>
          <p className="text-purple-400 text-xs font-bold uppercase tracking-widest mb-2">Product Architecture</p>
          <h2 className="text-3xl font-black text-white">Full-stack SaaS platform. Production-ready.</h2>
        </div>
        <div className="grid lg:grid-cols-2 gap-4">
          {[
            {
              layer: 'Frontend', icon: Smartphone, color: 'text-indigo-400', bg: 'bg-indigo-500/10',
              items: ['Vite + React 18 + Tailwind CSS', 'Mobile-first responsive design', 'Dark glassmorphism UI system', 'Vercel-deployed, auto-redeploy on push'],
            },
            {
              layer: 'Backend', icon: Shield, color: 'text-emerald-400', bg: 'bg-emerald-500/10',
              items: ['Node.js + Express API', 'Supabase PostgreSQL', 'JWT authentication (multi-tenant)', 'Railway hosting — live URL in minutes'],
            },
            {
              layer: 'AI Engine', icon: Bot, color: 'text-purple-400', bg: 'bg-purple-500/10',
              items: ['8 behavioral drop patterns detected', 'Streak + role-aware coaching', 'OpenAI GPT-4o-mini ready (drop-in)', 'Context model: history + streak + role'],
            },
            {
              layer: 'Plugin Platform', icon: Puzzle, color: 'text-cyan-400', bg: 'bg-cyan-500/10',
              items: ['Plugin registry with marketplace visibility', 'Custom scoring rules per plugin', 'AI coaching rules per plugin', 'Creator revenue share ready'],
            },
          ].map(({ layer, icon: Icon, color, bg, items }) => (
            <div key={layer} className={`p-4 rounded-2xl ${bg} border border-white/6`}>
              <div className="flex items-center gap-2 mb-3">
                <Icon size={14} className={color} />
                <p className={`text-sm font-bold ${color}`}>{layer}</p>
              </div>
              <div className="space-y-1.5">
                {items.map(item => (
                  <div key={item} className="flex items-center gap-2">
                    <CheckCircle2 size={9} className="text-green-400 shrink-0" />
                    <p className="text-white/50 text-xs">{item}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 9,
    label: 'Why Now',
    color: 'from-cyan-600/10 to-blue-600/8',
    borderColor: 'border-cyan-500/20',
    render: () => (
      <div className="h-full space-y-6">
        <div>
          <p className="text-cyan-400 text-xs font-bold uppercase tracking-widest mb-2">Why Now</p>
          <h2 className="text-3xl font-black text-white">Three massive tailwinds. One intersection.</h2>
        </div>
        <div className="space-y-4">
          {[
            {
              title: 'The Remote Work Shift',
              icon: Globe,
              color: 'text-cyan-400',
              bg: 'bg-cyan-500/10',
              stat: '42% of workforce',
              desc: 'Remote and hybrid work has destroyed traditional management by proximity. Managers can\'t see behavior. They need a system. Behavior Engine is that system.',
            },
            {
              title: 'AI Adoption Wave',
              icon: Bot,
              color: 'text-indigo-400',
              bg: 'bg-indigo-500/10',
              stat: '$15B AI coaching market by 2028',
              desc: 'Companies are actively buying AI-powered tools that improve human performance. We\'re positioned at the intersection of AI and behavior science.',
            },
            {
              title: 'Performance Accountability Demand',
              icon: BarChart2,
              color: 'text-purple-400',
              bg: 'bg-purple-500/10',
              stat: '71% of CEOs top priority',
              desc: 'Post-pandemic, execution accountability is the #1 leadership challenge. Boards and investors are demanding visible performance data. We provide it.',
            },
          ].map(({ title, icon: Icon, color, bg, stat, desc }) => (
            <div key={title} className={`flex items-start gap-4 p-5 rounded-2xl ${bg} border border-white/6`}>
              <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center shrink-0`}>
                <Icon size={18} className={color} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-1 flex-wrap">
                  <p className={`font-bold text-sm ${color}`}>{title}</p>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${bg} ${color} border border-white/8`}>{stat}</span>
                </div>
                <p className="text-white/45 text-sm leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 10,
    label: 'Vision',
    color: 'from-indigo-600/20 to-purple-600/15',
    borderColor: 'border-indigo-500/30',
    render: () => (
      <div className="flex flex-col items-center justify-center h-full text-center space-y-8">
        <div>
          <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest mb-4">The Vision</p>
          <h2 className="text-4xl lg:text-5xl font-black text-white leading-tight mb-6">
            A world where every role
            <br />
            is a{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
              measurable execution system.
            </span>
          </h2>
          <p className="text-white/40 text-lg max-w-2xl mx-auto leading-relaxed">
            We are building the operating system layer between humans and their work. Not a productivity app. Not a CRM. A behavioral intelligence platform that turns any role into a structured, AI-coached, continuously improving execution system.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-4 max-w-xl">
          {[
            { icon: '🏭', label: 'Phase 1', sub: 'Sales & Operations teams', color: 'text-indigo-400' },
            { icon: '🌍', label: 'Phase 2', sub: 'Every industry via marketplace', color: 'text-purple-400' },
            { icon: '🧠', label: 'Phase 3', sub: 'AI-native behavior OS', color: 'text-pink-400' },
          ].map(({ icon, label, sub, color }) => (
            <div key={label} className="p-4 rounded-2xl bg-white/4 border border-white/8">
              <span className="text-2xl block mb-1">{icon}</span>
              <p className={`text-sm font-bold ${color}`}>{label}</p>
              <p className="text-white/30 text-xs mt-0.5">{sub}</p>
            </div>
          ))}
        </div>
        <p className="text-white/20 text-sm italic">
          "Shopify of behavior systems — a platform that makes execution programmable."
        </p>
      </div>
    ),
  },
  {
    id: 11,
    label: 'The Ask',
    color: 'from-emerald-600/15 to-indigo-600/10',
    borderColor: 'border-emerald-500/20',
    render: () => (
      <div className="h-full space-y-6">
        <div>
          <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-2">The Ask</p>
          <h2 className="text-3xl font-black text-white">$500K to accelerate what's already working.</h2>
        </div>
        <div className="grid lg:grid-cols-3 gap-3">
          {[
            { pct: '40%', amount: '$200K', label: 'Product & AI Engine', color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20', items: ['OpenAI API integration', 'Plugin creator tools', 'Mobile app build', 'Stripe billing live'] },
            { pct: '35%', amount: '$175K', label: 'Enterprise Sales', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', items: ['Enterprise sales hire', 'Demo environment', 'Case study production', 'Channel partnerships'] },
            { pct: '25%', amount: '$125K', label: 'Operations & Growth', color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20', items: ['Infrastructure scaling', 'Customer success', 'Marketing funnel', 'Legal & compliance'] },
          ].map(({ pct, amount, label, color, bg, border, items }) => (
            <div key={label} className={`p-5 rounded-2xl ${bg} border ${border}`}>
              <div className="mb-3">
                <p className={`text-3xl font-black ${color}`}>{amount}</p>
                <p className={`text-xs font-semibold ${color} opacity-60`}>{pct} of raise · {label}</p>
              </div>
              <div className="space-y-1.5">
                {items.map(item => (
                  <div key={item} className="flex items-center gap-2">
                    <ArrowRight size={9} className={`${color} shrink-0`} />
                    <p className="text-white/55 text-xs">{item}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="grid lg:grid-cols-2 gap-3">
          <div className="p-4 rounded-2xl bg-white/3 border border-white/6">
            <p className="text-white/25 text-[10px] uppercase tracking-widest mb-3">18-Month Milestones</p>
            <div className="space-y-2">
              {[
                ['Month 3', '50 paying teams', 'text-indigo-400'],
                ['Month 6', '$25K MRR', 'text-purple-400'],
                ['Month 12', '200 teams · $100K MRR', 'text-cyan-400'],
                ['Month 18', '1,000 teams · Series A ready', 'text-emerald-400'],
              ].map(([time, milestone, color]) => (
                <div key={time} className="flex items-center gap-3">
                  <span className="text-white/20 text-[10px] font-mono w-16 shrink-0">{time}</span>
                  <span className={`text-xs font-semibold ${color}`}>{milestone}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-emerald-500/8 border border-emerald-500/20 flex flex-col justify-center">
            <p className="text-emerald-400 font-black text-2xl mb-1">$500K</p>
            <p className="text-white/50 text-sm mb-3">Pre-seed round · 18-month runway</p>
            <div className="space-y-1.5">
              {['SAFE note at $3M cap', 'Pro-rata rights', 'Board observer seat available', 'Monthly investor updates'].map(t => (
                <div key={t} className="flex items-center gap-2">
                  <CheckCircle2 size={10} className="text-green-400 shrink-0" />
                  <p className="text-white/50 text-xs">{t}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    ),
  },
];

export default function PitchDeck() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);

  const slide = SLIDES[currentSlide];
  const SlideContent = slide.render;

  const prev = () => setCurrentSlide(i => Math.max(0, i - 1));
  const next = () => setCurrentSlide(i => Math.min(SLIDES.length - 1, i + 1));

  const handleKey = (e) => {
    if (e.key === 'ArrowRight') next();
    if (e.key === 'ArrowLeft') prev();
    if (e.key === 'Escape') setFullscreen(false);
  };

  return (
    <div className="max-w-5xl mx-auto" onKeyDown={handleKey} tabIndex={0} outline="none">
      <MobileHeader title="Pitch Deck" />

      {/* Desktop header */}
      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Star size={16} className="text-yellow-400" />
            <span className="text-yellow-400 text-xs font-semibold uppercase tracking-widest">Investor Pitch Deck</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Behavior Engine</h1>
          <p className="text-white/35 text-sm mt-0.5">11 slides · Funding-ready · Interactive presentation</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-white/25 text-xs">{currentSlide + 1} / {SLIDES.length}</span>
          <button
            onClick={() => setFullscreen(!fullscreen)}
            className="glass p-2 rounded-lg border border-white/8 hover:border-white/20 text-white/35 hover:text-white/70 transition-all"
          >
            <Maximize2 size={14} />
          </button>
        </div>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-4">
        {/* Slide dot nav */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1 flex-wrap">
            {SLIDES.map((s, i) => (
              <button
                key={s.id}
                onClick={() => setCurrentSlide(i)}
                className={`group relative transition-all ${currentSlide === i ? 'w-16' : 'w-2'} h-2 rounded-full overflow-hidden ${currentSlide === i ? 'bg-indigo-500' : 'bg-white/15 hover:bg-white/30'}`}
                title={s.label}
              >
                {currentSlide === i && (
                  <span className="absolute inset-0 flex items-center justify-center text-[8px] text-white/80 font-bold">{s.label}</span>
                )}
              </button>
            ))}
          </div>
          <p className="text-white/20 text-xs font-mono">{currentSlide + 1}/{SLIDES.length}</p>
        </div>

        {/* Main slide */}
        <div
          className={`relative bg-gradient-to-br ${slide.color} border ${slide.borderColor} rounded-2xl overflow-hidden transition-all`}
          style={{ minHeight: fullscreen ? '80vh' : '520px' }}
        >
          {/* Slide label */}
          <div className="absolute top-4 left-5 z-10">
            <span className="text-white/15 text-[10px] font-mono">SLIDE {String(currentSlide + 1).padStart(2, '0')}</span>
          </div>

          {/* Content area */}
          <div className="p-6 lg:p-8 h-full" style={{ paddingTop: '2.5rem' }}>
            <SlideContent />
          </div>

          {/* Nav arrows */}
          <div className="absolute bottom-4 right-4 flex items-center gap-2">
            <button
              onClick={prev}
              disabled={currentSlide === 0}
              className="w-9 h-9 rounded-xl glass border border-white/10 flex items-center justify-center text-white/35 hover:text-white/70 disabled:opacity-20 transition-all hover:border-white/25"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={next}
              disabled={currentSlide === SLIDES.length - 1}
              className="w-9 h-9 rounded-xl glass border border-white/10 flex items-center justify-center text-white/35 hover:text-white/70 disabled:opacity-20 transition-all hover:border-white/25"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Slide index row */}
        <div className="grid grid-cols-4 lg:grid-cols-6 gap-2">
          {SLIDES.map((s, i) => (
            <button
              key={s.id}
              onClick={() => setCurrentSlide(i)}
              className={`py-2 px-3 rounded-xl text-[10px] font-semibold transition-all border ${
                currentSlide === i
                  ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                  : 'glass text-white/25 border-white/6 hover:text-white/50 hover:border-white/15'
              }`}
            >
              <span className="text-white/20 block font-mono">{String(s.id).padStart(2, '0')}</span>
              {s.label}
            </button>
          ))}
        </div>

        {/* Download / share */}
        <div className="flex items-center gap-3 glass rounded-xl p-4 border border-white/8">
          <Star size={13} className="text-yellow-400" />
          <div className="flex-1">
            <p className="text-white/60 text-sm font-medium">Ready to share with investors</p>
            <p className="text-white/25 text-xs">Use the slide index above to jump to any section · Arrow keys to navigate</p>
          </div>
        </div>
      </div>
    </div>
  );
}
