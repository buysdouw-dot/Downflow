/**
 * AcquisitionPlan — 30-Day User Acquisition Plan
 * Week-by-week execution path. 0 → 100 → 1,000 → 10,000 users.
 * Outreach scripts, daily task tracker, viral loop map, live user counter.
 */
import { useState } from 'react';
import {
  Users, Zap, Share2, Target, CheckCircle2, Check, Copy,
  ArrowRight, Flame, MessageSquare, TrendingUp, Star, Play,
  Clock, ChevronRight,
} from 'lucide-react';

// ── Weeks ─────────────────────────────────────────────────────────────────────
const WEEKS = [
  {
    id: 'w1',
    week: 'Week 1',
    label: 'Validation',
    goal: '0 → 100 users',
    color: 'text-white/60',
    accent: '#a1a1aa',
    border: 'border-white/10',
    bg: 'bg-white/3',
    badge: 'MANUAL',
    theme: 'Find your first 100. Manually. Forget automation.',
    channels: [
      { name: 'WhatsApp Outreach',  desc: 'SMEs, sales teams, managers in your network. DM 30 people/day.',         daily: '30 DMs' },
      { name: 'LinkedIn Posts',     desc: 'Post 1 result, 1 insight, or 1 question per day. No selling.',           daily: '1 post' },
      { name: 'Manual Onboarding',  desc: 'Onboard every user yourself on Zoom. Learn their pain.',                  daily: '2 calls' },
      { name: 'Facebook Groups',    desc: 'Post in Sales, Startups, Remote Work groups. Ask questions, not pitches.', daily: '3 groups' },
    ],
    tasks: [
      'Set up Stripe payment link ($10/mo)',
      'Send WhatsApp message to 30 contacts',
      'Post first LinkedIn execution tip',
      'Onboard first 3 users via Zoom call',
      'Create a simple "execution score" screenshot',
      'Ask 5 users for a referral',
      'Get 1 testimonial quote',
    ],
    script: `"Hey [Name], I'm testing a system that improves team execution in 7 days.

It gives each person a daily score + AI coaching.

One team went from 42% to 78% execution in 6 weeks.

Want access? Free trial, no credit card."`,
    north_star: '10 paying users by Day 7',
  },
  {
    id: 'w2',
    week: 'Week 2',
    label: 'Viral Loop Activation',
    goal: '100 → 500 users',
    color: 'text-indigo-400',
    accent: '#818cf8',
    border: 'border-indigo-500/20',
    bg: 'bg-indigo-500/5',
    badge: 'VIRAL',
    theme: 'Make the product share itself. Score cards. Leaderboard screenshots.',
    channels: [
      { name: 'Execution Score Cards', desc: 'Users share their weekly score on LinkedIn. You design the card.',   daily: '5 shares' },
      { name: 'Leaderboard Screenshots', desc: 'Teams post "we hit 80%+ execution this week" on Slack + LinkedIn.', daily: '3 posts' },
      { name: 'Referral Ask',          desc: 'Every user who stays 7 days gets asked: "Who else runs a team?"',   daily: '5 asks' },
      { name: 'Twitter/X Thread',      desc: 'Post a thread on "how we track execution at [Company]".',            daily: '1 thread' },
    ],
    tasks: [
      'Design score card template (Canva)',
      'Add "Share my score" button to dashboard',
      'Add leaderboard with team ranking',
      'Send referral ask to all active users',
      'Post Week 1 results on LinkedIn (numbers)',
      'Create a short demo video (60 seconds)',
      'Reach out to 2 niche LinkedIn creators',
    ],
    script: `"We just hit 78% team execution this week.

6 weeks ago we were at 42%.

Using daily scoring + AI coaching.

If your team wants to try: [link]"`,
    north_star: '100 users by Day 14',
  },
  {
    id: 'w3',
    week: 'Week 3',
    label: 'Pilot Companies',
    goal: '500 → 2,000 users',
    color: 'text-purple-400',
    accent: '#a78bfa',
    border: 'border-purple-500/20',
    bg: 'bg-purple-500/5',
    badge: 'B2B',
    theme: 'Stop selling to individuals. Start selling to teams. 1 deal = 10-30 users.',
    channels: [
      { name: 'Cold Email (Team Leads)',  desc: '50 targeted emails/day to Sales VPs, Revenue Ops, team managers.', daily: '50 emails' },
      { name: '7-Day Pilot Offer',        desc: 'Free 7-day pilot for 1 team. No credit card. Just results.',       daily: '3 pilots' },
      { name: 'LinkedIn DMs (Decision Makers)', desc: 'Target: companies 10–200 people, B2B, professional services.', daily: '20 DMs' },
      { name: 'Case Study Post',          desc: 'Post a before/after story: "Company X went from Y% to Z%."',       daily: '1 post' },
    ],
    tasks: [
      'Create "7-Day Pilot" landing page',
      'Build automated pilot onboarding (email sequence)',
      'Close 3 paying companies ($500+ MRR)',
      'Record 1 case study video with pilot company',
      'Build basic admin dashboard for team managers',
      'Post case study on LinkedIn (with real numbers)',
      'Reach out to 5 sales coaches / consultants for partnership',
    ],
    script: `Subject: Free 7-day execution pilot for your sales team

Hi [Name],

We help sales teams improve execution consistency in 7 days.

Your team gets a daily score. AI coaching for each rep. Manager dashboard.

One team: 42% → 78% in 6 weeks.

No credit card. I set it up in 10 minutes.

Worth trying?`,
    north_star: '5 paying companies = 1,000+ users by Day 21',
  },
  {
    id: 'w4',
    week: 'Week 4',
    label: 'Scale Signals',
    goal: '2,000 → 10,000 users',
    color: 'text-emerald-400',
    accent: '#34d399',
    border: 'border-emerald-500/20',
    bg: 'bg-emerald-500/5',
    badge: 'SCALE',
    theme: 'Amplify what works. Testimonials, case studies, referral programs, content.',
    channels: [
      { name: 'Testimonials & Case Studies', desc: 'Turn every success story into a post, a video, an email.',       daily: '1 story' },
      { name: 'Before/After Metrics',        desc: 'X% → Y% execution. $0 → $Z MRR in 30 days. Numbers only.',     daily: '1 stat' },
      { name: 'Referral Program',            desc: '1 free month for every team you refer. Turns users into sales.', daily: '10 asks' },
      { name: 'Outbound Sales',              desc: 'Hire commission-only sales rep. Give them the pilot script.',    daily: '50 outreach' },
    ],
    tasks: [
      'Launch referral program ($50/referral or 1 month free)',
      'Produce 3 case study posts with % improvement numbers',
      'Hire 1 commission-only sales rep',
      'Create annual plan (2 months free = less churn)',
      'Post "30-day results" thread on LinkedIn + Twitter',
      'Apply to Y Combinator / SaaS accelerators',
      'Build content library: 30 tips on execution',
    ],
    script: `"30 days ago: 0 paying customers.

Today: 47 teams, $4,800 MRR.

What worked:

1. WhatsApp outreach (Week 1)
2. Score card sharing (Week 2)
3. Company pilots (Week 3)
4. Referral program (Week 4)

Not ads. Not SEO. Just direct outreach + results."`,
    north_star: '$10K MRR, 10,000 users within 90 days',
  },
];

// ── Viral loop steps ───────────────────────────────────────────────────────────
const VIRAL = [
  { label: 'User gets score',       color: '#818cf8', sub: 'Daily execution % visible' },
  { label: 'Proud → shares it',     color: '#a78bfa', sub: 'LinkedIn, Slack, Twitter' },
  { label: 'New visitor sees post', color: '#22d3ee', sub: '3% click rate = ~30 visits' },
  { label: 'Lands on your page',    color: '#34d399', sub: 'Pilot offer converts 20%' },
  { label: 'Joins and gets score',  color: '#fbbf24', sub: 'Loop restarts' },
];

// ── Result path milestones ────────────────────────────────────────────────────
const MILESTONES = [
  { users: '100',    label: 'Proof',            color: 'text-white/50',   border: 'border-white/10',        bg: 'bg-white/2'       },
  { users: '1,000',  label: 'Traction',         color: 'text-indigo-400', border: 'border-indigo-500/20',   bg: 'bg-indigo-500/5'  },
  { users: '10,000', label: 'SaaS Business',    color: 'text-emerald-400',border: 'border-emerald-500/20',  bg: 'bg-emerald-500/5' },
  { users: '100,000',label: 'Fundable',         color: 'text-purple-400', border: 'border-purple-500/20',   bg: 'bg-purple-500/5'  },
];

// ── Copy btn ──────────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1800); }}
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all shrink-0 ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'
      }`}>
      {c ? <><Check size={9} /> Copied</> : <><Copy size={9} /> Copy</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AcquisitionPlan() {
  const [activeWeek, setActiveWeek] = useState('w1');
  const [view, setView]   = useState('plan'); // 'plan' | 'viral' | 'milestones'
  const [tasks, setTasks] = useState(() => {
    try { return JSON.parse(localStorage.getItem('be_acq_tasks')) ?? {}; } catch { return {}; }
  });
  const [userCount, setUserCount] = useState(() => {
    try { return parseInt(localStorage.getItem('be_acq_users') ?? '0', 10); } catch { return 0; }
  });
  const [addCount, setAddCount] = useState('');

  const week = WEEKS.find(w => w.id === activeWeek) ?? WEEKS[0];

  const toggleTask = (key) => {
    const updated = { ...tasks, [key]: !tasks[key] };
    setTasks(updated);
    try { localStorage.setItem('be_acq_tasks', JSON.stringify(updated)); } catch {}
  };

  const logUsers = () => {
    const n = parseInt(addCount, 10);
    if (!n || n <= 0) return;
    const next = userCount + n;
    setUserCount(next);
    setAddCount('');
    try { localStorage.setItem('be_acq_users', String(next)); } catch {}
  };

  const currentMilestone = userCount < 100 ? 0 : userCount < 1000 ? 1 : userCount < 10000 ? 2 : 3;

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Users size={14} className="text-indigo-400" />
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">30-Day Acquisition Plan</p>
            </div>
            <h1 className="text-3xl font-black mb-1">0 → 10,000 Users</h1>
            <p className="text-white/35 text-sm">Guaranteed execution path. Week-by-week. No ads required.</p>
          </div>

          {/* User counter */}
          <div className="p-4 rounded-2xl border border-indigo-500/20 bg-indigo-500/5 min-w-[160px]">
            <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">Total Users</p>
            <p className="text-3xl font-black text-indigo-400">{userCount.toLocaleString()}</p>
            <p className="text-white/20 text-[9px] mt-1 capitalize">{MILESTONES[currentMilestone]?.label}</p>
          </div>
        </div>

        {/* Add users */}
        <div className="flex items-center gap-3">
          <input type="number" value={addCount} onChange={e => setAddCount(e.target.value)}
            placeholder="Add users" onKeyDown={e => e.key === 'Enter' && logUsers()}
            className="w-32 px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-sm outline-none placeholder-white/20 focus:border-indigo-500/40" />
          <button onClick={logUsers} className="px-4 py-2 bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-sm rounded-xl transition-all">
            + Log Users
          </button>
          {userCount > 0 && (
            <button onClick={() => { setUserCount(0); try { localStorage.removeItem('be_acq_users'); } catch {} }}
              className="px-3 py-2 text-white/25 text-xs border border-white/8 rounded-xl hover:text-white/40">Reset</button>
          )}
        </div>

        {/* View tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6">
          {[['plan','Week Plan'],['viral','Viral Loop'],['milestones','Result Path']].map(([v, l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── WEEK PLAN ───────────────────────────────────────── */}
        {view === 'plan' && (
          <div className="grid lg:grid-cols-[220px_1fr] gap-6">
            {/* Week selector */}
            <div className="space-y-1.5">
              {WEEKS.map(w => {
                const doneTasks = w.tasks.filter((_, i) => tasks[`${w.id}_${i}`]).length;
                const isActive  = activeWeek === w.id;
                return (
                  <button key={w.id} onClick={() => setActiveWeek(w.id)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${isActive ? `${w.border} ${w.bg}` : 'border-white/6 bg-white/2 hover:bg-white/4'}`}>
                    <div className="flex items-center justify-between">
                      <p className={`text-xs font-bold ${isActive ? w.color : 'text-white/40'}`}>{w.week}</p>
                      <span className={`text-[8px] font-black px-1.5 py-0.5 rounded border ${isActive ? `${w.bg} ${w.border} ${w.color}` : 'bg-white/4 border-white/8 text-white/20'}`}>{w.badge}</span>
                    </div>
                    <p className={`text-[9px] mt-0.5 ${isActive ? w.color : 'text-white/25'}`}>{w.goal}</p>
                    <div className="mt-2 h-1 bg-white/8 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{ width: `${(doneTasks / w.tasks.length) * 100}%`, background: w.accent }} />
                    </div>
                    <p className="text-white/20 text-[8px] mt-1">{doneTasks}/{w.tasks.length} tasks</p>
                  </button>
                );
              })}
            </div>

            {/* Week detail */}
            <div className="space-y-5">
              {/* Theme */}
              <div className={`p-4 rounded-2xl border ${week.border} ${week.bg}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-[8px] font-black uppercase tracking-widest ${week.color}`}>{week.badge}</span>
                  <span className="text-white/20 text-[8px]">·</span>
                  <span className={`text-xs font-bold ${week.color}`}>{week.label} — {week.goal}</span>
                </div>
                <p className="text-white/50 text-sm leading-relaxed">{week.theme}</p>
              </div>

              {/* Channels */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Channels</p>
                <div className="grid sm:grid-cols-2 gap-2">
                  {week.channels.map(ch => (
                    <div key={ch.name} className="p-3 rounded-xl border border-white/8 bg-white/2">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-white/55 text-xs font-semibold">{ch.name}</p>
                        <span style={{ color: week.accent }} className="text-[9px] font-bold">{ch.daily}</span>
                      </div>
                      <p className="text-white/25 text-[10px] leading-snug">{ch.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tasks */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Weekly Execution Tasks</p>
                <div className="space-y-1.5">
                  {week.tasks.map((t, i) => {
                    const key = `${week.id}_${i}`;
                    const done = !!tasks[key];
                    return (
                      <button key={i} onClick={() => toggleTask(key)}
                        className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                          done ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/6 bg-white/2 hover:border-white/12'
                        }`}>
                        <div className={`w-4 h-4 rounded-md flex items-center justify-center shrink-0 transition-all ${done ? 'bg-emerald-500' : 'border border-white/20'}`}>
                          {done && <Check size={8} className="text-white" />}
                        </div>
                        <span className={`text-xs flex-1 ${done ? 'line-through text-white/25' : 'text-white/55'}`}>{t}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Script */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest">Outreach Script</p>
                  <CopyBtn text={week.script} />
                </div>
                <div className="p-4 rounded-xl border border-white/8 bg-black/30">
                  <pre className="text-white/50 text-xs leading-relaxed whitespace-pre-wrap font-sans">{week.script}</pre>
                </div>
              </div>

              {/* North star */}
              <div className={`p-4 rounded-xl border ${week.border} ${week.bg}`}>
                <p className={`text-xs font-bold ${week.color}`}>North Star: {week.north_star}</p>
              </div>
            </div>
          </div>
        )}

        {/* ── VIRAL LOOP ──────────────────────────────────────── */}
        {view === 'viral' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0b0f1a]">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-5">Viral Growth Loop</p>
              <div className="flex items-center gap-3 flex-wrap">
                {VIRAL.map((step, i) => (
                  <div key={step.label} className="flex items-center gap-3">
                    <div className="text-center">
                      <div className="px-4 py-3 rounded-xl border mb-1.5" style={{ borderColor: `${step.color}30`, background: `${step.color}08` }}>
                        <p className="text-xs font-bold" style={{ color: step.color }}>{step.label}</p>
                        <p className="text-[9px] mt-0.5" style={{ color: `${step.color}80` }}>{step.sub}</p>
                      </div>
                    </div>
                    {i < VIRAL.length - 1 && <ArrowRight size={12} className="text-white/15 shrink-0" />}
                  </div>
                ))}
                <div className="flex items-center gap-3">
                  <ArrowRight size={12} className="text-white/15" />
                  <div className="px-3 py-3 rounded-xl border border-white/8 text-center">
                    <p className="text-[10px] text-white/20 font-bold">Loop ∞</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-4">
              {[
                { title: 'Week 2: Add These Features', color: 'text-indigo-400', items: [
                  '"Share my score" button → LinkedIn / Slack',
                  'Team leaderboard → encourages competition',
                  '"Your team hit 80%!" weekly recap email',
                  '"Invite a teammate" inside the dashboard',
                ]},
                { title: 'Week 3: Amplify with Content', color: 'text-purple-400', items: [
                  'Post "execution stats" weekly on LinkedIn',
                  '"Before vs After" screenshots from pilot teams',
                  'DM every commenter to offer a pilot',
                  'Build email list from content = warm leads',
                ]},
              ].map(({ title, color, items }) => (
                <div key={title} className="p-5 rounded-2xl border border-white/8 bg-white/2 space-y-3">
                  <p className={`text-xs font-bold uppercase tracking-widest ${color}`}>{title}</p>
                  {items.map(item => (
                    <div key={item} className="flex items-start gap-2">
                      <ChevronRight size={10} className={`${color} shrink-0 mt-0.5`} />
                      <p className="text-white/45 text-xs leading-snug">{item}</p>
                    </div>
                  ))}
                </div>
              ))}
            </div>

            <div className="p-5 rounded-2xl border border-indigo-500/20 bg-indigo-500/5">
              <p className="text-indigo-400 font-bold text-sm mb-2">Viral Coefficient Target: K &gt; 0.5</p>
              <p className="text-white/45 text-sm leading-relaxed">
                Every 100 users need to bring in 50+ more through sharing.
                At K=0.5 your acquisition cost drops by half every cycle.
                At K=1.0 the product grows without any outreach at all.
              </p>
            </div>
          </div>
        )}

        {/* ── MILESTONES ──────────────────────────────────────── */}
        {view === 'milestones' && (
          <div className="space-y-4">
            <div className="grid lg:grid-cols-2 gap-4">
              {MILESTONES.map((m, i) => {
                const reached = currentMilestone >= i;
                return (
                  <div key={m.users} className={`p-5 rounded-2xl border transition-all ${reached ? `${m.border} ${m.bg}` : 'border-white/6 bg-white/2 opacity-60'}`}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className={`text-2xl font-black ${reached ? m.color : 'text-white/30'}`}>{m.users} users</p>
                        <p className={`text-xs font-bold mt-0.5 uppercase tracking-widest ${reached ? m.color : 'text-white/25'}`}>{m.label}</p>
                      </div>
                      {reached && <CheckCircle2 size={18} className={m.color} />}
                    </div>
                    {[
                      ['This means you have...', [
                        '100 = Real feedback + first revenue',
                        '1,000 = Proof it can scale + investor interest',
                        '10,000 = Real SaaS business + $50K MRR potential',
                        '100,000 = Fundable, acquirable, or profitable',
                      ][i]],
                      ['What unlocks...', [
                        'Pricing confidence. Product market fit signal.',
                        'Series A conversations. Press. Hiring.',
                        'Churn becomes manageable. Payback period drops.',
                        'Multiple acquisition offers or $1M+ ARR.',
                      ][i]],
                    ].map(([l, v]) => (
                      <div key={l} className="mt-2">
                        <p className="text-white/20 text-[9px] uppercase tracking-widest">{l}</p>
                        <p className={`text-xs mt-0.5 leading-snug ${reached ? 'text-white/55' : 'text-white/25'}`}>{v}</p>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>

            <div className="p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-sm mb-3">The Result Path</p>
              <div className="flex items-center gap-3 flex-wrap">
                {MILESTONES.map((m, i) => (
                  <div key={m.users} className="flex items-center gap-3">
                    <div className={`text-center px-3 py-2 rounded-xl border ${currentMilestone >= i ? `${m.border} ${m.bg}` : 'border-white/6 bg-white/2'}`}>
                      <p className={`text-xs font-black ${currentMilestone >= i ? m.color : 'text-white/25'}`}>{m.users}</p>
                      <p className={`text-[9px] ${currentMilestone >= i ? m.color : 'text-white/20'}`}>{m.label}</p>
                    </div>
                    {i < MILESTONES.length - 1 && <ArrowRight size={10} className="text-white/15" />}
                  </div>
                ))}
              </div>
              <p className="text-white/35 text-xs mt-4 leading-relaxed">
                Each milestone is not just a number. It is a proof point, an unlock, a new level of leverage.
                Focus on the next milestone only. Stop planning for 100,000 when you have 100.
              </p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
