/**
 * GitCommitRepo — True GitHub Repo (Commit-by-Commit Build)
 * Shows the repo as it was built: 8 commits, each adding a layer.
 * Every commit has the full diff + real file content.
 * Copy any commit, copy git commands, or copy the full history.
 */
import { useState } from 'react';
import {
  GitBranch, GitCommit, Copy, Check, ChevronDown, ChevronRight,
  Terminal, Package, Server, Brain, Monitor, Users, BarChart2,
  Cloud, ArrowRight, Plus, Minus, Clock,
} from 'lucide-react';

// ── Commits ────────────────────────────────────────────────────────────────────
const COMMITS = [
  {
    sha: 'a1b2c3d',
    message: 'chore: project bootstrap',
    tag: 'COMMIT 1',
    author: 'you',
    date: 'Day 1',
    Icon: Package,
    color: '#a1a1aa',
    summary: 'Init repo. Workspace structure. Root package.json. .gitignore. README.',
    commands: [
      'git init behavior-engine-saas',
      'cd behavior-engine-saas',
      'npm init -y',
      'mkdir -p backend/src frontend/src infra',
      'git add . && git commit -m "chore: project bootstrap"',
    ],
    files: [
      {
        path: 'package.json',
        status: 'added',
        content: `{
  "name": "behavior-engine-saas",
  "version": "1.0.0",
  "private": true,
  "workspaces": ["backend", "frontend"],
  "scripts": {
    "dev": "concurrently \\"npm run dev --workspace=backend\\" \\"npm run dev --workspace=frontend\\""
  },
  "devDependencies": { "concurrently": "^8.2.0" }
}`,
      },
      {
        path: '.gitignore',
        status: 'added',
        content: `node_modules/\ndist/\nbuild/\n.env\n.env.local\n*.log\n.DS_Store`,
      },
      {
        path: 'README.md',
        status: 'added',
        content: `# Behavior Engine SaaS\nTeam execution tracker with AI coaching.\n\n## Quick Start\n\`\`\`bash\nnpm install\nnpm run dev\n\`\`\``,
      },
    ],
  },
  {
    sha: 'b2c3d4e',
    message: 'feat: backend core (Express server + app)',
    tag: 'COMMIT 2',
    author: 'you',
    date: 'Day 1',
    Icon: Server,
    color: '#34d399',
    summary: 'Express app. CORS. JSON body parser. Health check route. Server entry point.',
    commands: [
      'cd backend',
      'npm init -y',
      'npm install express cors dotenv',
      'npm install --save-dev nodemon',
      'mkdir -p src',
      'git add . && git commit -m "feat: backend core"',
    ],
    files: [
      {
        path: 'backend/src/server.js',
        status: 'added',
        content: `require('dotenv').config();
const app  = require('./app');
const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(\`Behavior Engine running on port \${PORT}\`);
});`,
      },
      {
        path: 'backend/src/app.js',
        status: 'added',
        content: `const express = require('express');
const cors    = require('cors');
const app     = express();

app.use(cors());
app.use(express.json());

app.get('/health', (_, res) => res.json({ ok: true }));

module.exports = app;`,
      },
      {
        path: 'backend/package.json',
        status: 'added',
        content: `{
  "name": "behavior-engine-backend",
  "main": "src/server.js",
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "dotenv": "^16.0.3"
  }
}`,
      },
    ],
  },
  {
    sha: 'c3d4e5f',
    message: 'feat: task engine + score calculation',
    tag: 'COMMIT 3',
    author: 'you',
    date: 'Day 2',
    Icon: BarChart2,
    color: '#818cf8',
    summary: 'Task store. addTask, completeTask. calculateScore. behaviorStatus. REST route.',
    commands: [
      'mkdir -p backend/src/{engine,db,routes}',
      'git add . && git commit -m "feat: task engine + score calculation"',
    ],
    files: [
      {
        path: 'backend/src/engine/score.js',
        status: 'added',
        content: `function calculateScore(tasks) {
  if (!tasks?.length) return 0;
  const earned = tasks.reduce((s, t) => s + (t.completed ? (t.points||10) : 0), 0);
  const total  = tasks.reduce((s, t) => s + (t.points||10), 0);
  return total > 0 ? Math.round((earned / total) * 100) : 0;
}

function behaviorStatus(score) {
  if (score >= 75) return 'HIGH_PERFORMANCE';
  if (score >= 40) return 'MEDIUM_PERFORMANCE';
  return 'LOW_PERFORMANCE';
}

module.exports = { calculateScore, behaviorStatus };`,
      },
      {
        path: 'backend/src/db/memoryStore.js',
        status: 'added',
        content: `// In-memory store — replace with Postgres in production
const users = new Map();
const tasks = new Map();
const leads = new Map();

module.exports = {
  getUser:      email => users.get(email),
  saveUser:     u     => users.set(u.email, u),
  getUserTasks: uid   => [...tasks.values()].filter(t => t.userId === uid),
  saveTask:     t     => tasks.set(t.id, t),
  getLeads:     oid   => [...leads.values()].filter(l => l.ownerId === oid),
  saveLead:     l     => leads.set(l.id, l),
};`,
      },
      {
        path: 'backend/src/routes/tasks.js',
        status: 'added',
        content: `const router = require('express').Router();
const { v4: uuid } = require('uuid');
const store  = require('../db/memoryStore');
const { calculateScore } = require('../engine/score');

router.get('/', (req, res) => {
  const tasks = store.getUserTasks(req.user.id);
  res.json({ tasks, score: calculateScore(tasks) });
});

router.post('/', (req, res) => {
  const task = { id: uuid(), userId: req.user.id, title: req.body.title, points: 10, completed: false, createdAt: Date.now() };
  store.saveTask(task);
  res.status(201).json(task);
});

router.patch('/:id/complete', (req, res) => {
  const task = store.getUserTasks(req.user.id).find(t => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: 'Not found' });
  Object.assign(task, { completed: true, completedAt: Date.now() });
  store.saveTask(task);
  res.json(task);
});

module.exports = router;`,
      },
    ],
  },
  {
    sha: 'd4e5f6a',
    message: 'feat: AI coach engine',
    tag: 'COMMIT 4',
    author: 'you',
    date: 'Day 2',
    Icon: Brain,
    color: '#a78bfa',
    summary: 'getCoachMessage. Pattern detection. Insight generation. Plug into tasks route.',
    commands: [
      'git add . && git commit -m "feat: AI coach engine"',
    ],
    files: [
      {
        path: 'backend/src/engine/ai.js',
        status: 'added',
        content: `function getCoachMessage({ score, dropRate = 0 }) {
  if (score < 20)     return { message: 'Reduce scope. Execute 1 task only.', type: 'intervention' };
  if (dropRate > 0.5) return { message: 'Inconsistency detected. Fix routine first.', type: 'pattern_alert' };
  if (score >= 80)    return { message: 'Strong execution. Increase output.', type: 'growth_signal' };
  return { message: 'Build consistency before adding complexity.', type: 'guidance' };
}

module.exports = { getCoachMessage };`,
      },
      {
        path: 'backend/src/engine/behavior.js',
        status: 'added',
        content: `function analyzeBehavior(tasks) {
  const done = tasks.filter(t => t.completed);
  const rate = tasks.length ? done.length / tasks.length : 0;
  const burnoutRisk = rate < 0.3 && tasks.length > 5;
  return { completionRate: Math.round(rate * 100) / 100, burnoutRisk };
}

module.exports = { analyzeBehavior };`,
      },
      {
        path: 'backend/src/routes/tasks.js',
        status: 'modified',
        diff: `+ const { getCoachMessage } = require('../engine/ai');

  router.get('/', (req, res) => {
    const tasks    = store.getUserTasks(req.user.id);
    const score    = calculateScore(tasks);
+   const coaching = getCoachMessage({ score });
+   res.json({ tasks, score, coaching });
-   res.json({ tasks, score });
  });`,
      },
    ],
  },
  {
    sha: 'e5f6a7b',
    message: 'feat: auth (JWT + bcrypt)',
    tag: 'COMMIT 5',
    author: 'you',
    date: 'Day 3',
    Icon: Users,
    color: '#22d3ee',
    summary: 'Register + login routes. JWT signing. bcrypt password hashing. Auth middleware.',
    commands: [
      'npm install bcryptjs jsonwebtoken uuid --workspace=backend',
      'git add . && git commit -m "feat: auth (JWT + bcrypt)"',
    ],
    files: [
      {
        path: 'backend/src/routes/auth.js',
        status: 'added',
        content: `const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const store  = require('../db/memoryStore');

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (store.getUser(email)) return res.status(409).json({ error: 'User exists' });
  const user = { id: uuid(), email, name, hash: await bcrypt.hash(password, 10) };
  store.saveUser(user);
  const token = jwt.sign({ id: user.id, email }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.status(201).json({ token, user: { id: user.id, email, name } });
});

router.post('/login', async (req, res) => {
  const user = store.getUser(req.body.email);
  if (!user || !(await bcrypt.compare(req.body.password, user.hash)))
    return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
});

module.exports = router;`,
      },
      {
        path: 'backend/src/middleware/auth.js',
        status: 'added',
        content: `const jwt = require('jsonwebtoken');

function authenticate(req, res, next) {
  const h = req.headers.authorization;
  if (!h?.startsWith('Bearer ')) return res.status(401).json({ error: 'No token' });
  try { req.user = jwt.verify(h.slice(7), process.env.JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Invalid token' }); }
}

module.exports = { authenticate };`,
      },
    ],
  },
  {
    sha: 'f6a7b8c',
    message: 'feat: frontend dashboard (React + Vite)',
    tag: 'COMMIT 6',
    author: 'you',
    date: 'Day 4',
    Icon: Monitor,
    color: '#fbbf24',
    summary: 'Vite + React 18. Auth context. Login page. Dashboard with score + coaching.',
    commands: [
      'cd frontend',
      'npm create vite@latest . -- --template react',
      'npm install react-router-dom',
      'npm install -D tailwindcss postcss autoprefixer',
      'npx tailwindcss init -p',
      'git add . && git commit -m "feat: frontend dashboard"',
    ],
    files: [
      {
        path: 'frontend/src/App.jsx',
        status: 'added',
        content: `import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { createContext, useContext, useState } from 'react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('be_token'));
  const [user,  setUser]  = useState(() => JSON.parse(localStorage.getItem('be_user')||'null'));

  const login = async (email, password) => {
    const res  = await fetch('/api/auth/login', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({email,password}) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    localStorage.setItem('be_token', data.token);
    localStorage.setItem('be_user', JSON.stringify(data.user));
    setToken(data.token); setUser(data.user);
  };

  const logout = () => { localStorage.clear(); setToken(null); setUser(null); };

  return <AuthCtx.Provider value={{ token, user, login, logout, isAuthenticated: !!token }}>{children}</AuthCtx.Provider>;
}

const Guard = ({ children }) => { const { isAuthenticated } = useAuth(); return isAuthenticated ? children : <Navigate to="/login" replace />; };

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/"     element={<Guard><Dashboard /></Guard>} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}`,
      },
      {
        path: 'frontend/src/pages/Dashboard.jsx',
        status: 'added',
        content: `import { useEffect, useState } from 'react';
import { useAuth } from '../App';

export default function Dashboard() {
  const { token, user } = useAuth();
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch('/api/tasks', { headers: { Authorization: 'Bearer ' + token } })
      .then(r => r.json()).then(setData);
  }, [token]);

  const score = data?.score ?? 0;
  const color = score >= 75 ? '#34d399' : score >= 40 ? '#fbbf24' : '#f87171';

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6 max-w-xl mx-auto">
      <h2 className="text-xl font-bold mb-6">Welcome, {user?.name}</h2>
      {data ? (
        <>
          <div className="p-6 rounded-2xl border border-white/8 bg-white/2 mb-4">
            <p className="text-white/30 text-sm">Execution Score</p>
            <p className="text-5xl font-black mt-1" style={{ color }}>{score}%</p>
          </div>
          {data.coaching && (
            <div className="p-4 rounded-xl border border-white/8 bg-white/2">
              <p className="text-indigo-400 text-xs font-bold uppercase mb-1">AI Coach</p>
              <p className="text-white/60 text-sm">{data.coaching.message}</p>
            </div>
          )}
        </>
      ) : <p className="text-white/30">Loading...</p>}
    </div>
  );
}`,
      },
    ],
  },
  {
    sha: 'a7b8c9d',
    message: 'feat: CRM leads pipeline',
    tag: 'COMMIT 7',
    author: 'you',
    date: 'Day 5',
    Icon: Users,
    color: '#f472b6',
    summary: 'Lead model. addLead / updateStatus. Pipeline route. CRM automation service.',
    commands: [
      'git add . && git commit -m "feat: CRM leads pipeline"',
    ],
    files: [
      {
        path: 'backend/src/routes/crm.js',
        status: 'added',
        content: `const router = require('express').Router();
const { v4: uuid } = require('uuid');
const store = require('../db/memoryStore');

const TRANSITIONS = { signup:'contacted', demo_booked:'demo', demo_done:'pilot', first_task:'active', day7_complete:'converted', upsell:'expansion' };

router.get('/leads', (req, res) => res.json({ leads: store.getLeads(req.user.id) }));

router.post('/leads', (req, res) => {
  const lead = { id: uuid(), ownerId: req.user.id, ...req.body, status: 'new', events: [], createdAt: Date.now() };
  store.saveLead(lead);
  res.status(201).json(lead);
});

router.patch('/leads/:id/event', (req, res) => {
  const lead = store.getLeads(req.user.id).find(l => l.id === req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  const next = TRANSITIONS[req.body.event];
  if (next) { lead.status = next; lead.events.push({ event: req.body.event, ts: Date.now() }); }
  store.saveLead(lead);
  res.json(lead);
});

module.exports = router;`,
      },
    ],
  },
  {
    sha: 'b8c9d0e',
    message: 'chore: deploy config (Railway + Vercel + Docker)',
    tag: 'COMMIT 8',
    author: 'you',
    date: 'Day 6',
    Icon: Cloud,
    color: '#34d399',
    summary: 'docker-compose. nginx.conf. railway.json. Vercel config. .env.example. README deploy section.',
    commands: [
      '# Add to backend/package.json scripts: "start": "node src/server.js"',
      'git add . && git commit -m "chore: deploy config"',
      '',
      '# Deploy:',
      'git push origin main',
      '# Railway: connect repo → set env vars → auto-deploy',
      '# Vercel:  connect frontend folder → auto-deploy',
    ],
    files: [
      {
        path: 'docker-compose.yml',
        status: 'added',
        content: `version: '3.9'
services:
  backend:
    build: ./backend
    ports: ["3001:3001"]
    environment: { PORT: 3001, JWT_SECRET: \${JWT_SECRET}, NODE_ENV: production }
    restart: unless-stopped
  frontend:
    build: ./frontend
    ports: ["80:80"]
    depends_on: [backend]
    restart: unless-stopped`,
      },
      {
        path: 'infra/railway.json',
        status: 'added',
        content: `{
  "$schema": "https://railway.app/railway.schema.json",
  "build": { "builder": "NIXPACKS" },
  "deploy": {
    "startCommand": "node src/server.js",
    "healthcheckPath": "/health",
    "restartPolicyType": "ON_FAILURE"
  }
}`,
      },
      {
        path: '.env.example',
        status: 'added',
        content: `PORT=3001\nJWT_SECRET=replace_with_32_char_min_secret\nNODE_ENV=development\n# DATABASE_URL=postgresql://...`,
      },
    ],
  },
];

// ── Copy button ────────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1800); }}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border shrink-0 transition-all ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'
      }`}>
      {c ? <><Check size={8} /> Copied</> : <><Copy size={8} /> Copy</>}
    </button>
  );
}

// ── File status badge ─────────────────────────────────────────────────────────
function StatusBadge({ status }) {
  const cfg = {
    added:    { label: '+ added',    cls: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' },
    modified: { label: '~ modified', cls: 'text-yellow-400  bg-yellow-500/10  border-yellow-500/20'  },
    deleted:  { label: '- deleted',  cls: 'text-red-400     bg-red-500/10     border-red-500/20'     },
  };
  const { label, cls } = cfg[status] ?? cfg.added;
  return <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded border ${cls}`}>{label}</span>;
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function GitCommitRepo() {
  const [active,    setActive]    = useState(COMMITS[0].sha);
  const [openFiles, setOpenFiles] = useState(new Set());

  const commit = COMMITS.find(c => c.sha === active) ?? COMMITS[0];
  const CIcon  = commit.Icon;

  const toggleFile = (path) => {
    const n = new Set(openFiles);
    n.has(path) ? n.delete(path) : n.add(path);
    setOpenFiles(n);
  };

  const allCommands = COMMITS.flatMap(c => c.commands).filter(Boolean).join('\n');

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <GitBranch size={13} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">Git History</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Commit-by-Commit Build</h1>
            <p className="text-white/35 text-sm">8 commits. Every file shown. Copy commands or full diffs.</p>
          </div>
          <CopyBtn text={allCommands} />
        </div>

        <div className="grid lg:grid-cols-[260px_1fr] gap-6">

          {/* Commit timeline sidebar */}
          <div className="space-y-1 relative">
            {/* Vertical line */}
            <div className="absolute left-[18px] top-4 bottom-4 w-px bg-white/8" />
            {COMMITS.map((c, i) => {
              const isActive = active === c.sha;
              const CIco = c.Icon;
              return (
                <button key={c.sha} onClick={() => setActive(c.sha)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all relative ${
                    isActive ? 'bg-white/6 border border-white/10' : 'hover:bg-white/3'
                  }`}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 z-10"
                    style={{ background: isActive ? c.color + '18' : 'rgba(255,255,255,0.04)', border: `1px solid ${isActive ? c.color + '30' : 'rgba(255,255,255,0.06)'}` }}>
                    <CIco size={12} style={{ color: isActive ? c.color : 'rgba(255,255,255,0.2)' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-[9px] font-black uppercase tracking-widest mb-0.5`} style={{ color: isActive ? c.color : 'rgba(255,255,255,0.2)' }}>{c.tag}</p>
                    <p className={`text-xs font-semibold truncate ${isActive ? 'text-white/70' : 'text-white/30'}`}>{c.message}</p>
                    <p className="text-white/20 text-[8px] font-mono">{c.sha} · {c.date}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Commit detail */}
          <div className="space-y-4">
            {/* Header */}
            <div className="p-5 rounded-2xl border border-white/10 bg-white/2" style={{ borderColor: commit.color + '25', background: commit.color + '06' }}>
              <div className="flex items-center gap-3 mb-2">
                <CIcon size={16} style={{ color: commit.color }} />
                <div>
                  <p className="text-sm font-bold text-white/80">{commit.message}</p>
                  <p className="text-[9px] text-white/30 font-mono">{commit.sha} · {commit.author} · {commit.date}</p>
                </div>
              </div>
              <p className="text-white/40 text-xs">{commit.summary}</p>
            </div>

            {/* Commands */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Terminal size={10} className="text-white/30" />
                  <p className="text-white/25 text-[9px] uppercase tracking-widest">Git Commands</p>
                </div>
                <CopyBtn text={commit.commands.join('\n')} />
              </div>
              <div className="p-3 rounded-xl bg-black/40 border border-white/6">
                {commit.commands.map((cmd, i) => (
                  <div key={i} className={`font-mono text-[10px] leading-loose ${cmd.startsWith('#') ? 'text-white/20' : cmd === '' ? 'h-2' : 'text-emerald-300/80'}`}>
                    {cmd !== '' && !cmd.startsWith('#') && <span className="text-white/20 mr-1">$</span>}
                    {cmd}
                  </div>
                ))}
              </div>
            </div>

            {/* Changed files */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">
                Files Changed ({commit.files.length})
              </p>
              <div className="space-y-2">
                {commit.files.map(file => {
                  const isOpen = openFiles.has(file.path);
                  return (
                    <div key={file.path} className="rounded-xl border border-white/8 bg-white/2 overflow-hidden">
                      <button onClick={() => toggleFile(file.path)}
                        className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/4 transition-all">
                        {isOpen ? <ChevronDown size={9} className="text-white/25" /> : <ChevronRight size={9} className="text-white/25" />}
                        <code className="text-white/55 text-[10px] font-mono flex-1 text-left">{file.path}</code>
                        <StatusBadge status={file.status} />
                        {(file.content || file.diff) && <CopyBtn text={file.content ?? file.diff} />}
                      </button>
                      {isOpen && (
                        <div className="border-t border-white/6 bg-black/30 p-3">
                          {file.diff ? (
                            <pre className="text-[9px] font-mono leading-relaxed overflow-x-auto">
                              {file.diff.split('\n').map((line, li) => (
                                <div key={li} className={
                                  line.startsWith('+') ? 'text-emerald-400/80 bg-emerald-500/5' :
                                  line.startsWith('-') ? 'text-red-400/70 bg-red-500/5' :
                                  'text-white/35'
                                }>{line}</div>
                              ))}
                            </pre>
                          ) : (
                            <pre className="text-[9px] text-emerald-300/70 font-mono leading-relaxed overflow-x-auto whitespace-pre-wrap">{file.content}</pre>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between pt-2">
              {COMMITS.findIndex(c => c.sha === active) > 0 && (
                <button onClick={() => setActive(COMMITS[COMMITS.findIndex(c => c.sha === active) - 1].sha)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-white/8 text-white/35 text-xs hover:text-white/60 transition-all">
                  ← Prev commit
                </button>
              )}
              {COMMITS.findIndex(c => c.sha === active) < COMMITS.length - 1 && (
                <button onClick={() => setActive(COMMITS[COMMITS.findIndex(c => c.sha === active) + 1].sha)}
                  className="ml-auto flex items-center gap-1.5 px-3 py-2 rounded-xl border border-emerald-500/20 bg-emerald-500/5 text-emerald-400 text-xs hover:bg-emerald-500/10 transition-all font-semibold">
                  Next commit →
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
