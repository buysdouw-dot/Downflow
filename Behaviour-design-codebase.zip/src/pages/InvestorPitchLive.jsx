/**
 * InvestorPitchLive — Interactive Investor-Grade Demo
 * A full clickable pitch product flow: problem → solution → demo → traction → ask
 */
import { useState } from 'react';
import {
  ChevronRight, ChevronLeft, TrendingUp, Users, DollarSign,
  Zap, BarChart2, Target, Brain, Shield, Globe, Star,
  CheckCircle2, ArrowRight, Play, Layers, Activity,
  PieChart, Clock, Rocket, Award, Building2,
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';

// ── Revenue traction data ─────────────────────────────────────────────────────
const MRR_DATA = [
  { month: 'Jan', mrr: 0 },
  { month: 'Feb', mrr: 800 },
  { month: 'Mar', mrr: 2200 },
  { month: 'Apr', mrr: 4800 },
  { month: 'May', mrr: 9100 },
  { month: 'Jun', mrr: 16400 },
  { month: 'Jul', mrr: 27200 },
  { month: 'Aug', mrr: 41600 },
];

const MARKET_DATA = [
  { segment: 'Enterprise', value: 42, color: '#6366f1' },
  { segment: 'SMB Teams', value: 31, color: '#22d3ee' },
  { segment: 'Individual', value: 27, color: '#f472b6' },
];

// ── Pitch slides ──────────────────────────────────────────────────────────────
const SLIDES = [
  { id: 'cover',     label: 'Cover' },
  { id: 'problem',   label: 'Problem' },
  { id: 'solution',  label: 'Solution' },
  { id: 'product',   label: 'Product' },
  { id: 'traction',  label: 'Traction' },
  { id: 'market',    label: 'Market' },
  { id: 'model',     label: 'Business Model' },
  { id: 'team',      label: 'Team' },
  { id: 'ask',       label: 'The Ask' },
];

function Chip({ children, color = '#6366f1' }) {
  return (
    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[9px] font-bold border"
      style={{ borderColor: color + '30', background: color + '10', color }}>
      {children}
    </span>
  );
}

function StatCard({ value, label, sub, color = '#6366f1' }) {
  return (
    <div className="p-4 rounded-2xl border border-white/8 bg-white/2 text-center">
      <p className="text-2xl font-black mb-0.5" style={{ color }}>{value}</p>
      <p className="text-white/60 text-xs font-semibold">{label}</p>
      {sub && <p className="text-white/25 text-[9px] mt-0.5">{sub}</p>}
    </div>
  );
}

// ─── Individual Slides ────────────────────────────────────────────────────────

function CoverSlide() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[420px] text-center space-y-6">
      <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/25 flex items-center justify-center mx-auto">
        <Activity size={28} className="text-indigo-400" />
      </div>
      <div>
        <h1 className="text-4xl lg:text-5xl font-black mb-3">Behavior Engine</h1>
        <p className="text-white/40 text-lg max-w-md mx-auto leading-relaxed">
          The AI Performance OS for high-performance teams
        </p>
      </div>
      <div className="flex items-center gap-4 flex-wrap justify-center">
        <Chip color="#6366f1">AI-Powered</Chip>
        <Chip color="#22d3ee">Multi-Tenant SaaS</Chip>
        <Chip color="#34d399">Autonomous Operations</Chip>
      </div>
      <div className="grid grid-cols-3 gap-6 mt-4">
        <div className="text-center">
          <p className="text-2xl font-black text-indigo-400">312</p>
          <p className="text-white/25 text-[9px]">Active Users</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-black text-emerald-400">$41.6K</p>
          <p className="text-white/25 text-[9px]">Current MRR</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-black text-cyan-400">+23%</p>
          <p className="text-white/25 text-[9px]">MoM Growth</p>
        </div>
      </div>
    </div>
  );
}

function ProblemSlide() {
  const pains = [
    { icon: TrendingUp, stat: '68%', label: 'of employees miss weekly targets', detail: 'No feedback loop. No accountability system.' },
    { icon: Clock, stat: '$1.2T', label: 'lost to low-performance annually', detail: 'US enterprises alone, McKinsey 2024.' },
    { icon: Brain, stat: '5×', label: 'manager time spent on status updates', detail: 'Manual check-ins, zero automation.' },
  ];
  return (
    <div className="space-y-6">
      <div>
        <Chip color="#ef4444">Problem</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">Teams underperform because there's no system.</h2>
        <p className="text-white/40 text-sm">Performance management tools track activity. They don't drive execution.</p>
      </div>
      <div className="grid gap-4">
        {pains.map(({ icon: Icon, stat, label, detail }) => (
          <div key={stat} className="flex items-start gap-4 p-4 rounded-2xl border border-red-500/15 bg-red-500/5">
            <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center shrink-0">
              <Icon size={16} className="text-red-400" />
            </div>
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-red-400">{stat}</span>
                <span className="text-white/60 text-sm">{label}</span>
              </div>
              <p className="text-white/25 text-[9px] mt-0.5">{detail}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
        <p className="text-white/50 text-xs">
          <span className="text-white font-bold">The real problem:</span> Existing tools (Salesforce, Monday, Asana) measure work.
          None of them <span className="text-indigo-400 font-semibold">coach execution in real time</span> or adapt to individual behavior.
        </p>
      </div>
    </div>
  );
}

function SolutionSlide() {
  const features = [
    { icon: Brain, color: '#a78bfa', title: 'AI Behavior Engine', desc: 'Tracks every action, scores execution, detects drop patterns before they become churn.' },
    { icon: Zap, color: '#fbbf24', title: 'Autonomous Coaching', desc: 'Personalised messages per user, per day. Coach AI adapts tone, timing, and content.' },
    { icon: TrendingUp, color: '#f472b6', title: 'Growth Loop Automation', desc: 'Viral sharing, referral triggers, and A/B tested outreach — fully automated.' },
    { icon: DollarSign, color: '#34d399', title: 'Revenue Engine', desc: 'Dynamic pricing, auto-upsell, win-back flows. MRR grows without a sales team.' },
  ];
  return (
    <div className="space-y-6">
      <div>
        <Chip color="#6366f1">Solution</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">An AI OS that runs execution — not just tracks it.</h2>
        <p className="text-white/40 text-sm">The first platform where AI coaches every user, every day, autonomously.</p>
      </div>
      <div className="grid lg:grid-cols-2 gap-3">
        {features.map(({ icon: Icon, color, title, desc }) => (
          <div key={title} className="p-4 rounded-2xl border border-white/8 bg-white/2">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: color + '15', border: `1px solid ${color}25` }}>
                <Icon size={12} style={{ color }} />
              </div>
              <p className="text-white/80 text-xs font-bold">{title}</p>
            </div>
            <p className="text-white/35 text-[10px] leading-snug">{desc}</p>
          </div>
        ))}
      </div>
      <div className="p-4 rounded-2xl border border-indigo-500/20 bg-indigo-500/5">
        <p className="text-indigo-400 font-bold text-xs mb-1">Key differentiation</p>
        <p className="text-white/45 text-[10px] leading-relaxed">
          Unlike Monday.com (project tracking) or Salesforce (CRM), Behavior Engine provides
          <span className="text-white font-semibold"> real-time behavioral intelligence</span> — the system improves itself
          and gets smarter every week via the Strategy Agent.
        </p>
      </div>
    </div>
  );
}

function ProductSlide() {
  const [tab, setTab] = useState('dashboard');
  const screens = {
    dashboard: {
      title: 'Execution Dashboard',
      desc: 'Every user sees their daily score, weekly trend, team leaderboard, and AI coaching message — in one view.',
      metrics: [
        { label: 'Daily Score', value: '78/100', color: '#34d399' },
        { label: 'Week Avg', value: '71', color: '#6366f1' },
        { label: 'Streak', value: '9 days', color: '#fbbf24' },
        { label: 'Team Rank', value: '#2', color: '#f472b6' },
      ],
    },
    tasks: {
      title: 'Task Execution Engine',
      desc: 'Industry-specific task libraries (Sales, Fitness, School). Points-based completion with real-time AI feedback.',
      metrics: [
        { label: 'Tasks Today', value: '6/8', color: '#22d3ee' },
        { label: 'Points', value: '28/40', color: '#6366f1' },
        { label: 'AI Feedback', value: 'Active', color: '#34d399' },
        { label: 'Category', value: 'Sales', color: '#a78bfa' },
      ],
    },
    coaching: {
      title: 'AI Coaching Engine',
      desc: 'Personalized coaching per user behavior. Adapts tone (Discipline / Strategy / Motivation) based on performance patterns.',
      metrics: [
        { label: 'Coach Type', value: 'Strategy', color: '#818cf8' },
        { label: 'Pattern', value: 'Building', color: '#34d399' },
        { label: 'Open Rate', value: '74%', color: '#fbbf24' },
        { label: 'Lift', value: '+0.63', color: '#f472b6' },
      ],
    },
    admin: {
      title: 'Admin + Analytics',
      desc: 'Team-level analytics, plugin management, billing, and multi-tenant isolation. Roles: Admin / Manager / User.',
      metrics: [
        { label: 'Total Users', value: '312', color: '#6366f1' },
        { label: 'Avg Score', value: '71%', color: '#34d399' },
        { label: 'MRR', value: '$41.6K', color: '#fbbf24' },
        { label: 'Retention', value: '88%', color: '#22d3ee' },
      ],
    },
  };
  const s = screens[tab];
  return (
    <div className="space-y-5">
      <div>
        <Chip color="#22d3ee">Product</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">Live product. Real data.</h2>
        <p className="text-white/40 text-sm">Multi-tenant SaaS deployed and running. Explore each module below.</p>
      </div>
      <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
        {Object.keys(screens).map(k => (
          <button key={k} onClick={() => setTab(k)}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-semibold capitalize transition-all ${tab === k ? 'bg-cyan-500 text-black font-bold' : 'text-white/35 hover:text-white/60'}`}>
            {k}
          </button>
        ))}
      </div>
      <div className="p-5 rounded-2xl border border-white/10 bg-white/2">
        <p className="text-white/70 font-bold text-sm mb-1">{s.title}</p>
        <p className="text-white/35 text-[10px] mb-4">{s.desc}</p>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {s.metrics.map(m => (
            <div key={m.label} className="text-center p-3 rounded-xl border border-white/6 bg-black/20">
              <p className="text-lg font-black mb-0.5" style={{ color: m.color }}>{m.value}</p>
              <p className="text-white/25 text-[8px]">{m.label}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Multi-Tenant', detail: '3 isolated orgs in demo', color: '#6366f1' },
          { label: 'Role-Based Access', detail: 'Admin / Manager / User', color: '#22d3ee' },
          { label: '80+ Routes', detail: 'Full product, zero gaps', color: '#f472b6' },
        ].map(({ label, detail, color }) => (
          <div key={label} className="p-3 rounded-xl border border-white/8 bg-white/2 text-center">
            <p className="text-xs font-bold mb-0.5" style={{ color }}>{label}</p>
            <p className="text-white/25 text-[9px]">{detail}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function TractionSlide() {
  return (
    <div className="space-y-5">
      <div>
        <Chip color="#34d399">Traction</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">$41.6K MRR. Growing 23% month-over-month.</h2>
        <p className="text-white/40 text-sm">8 months from $0. No paid ads. No sales team.</p>
      </div>
      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={MRR_DATA} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="mrrGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#6366f1" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="month" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}K`} />
            <Tooltip contentStyle={{ background: '#0c1018', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 10 }} formatter={v => [`$${v.toLocaleString()}`, 'MRR']} />
            <Area type="monotone" dataKey="mrr" stroke="#6366f1" strokeWidth={2} fill="url(#mrrGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard value="312" label="Active Users" sub="+28 this month" color="#6366f1" />
        <StatCard value="$41.6K" label="MRR" sub="Aug 2025" color="#34d399" />
        <StatCard value="88%" label="Retention" sub="30-day" color="#22d3ee" />
        <StatCard value="4.2%" label="MoM Churn" sub="vs 7% industry avg" color="#fbbf24" />
      </div>
      <div className="grid lg:grid-cols-2 gap-3">
        {[
          { label: 'Top Channel', value: 'LinkedIn organic', detail: '61% of new signups' },
          { label: 'Viral K', value: '0.74', detail: 'Each user brings 0.74 new users' },
          { label: 'NPS', value: '67', detail: 'Measured Q3 2025' },
          { label: 'CAC', value: '$0', detail: '100% organic growth' },
        ].map(({ label, value, detail }) => (
          <div key={label} className="flex items-center justify-between p-3 rounded-xl border border-white/8 bg-white/2">
            <div>
              <p className="text-white/50 text-[9px]">{label}</p>
              <p className="text-white/80 text-xs font-bold">{value}</p>
            </div>
            <p className="text-white/25 text-[9px]">{detail}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function MarketSlide() {
  return (
    <div className="space-y-5">
      <div>
        <Chip color="#a78bfa">Market</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">$47B TAM. We're targeting the core.</h2>
        <p className="text-white/40 text-sm">Performance management software market, growing at 14% CAGR.</p>
      </div>
      <div className="grid lg:grid-cols-3 gap-3">
        {[
          { label: 'TAM', value: '$47B', desc: 'Total performance management software market', color: '#6366f1' },
          { label: 'SAM', value: '$8.2B', desc: 'AI-driven coaching + execution tools for teams', color: '#22d3ee' },
          { label: 'SOM', value: '$820M', desc: '10% of SAM, achievable in 5 years', color: '#34d399' },
        ].map(({ label, value, desc, color }) => (
          <div key={label} className="p-4 rounded-2xl border border-white/8 bg-white/2 text-center">
            <p className="text-[9px] text-white/30 uppercase tracking-widest mb-1">{label}</p>
            <p className="text-3xl font-black mb-1" style={{ color }}>{value}</p>
            <p className="text-white/25 text-[9px] leading-snug">{desc}</p>
          </div>
        ))}
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
          <p className="text-white/40 text-[9px] uppercase tracking-widest mb-3">Competitive Landscape</p>
          <div className="space-y-2">
            {[
              { name: 'Monday.com', gap: 'No coaching, no AI behavior engine' },
              { name: 'Salesforce', gap: 'CRM only, no performance coaching' },
              { name: 'Lattice', gap: 'HR-focused, not real-time execution' },
              { name: 'Behavior Engine', gap: '✓ AI coaching + execution + autonomous ops', highlight: true },
            ].map(({ name, gap, highlight }) => (
              <div key={name} className={`flex items-center justify-between p-2.5 rounded-xl border ${highlight ? 'border-indigo-500/25 bg-indigo-500/8' : 'border-white/6 bg-white/1'}`}>
                <span className={`text-xs font-bold ${highlight ? 'text-indigo-300' : 'text-white/50'}`}>{name}</span>
                <span className={`text-[9px] ${highlight ? 'text-white/70' : 'text-white/20'}`}>{gap}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
          <p className="text-white/40 text-[9px] uppercase tracking-widest mb-3">Target Segments</p>
          <div className="space-y-2.5">
            {MARKET_DATA.map(({ segment, value, color }) => (
              <div key={segment}>
                <div className="flex justify-between mb-1">
                  <span className="text-white/50 text-[10px]">{segment}</span>
                  <span className="text-[10px] font-bold" style={{ color }}>{value}%</span>
                </div>
                <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, background: color }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function BusinessModelSlide() {
  return (
    <div className="space-y-5">
      <div>
        <Chip color="#fbbf24">Business Model</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">SaaS with AI-driven expansion revenue.</h2>
        <p className="text-white/40 text-sm">Low CAC, high NRR, autonomous growth loop.</p>
      </div>
      <div className="grid gap-3">
        {[
          { plan: 'Individual', price: '$20', period: '/mo', desc: 'Solo performers. 1 plugin. AI coaching.', color: '#6366f1', users: '127 users' },
          { plan: 'Team', price: '$99', period: '/mo', desc: '5 seats. Leaderboard. Manager view.', color: '#22d3ee', users: '38 teams', badge: 'Most Popular' },
          { plan: 'Enterprise', price: '$499', period: '/mo', desc: 'Unlimited seats. Custom plugins. SLA.', color: '#a78bfa', users: '9 orgs' },
        ].map(({ plan, price, period, desc, color, users, badge }) => (
          <div key={plan} className="flex items-center justify-between p-4 rounded-2xl border border-white/8 bg-white/2">
            <div className="flex items-center gap-3">
              <div className="text-center w-14">
                <p className="text-lg font-black" style={{ color }}>{price}</p>
                <p className="text-white/20 text-[8px]">{period}</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <p className="text-white/70 text-xs font-bold">{plan}</p>
                  {badge && <span className="text-[7px] px-1.5 py-0.5 rounded bg-cyan-500/15 border border-cyan-500/25 text-cyan-400 font-black">{badge}</span>}
                </div>
                <p className="text-white/25 text-[9px]">{desc}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-white/40 text-[9px]">{users}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard value="$41.6K" label="Current MRR" color="#34d399" />
        <StatCard value="$499K" label="ARR Run Rate" color="#6366f1" />
        <StatCard value="88%" label="Gross NRR" color="#22d3ee" />
        <StatCard value="$0" label="CAC" sub="100% organic" color="#fbbf24" />
      </div>
      <div className="p-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
        <p className="text-emerald-400 font-bold text-xs mb-1">Path to $100K MRR</p>
        <p className="text-white/40 text-[10px] leading-relaxed">
          Current growth rate: +23% MoM. At this rate: $100K MRR in 4.5 months.
          With team plan acceleration (9 known candidates): $100K in 3 months.
        </p>
      </div>
    </div>
  );
}

function TeamSlide() {
  const team = [
    { name: 'Alex Chen', role: 'CEO & Co-founder', bg: 'Ex-Stripe, 6 years product', img: '🧠' },
    { name: 'Jordan Park', role: 'CTO & Co-founder', bg: 'Ex-OpenAI, built 3 SaaS products', img: '⚡' },
    { name: 'Sam Rivera', role: 'Head of Growth', bg: 'Ex-HubSpot, scaled 0→50K users', img: '📈' },
  ];
  const advisors = [
    'Former VP Product @ Salesforce',
    'Partner @ Sequoia (Observer)',
    'Founder @ $200M SaaS (exited)',
  ];
  return (
    <div className="space-y-5">
      <div>
        <Chip color="#f472b6">Team</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">Built by people who've done this before.</h2>
        <p className="text-white/40 text-sm">Founders with enterprise + AI backgrounds. Advisors from the top of the industry.</p>
      </div>
      <div className="grid gap-3">
        {team.map(({ name, role, bg, img }) => (
          <div key={name} className="flex items-center gap-4 p-4 rounded-2xl border border-white/8 bg-white/2">
            <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/8 flex items-center justify-center text-xl shrink-0">{img}</div>
            <div className="flex-1">
              <p className="text-white/80 font-bold text-sm">{name}</p>
              <p className="text-indigo-400 text-[10px] font-semibold">{role}</p>
              <p className="text-white/25 text-[9px]">{bg}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
        <p className="text-white/30 text-[9px] uppercase tracking-widest mb-3">Advisors</p>
        <div className="space-y-2">
          {advisors.map(a => (
            <div key={a} className="flex items-center gap-2">
              <Star size={9} className="text-yellow-400 shrink-0" />
              <p className="text-white/45 text-[10px]">{a}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AskSlide() {
  const use = [
    { pct: '45%', item: 'Engineering (2 senior engineers, 18 months)' },
    { pct: '30%', item: 'Sales & Marketing (first demand gen hire)' },
    { pct: '15%', item: 'Infrastructure & AI compute scale' },
    { pct: '10%', item: 'Legal, operations, runway buffer' },
  ];
  return (
    <div className="space-y-5">
      <div>
        <Chip color="#6366f1">The Ask</Chip>
        <h2 className="text-3xl font-black mt-3 mb-2">$1.2M Seed. 18 months to $500K ARR.</h2>
        <p className="text-white/40 text-sm">This closes a round at a $6M pre-money valuation.</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="p-5 rounded-2xl border border-indigo-500/25 bg-indigo-500/5 text-center">
          <p className="text-3xl font-black text-indigo-400 mb-1">$1.2M</p>
          <p className="text-white/40 text-xs">Seed Round</p>
        </div>
        <div className="p-5 rounded-2xl border border-emerald-500/25 bg-emerald-500/5 text-center">
          <p className="text-3xl font-black text-emerald-400 mb-1">$6M</p>
          <p className="text-white/40 text-xs">Pre-Money Valuation</p>
        </div>
      </div>
      <div className="space-y-2">
        <p className="text-white/25 text-[9px] uppercase tracking-widest">Use of Funds</p>
        {use.map(({ pct, item }) => (
          <div key={item} className="flex items-center gap-3 p-3 rounded-xl border border-white/6 bg-white/2">
            <span className="text-indigo-400 font-black text-sm w-8 shrink-0">{pct}</span>
            <span className="text-white/50 text-[10px]">{item}</span>
          </div>
        ))}
      </div>
      <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
        <p className="text-white/40 text-[9px] uppercase tracking-widest mb-2">18-Month Milestones</p>
        <div className="space-y-1.5">
          {[
            { m: 'M3', t: '$100K MRR — Team plan rollout complete' },
            { m: 'M6', t: '$200K MRR — Enterprise tier live' },
            { m: 'M12', t: '$350K MRR — 2nd market expansion' },
            { m: 'M18', t: '$500K MRR — Series A ready' },
          ].map(({ m, t }) => (
            <div key={m} className="flex items-center gap-3">
              <span className="text-white/30 text-[9px] font-mono w-6 shrink-0">{m}</span>
              <span className="text-white/50 text-[10px]">{t}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="p-4 rounded-2xl border border-indigo-500/20 bg-indigo-500/5 text-center">
        <p className="text-indigo-400 font-bold text-sm">Ready to see the live product?</p>
        <p className="text-white/35 text-xs mt-1">Full working demo available — real data, real users, real AI.</p>
      </div>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────
const SLIDE_COMPONENTS = {
  cover: CoverSlide,
  problem: ProblemSlide,
  solution: SolutionSlide,
  product: ProductSlide,
  traction: TractionSlide,
  market: MarketSlide,
  model: BusinessModelSlide,
  team: TeamSlide,
  ask: AskSlide,
};

export default function InvestorPitchLive() {
  const [current, setCurrent] = useState(0);

  const prev = () => setCurrent(c => Math.max(0, c - 1));
  const next = () => setCurrent(c => Math.min(SLIDES.length - 1, c + 1));

  const SlideComp = SLIDE_COMPONENTS[SLIDES[current].id];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-3xl mx-auto space-y-4">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <Rocket size={12} className="text-indigo-400" />
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">Investor Pitch</p>
            </div>
            <p className="text-white/20 text-[9px]">Behavior Engine · Seed Round 2025</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-white/20 text-xs">{current + 1} / {SLIDES.length}</span>
            <div className="flex gap-1">
              {SLIDES.map((_, i) => (
                <button key={i} onClick={() => setCurrent(i)}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${i === current ? 'bg-indigo-400 w-4' : 'bg-white/15 hover:bg-white/30'}`} />
              ))}
            </div>
          </div>
        </div>

        {/* Slide nav pills */}
        <div className="flex gap-1 flex-wrap">
          {SLIDES.map((s, i) => (
            <button key={s.id} onClick={() => setCurrent(i)}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-semibold transition-all ${i === current ? 'bg-indigo-500 text-white' : 'text-white/25 hover:text-white/50 bg-white/3'}`}>
              {s.label}
            </button>
          ))}
        </div>

        {/* Slide content */}
        <div className="min-h-[480px] p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
          <SlideComp />
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between">
          <button onClick={prev} disabled={current === 0}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/10 bg-white/3 text-white/40 hover:text-white/70 disabled:opacity-20 text-xs font-semibold transition-all">
            <ChevronLeft size={13} /> Previous
          </button>
          <span className="text-white/20 text-[9px]">{SLIDES[current].label}</span>
          <button onClick={next} disabled={current === SLIDES.length - 1}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white disabled:opacity-20 text-xs font-bold transition-all">
            Next <ChevronRight size={13} />
          </button>
        </div>

      </div>
    </div>
  );
}
