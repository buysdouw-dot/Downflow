/**
 * AutoCRM — Automated Sales + CRM System
 * Pipeline: Lead → Signup → Activation → Pilot → Paid → Expansion
 * No manual selling. Behavior-triggered automation engine.
 */
import { useState, useEffect } from 'react';
import {
  Users, TrendingUp, Zap, DollarSign, ArrowRight, Plus,
  RefreshCw, Bell, CheckCircle2, Clock, Target, Mail,
  Phone, Star, ChevronRight, Activity, Filter, BarChart2,
  Flame, Eye, MessageCircle, X,
} from 'lucide-react';

// ── Lead model ────────────────────────────────────────────────────────────────
const STATUSES = ['new', 'contacted', 'pilot', 'paid', 'expansion'];

const STATUS_CFG = {
  new:        { label: 'New',        color: 'text-white/50',   bg: 'bg-white/5',       border: 'border-white/10',     dot: 'bg-white/30'       },
  contacted:  { label: 'Contacted',  color: 'text-blue-400',   bg: 'bg-blue-500/10',   border: 'border-blue-500/20',  dot: 'bg-blue-400'       },
  pilot:      { label: 'Pilot',      color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20',dot: 'bg-indigo-400'     },
  paid:       { label: 'Paid',       color: 'text-emerald-400',bg: 'bg-emerald-500/10',border: 'border-emerald-500/20',dot: 'bg-emerald-400'   },
  expansion:  { label: 'Expansion',  color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', dot: 'bg-yellow-400'    },
};

const SOURCES = ['Referral', 'LinkedIn', 'Cold Outreach', 'Inbound', 'Ad', 'WhatsApp'];

const SEED_LEADS = [
  { id: 1,  name: 'Marcus Chen',    company: 'NovaSales',     status: 'expansion', source: 'Referral',     lastAction: 'Upgraded to team plan',     score: 89, daysIn: 28, teamSize: 18, value: 4999 },
  { id: 2,  name: 'Sarah Kim',      company: 'Peak Ops',      status: 'paid',      source: 'LinkedIn',     lastAction: 'Completed 7-day pilot',      score: 74, daysIn: 12, teamSize: 9,  value: 1199 },
  { id: 3,  name: 'James Torres',   company: 'FlexForce',     status: 'paid',      source: 'Cold Outreach',lastAction: 'Activated AI coaching',       score: 61, daysIn: 9,  teamSize: 12, value: 1199 },
  { id: 4,  name: 'Leila Nkosi',    company: 'Momentum Co',   status: 'pilot',     source: 'Inbound',      lastAction: 'Completed 5-day pilot',      score: 55, daysIn: 6,  teamSize: 7,  value: 599  },
  { id: 5,  name: 'Daniel Park',    company: 'ExecOps',       status: 'pilot',     source: 'Referral',     lastAction: 'First task completed',       score: 42, daysIn: 4,  teamSize: 5,  value: 599  },
  { id: 6,  name: 'Aisha Williams', company: 'Velocity Team', status: 'contacted', source: 'Ad',           lastAction: 'Replied to demo invite',     score: 0,  daysIn: 2,  teamSize: 11, value: 0    },
  { id: 7,  name: 'Tom Bennett',    company: 'ScaleHQ',       status: 'contacted', source: 'WhatsApp',     lastAction: 'Watched product video',      score: 0,  daysIn: 1,  teamSize: 6,  value: 0    },
  { id: 8,  name: 'Priya Sharma',   company: 'SalesForge',    status: 'new',       source: 'LinkedIn',     lastAction: 'Visited landing page',       score: 0,  daysIn: 0,  teamSize: 8,  value: 0    },
  { id: 9,  name: 'Carlos Ruiz',    company: 'Frontline Co',  status: 'new',       source: 'Cold Outreach',lastAction: 'Opened cold email',          score: 0,  daysIn: 0,  teamSize: 4,  value: 0    },
];

// ── Automation engine ─────────────────────────────────────────────────────────
function moveLead(lead, event) {
  const next = { ...lead, lastAction: event };
  if (event === 'signup')          next.status = 'contacted';
  if (event === 'first_task_done') next.status = 'pilot';
  if (event === '7_day_success')   next.status = 'paid';
  if (event === 'team_expansion')  next.status = 'expansion';
  return next;
}

const FUNNEL_STEPS = [
  { id: 'ad',        label: 'Ad / Outreach',      icon: Target,       color: 'text-white/40',   desc: 'Content, LinkedIn DMs, cold email'                  },
  { id: 'landing',   label: 'Landing Page',        icon: Eye,          color: 'text-blue-400',   desc: 'CTA: "Start free 7-day pilot for your team"'         },
  { id: 'signup',    label: 'Signup → Contacted',  icon: Mail,         color: 'text-indigo-400', desc: 'Auto-email: pilot setup instructions sent in < 2min' },
  { id: 'task',      label: 'First Task → Pilot',  icon: CheckCircle2, color: 'text-purple-400', desc: 'Trigger: first action logged → status = pilot'       },
  { id: 'feedback',  label: 'AI Feedback Loop',    icon: MessageCircle,color: 'text-cyan-400',   desc: 'Daily coaching emails + in-app nudges'               },
  { id: 'upgrade',   label: 'Upgrade Prompt',      icon: Flame,        color: 'text-emerald-400',desc: '"5-day streak! Unlock team analytics?" → paid'       },
];

const AUTOMATIONS = [
  { trigger: 'User signs up',          action: 'Send onboarding email + assign first task',           delay: 'Instant',    icon: Mail,         color: 'text-blue-400',    bg: 'bg-blue-500/8',    border: 'border-blue-500/15'    },
  { trigger: 'First task completed',   action: 'Trigger: status → pilot. Send "Day 1 win" email',    delay: 'Instant',    icon: CheckCircle2, color: 'text-indigo-400',  bg: 'bg-indigo-500/8',  border: 'border-indigo-500/15'  },
  { trigger: '3 days without login',   action: 'Re-engagement SMS + push notification',              delay: '72 hrs',     icon: Bell,         color: 'text-yellow-400',  bg: 'bg-yellow-500/8',  border: 'border-yellow-500/15'  },
  { trigger: '5-day streak hit',       action: 'Show upgrade modal: "Unlock team analytics?"',       delay: 'Instant',    icon: Flame,        color: 'text-emerald-400', bg: 'bg-emerald-500/8', border: 'border-emerald-500/15' },
  { trigger: '7-day pilot complete',   action: 'Trigger: status → paid. Send payment link',          delay: 'Day 7',      icon: DollarSign,   color: 'text-emerald-400', bg: 'bg-emerald-500/8', border: 'border-emerald-500/15' },
  { trigger: 'Team size > 10',         action: 'Trigger: status → expansion. Upsell enterprise',     delay: 'Auto-detect',icon: TrendingUp,   color: 'text-yellow-400',  bg: 'bg-yellow-500/8',  border: 'border-yellow-500/15'  },
  { trigger: 'Score drops RED 2+ days',action: 'Manager alert email + re-engagement sequence',       delay: '48 hrs',     icon: Activity,     color: 'text-red-400',     bg: 'bg-red-500/8',     border: 'border-red-500/15'     },
];

const UPGRADE_PROMPT = {
  trigger:   '5-day streak completed',
  headline:  'You\'ve completed 5 days. Unlock full team analytics?',
  body:      'See who\'s executing on your team. Upgrade to Pro for $99/month.',
  cta:       'Unlock Team Analytics →',
  note:      'This single popup drives 60% of free→paid conversions. Timing is everything.',
};

// ── Storage ───────────────────────────────────────────────────────────────────
function loadLeads()   { try { return JSON.parse(localStorage.getItem('be_crm_leads')) ?? SEED_LEADS; } catch { return SEED_LEADS; } }
function saveLeads(ls) { try { localStorage.setItem('be_crm_leads', JSON.stringify(ls)); } catch {} }

// ── Sub-components ────────────────────────────────────────────────────────────
function LeadCard({ lead, onMove, onSelect, selected }) {
  const cfg = STATUS_CFG[lead.status];
  return (
    <div
      onClick={() => onSelect(lead)}
      className={`p-3 rounded-xl border cursor-pointer transition-all hover:border-white/15 ${
        selected ? 'border-indigo-500/40 bg-indigo-500/6' : `${cfg.border} ${cfg.bg}`
      }`}
    >
      <div className="flex items-start justify-between mb-2">
        <div>
          <p className="text-white text-xs font-semibold leading-none">{lead.name}</p>
          <p className="text-white/35 text-[10px] mt-0.5">{lead.company}</p>
        </div>
        <div className={`flex items-center gap-1 px-1.5 py-0.5 rounded-full ${cfg.bg} border ${cfg.border}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
          <span className={`text-[8px] font-bold ${cfg.color}`}>{cfg.label}</span>
        </div>
      </div>
      <div className="flex items-center gap-3 text-[9px] text-white/25">
        <span className="flex items-center gap-0.5"><Users size={8} /> {lead.teamSize}</span>
        <span className="flex items-center gap-0.5"><Clock size={8} /> Day {lead.daysIn}</span>
        {lead.value > 0 && <span className="flex items-center gap-0.5 text-emerald-400/60"><DollarSign size={8} /> {lead.value.toLocaleString()}</span>}
      </div>
      <p className="text-white/20 text-[9px] mt-1.5 truncate">{lead.lastAction}</p>

      {/* Quick advance button */}
      {lead.status !== 'expansion' && (
        <button
          onClick={e => { e.stopPropagation(); onMove(lead); }}
          className="mt-2 w-full flex items-center justify-center gap-1 py-1.5 rounded-lg bg-white/4 hover:bg-white/8 border border-white/6 text-white/30 hover:text-white/60 text-[9px] font-semibold transition-all"
        >
          <Zap size={8} /> Advance
        </button>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sub, color }) {
  return (
    <div className="p-4 rounded-xl bg-white/2 border border-white/6">
      <Icon size={13} className={`${color} mb-2`} />
      <p className={`text-2xl font-black ${color}`}>{value}</p>
      <p className="text-white/25 text-[10px] mt-0.5">{label}</p>
      {sub && <p className="text-white/15 text-[9px]">{sub}</p>}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AutoCRM() {
  const [leads,       setLeads]      = useState(loadLeads);
  const [view,        setView]       = useState('pipeline'); // 'pipeline' | 'funnel' | 'automations'
  const [selected,    setSelected]   = useState(null);
  const [filterSrc,   setFilterSrc]  = useState('All');
  const [showPrompt,  setShowPrompt] = useState(false);

  useEffect(() => { saveLeads(leads); }, [leads]);

  const advanceLead = (lead) => {
    const idx = STATUSES.indexOf(lead.status);
    if (idx < STATUSES.length - 1) {
      const events = ['signup', 'first_task_done', '7_day_success', 'team_expansion'];
      const updated = moveLead(lead, events[idx] ?? 'signup');
      setLeads(prev => prev.map(l => l.id === lead.id ? updated : l));
      if (selected?.id === lead.id) setSelected(updated);
    }
  };

  const addLead = () => {
    const newLead = {
      id: Date.now(),
      name: 'New Lead',
      company: 'Company Name',
      status: 'new',
      source: 'Inbound',
      lastAction: 'Added manually',
      score: 0,
      daysIn: 0,
      teamSize: 5,
      value: 0,
    };
    setLeads(prev => [newLead, ...prev]);
    setSelected(newLead);
  };

  const sources = ['All', ...SOURCES];
  const filtered = filterSrc === 'All' ? leads : leads.filter(l => l.source === filterSrc);

  const stats = {
    total:    leads.length,
    pilot:    leads.filter(l => l.status === 'pilot').length,
    paid:     leads.filter(l => l.status === 'paid' || l.status === 'expansion').length,
    mrr:      leads.filter(l => l.status === 'paid' || l.status === 'expansion').reduce((s, l) => s + l.value, 0),
    convRate: leads.length ? Math.round((leads.filter(l => l.status === 'paid' || l.status === 'expansion').length / leads.length) * 100) : 0,
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Zap size={14} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">Automated CRM</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Sales + CRM System</h1>
            <p className="text-white/35 text-sm">No manual selling. Behavior-triggered pipeline automation.</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowPrompt(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold hover:bg-emerald-500/15 transition-all">
              <Flame size={11} /> Upgrade Prompt
            </button>
            <button onClick={addLead}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-white text-xs font-bold transition-all">
              <Plus size={11} /> Add Lead
            </button>
          </div>
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard icon={Users}       label="Total Leads"   value={stats.total}                  color="text-white/60"   />
          <StatCard icon={Target}      label="In Pilot"      value={stats.pilot}                  color="text-indigo-400" />
          <StatCard icon={CheckCircle2}label="Paid / Exp"    value={stats.paid}                   color="text-emerald-400"/>
          <StatCard icon={DollarSign}  label="Est. MRR"      value={`$${(stats.mrr/100).toFixed(0)}k`} sub={`${stats.convRate}% conv rate`} color="text-yellow-400" />
        </div>

        {/* View toggle */}
        <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
          {[['pipeline','Pipeline'],['funnel','Funnel'],['automations','Automations']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── PIPELINE VIEW ─────────────────────────────────────────────── */}
        {view === 'pipeline' && (
          <div className="grid lg:grid-cols-[1fr_280px] gap-6">

            {/* Kanban */}
            <div className="space-y-4">
              {/* Source filter */}
              <div className="flex items-center gap-2 flex-wrap">
                <Filter size={11} className="text-white/25" />
                {sources.map(s => (
                  <button key={s} onClick={() => setFilterSrc(s)}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-semibold transition-all ${
                      filterSrc === s ? 'bg-indigo-500 text-white' : 'bg-white/4 border border-white/8 text-white/35 hover:text-white/60'
                    }`}>{s}</button>
                ))}
              </div>

              {/* Columns */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                {STATUSES.map(status => {
                  const cfg = STATUS_CFG[status];
                  const stageLeads = filtered.filter(l => l.status === status);
                  return (
                    <div key={status} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                          <span className={`text-[10px] font-bold ${cfg.color}`}>{cfg.label}</span>
                        </div>
                        <span className="text-white/20 text-[9px] font-mono">{stageLeads.length}</span>
                      </div>
                      <div className="space-y-2">
                        {stageLeads.map(lead => (
                          <LeadCard key={lead.id} lead={lead} onMove={advanceLead}
                            onSelect={setSelected} selected={selected?.id === lead.id} />
                        ))}
                        {stageLeads.length === 0 && (
                          <div className="p-3 rounded-xl border border-dashed border-white/6 text-center">
                            <p className="text-white/15 text-[9px]">Empty</p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Detail panel */}
            {selected ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest">Lead Detail</p>
                  <button onClick={() => setSelected(null)} className="text-white/20 hover:text-white/50">
                    <X size={12} />
                  </button>
                </div>
                <div className={`p-4 rounded-xl border ${STATUS_CFG[selected.status].border} ${STATUS_CFG[selected.status].bg}`}>
                  <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full mb-3 ${STATUS_CFG[selected.status].bg} border ${STATUS_CFG[selected.status].border}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${STATUS_CFG[selected.status].dot}`} />
                    <span className={`text-[9px] font-bold ${STATUS_CFG[selected.status].color}`}>{STATUS_CFG[selected.status].label}</span>
                  </div>
                  <h3 className="text-white font-bold text-base">{selected.name}</h3>
                  <p className="text-white/40 text-xs">{selected.company}</p>
                </div>
                {[
                  ['Source',    selected.source, Star],
                  ['Team Size', `${selected.teamSize} members`, Users],
                  ['Days In',   `Day ${selected.daysIn}`, Clock],
                  ['Value',     selected.value > 0 ? `$${selected.value.toLocaleString()}/yr` : 'Not yet paid', DollarSign],
                ].map(([label, val, Icon]) => (
                  <div key={label} className="flex items-center justify-between py-2 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      <Icon size={11} className="text-white/20" />
                      <span className="text-white/35 text-xs">{label}</span>
                    </div>
                    <span className="text-white/60 text-xs font-semibold">{val}</span>
                  </div>
                ))}
                <div className="p-3 rounded-xl bg-white/3 border border-white/6">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest mb-1">Last Action</p>
                  <p className="text-white/50 text-xs">{selected.lastAction}</p>
                </div>
                {selected.status !== 'expansion' && (
                  <button onClick={() => advanceLead(selected)}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white text-sm font-bold transition-all">
                    <Zap size={14} /> Advance Pipeline <ArrowRight size={14} />
                  </button>
                )}
              </div>
            ) : (
              <div className="p-6 rounded-xl bg-white/2 border border-white/6 text-center space-y-2">
                <Users size={20} className="mx-auto text-white/15" />
                <p className="text-white/25 text-sm">Select a lead</p>
                <p className="text-white/15 text-xs">Click any lead card to view details</p>
              </div>
            )}
          </div>
        )}

        {/* ── FUNNEL VIEW ───────────────────────────────────────────────── */}
        {view === 'funnel' && (
          <div className="grid lg:grid-cols-[1fr_320px] gap-6">
            <div className="space-y-3">
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Automated Funnel Flow</p>
              {FUNNEL_STEPS.map((step, i) => {
                const Icon = step.icon;
                const count = i === 0 ? leads.length
                  : i === 1 ? leads.filter(l => l.status !== 'new').length
                  : i === 2 ? leads.filter(l => ['contacted','pilot','paid','expansion'].includes(l.status)).length
                  : i === 3 ? leads.filter(l => ['pilot','paid','expansion'].includes(l.status)).length
                  : i === 4 ? leads.filter(l => ['paid','expansion'].includes(l.status)).length
                  : leads.filter(l => l.status === 'expansion').length;
                const pct = leads.length ? Math.round((count / leads.length) * 100) : 0;
                return (
                  <div key={step.id}>
                    <div className={`flex items-center gap-4 p-4 rounded-xl bg-white/2 border border-white/6 hover:border-white/10 transition-all`}>
                      <div className="w-10 h-10 rounded-xl bg-white/4 border border-white/8 flex items-center justify-center shrink-0">
                        <Icon size={16} className={step.color} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className={`text-sm font-bold ${step.color}`}>{step.label}</p>
                          <span className="text-white/40 text-xs font-mono">{count} <span className="text-white/20">({pct}%)</span></span>
                        </div>
                        <p className="text-white/30 text-xs leading-snug">{step.desc}</p>
                        <div className="mt-2 h-1 bg-white/6 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full transition-all duration-700 ${
                            step.color.replace('text-', 'bg-').replace('/400', '/50')
                          }`} style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    </div>
                    {i < FUNNEL_STEPS.length - 1 && (
                      <div className="flex justify-center my-0.5">
                        <div className="w-px h-4 bg-white/8" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Funnel stats */}
            <div className="space-y-4">
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Conversion Metrics</p>
              <div className="space-y-3">
                {[
                  { label: 'Signup → Pilot',  rate: leads.length ? Math.round((leads.filter(l=>['pilot','paid','expansion'].includes(l.status)).length / Math.max(1, leads.filter(l=>l.status!=='new').length)) * 100) : 0, color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
                  { label: 'Pilot → Paid',    rate: leads.length ? Math.round((leads.filter(l=>['paid','expansion'].includes(l.status)).length / Math.max(1, leads.filter(l=>['pilot','paid','expansion'].includes(l.status)).length)) * 100) : 0, color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
                  { label: 'Paid → Expansion',rate: leads.length ? Math.round((leads.filter(l=>l.status==='expansion').length / Math.max(1, leads.filter(l=>['paid','expansion'].includes(l.status)).length)) * 100) : 0, color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
                ].map(({ label, rate, color, bg, border }) => (
                  <div key={label} className={`p-3 rounded-xl ${bg} border ${border}`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-white/50 text-xs">{label}</span>
                      <span className={`text-base font-black ${color}`}>{rate}%</span>
                    </div>
                    <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${bg.replace('/10','')}`}
                        style={{ width: `${rate}%` }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-4 rounded-xl bg-white/3 border border-white/6">
                <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Industry Benchmark</p>
                {[['Free → Paid', '3–5%', '→ target: 15%'],['Pilot → Paid','18–25%','→ target: 55%'],['Paid → Expansion','12%','→ target: 30%']].map(([l,b,t])=>(
                  <div key={l} className="flex items-center justify-between py-1 border-b border-white/5 last:border-0">
                    <span className="text-white/30 text-[10px]">{l}</span>
                    <span className="text-white/20 text-[9px]">{b} <span className="text-emerald-400/60">{t}</span></span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── AUTOMATIONS VIEW ──────────────────────────────────────────── */}
        {view === 'automations' && (
          <div className="space-y-4">
            <div className="grid lg:grid-cols-2 gap-4">
              {/* Automation rules */}
              <div className="space-y-3">
                <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Automation Rules</p>
                {AUTOMATIONS.map((auto) => {
                  const Icon = auto.icon;
                  return (
                    <div key={auto.trigger} className={`flex items-start gap-4 p-4 rounded-xl ${auto.bg} border ${auto.border}`}>
                      <div className={`w-9 h-9 rounded-xl ${auto.bg} border ${auto.border} flex items-center justify-center shrink-0`}>
                        <Icon size={15} className={auto.color} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-white/70 text-xs font-semibold">If: <span className={`${auto.color}`}>{auto.trigger}</span></p>
                            <p className="text-white/45 text-xs mt-0.5">Then: {auto.action}</p>
                          </div>
                          <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full ${auto.bg} border ${auto.border} ${auto.color} whitespace-nowrap shrink-0`}>
                            {auto.delay}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Upgrade prompt preview */}
              <div className="space-y-3">
                <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Upgrade Prompt (Auto-Close)</p>
                <div className="p-5 rounded-2xl border border-emerald-500/25 bg-emerald-500/5">
                  <div className="flex items-center gap-2 mb-3">
                    <Flame size={16} className="text-emerald-400" />
                    <p className="text-emerald-400 font-bold text-sm">Trigger: {UPGRADE_PROMPT.trigger}</p>
                  </div>
                  {/* Modal mockup */}
                  <div className="rounded-2xl border border-white/10 bg-[#0b0f1a] p-5 space-y-3 shadow-2xl">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
                      <Flame size={18} className="text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm leading-snug">{UPGRADE_PROMPT.headline}</p>
                      <p className="text-white/40 text-xs mt-1">{UPGRADE_PROMPT.body}</p>
                    </div>
                    <button className="w-full py-3 rounded-xl bg-emerald-500 text-white text-sm font-bold flex items-center justify-center gap-2">
                      {UPGRADE_PROMPT.cta} <ArrowRight size={14} />
                    </button>
                    <button className="w-full py-2 rounded-xl bg-white/3 text-white/30 text-xs">
                      Not yet
                    </button>
                  </div>
                  <p className="text-white/30 text-xs mt-3 leading-snug">
                    <span className="text-emerald-400 font-semibold">Note: </span>{UPGRADE_PROMPT.note}
                  </p>
                </div>

                {/* Lead model */}
                <div className="space-y-2">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest">Lead Data Model</p>
                  <div className="p-3 rounded-xl bg-black/30 border border-white/6">
                    <pre className="text-[10px] text-indigo-400/70 leading-relaxed overflow-x-auto scrollbar-hide">{`{
  name:       string,
  company:    string,
  status:     "new | contacted | pilot | paid",
  source:     "Referral | LinkedIn | ...",
  lastAction: string,
  teamSize:   number,
  value:      number,   // monthly value ($)
  daysIn:     number,   // days in current stage
}`}</pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Upgrade prompt modal */}
        {showPrompt && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowPrompt(false)}>
            <div className="max-w-sm w-full rounded-2xl border border-emerald-500/30 bg-[#0b0f1a] p-6 space-y-4"
              onClick={e => e.stopPropagation()}>
              <button onClick={() => setShowPrompt(false)} className="absolute top-4 right-4 text-white/25 hover:text-white/50">
                <X size={14} />
              </button>
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
                <Flame size={22} className="text-emerald-400" />
              </div>
              <div>
                <p className="text-white font-black text-lg leading-snug">{UPGRADE_PROMPT.headline}</p>
                <p className="text-white/40 text-sm mt-1">{UPGRADE_PROMPT.body}</p>
              </div>
              <button onClick={() => setShowPrompt(false)}
                className="w-full py-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-base font-bold flex items-center justify-center gap-2 transition-all shadow-xl shadow-emerald-500/25">
                {UPGRADE_PROMPT.cta} <ArrowRight size={16} />
              </button>
              <button onClick={() => setShowPrompt(false)}
                className="w-full py-2.5 rounded-xl bg-white/4 text-white/30 hover:text-white/50 text-sm transition-all">
                Not yet — continue free
              </button>
              <p className="text-white/20 text-[10px] text-center">No credit card required to upgrade today</p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
