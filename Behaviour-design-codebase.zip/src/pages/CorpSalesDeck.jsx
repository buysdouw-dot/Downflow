/**
 * CorpSalesDeck — Corporate Sales Deck + Closing System
 * Full 8-slide deck with interactive closing scripts.
 * Positioning: "Execution performance improvement system for teams"
 */
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Briefcase, ChevronLeft, ChevronRight, Copy, CheckCircle2,
  Zap, TrendingUp, Users, Bot, BarChart2, DollarSign, Target,
  AlertTriangle, CheckCircle, Shield, Phone, ArrowRight, Star,
  MessageCircle, Flame,
} from 'lucide-react';

// ── Slide data ────────────────────────────────────────────────────────────────
const SLIDES = [
  {
    id: 1,
    tag: 'Title',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    render: () => (
      <div className="flex flex-col items-center justify-center h-full text-center space-y-6 px-8">
        <div className="w-16 h-16 rounded-2xl bg-indigo-500 flex items-center justify-center shadow-2xl shadow-indigo-500/30 mx-auto">
          <Zap size={28} className="text-white" />
        </div>
        <div>
          <h2 className="text-3xl lg:text-4xl font-black mb-3">Behavior Engine</h2>
          <p className="text-indigo-400 text-lg font-semibold mb-4">Execution Operating System for Teams</p>
          <p className="text-white/35 text-sm max-w-md mx-auto leading-relaxed">
            Track, measure, and improve daily team performance through structured behavior systems and AI coaching.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-3">
          {['Sales Teams', 'Operations', 'Education', 'Logistics'].map(t => (
            <span key={t} className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">{t}</span>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 2,
    tag: 'The Problem',
    color: 'text-red-400',
    bg: 'bg-red-500/8',
    border: 'border-red-500/20',
    render: () => (
      <div className="flex flex-col justify-center h-full px-8 space-y-5">
        <div>
          <p className="text-red-400 text-xs font-bold uppercase tracking-widest mb-2">Slide 2 · The Problem</p>
          <h2 className="text-2xl lg:text-3xl font-black mb-3">Teams fail due to inconsistent execution.</h2>
          <p className="text-white/40 text-sm">Not lack of skill. Not lack of strategy. Execution breaks down daily.</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: '😤', stat: '82%', text: 'of managers can\'t see who\'s executing daily' },
            { icon: '📉', stat: '67%', text: 'of reps miss quota from poor daily habits'     },
            { icon: '🔁', stat: '$1.5T', text: 'lost annually to inconsistent team execution' },
            { icon: '🏳️', stat: '73%', text: 'of behavior programs fail without tracking'   },
          ].map(({ icon, stat, text }) => (
            <div key={stat} className="p-4 rounded-xl bg-red-500/8 border border-red-500/15">
              <p className="text-red-400 text-xl font-black mb-1">{stat}</p>
              <p className="text-white/40 text-xs leading-snug">{icon} {text}</p>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 3,
    tag: 'Cost of Problem',
    color: 'text-orange-400',
    bg: 'bg-orange-500/8',
    border: 'border-orange-500/20',
    render: () => (
      <div className="flex flex-col justify-center h-full px-8 space-y-5">
        <div>
          <p className="text-orange-400 text-xs font-bold uppercase tracking-widest mb-2">Slide 3 · Cost of Problem</p>
          <h2 className="text-2xl lg:text-3xl font-black mb-2">What inconsistency actually costs.</h2>
        </div>
        <div className="space-y-3">
          {[
            { icon: DollarSign, color: 'text-red-400',    bg: 'bg-red-500/8',    border: 'border-red-500/15',    title: 'Lost Revenue',       desc: 'Every unfollowed-up lead is dead revenue. Reps that don\'t execute drain pipeline.' },
            { icon: Phone,      color: 'text-orange-400', bg: 'bg-orange-500/8', border: 'border-orange-500/15', title: 'Poor Follow-Ups',    desc: '75% of deals require 5 follow-ups. Only 12% of reps do more than 3. Daily tracking closes this gap.' },
            { icon: Shield,     color: 'text-yellow-400', bg: 'bg-yellow-500/8', border: 'border-yellow-500/15', title: 'Low Accountability', desc: 'Without visible data, managers manage by gut. That\'s expensive and often wrong.' },
          ].map(({ icon: Icon, color, bg, border, title, desc }) => (
            <div key={title} className={`flex gap-4 p-4 rounded-xl ${bg} border ${border}`}>
              <div className={`w-10 h-10 rounded-xl ${bg} border ${border} flex items-center justify-center shrink-0`}>
                <Icon size={17} className={color} />
              </div>
              <div>
                <p className={`font-bold text-sm ${color}`}>{title}</p>
                <p className="text-white/35 text-xs leading-snug mt-0.5">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 4,
    tag: 'The Solution',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    render: () => (
      <div className="flex flex-col justify-center h-full px-8 space-y-5">
        <div>
          <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest mb-2">Slide 4 · Solution</p>
          <h2 className="text-2xl lg:text-3xl font-black mb-2">We track and improve daily behavior.</h2>
          <p className="text-white/40 text-sm">Not performance reviews. Not CRM data. Real behavior — every day.</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: Target,    label: 'Assign Tasks',       desc: 'Role-based daily actions for every team member',  color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
            { icon: BarChart2, label: 'Score Performance',  desc: 'GREEN/YELLOW/RED status — visible in real-time',   color: 'text-emerald-400',bg: 'bg-emerald-500/10',border: 'border-emerald-500/20'},
            { icon: Bot,       label: 'AI Coaching',        desc: 'Personalized coaching per user, per pattern',      color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
            { icon: Users,     label: 'Team Visibility',    desc: 'Manager dashboard shows who\'s executing live',    color: 'text-cyan-400',   bg: 'bg-cyan-500/10',   border: 'border-cyan-500/20'   },
          ].map(({ icon: Icon, label, desc, color, bg, border }) => (
            <div key={label} className={`p-4 rounded-xl ${bg} border ${border}`}>
              <Icon size={16} className={`${color} mb-2`} />
              <p className={`text-sm font-bold ${color} mb-1`}>{label}</p>
              <p className="text-white/35 text-xs leading-snug">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 5,
    tag: 'How It Works',
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/8',
    border: 'border-cyan-500/20',
    render: () => (
      <div className="flex flex-col justify-center h-full px-8 space-y-4">
        <div>
          <p className="text-cyan-400 text-xs font-bold uppercase tracking-widest mb-2">Slide 5 · How It Works</p>
          <h2 className="text-2xl lg:text-3xl font-black mb-2">4 steps. Real change.</h2>
        </div>
        <div className="space-y-3">
          {[
            { step: '01', title: 'Assign Tasks',         desc: 'Each team member gets daily behavior tasks matched to their role via your plugin.', color: 'text-indigo-400',  bg: 'bg-indigo-500/8',  border: 'border-indigo-500/15'  },
            { step: '02', title: 'Track Execution',      desc: 'Team logs each action in one tap. Timestamps, completion rates, and patterns captured.', color: 'text-cyan-400',   bg: 'bg-cyan-500/8',    border: 'border-cyan-500/15'    },
            { step: '03', title: 'Score Performance',    desc: 'Behavior Engine assigns GREEN/YELLOW/RED status daily. Managers see the full picture.', color: 'text-emerald-400', bg: 'bg-emerald-500/8', border: 'border-emerald-500/15' },
            { step: '04', title: 'Improve Behavior',     desc: 'AI coach gives real-time personalized feedback. Patterns improve week over week.', color: 'text-purple-400',  bg: 'bg-purple-500/8',  border: 'border-purple-500/15'  },
          ].map(({ step, title, desc, color, bg, border }) => (
            <div key={step} className={`flex items-start gap-4 p-3 rounded-xl ${bg} border ${border}`}>
              <span className={`text-xs font-black font-mono shrink-0 w-8 text-center ${color}`}>{step}</span>
              <div>
                <p className={`text-sm font-bold ${color}`}>{title}</p>
                <p className="text-white/35 text-xs mt-0.5">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 6,
    tag: 'Results',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/8',
    border: 'border-emerald-500/20',
    render: () => (
      <div className="flex flex-col justify-center h-full px-8 space-y-5">
        <div>
          <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-2">Slide 6 · Results</p>
          <h2 className="text-2xl lg:text-3xl font-black mb-2">Real results from pilot teams.</h2>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[
            { metric: '+43%', label: 'task completion in 7 days',       color: 'text-emerald-400' },
            { metric: '3×',   label: 'more follow-ups per rep weekly',  color: 'text-indigo-400'  },
            { metric: '89%',  label: 'maintain GREEN status at day 30', color: 'text-yellow-400'  },
            { metric: '7d',   label: 'to visible behavioral change',    color: 'text-purple-400'  },
          ].map(({ metric, label, color }) => (
            <div key={label} className="p-4 rounded-xl bg-white/3 border border-white/6 text-center">
              <p className={`text-3xl font-black ${color} mb-1`}>{metric}</p>
              <p className="text-white/35 text-xs leading-snug">{label}</p>
            </div>
          ))}
        </div>
        <div className="p-4 rounded-xl bg-white/3 border border-white/6">
          <p className="text-white/25 text-[10px] uppercase tracking-widest mb-2">Pilot Feedback</p>
          <p className="text-white/60 text-sm italic">"After 2 weeks, our outreach volume doubled. The leaderboard made everyone want to stay green."</p>
          <p className="text-white/25 text-xs mt-1">— Sales Director, NovaSales (14-person team)</p>
        </div>
      </div>
    ),
  },
  {
    id: 7,
    tag: 'Pricing',
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/8',
    border: 'border-yellow-500/20',
    render: () => (
      <div className="flex flex-col justify-center h-full px-8 space-y-5">
        <div>
          <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest mb-2">Slide 7 · Pricing</p>
          <h2 className="text-2xl lg:text-3xl font-black mb-2">Simple, scalable pricing.</h2>
        </div>
        <div className="space-y-3">
          {[
            { name: 'Starter',    price: '$49/mo',         desc: 'Up to 10 users',          color: 'text-emerald-400', features: ['Core engine', 'Leaderboard', 'Email support'] },
            { name: 'Pro',        price: '$99/mo',         desc: 'Up to 50 users',          color: 'text-indigo-400',  features: ['AI coaching', 'Admin analytics', 'Plugin marketplace'], popular: true },
            { name: 'Enterprise', price: 'Custom pricing', desc: 'Unlimited users + API',   color: 'text-purple-400',  features: ['Custom plugins', 'SLA', 'Dedicated manager'] },
          ].map(({ name, price, desc, color, features, popular }) => (
            <div key={name} className={`flex items-center gap-4 p-4 rounded-xl border ${popular ? 'border-indigo-500/30 bg-indigo-500/8' : 'border-white/6 bg-white/2'}`}>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className={`font-bold text-sm ${color}`}>{name}</p>
                  {popular && <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full bg-indigo-500 text-white">POPULAR</span>}
                </div>
                <p className="text-white/25 text-xs">{desc}</p>
              </div>
              <div className="text-right">
                <p className={`text-lg font-black ${color}`}>{price}</p>
                <div className="flex gap-1 justify-end mt-1">
                  {features.slice(0, 2).map(f => (
                    <span key={f} className={`text-[8px] px-1.5 py-0.5 rounded-full bg-white/5 text-white/30`}>{f}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="text-white/20 text-xs text-center">All plans include 7-day free pilot · No credit card required</p>
      </div>
    ),
  },
  {
    id: 8,
    tag: 'Pilot Offer',
    color: 'text-red-400',
    bg: 'bg-red-500/8',
    border: 'border-red-500/20',
    render: ({ navigate }) => (
      <div className="flex flex-col items-center justify-center h-full text-center px-8 space-y-6">
        <div className="w-14 h-14 rounded-2xl bg-red-500/15 border border-red-500/25 flex items-center justify-center mx-auto">
          <Flame size={26} className="text-red-400" />
        </div>
        <div>
          <p className="text-red-400 text-xs font-bold uppercase tracking-widest mb-2">Slide 8 · Close</p>
          <h2 className="text-2xl lg:text-3xl font-black mb-3">Start with a 7-day pilot.</h2>
          <p className="text-white/40 text-sm max-w-sm mx-auto leading-relaxed">
            No long contracts. No IT complexity. Set up your team in 10 minutes and see real execution data from day one.
          </p>
        </div>
        <div className="w-full space-y-2 max-w-sm">
          {['Free 7-day pilot for your entire team', 'Setup in under 10 minutes', 'Full AI coaching from day 1', 'No value = no cost. Simple.'].map(t => (
            <div key={t} className="flex items-center gap-2.5">
              <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
              <span className="text-white/55 text-sm">{t}</span>
            </div>
          ))}
        </div>
        <button onClick={() => navigate('/start')}
          className="flex items-center gap-2 px-8 py-4 bg-red-500 hover:bg-red-400 rounded-2xl text-base font-bold text-white transition-all shadow-xl shadow-red-500/25">
          Start Free Pilot <ArrowRight size={16} />
        </button>
      </div>
    ),
  },
];

// ── Closing Scripts ───────────────────────────────────────────────────────────
const CLOSING_SCRIPTS = [
  {
    phase: 'Initial Contact',
    icon: MessageCircle,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    script: '"We help teams improve execution consistency in 7 days using structured daily tracking. Want a pilot?"',
    notes: 'Keep it short. One sentence. Wait for the reply before saying anything else.',
  },
  {
    phase: 'After Interest',
    icon: Target,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    script: '"We\'ll set up your team in under 10 minutes. You\'ll see execution data immediately — who\'s performing, who needs coaching, where the gaps are."',
    notes: 'Focus on immediate ROI. They see data on day 1. No setup complexity. No waiting.',
  },
  {
    phase: 'Handling "What does it cost?"',
    icon: DollarSign,
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/20',
    script: '"$49/month per team for up to 10 users. But let\'s not talk about cost yet — run the 7-day pilot free. You\'ll see the value before you pay anything."',
    notes: 'Don\'t sell on price. Sell on risk-reversal. Zero cost to see results.',
  },
  {
    phase: 'Handling "We already have CRM"',
    icon: Shield,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
    script: '"This isn\'t CRM. CRM tracks pipeline. Behavior Engine tracks execution — the daily actions that feed your CRM. Most CRM failures happen because reps don\'t execute consistently. We fix that."',
    notes: 'This objection comes up every time. Separate positioning. Not competing with Salesforce.',
  },
  {
    phase: 'The Close',
    icon: CheckCircle,
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/20',
    script: '"Let\'s run a 7-day pilot with your team. If there\'s no value, you walk away with zero obligation. If you see value — we\'ll talk about continuing monthly. Deal?"',
    notes: 'Always close with a no-risk offer. 7-day pilot = no objection possible. They have nothing to lose.',
  },
];

// ── Main Component ─────────────────────────────────────────────────────────────
export default function CorpSalesDeck() {
  const navigate    = useNavigate();
  const [slide, setSlide]       = useState(0);
  const [copiedIdx, setCopied]  = useState(null);
  const [activeScript, setScript] = useState(null);
  const [view, setView]         = useState('deck'); // 'deck' | 'scripts'

  const prevSlide = () => setSlide(p => Math.max(0, p - 1));
  const nextSlide = () => setSlide(p => Math.min(SLIDES.length - 1, p + 1));

  const copyScript = (i, text) => {
    navigator.clipboard.writeText(text.replace(/"/g, '')).catch(() => {});
    setCopied(i);
    setTimeout(() => setCopied(null), 2000);
  };

  const currentSlide = SLIDES[slide];
  const c = {
    color:  currentSlide.color,
    bg:     currentSlide.bg,
    border: currentSlide.border,
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Briefcase size={14} className="text-yellow-400" />
              <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest">Corporate Sales System</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Sales Deck + Closing Scripts</h1>
            <p className="text-white/35 text-sm">You are not selling software. You are selling execution performance improvement.</p>
          </div>
        </div>

        {/* View toggle */}
        <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
          {[['deck', 'Sales Deck'], ['scripts', 'Closing Scripts']].map(([v, l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-5 py-2 rounded-lg text-sm font-semibold transition-all ${view === v ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {view === 'deck' && (
          <div className="grid lg:grid-cols-[1fr_280px] gap-6">

            {/* Main slide */}
            <div>
              <div className={`rounded-2xl border ${c.border} ${c.bg} overflow-hidden`}
                style={{ minHeight: '420px' }}>
                {/* Slide header */}
                <div className={`flex items-center justify-between px-6 py-3 border-b ${c.border}`}>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-black font-mono ${c.color}`}>{String(slide + 1).padStart(2, '0')}</span>
                    <span className={`text-xs font-bold ${c.color}`}>{currentSlide.tag}</span>
                  </div>
                  <span className="text-white/20 text-[10px]">{slide + 1} / {SLIDES.length}</span>
                </div>

                {/* Slide content */}
                <div style={{ minHeight: '360px' }}>
                  {currentSlide.render({ navigate })}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between mt-4">
                <button onClick={prevSlide} disabled={slide === 0}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/4 border border-white/8 text-white/40 hover:text-white/70 disabled:opacity-30 transition-all text-sm">
                  <ChevronLeft size={14} /> Previous
                </button>

                {/* Dot nav */}
                <div className="flex gap-1.5">
                  {SLIDES.map((_, i) => (
                    <button key={i} onClick={() => setSlide(i)}
                      className={`rounded-full transition-all ${i === slide ? `w-5 h-2 ${SLIDES[i].color.replace('text-', 'bg-')}` : 'w-2 h-2 bg-white/15 hover:bg-white/30'}`} />
                  ))}
                </div>

                <button onClick={nextSlide} disabled={slide === SLIDES.length - 1}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/4 border border-white/8 text-white/40 hover:text-white/70 disabled:opacity-30 transition-all text-sm">
                  Next <ChevronRight size={14} />
                </button>
              </div>
            </div>

            {/* Slide thumbnails */}
            <div className="space-y-2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest px-1">All Slides</p>
              <div className="space-y-1.5 max-h-[480px] overflow-y-auto scrollbar-hide pr-1">
                {SLIDES.map((s, i) => (
                  <button key={s.id} onClick={() => setSlide(i)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                      i === slide ? `${s.border} ${s.bg}` : 'border-white/5 bg-white/1 hover:border-white/10'
                    }`}>
                    <span className={`text-[9px] font-black font-mono w-5 shrink-0 ${i === slide ? s.color : 'text-white/20'}`}>
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className={`text-xs font-semibold ${i === slide ? s.color : 'text-white/40'}`}>{s.tag}</span>
                    {i === slide && <div className={`w-1 h-1 rounded-full ml-auto ${s.color.replace('text-', 'bg-')}`} />}
                  </button>
                ))}
              </div>

              {/* Presenter notes */}
              <div className="p-3 rounded-xl bg-white/3 border border-white/6 mt-2">
                <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Presenter Notes</p>
                <p className="text-white/35 text-xs leading-relaxed">
                  {slide === 0 && 'Lead with the name + positioning. Don\'t explain. Ask "do your teams struggle with execution consistency?"'}
                  {slide === 1 && 'Present the data first. Let silence do the work after each stat. Don\'t rush to the solution.'}
                  {slide === 2 && 'Make the cost personal. Ask: "What does a lost deal cost your team per week?"'}
                  {slide === 3 && 'Keep this fast. 30 seconds. "We track behavior, score it, and coach in real-time."'}
                  {slide === 4 && 'Use the word "tap." One tap = logged. No forms. That\'s the hook.'}
                  {slide === 5 && 'Real numbers from real pilots. If you have your own data, use it here.'}
                  {slide === 6 && 'Don\'t negotiate on price. Push to the pilot. "Let\'s talk price after you see the data."'}
                  {slide === 7 && 'End with the CTA. One ask: "Start the 7-day pilot." That\'s it.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {view === 'scripts' && (
          <div className="space-y-4">
            {/* Positioning block */}
            <div className="p-5 rounded-2xl border border-yellow-500/20 bg-yellow-500/5">
              <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest mb-2">Core Positioning — Say This Every Time</p>
              <p className="text-white/70 text-base font-semibold leading-relaxed">
                "We help teams improve execution consistency in 7 days. Not motivation. Not more training.
                Just a system that tracks, scores, and coaches daily behavior."
              </p>
            </div>

            {/* Scripts */}
            <div className="space-y-3">
              {CLOSING_SCRIPTS.map((script, i) => {
                const Icon = script.icon;
                const isOpen = activeScript === i;
                return (
                  <div key={script.phase} className={`rounded-2xl border transition-all overflow-hidden ${isOpen ? `${script.border} ${script.bg}` : 'border-white/6 bg-white/1 hover:border-white/10'}`}>
                    <button onClick={() => setScript(isOpen ? null : i)}
                      className="w-full flex items-center gap-4 p-4 text-left">
                      <div className={`w-9 h-9 rounded-xl ${script.bg} border ${script.border} flex items-center justify-center shrink-0`}>
                        <Icon size={15} className={script.color} />
                      </div>
                      <div className="flex-1">
                        <p className={`font-bold text-sm ${isOpen ? script.color : 'text-white/70'}`}>{script.phase}</p>
                      </div>
                      <ChevronRight size={14} className={`text-white/20 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
                    </button>

                    {isOpen && (
                      <div className="px-4 pb-4 space-y-3 border-t border-white/5 pt-3">
                        <div className={`p-4 rounded-xl ${script.bg} border ${script.border}`}>
                          <div className="flex items-center justify-between mb-2">
                            <p className={`text-[9px] font-bold uppercase tracking-widest ${script.color}`}>Script</p>
                            <button onClick={() => copyScript(i, script.script)}
                              className={`flex items-center gap-1 text-[9px] font-semibold px-2 py-1 rounded-lg ${script.bg} ${script.color} border ${script.border}`}>
                              {copiedIdx === i ? <><CheckCircle2 size={9} /> Copied!</> : <><Copy size={9} /> Copy</>}
                            </button>
                          </div>
                          <p className="text-white/70 text-sm leading-relaxed italic">{script.script}</p>
                        </div>
                        <div className="p-3 rounded-xl bg-white/3 border border-white/6">
                          <p className="text-white/20 text-[9px] uppercase tracking-widest mb-1">Coaching Note</p>
                          <p className="text-white/45 text-xs leading-snug">{script.notes}</p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Final rule */}
            <div className="p-5 rounded-2xl border border-red-500/20 bg-red-500/5">
              <p className="text-red-400 font-bold text-sm mb-2">The Golden Rule</p>
              <p className="text-white/55 text-sm leading-relaxed">
                Never sell on price. Always sell on the pilot. A 7-day free pilot has no objection possible.
                Close every conversation with: <span className="text-white font-semibold">"Let's run the pilot. If there's no value, you walk away."</span>
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
