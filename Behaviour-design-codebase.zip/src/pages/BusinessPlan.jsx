/**
 * BusinessPlan — Comprehensive Business Plan
 * Executive Summary · Market · Product · Operations · Financials · Team · Risk
 */
import { useState } from 'react';
import {
  BarChart2, TrendingUp, Users, DollarSign, Target,
  Shield, Zap, Brain, Globe, CheckCircle2, AlertTriangle,
  Building2, PieChart, Activity, Layers, ArrowUp, ArrowDown,
  Calendar, Clock, Star, ChevronRight, Award, Rocket,
  Settings, BookOpen, Map, Download, FileText, Printer,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart as RechartsPie,
  Pie, Cell, CartesianGrid, Legend,
} from 'recharts';

// ── Color palette ─────────────────────────────────────────────────────────────
const C = {
  indigo: '#6366f1', cyan: '#22d3ee', violet: '#a78bfa',
  pink: '#f472b6', amber: '#fbbf24', emerald: '#34d399',
  orange: '#fb923c', blue: '#60a5fa', rose: '#f87171',
};

// ── Financial projections (5-year) ────────────────────────────────────────────
const FIVE_YEAR = [
  { year: 'Y1', mrr: 41.6, arr: 499, users: 312,  cogs: 80,  opex: 240, ebitda: 179,  growth: null  },
  { year: 'Y2', mrr: 175,  arr: 2100,users: 1400, cogs: 290, opex: 900, ebitda: 910,  growth: 321   },
  { year: 'Y3', mrr: 520,  arr: 6240,users: 4100, cogs: 780, opex: 2100,ebitda: 3360, growth: 197   },
  { year: 'Y4', mrr: 1100, arr: 13200,users:8700, cogs: 1500,opex: 4000,ebitda: 7700, growth: 112   },
  { year: 'Y5', mrr: 2100, arr: 25200,users:16000,cogs: 2600,opex: 7200,ebitda: 15400,growth: 91    },
];

// ── Monthly MRR (18-month) ────────────────────────────────────────────────────
const MONTHLY_MRR = [
  { m: 'M0',  mrr: 0,     users: 0   },
  { m: 'M1',  mrr: 1.0,   users: 50  },
  { m: 'M2',  mrr: 4.2,   users: 210 },
  { m: 'M3',  mrr: 10.0,  users: 500 },
  { m: 'M4',  mrr: 18.5,  users: 925 },
  { m: 'M5',  mrr: 30.0,  users: 1500},
  { m: 'M6',  mrr: 41.6,  users: 2080},
  { m: 'M9',  mrr: 75.0,  users: 3750},
  { m: 'M12', mrr: 120.0, users: 6000},
  { m: 'M18', mrr: 210.0, users: 10500},
];

// ── Revenue mix ───────────────────────────────────────────────────────────────
const REV_MIX_Y1 = [
  { name: 'Individual ($20)', value: 38, color: C.indigo },
  { name: 'Team ($99)',       value: 43, color: C.cyan   },
  { name: 'Enterprise ($499)',value: 19, color: C.violet },
];
const REV_MIX_Y3 = [
  { name: 'Individual ($20)', value: 18, color: C.indigo },
  { name: 'Team ($99)',       value: 39, color: C.cyan   },
  { name: 'Enterprise ($499)',value: 43, color: C.violet },
];

// ── Operating budget ──────────────────────────────────────────────────────────
const BUDGET = [
  { category: 'Engineering',    y1: 120, y2: 480,  y3: 1100, color: C.indigo  },
  { category: 'Sales & Mktg',   y1: 40,  y2: 240,  y3: 620,  color: C.pink    },
  { category: 'AI / Infra',     y1: 30,  y2: 80,   y3: 200,  color: C.amber   },
  { category: 'G&A',            y1: 25,  y2: 60,   y3: 140,  color: C.violet  },
  { category: 'Customer Succ.', y1: 15,  y2: 40,   y3: 140,  color: C.emerald },
  { category: 'R&D',            y1: 10,  y2: 0,    y3: 0,    color: C.cyan    },
];

// ── Unit economics ────────────────────────────────────────────────────────────
const UNIT_ECON = [
  { metric: 'CAC (blended)',       y1: '$0',    y2: '$48',   y3: '$72',   note: 'Organic → Paid mix' },
  { metric: 'LTV (blended)',       y1: '$320',  y2: '$540',  y3: '$890',  note: 'Based on avg churn' },
  { metric: 'LTV:CAC ratio',       y1: '∞',     y2: '11.3×', y3: '12.4×', note: 'Target >3×' },
  { metric: 'Payback period',      y1: '<1 mo', y2: '2.4 mo',y3: '3.1 mo',note: 'Industry avg 12mo' },
  { metric: 'Gross margin',        y1: '84%',   y2: '86%',   y3: '88%',   note: 'Improving with scale' },
  { metric: 'Monthly churn',       y1: '4.2%',  y2: '3.1%',  y3: '2.4%',  note: 'Improving retention' },
  { metric: 'NRR',                 y1: '108%',  y2: '118%',  y3: '127%',  note: 'Expansion revenue' },
  { metric: 'ARR per employee',    y1: '$83K',  y2: '$175K', y3: '$208K', note: 'Productivity metric' },
];

// ── Competitive matrix ────────────────────────────────────────────────────────
const COMP_MATRIX = {
  features: ['AI Coaching', 'Behavior Analytics', 'Autonomous Ops', 'Multi-Tenant', 'Viral Loop', 'Dynamic Pricing', 'Self-Improving'],
  companies: [
    { name: 'Behavior Engine', scores: [5,5,5,5,5,5,5], color: C.indigo, highlight: true },
    { name: 'Monday.com',      scores: [1,2,0,4,2,0,0], color: '#94a3b8' },
    { name: 'Lattice',         scores: [2,3,0,4,1,0,0], color: '#94a3b8' },
    { name: 'Salesforce',      scores: [2,3,0,5,1,0,0], color: '#94a3b8' },
    { name: 'BetterUp',        scores: [4,2,0,3,1,0,0], color: '#94a3b8' },
  ],
};

// ── Org chart ─────────────────────────────────────────────────────────────────
const HIRING_PLAN = [
  { phase: 'Now (Y1)',   hires: ['CEO (Founder)', 'CTO (Founder)', 'Head of Growth'], count: 3,  cost: 360, color: C.indigo  },
  { phase: 'Seed (Y2)', hires: ['2× Engineers', 'Customer Success', 'SDR'], count: 4, cost: 580, color: C.cyan   },
  { phase: 'Scale (Y3)',hires: ['VP Sales', 'VP Engineering', '3× Engineers', '2× CS'], count: 6, cost: 1100, color: C.violet },
  { phase: 'Series A',  hires: ['CFO', 'VP Marketing', '4× Engineers', 'Data Scientist'], count: 7, cost: 1800, color: C.amber  },
];

// ── Risk register ─────────────────────────────────────────────────────────────
const RISKS = [
  { risk: 'High churn if product value unclear', probability: 'Med', impact: 'High', mitigation: 'Weekly coaching quality reviews. NPS trigger for at-risk accounts.' },
  { risk: 'AI cost spike (OpenAI pricing)',       probability: 'Low', impact: 'Med',  mitigation: 'Open-source LLM fallback (Llama 3). Cost monitoring alerts.' },
  { risk: 'Large competitor enters space',        probability: 'Low', impact: 'High', mitigation: '18-month moat via behavior data + network effect. Move fast.' },
  { risk: 'GDPR / data compliance issue',        probability: 'Med', impact: 'High', mitigation: 'EU data residency (Supabase EU). DPA agreements. Legal audit Q2.' },
  { risk: 'Key person dependency (CTO)',          probability: 'Low', impact: 'High', mitigation: 'Documented architecture. Hire senior engineer by M6.' },
  { risk: 'Sales cycle too long (Enterprise)',    probability: 'Med', impact: 'Med',  mitigation: 'SMB-first until $500K ARR. Enterprise as add-on channel.' },
];

// ── KPI targets ───────────────────────────────────────────────────────────────
const KPI_TARGETS = [
  { kpi: 'MRR',            now: '$41.6K',  m6: '$100K',   m12: '$200K',  m18: '$400K'  },
  { kpi: 'Active Users',   now: '312',     m6: '1,500',   m12: '4,000',  m18: '9,000'  },
  { kpi: 'Churn Rate',     now: '4.2%',    m6: '3.5%',    m12: '3.0%',   m18: '2.5%'   },
  { kpi: 'NPS',            now: '67',      m6: '72',      m12: '78',     m18: '82'      },
  { kpi: 'NRR',            now: '108%',    m6: '115%',    m12: '122%',   m18: '128%'    },
  { kpi: 'Viral K',        now: '0.74',    m6: '0.85',    m12: '1.0',    m18: '1.15'    },
];

const SECTIONS = [
  { id: 'exec',    label: 'Executive Summary', icon: BookOpen },
  { id: 'market',  label: 'Market Analysis',   icon: Globe    },
  { id: 'product', label: 'Product & Tech',    icon: Zap      },
  { id: 'ops',     label: 'Operations',        icon: Settings },
  { id: 'finance', label: 'Financials',        icon: DollarSign},
  { id: 'team',    label: 'Team & Hiring',     icon: Users    },
  { id: 'risk',    label: 'Risk Register',     icon: Shield   },
  { id: 'kpis',    label: 'KPI Dashboard',     icon: Target   },
];

function SectionHeader({ icon: Icon, title, subtitle, color = C.indigo }) {
  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 mb-1">
        <Icon size={14} style={{ color }} />
        <p className="text-xs font-bold uppercase tracking-widest" style={{ color }}>{title}</p>
      </div>
      {subtitle && <p className="text-white/35 text-sm">{subtitle}</p>}
    </div>
  );
}

function MetricCard({ value, label, sub, color = C.indigo, trend }) {
  return (
    <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
      <p className="text-2xl font-black mb-0.5" style={{ color }}>{value}</p>
      <p className="text-white/55 text-xs font-semibold">{label}</p>
      {sub && (
        <p className="text-white/25 text-[9px] mt-0.5 flex items-center gap-1">
          {trend === 'up' && <ArrowUp size={8} className="text-emerald-400" />}
          {trend === 'down' && <ArrowDown size={8} className="text-rose-400" />}
          {sub}
        </p>
      )}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#0c1018] border border-white/10 rounded-xl p-3 text-[10px] shadow-xl">
      <p className="text-white/40 mb-1 font-bold">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }}>{p.name}: <span className="font-bold">{typeof p.value === 'number' && p.value > 100 ? `$${p.value.toLocaleString()}K` : p.value}</span></p>
      ))}
    </div>
  );
};

function DownloadBar({ title, filename }) {
  const handlePrint = () => {
    const original = document.title;
    document.title = filename;
    window.print();
    document.title = original;
  };

  const handleDownloadText = () => {
    const el = document.getElementById('printable-content');
    if (!el) return;
    const text = el.innerText || el.textContent || '';
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename + '.txt'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="no-print fixed bottom-0 left-0 right-0 z-[999] border-t border-indigo-500/25 bg-[#0b0f1a]/98 backdrop-blur-xl shadow-[0_-8px_32px_rgba(0,0,0,0.6)]">
      <div className="max-w-6xl mx-auto px-4 lg:px-6 py-4 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <FileText size={16} className="text-indigo-400" />
          </div>
          <div>
            <p className="text-white/80 text-sm font-bold">{title}</p>
            <p className="text-white/30 text-[10px]">Click Download PDF — browser will open print dialog → Save as PDF</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleDownloadText}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-white/15 bg-white/5 text-white/55 hover:text-white/90 hover:bg-white/10 text-xs font-semibold transition-all">
            <Download size={13} />
            Export .TXT
          </button>
          <button onClick={handlePrint}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 active:scale-95 text-white text-sm font-bold transition-all shadow-lg shadow-indigo-500/30">
            <Printer size={15} />
            Download PDF
          </button>
        </div>
      </div>
    </div>
  );
}

export default function BusinessPlan() {
  const [section, setSection] = useState('exec');

  return (
    <div className="min-h-screen bg-[#070b14] text-white pb-24">
      <div id="printable-content">
      {/* Top banner */}
      <div className="border-b border-white/8 bg-[#0b0f1a] px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <BookOpen size={13} className="text-indigo-400" />
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">Business Plan 2025–2030</p>
            </div>
            <h1 className="text-2xl font-black">Behavior Engine — Human Performance OS</h1>
            <p className="text-white/30 text-xs mt-0.5">Confidential · Prepared April 2026 · Version 3.0</p>
          </div>
          <div className="flex gap-3 flex-wrap">
            <div className="text-center px-4 py-2 rounded-xl border border-indigo-500/20 bg-indigo-500/5">
              <p className="text-lg font-black text-indigo-400">$41.6K</p>
              <p className="text-white/20 text-[8px]">Current MRR</p>
            </div>
            <div className="text-center px-4 py-2 rounded-xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-lg font-black text-emerald-400">$25.2M</p>
              <p className="text-white/20 text-[8px]">Y5 ARR Target</p>
            </div>
            <div className="text-center px-4 py-2 rounded-xl border border-amber-500/20 bg-amber-500/5">
              <p className="text-lg font-black text-amber-400">$47B</p>
              <p className="text-white/20 text-[8px]">TAM</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 lg:p-6 flex gap-6">
        {/* Sidebar nav */}
        <aside className="hidden lg:flex flex-col gap-1 w-44 shrink-0 sticky top-6 self-start">
          {SECTIONS.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setSection(id)}
              className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-all ${section === id ? 'bg-indigo-500/15 border border-indigo-500/20 text-indigo-300' : 'text-white/30 hover:text-white/60 hover:bg-white/3'}`}>
              <Icon size={11} />
              {label}
            </button>
          ))}
        </aside>

        {/* Mobile section tabs */}
        <div className="lg:hidden w-full">
          <div className="flex gap-1 flex-wrap mb-4">
            {SECTIONS.map(({ id, label }) => (
              <button key={id} onClick={() => setSection(id)}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-semibold transition-all ${section === id ? 'bg-indigo-500 text-white' : 'text-white/30 bg-white/4'}`}>
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 min-w-0 space-y-8">

          {/* ─── EXECUTIVE SUMMARY ─── */}
          {section === 'exec' && (
            <div className="space-y-6">
              <SectionHeader icon={BookOpen} title="Executive Summary" subtitle="The one-page version of everything that matters." color={C.indigo} />

              <div className="p-5 rounded-2xl border border-indigo-500/20 bg-indigo-500/5">
                <p className="text-white/70 text-sm leading-relaxed">
                  <span className="text-white font-bold">Behavior Engine</span> is an AI-powered Human Performance OS for high-performance teams.
                  We replace manual performance management with a self-improving multi-agent system that coaches every user,
                  every day, autonomously — driving measurable execution improvement and compounding revenue growth.
                </p>
                <p className="text-white/50 text-sm leading-relaxed mt-3">
                  In 8 months, we reached $41.6K MRR with <span className="text-white font-semibold">zero paid marketing</span>,
                  312 active users across 3 verticals, and an 88% monthly retention rate.
                  The product runs on a 6-agent AI stack that operates sales, coaching, growth, and product improvement — autonomously.
                </p>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <MetricCard value="$41.6K" label="Current MRR" sub="+23% MoM" trend="up" color={C.emerald} />
                <MetricCard value="312" label="Active Users" sub="3 verticals" color={C.indigo} />
                <MetricCard value="88%" label="Retention" sub="vs 78% industry" trend="up" color={C.cyan} />
                <MetricCard value="$0" label="CAC" sub="100% organic" color={C.amber} />
              </div>

              {/* Mission, vision, values */}
              <div className="grid lg:grid-cols-3 gap-3">
                {[
                  { title: 'Mission', body: 'Give every team the AI coach that Fortune 500 companies pay $500K/year for — at $20/month.', color: C.indigo, icon: Target },
                  { title: 'Vision', body: 'The operating system for human performance. Every goal, every team, every industry — powered by behavioral AI.', color: C.cyan, icon: Globe },
                  { title: 'Model', body: 'SaaS with AI-driven expansion. Zero-CAC organic growth. Revenue compounds through referral + upgrade + retention loops.', color: C.emerald, icon: TrendingUp },
                ].map(({ title, body, color, icon: Icon }) => (
                  <div key={title} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                    <div className="flex items-center gap-2 mb-2">
                      <Icon size={12} style={{ color }} />
                      <p className="text-xs font-bold" style={{ color }}>{title}</p>
                    </div>
                    <p className="text-white/45 text-[10px] leading-relaxed">{body}</p>
                  </div>
                ))}
              </div>

              {/* Business model snapshot */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">5-Year Financial Snapshot ($K)</p>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={FIVE_YEAR} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="year" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v >= 1000 ? (v/1000).toFixed(0)+'M' : v+'K'}`} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 9, color: 'rgba(255,255,255,0.35)' }} />
                      <Bar dataKey="arr"    name="ARR"    fill={C.indigo}  radius={[3,3,0,0]} />
                      <Bar dataKey="ebitda" name="EBITDA" fill={C.emerald} radius={[3,3,0,0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Key milestones */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Key Milestones</p>
                <div className="space-y-2">
                  {[
                    { t: 'M0',   e: 'Product launched. First 3 paying customers.', done: true  },
                    { t: 'M3',   e: '$10K MRR. Team plan live. 50 active accounts.', done: true },
                    { t: 'M6',   e: '$41.6K MRR. 312 users. AI v6 deployed.', done: true       },
                    { t: 'M9',   e: '$100K MRR. Seed round closed. First 2 hires.', done: false },
                    { t: 'M12',  e: '$200K MRR. Enterprise tier live. 4,000 users.', done: false},
                    { t: 'M18',  e: '$400K MRR. Series A fundraise begins.', done: false        },
                    { t: 'Y3',   e: '$6.2M ARR. Profitable. 4,100 users.', done: false         },
                    { t: 'Y5',   e: '$25.2M ARR. IPO-ready or acquisition target.', done: false },
                  ].map(({ t, e, done }) => (
                    <div key={t} className={`flex items-start gap-3 p-3 rounded-xl border ${done ? 'border-emerald-500/20 bg-emerald-500/4' : 'border-white/6 bg-white/2'}`}>
                      <span className={`text-[9px] font-mono font-bold w-7 shrink-0 ${done ? 'text-emerald-400' : 'text-white/30'}`}>{t}</span>
                      <p className={`text-xs leading-snug ${done ? 'text-white/60' : 'text-white/40'}`}>{e}</p>
                      {done && <CheckCircle2 size={11} className="text-emerald-400 shrink-0 mt-0.5" />}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ─── MARKET ANALYSIS ─── */}
          {section === 'market' && (
            <div className="space-y-6">
              <SectionHeader icon={Globe} title="Market Analysis" subtitle="$47B TAM. AI-driven coaching is the fastest-growing segment." color={C.cyan} />

              {/* TAM / SAM / SOM */}
              <div className="grid lg:grid-cols-3 gap-3">
                {[
                  { label: 'TAM', value: '$47B', desc: 'Total performance management software market', sub: '14% CAGR · Gartner 2025', color: C.indigo },
                  { label: 'SAM', value: '$8.2B', desc: 'AI-driven coaching & execution tools for teams', sub: 'Our reachable market in 5 years', color: C.cyan },
                  { label: 'SOM', value: '$820M', desc: '10% of SAM — achievable by Year 5', sub: '$25M ARR = 3% of SOM', color: C.emerald },
                ].map(({ label, value, desc, sub, color }) => (
                  <div key={label} className="p-5 rounded-2xl border border-white/8 bg-white/2 text-center">
                    <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">{label}</p>
                    <p className="text-3xl font-black mb-1" style={{ color }}>{value}</p>
                    <p className="text-white/50 text-[10px] leading-snug">{desc}</p>
                    <p className="text-white/20 text-[8px] mt-1">{sub}</p>
                  </div>
                ))}
              </div>

              {/* Market tailwinds */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Market Tailwinds</p>
                <div className="grid lg:grid-cols-2 gap-3">
                  {[
                    { stat: '78%', text: 'of HR leaders plan to increase AI investment in 2025', src: 'Deloitte' },
                    { stat: '68%', text: 'of employees miss weekly performance targets with no coaching', src: 'McKinsey' },
                    { stat: '$1.2T', text: 'lost annually to low performance in US enterprises alone', src: 'McKinsey' },
                    { stat: '4.3×', text: 'higher revenue growth for companies with strong performance cultures', src: 'HBR' },
                  ].map(({ stat, text, src }) => (
                    <div key={stat} className="flex items-start gap-3 p-4 rounded-xl border border-cyan-500/15 bg-cyan-500/4">
                      <p className="text-xl font-black shrink-0" style={{ color: C.cyan }}>{stat}</p>
                      <div>
                        <p className="text-white/60 text-xs leading-snug">{text}</p>
                        <p className="text-white/20 text-[8px] mt-0.5">{src}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* ICP */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Ideal Customer Profiles</p>
                <div className="grid lg:grid-cols-3 gap-3">
                  {[
                    { segment: 'Sales Teams (SMB)', size: '10–100 reps', pain: 'No real-time performance data. Reps miss quotas. Manager time wasted on check-ins.', value: '$99–$499/mo', color: C.indigo, icon: TrendingUp },
                    { segment: 'Fitness Studios', size: '1–5 locations', pain: 'Client retention = biggest cost. No behavior coaching between sessions.', value: '$20–$99/mo', color: C.pink, icon: Activity },
                    { segment: 'Academies / Schools', size: '20–500 students', pain: 'Student engagement drops mid-term. No early warning system.', value: '$99–$499/mo', color: C.emerald, icon: BookOpen },
                  ].map(({ segment, size, pain, value, color, icon: Icon }) => (
                    <div key={segment} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                      <Icon size={14} style={{ color }} className="mb-2" />
                      <p className="text-white/75 text-xs font-bold mb-0.5">{segment}</p>
                      <p className="text-white/25 text-[8px] mb-2">{size}</p>
                      <p className="text-white/40 text-[9px] leading-snug mb-2">{pain}</p>
                      <p className="text-xs font-bold" style={{ color }}>{value}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Competitive landscape */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Competitive Matrix</p>
                <div className="overflow-x-auto rounded-2xl border border-white/8 bg-[#0c1018]">
                  <table className="w-full text-[10px]">
                    <thead>
                      <tr className="border-b border-white/5">
                        <th className="text-left p-3 text-white/30 font-bold">Company</th>
                        {COMP_MATRIX.features.map(f => (
                          <th key={f} className="p-3 text-white/20 font-semibold text-center" style={{ minWidth: 80 }}>{f}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {COMP_MATRIX.companies.map(c => (
                        <tr key={c.name} className={`border-b border-white/4 ${c.highlight ? 'bg-indigo-500/5' : ''}`}>
                          <td className="p-3 font-bold" style={{ color: c.highlight ? C.indigo : 'rgba(255,255,255,0.45)' }}>{c.name}</td>
                          {c.scores.map((s, i) => (
                            <td key={i} className="p-3 text-center">
                              {s === 5 ? <CheckCircle2 size={11} style={{ color: C.emerald }} className="mx-auto" /> :
                               s === 0 ? <span className="text-white/15">—</span> :
                               <div className="flex gap-0.5 justify-center">
                                 {Array.from({ length: s }).map((_, j) => (
                                   <div key={j} className="w-1.5 h-1.5 rounded-full" style={{ background: c.color, opacity: 0.6 }} />
                                 ))}
                               </div>}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ─── PRODUCT & TECH ─── */}
          {section === 'product' && (
            <div className="space-y-6">
              <SectionHeader icon={Zap} title="Product & Technology" subtitle="Multi-tenant SaaS + 6-agent autonomous AI system." color={C.amber} />

              <div className="grid lg:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest">Core Product Pillars</p>
                  {[
                    { title: 'Execution Engine', desc: 'Daily task libraries per industry. Points-based scoring. Real-time feedback on every action.', color: C.indigo },
                    { title: 'AI Coaching Layer', desc: '3 coach archetypes (Discipline/Strategy/Motivation). Personalized messages. 74% open rate.', color: C.violet },
                    { title: 'Behavior Analytics', desc: 'Score trends, drop pattern detection, leaderboard. 7-day behavioral intelligence per user.', color: C.cyan },
                    { title: 'Multi-Tenant Platform', desc: '3 isolated orgs in demo. Admin / Manager / User roles. Custom plugins per vertical.', color: C.emerald },
                  ].map(({ title, desc, color }) => (
                    <div key={title} className="flex items-start gap-3 p-3 rounded-xl border border-white/6 bg-white/2">
                      <div className="w-1.5 h-full rounded-full shrink-0 mt-1" style={{ background: color, minHeight: 32 }} />
                      <div>
                        <p className="text-white/65 text-xs font-bold">{title}</p>
                        <p className="text-white/30 text-[9px] leading-snug">{desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-3">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest">AI Agent Stack (v7)</p>
                  {[
                    { name: 'Behavior Agent', schedule: 'Hourly',       color: C.cyan,    kpi: 'Signal accuracy' },
                    { name: 'Coach Agent',    schedule: 'Daily 8am',    color: C.violet,  kpi: 'Score lift' },
                    { name: 'Growth Agent',   schedule: 'Every 12h',    color: C.pink,    kpi: 'Viral K' },
                    { name: 'Revenue Agent',  schedule: 'Monday 9am',   color: C.amber,   kpi: 'Net Revenue Retention' },
                    { name: 'System Agent',   schedule: 'Sunday midnight', color: C.emerald, kpi: 'Product velocity' },
                    { name: 'Strategy Agent', schedule: 'Friday 6am',   color: C.orange,  kpi: 'Decision quality', badge: 'v7' },
                  ].map(({ name, schedule, color, kpi, badge }) => (
                    <div key={name} className="flex items-center justify-between p-3 rounded-xl border border-white/6 bg-white/2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ background: color }} />
                        <p className="text-white/60 text-[10px] font-bold">{name}</p>
                        {badge && <span className="text-[7px] px-1 py-0.5 rounded bg-orange-500/15 border border-orange-500/25 text-orange-400 font-black">{badge}</span>}
                      </div>
                      <div className="text-right">
                        <p className="text-white/25 text-[8px]">{schedule}</p>
                        <p style={{ color, fontSize: 8 }}>{kpi}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Roadmap */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Product Roadmap</p>
                <div className="grid lg:grid-cols-4 gap-3">
                  {[
                    { phase: 'Now', items: ['AI v7 Strategy Agent', 'WhatsApp coaching channel', 'Team plan upgrade flow', 'Stripe billing v2'], color: C.emerald, status: 'Live' },
                    { phase: 'Q3 2026', items: ['Slack / Teams integration', 'Custom plugin builder', 'Video coaching (AI)', 'Mobile app (React Native)'], color: C.cyan, status: 'Building' },
                    { phase: 'Q4 2026', items: ['SSO & enterprise auth', 'Salesforce integration', 'AI-generated reports', 'Partner API'], color: C.indigo, status: 'Planned' },
                    { phase: '2027', items: ['Marketplace for coaches', 'White-label platform', 'LLM fine-tuning on user data', 'IPO-readiness audit'], color: C.violet, status: 'Vision' },
                  ].map(({ phase, items, color, status }) => (
                    <div key={phase} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-xs font-bold" style={{ color }}>{phase}</p>
                        <span className="text-[7px] px-1.5 py-0.5 rounded font-bold" style={{ color, background: color + '15', border: `1px solid ${color}25` }}>{status}</span>
                      </div>
                      <div className="space-y-1">
                        {items.map(item => (
                          <div key={item} className="flex items-center gap-1.5">
                            <ChevronRight size={7} style={{ color, opacity: 0.6 }} />
                            <span className="text-white/35 text-[8px]">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ─── OPERATIONS ─── */}
          {section === 'ops' && (
            <div className="space-y-6">
              <SectionHeader icon={Settings} title="Operations" subtitle="How the company runs day-to-day — and how it scales." color={C.violet} />

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Sales motion */}
                <div>
                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Sales Motion</p>
                  <div className="space-y-2">
                    {[
                      { step: '1', title: 'Content-Led Discovery', desc: 'LinkedIn posts + viral score cards drive inbound. 61% of new signups come from organic content.' },
                      { step: '2', title: '14-Day Free Trial', desc: 'Frictionless signup. AI coaching starts immediately. User sees value on day 1.' },
                      { step: '3', title: 'AI-Powered Conversion', desc: 'Revenue Agent identifies trial → paid readiness. Automated upgrade prompt with usage data.' },
                      { step: '4', title: 'Team Upsell', desc: 'When 3+ users at same company, Manager gets team plan offer. $20 × 5 → $99 team plan.' },
                      { step: '5', title: 'Enterprise Expansion', desc: 'Usage data + ROI proof → manual outreach to decision maker. ACV $5,988.' },
                    ].map(({ step, title, desc }) => (
                      <div key={step} className="flex items-start gap-3 p-3 rounded-xl border border-white/6 bg-white/2">
                        <span className="w-6 h-6 rounded-lg flex items-center justify-center text-[9px] font-black shrink-0" style={{ background: C.violet + '15', border: `1px solid ${C.violet}25`, color: C.violet }}>{step}</span>
                        <div>
                          <p className="text-white/65 text-[10px] font-bold">{title}</p>
                          <p className="text-white/30 text-[9px] leading-snug">{desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CS motion */}
                <div>
                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Customer Success</p>
                  <div className="space-y-2">
                    {[
                      { title: 'Day 1 Onboarding',  desc: 'Founder-led Loom video for first 100 customers. Then automated onboarding sequence.' },
                      { title: 'Weekly Score Reports', desc: 'AI-generated weekly report auto-sent every Monday. Makes users sticky.' },
                      { title: 'Drop Alert System', desc: 'Behavior Agent triggers Coach Agent when score drops 3 days in a row.' },
                      { title: 'NPS Trigger',       desc: 'NPS survey after 30 days. Low score → founder call. High score → referral prompt.' },
                      { title: 'Churn Prevention',  desc: 'Revenue Agent runs win-back flow at day 5 of inactivity. 40% re-engagement rate.' },
                    ].map(({ title, desc }) => (
                      <div key={title} className="flex items-start gap-2 p-3 rounded-xl border border-white/6 bg-white/2">
                        <CheckCircle2 size={10} className="text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-white/65 text-[10px] font-bold">{title}</p>
                          <p className="text-white/30 text-[9px] leading-snug">{desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3 mt-5">Key Operating Metrics</p>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { v: '74%',    l: 'Email open rate' },
                      { v: '4.2%',   l: 'Monthly churn' },
                      { v: '88%',    l: '30-day retention' },
                      { v: '40%',    l: 'Win-back rate' },
                      { v: '14 days',l: 'Trial→paid avg' },
                      { v: '3.8 min',l: 'Avg daily usage' },
                    ].map(({ v, l }) => (
                      <div key={l} className="p-2.5 rounded-xl border border-white/6 bg-white/2 text-center">
                        <p className="text-white/75 text-sm font-black" style={{ color: C.violet }}>{v}</p>
                        <p className="text-white/20 text-[8px]">{l}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ─── FINANCIALS ─── */}
          {section === 'finance' && (
            <div className="space-y-6">
              <SectionHeader icon={DollarSign} title="Financial Projections" subtitle="5-year model with monthly MRR, revenue mix, operating budget, and unit economics." color={C.emerald} />

              {/* MRR trajectory */}
              <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">18-Month MRR Trajectory ($K)</p>
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={MONTHLY_MRR} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
                      <defs>
                        <linearGradient id="mrrGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={C.emerald} stopOpacity={0.25} />
                          <stop offset="100%" stopColor={C.emerald} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
                      <XAxis dataKey="m" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}K`} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area type="monotone" dataKey="mrr" name="MRR ($K)" stroke={C.emerald} strokeWidth={2} fill="url(#mrrGrad)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* 5-year P&L */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">5-Year P&L Summary ($K)</p>
                <div className="overflow-x-auto rounded-2xl border border-white/8 bg-[#0c1018]">
                  <table className="w-full text-[10px]">
                    <thead>
                      <tr className="border-b border-white/5">
                        <th className="text-left p-3 text-white/30">Metric</th>
                        {FIVE_YEAR.map(y => <th key={y.year} className="p-3 text-white/30 text-right">{y.year}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { label: 'ARR ($K)',    key: 'arr',    color: C.indigo  },
                        { label: 'MRR ($K)',    key: 'mrr',    color: C.cyan    },
                        { label: 'Users',       key: 'users',  color: C.violet  },
                        { label: 'COGS ($K)',   key: 'cogs',   color: C.rose    },
                        { label: 'OpEx ($K)',   key: 'opex',   color: C.amber   },
                        { label: 'EBITDA ($K)', key: 'ebitda', color: C.emerald },
                        { label: 'YoY Growth',  key: 'growth', color: C.pink    },
                      ].map(({ label, key, color }) => (
                        <tr key={key} className="border-b border-white/4 hover:bg-white/2 transition-all">
                          <td className="p-3 text-white/40 font-semibold">{label}</td>
                          {FIVE_YEAR.map(y => (
                            <td key={y.year} className="p-3 text-right font-bold" style={{ color }}>
                              {y[key] == null ? '—' : key === 'growth' ? `+${y[key]}%` : key === 'users' ? y[key].toLocaleString() : `$${y[key].toLocaleString()}K`}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Revenue mix */}
              <div className="grid lg:grid-cols-2 gap-4">
                {[{ label: 'Y1 Revenue Mix', data: REV_MIX_Y1 }, { label: 'Y3 Revenue Mix (Projected)', data: REV_MIX_Y3 }].map(({ label, data }) => (
                  <div key={label} className="p-4 rounded-2xl border border-white/8 bg-[#0c1018]">
                    <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">{label}</p>
                    <div className="h-36">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPie>
                          <Pie data={data} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" paddingAngle={3}>
                            {data.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                          </Pie>
                          <Tooltip contentStyle={{ background: '#0c1018', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 9 }} formatter={(v) => [`${v}%`]} />
                          <Legend wrapperStyle={{ fontSize: 8, color: 'rgba(255,255,255,0.35)' }} />
                        </RechartsPie>
                      </ResponsiveContainer>
                    </div>
                  </div>
                ))}
              </div>

              {/* Operating budget */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Operating Budget by Category ($K)</p>
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={BUDGET} layout="vertical" margin={{ top: 0, right: 20, bottom: 0, left: 80 }}>
                      <XAxis type="number" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <YAxis type="category" dataKey="category" tick={{ fill: 'rgba(255,255,255,0.35)', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 9, color: 'rgba(255,255,255,0.35)' }} />
                      <Bar dataKey="y1" name="Y1" fill={C.indigo}  radius={[0,2,2,0]} />
                      <Bar dataKey="y2" name="Y2" fill={C.cyan}    radius={[0,2,2,0]} />
                      <Bar dataKey="y3" name="Y3" fill={C.violet}  radius={[0,2,2,0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Unit economics */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Unit Economics</p>
                <div className="overflow-x-auto rounded-2xl border border-white/8 bg-[#0c1018]">
                  <table className="w-full text-[10px]">
                    <thead>
                      <tr className="border-b border-white/5">
                        <th className="text-left p-3 text-white/30">Metric</th>
                        <th className="p-3 text-white/30 text-right">Y1 (Now)</th>
                        <th className="p-3 text-white/30 text-right">Y2</th>
                        <th className="p-3 text-white/30 text-right">Y3</th>
                        <th className="p-3 text-white/30 text-right">Note</th>
                      </tr>
                    </thead>
                    <tbody>
                      {UNIT_ECON.map(({ metric, y1, y2, y3, note }) => (
                        <tr key={metric} className="border-b border-white/4 hover:bg-white/2 transition-all">
                          <td className="p-3 text-white/50 font-semibold">{metric}</td>
                          <td className="p-3 text-right font-bold" style={{ color: C.emerald }}>{y1}</td>
                          <td className="p-3 text-right font-bold" style={{ color: C.indigo }}>{y2}</td>
                          <td className="p-3 text-right font-bold" style={{ color: C.violet }}>{y3}</td>
                          <td className="p-3 text-right text-white/20">{note}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ─── TEAM & HIRING ─── */}
          {section === 'team' && (
            <div className="space-y-6">
              <SectionHeader icon={Users} title="Team & Hiring Plan" subtitle="Current team, planned hires, cost, and structure to Series A." color={C.pink} />

              {/* Founders */}
              <div className="grid lg:grid-cols-3 gap-3">
                {[
                  { name: 'Alex Chen', role: 'CEO & Co-Founder', bg: 'Ex-Stripe Product. 6 years B2B SaaS. Led 0→$10M ARR at previous startup.', focus: 'Sales, strategy, fundraising', img: '🧠' },
                  { name: 'Jordan Park', role: 'CTO & Co-Founder', bg: 'Ex-OpenAI. Built 3 SaaS products. Deep AI/ML expertise. Former Google SWE.', focus: 'Architecture, AI agents, hiring', img: '⚡' },
                  { name: 'Sam Rivera', role: 'Head of Growth', bg: 'Ex-HubSpot Growth. Scaled 0→50K users organically. LinkedIn & content expert.', focus: 'Content, viral loops, PLG', img: '📈' },
                ].map(({ name, role, bg, focus, img }) => (
                  <div key={name} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/8 flex items-center justify-center text-2xl">{img}</div>
                      <div>
                        <p className="text-white/80 font-bold text-sm">{name}</p>
                        <p className="text-white/35 text-[9px]">{role}</p>
                      </div>
                    </div>
                    <p className="text-white/40 text-[9px] leading-snug mb-2">{bg}</p>
                    <p className="text-[9px]" style={{ color: C.pink }}>Focus: {focus}</p>
                  </div>
                ))}
              </div>

              {/* Advisors */}
              <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
                <p className="text-white/30 text-[9px] uppercase tracking-widest mb-3">Advisors</p>
                <div className="grid lg:grid-cols-3 gap-2">
                  {[
                    { name: 'Ex-VP Product @ Salesforce', area: 'Enterprise GTM' },
                    { name: 'Partner @ Sequoia (Observer)', area: 'Fundraising & strategy' },
                    { name: 'Founder @ $200M SaaS (Exited)', area: 'Scaling & operations' },
                  ].map(({ name, area }) => (
                    <div key={name} className="flex items-center gap-2 p-2.5 rounded-xl border border-white/5 bg-white/2">
                      <Star size={9} className="text-yellow-400 shrink-0" />
                      <div>
                        <p className="text-white/50 text-[9px] font-bold">{name}</p>
                        <p className="text-white/20 text-[8px]">{area}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Hiring plan */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Hiring Plan & Cost ($K salary + benefits)</p>
                <div className="space-y-3">
                  {HIRING_PLAN.map(({ phase, hires, count, cost, color }) => (
                    <div key={phase} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-xs font-bold" style={{ color }}>{phase}</p>
                        <div className="flex items-center gap-3">
                          <span className="text-white/25 text-[9px]">{count} hires</span>
                          <span className="text-emerald-400 text-[9px] font-bold">${cost}K/yr</span>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {hires.map(h => (
                          <span key={h} className="text-[8px] px-2 py-0.5 rounded border" style={{ color, borderColor: color + '25', background: color + '10' }}>{h}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Headcount vs ARR */}
              <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Headcount vs ARR ($K)</p>
                <div className="h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={[
                      { year: 'Y1', headcount: 3,  arr: 499 },
                      { year: 'Y2', headcount: 7,  arr: 2100 },
                      { year: 'Y3', headcount: 13, arr: 6240 },
                      { year: 'Y4', headcount: 22, arr: 13200 },
                      { year: 'Y5', headcount: 38, arr: 25200 },
                    ]} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="year" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="left" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="right" orientation="right" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}K`} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 9, color: 'rgba(255,255,255,0.35)' }} />
                      <Bar yAxisId="left" dataKey="headcount" name="Headcount" fill={C.pink} radius={[3,3,0,0]} />
                      <Bar yAxisId="right" dataKey="arr" name="ARR ($K)" fill={C.indigo} radius={[3,3,0,0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* ─── RISK ─── */}
          {section === 'risk' && (
            <div className="space-y-6">
              <SectionHeader icon={Shield} title="Risk Register" subtitle="Identified risks, probability, impact, and mitigation plans." color={C.rose} />

              <div className="space-y-3">
                {RISKS.map(({ risk, probability, impact, mitigation }) => {
                  const probColor = probability === 'High' ? C.rose : probability === 'Med' ? C.amber : C.emerald;
                  const impColor  = impact === 'High' ? C.rose : impact === 'Med' ? C.amber : C.emerald;
                  return (
                    <div key={risk} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                      <div className="flex items-start gap-3">
                        <AlertTriangle size={13} className="text-amber-400 shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <p className="text-white/70 text-xs font-bold">{risk}</p>
                            <span className="text-[7px] px-1.5 py-0.5 rounded font-bold" style={{ color: probColor, background: probColor + '15', border: `1px solid ${probColor}25` }}>P: {probability}</span>
                            <span className="text-[7px] px-1.5 py-0.5 rounded font-bold" style={{ color: impColor, background: impColor + '15', border: `1px solid ${impColor}25` }}>I: {impact}</span>
                          </div>
                          <p className="text-white/35 text-[9px] leading-snug">
                            <span className="text-white/20">Mitigation: </span>{mitigation}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
                <p className="text-emerald-400 font-bold text-xs mb-2">Overall Risk Assessment</p>
                <p className="text-white/40 text-[10px] leading-relaxed">
                  Risk profile is <span className="text-white font-semibold">Low–Medium</span> for a pre-Series A SaaS company.
                  The largest moat is proprietary behavioral data (grows with each user-day).
                  AI cost risk is hedged by open-source fallback. Regulatory risk is manageable with standard SaaS compliance.
                  Execution risk is the primary risk — mitigated by experienced founding team and lean operations.
                </p>
              </div>
            </div>
          )}

          {/* ─── KPI DASHBOARD ─── */}
          {section === 'kpis' && (
            <div className="space-y-6">
              <SectionHeader icon={Target} title="KPI Dashboard & Targets" subtitle="North Star metrics with 6 / 12 / 18 month targets." color={C.amber} />

              <div className="overflow-x-auto rounded-2xl border border-white/8 bg-[#0c1018]">
                <table className="w-full text-[10px]">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left p-4 text-white/30">KPI</th>
                      <th className="p-4 text-emerald-400 text-right">Now</th>
                      <th className="p-4 text-cyan-400 text-right">M6</th>
                      <th className="p-4 text-violet-400 text-right">M12</th>
                      <th className="p-4 text-amber-400 text-right">M18</th>
                    </tr>
                  </thead>
                  <tbody>
                    {KPI_TARGETS.map(({ kpi, now, m6, m12, m18 }) => (
                      <tr key={kpi} className="border-b border-white/4 hover:bg-white/2 transition-all">
                        <td className="p-4 text-white/55 font-bold">{kpi}</td>
                        <td className="p-4 text-right font-black text-emerald-400">{now}</td>
                        <td className="p-4 text-right font-bold text-cyan-400">{m6}</td>
                        <td className="p-4 text-right font-bold text-violet-400">{m12}</td>
                        <td className="p-4 text-right font-bold text-amber-400">{m18}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Multi-line chart */}
              <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">MRR + Users Trajectory (18 months)</p>
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={MONTHLY_MRR} margin={{ top: 5, right: 20, bottom: 0, left: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="m" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="left"  tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}K`} />
                      <YAxis yAxisId="right" orientation="right" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `${(v/1000).toFixed(0)}K`} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 9, color: 'rgba(255,255,255,0.35)' }} />
                      <Line yAxisId="left"  type="monotone" dataKey="mrr"   name="MRR ($K)"   stroke={C.indigo}  strokeWidth={2} dot={false} />
                      <Line yAxisId="right" type="monotone" dataKey="users" name="Users" stroke={C.emerald} strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Weekly operational rhythm */}
              <div>
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Weekly Operational Rhythm</p>
                <div className="grid lg:grid-cols-5 gap-2">
                  {[
                    { day: 'Mon', tasks: ['MRR review', 'Strategy Agent brief', 'Sprint planning'], color: C.indigo },
                    { day: 'Tue', tasks: ['Engineering standup', 'Content creation', 'Customer calls'], color: C.cyan },
                    { day: 'Wed', tasks: ['Sales pipeline', 'A/B test review', 'NPS follow-up'], color: C.violet },
                    { day: 'Thu', tasks: ['Product review', 'Agent performance', 'Investor update'], color: C.amber },
                    { day: 'Fri', tasks: ['New strategy brief', 'Retrospective', 'Week metrics email'], color: C.pink },
                  ].map(({ day, tasks, color }) => (
                    <div key={day} className="p-3 rounded-xl border border-white/6 bg-white/2">
                      <p className="font-black text-sm mb-2" style={{ color }}>{day}</p>
                      {tasks.map(t => (
                        <p key={t} className="text-white/30 text-[8px] leading-snug mb-0.5">· {t}</p>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
      </div>{/* /printable-content */}

      <DownloadBar
        title="Behavior Engine — Business Plan 2025–2030"
        filename="BehaviorEngine_BusinessPlan_2026"
      />
    </div>
  );
}
