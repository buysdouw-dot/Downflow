import { useState, useMemo } from 'react';
import {
  MessageSquare, Phone, RefreshCw, DollarSign,
  CheckCircle2, ChevronRight, AlertTriangle, Zap,
  Copy, Check, TrendingUp, Target, Bot, ArrowRight,
  Lock, Unlock,
} from 'lucide-react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { salesScripts, salesRules } from '../store/data';
import { salesFeedback, getRecoveryTask, getDailyStatus } from '../engine/salesAI';
import { getStatus, getStatusConfig } from '../engine/core';
import ScoreRing from '../components/ScoreRing';
import StatusBadge from '../components/StatusBadge';
import MobileHeader from '../components/MobileHeader';

// ── Action type config ────────────────────────────────────────────────────────
const ACTION_CONFIG = {
  outreach:     { label: 'Outreach',     icon: MessageSquare, points: 1, color: 'text-indigo-400',  bg: 'bg-indigo-500/10',  border: 'border-indigo-500/25',  taskId: 'se1', dailyMin: 20 },
  conversation: { label: 'Conversation', icon: Phone,         points: 3, color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/25', taskId: 'se2', dailyMin: 5  },
  follow_up:    { label: 'Follow-Up',    icon: RefreshCw,     points: 2, color: 'text-amber-400',   bg: 'bg-amber-500/10',   border: 'border-amber-500/25',   taskId: 'se3', dailyMin: 2  },
  closing:      { label: 'Close',        icon: DollarSign,    points: 5, color: 'text-green-400',   bg: 'bg-green-500/10',   border: 'border-green-500/25',   taskId: 'se4', dailyMin: 1  },
};

const ACTION_ORDER = ['outreach', 'conversation', 'follow_up', 'closing'];

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button
      onClick={copy}
      className="flex items-center gap-1.5 text-[10px] text-white/30 hover:text-white/60 transition-colors px-2 py-1 rounded-lg hover:bg-white/5"
    >
      {copied ? <Check size={11} className="text-green-400" /> : <Copy size={11} />}
      {copied ? 'Copied' : 'Copy script'}
    </button>
  );
}

function ScriptCard({ actionType, isRecovery = false }) {
  const script = salesScripts[actionType];
  const cfg = ACTION_CONFIG[actionType];
  const Icon = cfg.icon;
  if (!script) return null;

  const displayScript = isRecovery ? script.recoveryScript : script.script;

  return (
    <div className={`rounded-xl border ${cfg.border} ${cfg.bg} p-4`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Icon size={13} className={cfg.color} />
          <p className={`text-xs font-semibold ${cfg.color}`}>{script.title}</p>
          {isRecovery && (
            <span className="text-[9px] bg-white/8 text-white/40 px-1.5 py-0.5 rounded-full">Recovery Mode</span>
          )}
        </div>
        <CopyButton text={displayScript} />
      </div>
      <div className="bg-black/25 rounded-lg px-3 py-2.5 mb-2">
        <p className="text-white/80 text-sm italic leading-relaxed">"{displayScript}"</p>
      </div>
      <p className="text-white/30 text-xs">{script.tip}</p>
    </div>
  );
}

function ActionButton({ actionType, count, onLog, isRecovery }) {
  const cfg = ACTION_CONFIG[actionType];
  const Icon = cfg.icon;
  const [flash, setFlash] = useState(false);

  const handleClick = () => {
    onLog(actionType);
    setFlash(true);
    setTimeout(() => setFlash(false), 800);
  };

  return (
    <button
      onClick={handleClick}
      className={`w-full rounded-2xl p-4 border transition-all duration-200 text-left group
        ${flash
          ? `${cfg.bg} ${cfg.border} scale-[0.98]`
          : `glass ${cfg.border} hover:${cfg.bg} hover:scale-[1.01]`
        }`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className={`w-9 h-9 rounded-xl ${cfg.bg} border ${cfg.border} flex items-center justify-center`}>
          <Icon size={16} className={cfg.color} />
        </div>
        <div className="flex items-center gap-2">
          {count > 0 && (
            <span className={`text-xs font-bold ${cfg.color} bg-black/20 px-2 py-0.5 rounded-full`}>
              {count}× done
            </span>
          )}
          <span className={`text-xs font-bold ${cfg.color}`}>+{cfg.points} pts</span>
        </div>
      </div>

      <p className="text-white font-semibold text-sm mb-0.5">{cfg.label}</p>
      <p className="text-white/30 text-xs mb-3">
        {cfg.dailyMin > 0 ? `Target: ${count}/${cfg.dailyMin} today` : 'Bonus action'}
      </p>

      {/* Progress bar */}
      {cfg.dailyMin > 0 && (
        <div className="h-1 bg-white/6 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500`}
            style={{
              width: `${Math.min(100, (count / cfg.dailyMin) * 100)}%`,
              background: count >= cfg.dailyMin ? '#22c55e' : cfg.color.replace('text-', '').replace('-400', ''),
              backgroundColor: count >= cfg.dailyMin ? '#22c55e' : undefined,
            }}
          />
        </div>
      )}

      {/* Tap to log */}
      <div className={`mt-3 flex items-center gap-1.5 ${flash ? 'opacity-0' : 'opacity-0 group-hover:opacity-100'} transition-opacity`}>
        <span className="text-white/30 text-xs">Tap to log</span>
        <ArrowRight size={10} className="text-white/20" />
      </div>

      {flash && (
        <div className="mt-3 flex items-center gap-1.5">
          <CheckCircle2 size={12} className="text-green-400" />
          <span className="text-green-400 text-xs font-medium">Logged!</span>
        </div>
      )}
    </button>
  );
}

export default function SalesPlugin() {
  const { activeUserId, plugins, getTodayScore, getTodayLogs, logAction, feedback } = useBehavior();
  const { user } = useAuth();
  const plug = plugins['sales'];

  const score = getTodayScore(activeUserId);
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const todayLogs = getTodayLogs(activeUserId);
  const isRed = status === 'RED';

  // Count per action type
  const todayCounts = useMemo(() => {
    const counts = { outreach: 0, conversation: 0, follow_up: 0, closing: 0 };
    todayLogs.forEach((l) => {
      const task = plug.tasks.find((t) => t.id === l.taskId);
      if (task?.actionType && counts[task.actionType] !== undefined) {
        counts[task.actionType]++;
      }
    });
    return counts;
  }, [todayLogs, plug]);

  // Daily status checks
  const dailyStatus = useMemo(() => getDailyStatus(todayCounts, salesRules), [todayCounts]);
  const allRulesMet = dailyStatus.every((d) => d.met);

  // Recovery task
  const recoveryTask = useMemo(
    () => isRed ? getRecoveryTask(todayCounts, salesRules) : null,
    [isRed, todayCounts]
  );

  // Current AI feedback for selected action
  const [aiFeedback, setAiFeedback] = useState(null);
  const [activeScript, setActiveScript] = useState(null);

  const handleLog = (actionType) => {
    const task = plug.tasks.find((t) => t.actionType === actionType) ?? plug.tasks[0];
    logAction(activeUserId, task);

    const newCount = (todayCounts[actionType] ?? 0) + 1;
    const fb = salesFeedback(actionType, newCount, score + task.points, plug.dailyTarget);
    setAiFeedback({ ...fb, actionType });
  };

  const completedSteps = dailyStatus.filter((d) => d.met).length;
  const totalSteps = dailyStatus.length;

  return (
    <div className="max-w-5xl">
    <MobileHeader title="Sales Engine" />
    <div className="p-4 lg:p-6 space-y-5">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xl">💼</span>
            <h1 className="text-2xl font-bold text-white">Sales Execution Engine</h1>
          </div>
          <p className="text-white/35 text-sm">
            A system that forces you to do the daily actions that generate sales.
          </p>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <StatusBadge status={status} size="md" />
          <p className={`text-xs font-mono ${cfg.color}`}>{score}/40 pts today</p>
        </div>
      </div>

      {/* Recovery mode banner */}
      {isRed && recoveryTask && (
        <div className="rounded-xl bg-red-500/8 border border-red-500/30 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle size={16} className="text-red-400 mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="text-red-300 font-semibold text-sm">Recovery Mode Active</p>
              <p className="text-red-400/70 text-xs mt-0.5 mb-3">{recoveryTask.urgencyMsg}</p>
              <div className="bg-black/20 rounded-lg px-3 py-2.5">
                <p className="text-white/70 text-xs italic">
                  "{salesScripts[recoveryTask.actionType]?.recoveryScript}"
                </p>
              </div>
            </div>
            <CopyButton text={salesScripts[recoveryTask.actionType]?.recoveryScript ?? ''} />
          </div>
          <p className="text-red-400/50 text-[10px] mt-3">
            Reduce resistance, not standards. One action at a time.
          </p>
        </div>
      )}

      {/* Daily progress overview */}
      <div className="glass rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Target size={14} className="text-white/40" />
            <p className="text-white/50 text-xs font-semibold uppercase tracking-widest">Daily Execution Checklist</p>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-xs font-bold ${allRulesMet ? 'text-green-400' : 'text-white/30'}`}>
              {completedSteps}/{totalSteps} complete
            </span>
            {allRulesMet && <CheckCircle2 size={14} className="text-green-400" />}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-3">
          {dailyStatus.map((item) => {
            const acCfg = ACTION_CONFIG[item.key];
            if (!acCfg) return null;
            const Icon = acCfg.icon;
            return (
              <div
                key={item.key}
                className={`rounded-xl p-3 border transition-all ${
                  item.met
                    ? `${acCfg.bg} ${acCfg.border}`
                    : 'glass border-white/8'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <Icon size={13} className={item.met ? acCfg.color : 'text-white/25'} />
                  {item.met
                    ? <CheckCircle2 size={12} className="text-green-400" />
                    : <Lock size={11} className="text-white/15" />
                  }
                </div>
                <p className={`text-xs font-semibold mb-0.5 ${item.met ? acCfg.color : 'text-white/40'}`}>
                  {item.label}
                </p>
                <p className="text-white/25 text-[10px] mb-2">{item.count}/{item.min} done</p>
                <div className="h-1 bg-white/6 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-700`}
                    style={{
                      width: `${item.pct}%`,
                      background: item.met ? '#22c55e' : acCfg.color.replace('text-', '#').replace('-400', ''),
                      backgroundColor: item.met ? '#22c55e' : '#6366f1',
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Feedback panel */}
      {aiFeedback && (
        <div className={`rounded-xl border p-4 flex items-start gap-3 transition-all ${
          aiFeedback.urgency === 'green' ? 'bg-green-500/8 border-green-500/25' :
          aiFeedback.urgency === 'yellow' ? 'bg-yellow-500/8 border-yellow-500/25' :
          'bg-red-500/8 border-red-500/25'
        }`} style={{ animation: 'fadeIn 0.3s ease' }}>
          <Bot size={15} className={
            aiFeedback.urgency === 'green' ? 'text-green-400' :
            aiFeedback.urgency === 'yellow' ? 'text-yellow-400' : 'text-red-400'
          } />
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <p className="text-white/40 text-[10px] uppercase tracking-widest">AI Feedback</p>
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-white/8 text-white/50`}>
                {aiFeedback.tag}
              </span>
            </div>
            <p className="text-white/85 text-sm">{aiFeedback.msg}</p>
          </div>
          <button onClick={() => setAiFeedback(null)} className="text-white/20 hover:text-white/50 transition-colors text-xs">✕</button>
        </div>
      )}

      {/* Main execution area */}
      <div className="grid grid-cols-3 gap-5">

        {/* Action buttons — 2 cols */}
        <div className="col-span-2">
          <p className="text-white/25 text-xs uppercase tracking-widest mb-3">Tap to Log an Action</p>
          <div className="grid grid-cols-2 gap-3">
            {ACTION_ORDER.map((actionType) => (
              <div key={actionType}>
                <ActionButton
                  actionType={actionType}
                  count={todayCounts[actionType] ?? 0}
                  onLog={handleLog}
                  isRecovery={isRed}
                />
                <button
                  onClick={() => setActiveScript(activeScript === actionType ? null : actionType)}
                  className={`w-full mt-1.5 flex items-center justify-center gap-1 py-1.5 rounded-lg text-xs transition-all ${
                    activeScript === actionType
                      ? 'bg-white/8 text-white/60'
                      : 'text-white/20 hover:text-white/45 hover:bg-white/4'
                  }`}
                >
                  <MessageSquare size={10} />
                  {activeScript === actionType ? 'Hide script' : 'Show script'}
                </button>
                {activeScript === actionType && (
                  <div className="mt-1.5" style={{ animation: 'fadeIn 0.2s ease' }}>
                    <ScriptCard actionType={actionType} isRecovery={isRed} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">

          {/* Score ring */}
          <div className={`glass rounded-2xl p-4 flex flex-col items-center border ${cfg.border} ${cfg.glow}`}>
            <p className="text-white/25 text-[10px] uppercase tracking-widest mb-3">Score</p>
            <ScoreRing score={score} target={plug.dailyTarget} size={100} />
            <p className={`text-xs mt-3 text-center ${cfg.color}`}>
              {plug.dailyTarget - score > 0
                ? `${plug.dailyTarget - score} pts to target`
                : '✓ Target hit!'}
            </p>
          </div>

          {/* Today's log */}
          <div className="glass rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-white/35 text-xs font-semibold uppercase tracking-widest">Today's Log</p>
              <span className="text-white/20 text-xs">{todayLogs.length} actions</span>
            </div>
            {todayLogs.length === 0 ? (
              <p className="text-white/15 text-xs text-center py-4">No actions yet.<br />Start logging.</p>
            ) : (
              <div className="space-y-1.5 max-h-52 overflow-y-auto scrollbar-hide">
                {[...todayLogs].reverse().slice(0, 12).map((l) => {
                  const task = plug.tasks.find((t) => t.id === l.taskId);
                  const at = task?.actionType;
                  const ac = at ? ACTION_CONFIG[at] : null;
                  return (
                    <div key={l.id} className="flex items-center gap-2 py-1 border-b border-white/4 last:border-0">
                      {ac ? (
                        <ac.icon size={10} className={ac.color} />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-white/15" />
                      )}
                      <p className="text-white/40 text-xs flex-1 truncate">{l.taskName}</p>
                      <span className={`text-xs font-bold ${ac ? ac.color : 'text-white/30'}`}>+{l.points}</span>
                    </div>
                  );
                })}
              </div>
            )}
            {todayLogs.length > 0 && (
              <div className="pt-2 mt-1 border-t border-white/6 flex justify-between">
                <span className="text-white/20 text-xs">Total</span>
                <span className={`text-xs font-bold ${cfg.color}`}>{score} pts</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Daily flow guide */}
      <div className="glass rounded-2xl p-5">
        <p className="text-white/35 text-xs uppercase tracking-widest mb-4">Daily Execution Loop</p>
        <div className="flex items-center gap-0">
          {[
            { step: 'App shows task', icon: '📱' },
            { step: 'You execute',    icon: '⚡' },
            { step: 'Tap Done',       icon: '✅' },
            { step: 'Score updates',  icon: '📊' },
            { step: 'AI Feedback',    icon: '🤖' },
            { step: 'Next task',      icon: '🔄' },
          ].map((item, i, arr) => (
            <div key={i} className="flex items-center gap-0 flex-1">
              <div className="flex-1 flex flex-col items-center gap-1.5">
                <span className="text-base">{item.icon}</span>
                <p className="text-white/40 text-[10px] text-center leading-tight">{item.step}</p>
              </div>
              {i < arr.length - 1 && <ChevronRight size={12} className="text-white/15 shrink-0" />}
            </div>
          ))}
        </div>
      </div>

      {/* All scripts panel */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-white/25 text-xs uppercase tracking-widest">All Scripts</p>
          <p className="text-white/20 text-xs">Tap to copy and send</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {ACTION_ORDER.map((at) => (
            <ScriptCard key={at} actionType={at} isRecovery={false} />
          ))}
        </div>
      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
    </div>
  );
}
