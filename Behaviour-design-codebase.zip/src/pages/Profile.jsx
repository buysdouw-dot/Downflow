import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LogOut, Bell, TrendingUp, BarChart2, User,
  ChevronRight, Shield, Star, CheckCircle2, Edit3,
  Copy, Share2, Activity, CreditCard, Puzzle, Server, DollarSign,
} from 'lucide-react';
import { useAuth } from '../store/AuthContext';
import { useBehavior } from '../store/BehaviorContext';
import { useNotifications } from '../store/NotificationsContext';
import { getStatus, getStatusConfig } from '../engine/core';
import StatusBadge from '../components/StatusBadge';
import ScoreRing from '../components/ScoreRing';
import MobileHeader from '../components/MobileHeader';

const AVATAR_BG = [
  'from-indigo-500 to-purple-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-pink-500 to-rose-600',
  'from-cyan-500 to-blue-600',
  'from-violet-500 to-purple-600',
  'from-fuchsia-500 to-pink-600',
];

export default function Profile() {
  const { user, logout, tenantInfo, can } = useAuth();
  const { getTodayScore, getWeekScores, activeUserId, activePlugin, plugins } = useBehavior();
  const { unreadCount } = useNotifications();
  const navigate = useNavigate();

  const score = getTodayScore(activeUserId);
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const plug = plugins[activePlugin];
  const weekData = getWeekScores(activeUserId);
  const weekScores = weekData.map(d => d.score);
  const avg7 = Math.round(weekScores.reduce((a,b) => a+b, 0) / weekScores.length);
  const best = Math.max(...weekScores);
  const streak = (() => { let s=0; for(let i=weekScores.length-1;i>=0;i--){ if(weekScores[i]>=40) s++; else break; } return s; })();
  const greenDays = weekScores.filter(s => s >= 40).length;
  const avatarBg = AVATAR_BG[(user?.id ?? 1) % AVATAR_BG.length];

  const menuSections = [
    {
      title: 'Performance',
      items: [
        { icon: BarChart2,   label: 'Score Analysis',       sub: '7-day breakdown',           action: () => navigate('/score')         },
        { icon: TrendingUp,  label: 'Sales Engine',         sub: 'Daily execution loop',      action: () => navigate('/sales')         },
        { icon: Puzzle,      label: 'Plugin Marketplace',   sub: 'Manage behavior modules',   action: () => navigate('/plugins')   },
        { icon: Server,      label: 'Deployment Guide',     sub: 'Go live in 1 day',          action: () => navigate('/deploy')    },
        { icon: DollarSign,  label: '$1K SaaS Strategy',    sub: 'Outreach & revenue model',  action: () => navigate('/strategy')  },
      ],
    },
    {
      title: 'System',
      items: [
        { icon: Bell,        label: 'Notifications',        sub: `${unreadCount} unread`,     action: () => navigate('/notifications') },
        { icon: Shield,      label: 'Role & Permissions',   sub: user?.role ?? 'user',        action: null                             },
      ],
    },
    ...(can('view_admin') ? [{
      title: 'Admin',
      items: [
        { icon: Shield,      label: 'Admin Dashboard',      sub: 'Team overview',             action: () => navigate('/admin')         },
        { icon: Activity,    label: 'Analytics',            sub: 'Execution intelligence',    action: () => navigate('/analytics')     },
        { icon: CreditCard,  label: 'Billing',              sub: 'Plans & subscriptions',     action: () => navigate('/billing')       },
      ],
    }] : []),
  ];

  return (
    <div className="max-w-2xl mx-auto">
      <MobileHeader title="Profile" />

      <div className="px-4 lg:px-6 py-6 space-y-5">

        {/* User card */}
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center gap-4 mb-4">
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${avatarBg} flex items-center justify-center text-xl font-black text-white`}>
              {user?.avatar}
            </div>
            <div className="flex-1">
              <h2 className="text-white font-bold text-lg leading-tight">{user?.name}</h2>
              <p className="text-white/40 text-xs mt-0.5">{user?.title} · {tenantInfo?.icon} {tenantInfo?.name}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <StatusBadge status={status} size="xs" />
                {user?.role === 'admin' && (
                  <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/15 px-1.5 py-0.5 rounded-full border border-indigo-500/20">Admin</span>
                )}
              </div>
            </div>
            <ScoreRing score={score} target={plug?.dailyTarget ?? 40} size={64} />
          </div>

          {/* Week sparkbar */}
          <div className="flex items-end gap-1 h-10 mb-3">
            {weekData.map((d, i) => {
              const s = d.score;
              const sc = getStatusConfig(s >= 40 ? 'GREEN' : s >= 25 ? 'YELLOW' : 'RED');
              const isToday = i === weekData.length - 1;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className={`w-full rounded-sm ${sc.bar} ${isToday ? 'opacity-100' : 'opacity-50'}`}
                    style={{ height: `${Math.max(4, (s / 60) * 36)}px` }}
                  />
                  <p className="text-white/15 text-[8px]">{d.label[0]}</p>
                </div>
              );
            })}
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-4 gap-2 pt-3 border-t border-white/6">
            {[
              { label: '7d Avg', value: avg7,          color: 'text-indigo-400' },
              { label: 'Best',   value: best,          color: 'text-yellow-400' },
              { label: 'Streak', value: `${streak}d`,  color: 'text-green-400'  },
              { label: 'GREEN',  value: `${greenDays}/7`,color: 'text-white/50' },
            ].map(({ label, value, color }) => (
              <div key={label} className="text-center">
                <p className={`text-base font-bold ${color}`}>{value}</p>
                <p className="text-white/25 text-[9px] mt-0.5">{label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Menu sections */}
        {menuSections.map((section) => (
          <div key={section.title}>
            <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-2">{section.title}</p>
            <div className="glass rounded-xl overflow-hidden divide-y divide-white/5">
              {section.items.map(({ icon: Icon, label, sub, action }) => (
                <button
                  key={label}
                  onClick={action ?? undefined}
                  disabled={!action}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 text-left transition-all ${action ? 'hover:bg-white/4' : 'opacity-50'}`}
                >
                  <div className="w-8 h-8 rounded-xl bg-white/6 flex items-center justify-center shrink-0">
                    <Icon size={15} className="text-white/50" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white/80 text-sm font-medium">{label}</p>
                    <p className="text-white/30 text-xs">{sub}</p>
                  </div>
                  {action && <ChevronRight size={15} className="text-white/20 shrink-0" />}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Plugin info */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-2">Active Plugin</p>
          <div className="glass rounded-xl p-4 flex items-center gap-3">
            <span className="text-2xl">{plug?.icon}</span>
            <div className="flex-1">
              <p className="text-white font-semibold text-sm">{plug?.name}</p>
              <p className="text-white/30 text-xs">{plug?.tasks?.length} tasks · {plug?.dailyTarget}pt daily target</p>
            </div>
            <CheckCircle2 size={15} className="text-green-400" />
          </div>
        </div>

        {/* Sign out */}
        <button
          onClick={logout}
          className="w-full py-3.5 rounded-xl glass border border-red-500/20 text-red-400 hover:bg-red-500/8 transition-all flex items-center justify-center gap-2 font-medium text-sm"
        >
          <LogOut size={15} />
          Sign Out
        </button>

        <p className="text-white/15 text-xs text-center">Behavior Engine · v2.0 · Human Performance OS</p>
      </div>
    </div>
  );
}
