/**
 * GrowthDomination — 90-Day Growth Plan (0 → $100K ARR)
 * 4 phases with daily focus, channels, tasks, KPIs.
 * Live day counter. Outreach scripts. Growth loop visualiser.
 */
import { useState } from 'react';
import {
  Flame, Target, TrendingUp, Users, DollarSign, Zap,
  Check, Copy, ChevronRight, ArrowRight, Clock, Star,
  CheckCircle2, Play, BarChart2,
} from 'lucide-react';

// ── Phases ────────────────────────────────────────────────────────────────────
const PHASES = [
  {
    id: 'p1',
    days: 'Days 1–10',
    label: 'Validation',
    target: '$0 → $1K MRR',
    goalARR: 1000 * 12,
    color: '#a1a1aa',
    border: 'border-white/10',
    bg: 'bg-white/2',
    accent: '#a1a1aa',
    badge: 'MANUAL',
    north_star: '20–50 paying users. Proof of value.',
    truth: 'Do not write code. Do not build features. Find 20 people who have the problem and get them to pay.',
    channels: [
      { name: 'WhatsApp outreach',  daily: '30 DMs/day', desc: 'Managers, team leads, sales VPs in your network.' },
      { name: 'LinkedIn manual DM', daily: '20 DMs/day', desc: 'First line personalised. No pitch. Just a question.' },
      { name: 'Manual onboarding',  daily: '2 calls/day', desc: 'Zoom. Screen share. Learn their exact workflow.' },
      { name: 'Facebook groups',    daily: '3 posts/day', desc: 'Sales, startups, remote work. Ask questions.' },
    ],
    tasks: [
      'Set up Stripe + payment link ($10–$50/mo)',
      'DM 30 people in your network today',
      'Get on a call with 2 potential users',
      'Onboard first paying user (manually)',
      'Get 1 testimonial with a real number',
      'Post result on LinkedIn ("user X went from Y% to Z%")',
      'Ask every paid user for 1 referral',
    ],
    script: `"Hey [Name], I track team execution daily — like a fitness tracker for work performance.

Teams using it went from 42% to 78% execution in 6 weeks.

Want me to run a free 7-day test for your team? No setup needed."`,
    kpis: [{ k: 'Paying users', v: '20+' }, { k: 'MRR', v: '$200+' }, { k: 'Calls', v: '20' }, { k: 'Testimonials', v: '3' }],
  },
  {
    id: 'p2',
    days: 'Days 11–30',
    label: 'Pilot Phase',
    target: '$1K → $5K MRR',
    goalARR: 5000 * 12,
    color: '#818cf8',
    border: 'border-indigo-500/20',
    bg: 'bg-indigo-500/5',
    accent: '#818cf8',
    badge: 'B2B',
    north_star: '5–10 paying companies. Case studies with % improvement.',
    truth: 'Stop selling to individuals. One company = 10–30 users. One deal = 10x easier than 10 individual sales.',
    channels: [
      { name: 'Cold email (decision makers)', daily: '50/day', desc: 'VP Sales, RevOps, Sales Managers at 10–200 person companies.' },
      { name: '7-day pilot offer',            daily: '3 pilots', desc: 'Free 7 days. No credit card. Show the data after.' },
      { name: 'LinkedIn content',             daily: '1 post',  desc: 'Share "Team X hit 80% execution this week." Screenshot.' },
      { name: 'Referral from Phase 1',        daily: '5 asks',  desc: 'Every Phase 1 user gets asked: who else runs a team like yours?' },
    ],
    tasks: [
      'Build a "7-day pilot" landing page',
      'Write 5-email pilot onboarding sequence',
      'Close 3 paying companies ($1,500 MRR)',
      'Record 1 case study video (before/after)',
      'Add team admin dashboard (manager view)',
      'Post case study on LinkedIn (real numbers)',
      'Reach out to 3 sales coaches for partnership',
    ],
    script: `Subject: Free 7-day execution pilot — [Company]

Hi [Name],

We help sales teams improve execution consistency in 7 days.

Every rep gets a daily score. You see in real time who is executing and who is not.

Result from last week: [Client] went from 42% → 78% in 6 weeks.

Free pilot. No credit card. I set it up in 10 minutes.

Worth trying?`,
    kpis: [{ k: 'Paying companies', v: '5+' }, { k: 'MRR', v: '$2K+' }, { k: 'Case studies', v: '2' }, { k: 'Pilots running', v: '3' }],
  },
  {
    id: 'p3',
    days: 'Days 31–60',
    label: 'Replication',
    target: '$5K → $20K MRR',
    goalARR: 20000 * 12,
    color: '#34d399',
    border: 'border-emerald-500/20',
    bg: 'bg-emerald-500/5',
    accent: '#34d399',
    badge: 'SYSTEM',
    north_star: '$20K MRR. Referral engine live. Outreach systemised.',
    truth: 'You have proof. Now turn the sales motion into a system. Document what works. Hire or delegate.',
    channels: [
      { name: 'LinkedIn content engine', daily: '1 post + 20 comments', desc: 'Post execution stats. Reply to every comment. DM everyone who likes.' },
      { name: 'Referral program',        daily: 'ongoing',             desc: '1 free month for every company referred. Turns users into sales reps.' },
      { name: 'Cold outbound (scaled)',  daily: '100 emails/day',      desc: 'Automated sequence using Apollo/Lemlist. 3-email cadence.' },
      { name: '$20/user/mo pricing',     daily: 'pricing test',        desc: 'Raise prices for new customers. Grandfather existing ones.' },
    ],
    tasks: [
      'Launch referral program (1 month free per referral)',
      'Post 3 case studies with % numbers',
      'Set up automated cold email sequence (Apollo)',
      'Raise price to $20/user for new signups',
      'Add annual plan (2 months free = -30% churn)',
      'Apply to YC / SaaS accelerators',
      'Build content library: 30 tips on execution',
    ],
    script: `"30 days in. Here's what happened:

47 teams. $4,800 MRR.

What worked:
1. WhatsApp outreach (Days 1–10)
2. Company pilot offers (Days 11–30)
3. Referral program (live this week)

Not ads. Not SEO. Just outreach + results.

If you want access → [link]"`,
    kpis: [{ k: 'MRR', v: '$10K+' }, { k: 'Teams', v: '50+' }, { k: 'NRR', v: '>100%' }, { k: 'Churn', v: '<5%' }],
  },
  {
    id: 'p4',
    days: 'Days 61–90',
    label: 'Scale',
    target: '$20K → $100K ARR path',
    goalARR: 100000,
    color: '#fbbf24',
    border: 'border-yellow-500/20',
    bg: 'bg-yellow-500/5',
    accent: '#fbbf24',
    badge: 'ENTERPRISE',
    north_star: '$8K+ MRR = $100K ARR path. First enterprise deals. Team building.',
    truth: 'One enterprise deal ($5K+/mo) is worth 500 individual signups. Go upmarket. Your data is the proof.',
    channels: [
      { name: 'Enterprise outbound', daily: '20 personalised emails', desc: 'Target 50–500 person companies. Director/VP level only.' },
      { name: 'Outbound sales hire', daily: '1 SDR commission-only',  desc: 'Give them the script. Pay per booked demo.' },
      { name: 'Partner channel',     daily: '2 partner convos',       desc: 'Sales coaches, HR consultants, RevOps agencies.' },
      { name: 'Thought leadership',  daily: '1 long post + thread',   desc: 'You are now the expert on execution science.' },
    ],
    tasks: [
      'Close 1 enterprise deal ($2K+/mo)',
      'Hire 1 commission-only SDR',
      'Build partner deck (for sales coaches)',
      'Launch affiliate program',
      'Post "90-day results" thread (numbers)',
      'Put deck in front of 3 seed investors',
      'Document full sales playbook for hiring',
    ],
    script: `Subject: Execution performance data for [Company]

Hi [Name],

We have worked with 50+ sales teams. Average result: 31% improvement in execution consistency in 30 days.

The companies seeing the biggest results are [similar company type].

I have a 15-minute slot to show you a live dashboard of what your team would look like.

No pitch. Just data.

This week?`,
    kpis: [{ k: 'MRR', v: '$8K+' }, { k: 'ARR run rate', v: '$100K' }, { k: 'Enterprise deals', v: '1+' }, { k: 'SDR hired', v: '✓' }],
  },
];

// ── Growth loop ────────────────────────────────────────────────────────────────
const LOOP = [
  { label: 'Lead',        color: '#a1a1aa', desc: 'LinkedIn / email / referral'  },
  { label: 'Pilot',       color: '#818cf8', desc: 'Free 7-day team trial'        },
  { label: 'Results',     color: '#34d399', desc: 'Score improves X% → Y%'      },
  { label: 'Proof',       color: '#fbbf24', desc: 'Case study + social share'    },
  { label: 'Scale',       color: '#f472b6', desc: 'New leads see proof → repeat' },
];

// ── Copy button ────────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1800); }}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border shrink-0 transition-all ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'
      }`}>
      {c ? <><Check size={8} />Copied</> : <><Copy size={8} />Copy</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function GrowthDomination() {
  const [activePhase, setActivePhase] = useState('p1');
  const [view, setView]   = useState('phases'); // 'phases' | 'loop'
  const [tasks, setTasks] = useState(() => {
    try { return JSON.parse(localStorage.getItem('be_90d_tasks')) ?? {}; } catch { return {}; }
  });
  const [day, setDay] = useState(() => {
    try { return parseInt(localStorage.getItem('be_90d_day') ?? '1', 10); } catch { return 1; }
  });

  const phase = PHASES.find(p => p.id === activePhase) ?? PHASES[0];

  const toggle = (key) => {
    const n = { ...tasks, [key]: !tasks[key] };
    setTasks(n);
    try { localStorage.setItem('be_90d_tasks', JSON.stringify(n)); } catch {}
  };

  const setDayPersist = (d) => {
    setDay(d);
    try { localStorage.setItem('be_90d_day', String(d)); } catch {}
  };

  const currentPhaseIdx = day <= 10 ? 0 : day <= 30 ? 1 : day <= 60 ? 2 : 3;

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Flame size={13} className="text-orange-400" />
              <p className="text-orange-400 text-xs font-bold uppercase tracking-widest">90-Day Growth Domination</p>
            </div>
            <h1 className="text-3xl font-black mb-1">0 → $100K ARR</h1>
            <p className="text-white/35 text-sm">Four phases. Daily focus. No guessing. Execute the plan.</p>
          </div>

          {/* Day counter */}
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl border border-orange-500/20 bg-orange-500/5 text-center">
              <p className="text-2xl font-black text-orange-400">Day {day}</p>
              <p className="text-white/20 text-[9px]">{PHASES[currentPhaseIdx]?.label}</p>
            </div>
            <div className="flex flex-col gap-1">
              <button onClick={() => setDayPersist(Math.min(90, day + 1))} className="px-2 py-1 bg-white/5 border border-white/10 rounded text-xs hover:bg-white/10">+1</button>
              <button onClick={() => setDayPersist(Math.max(1, day - 1))}  className="px-2 py-1 bg-white/5 border border-white/10 rounded text-xs hover:bg-white/10">-1</button>
            </div>
          </div>
        </div>

        {/* 90-day progress bar */}
        <div>
          <div className="flex justify-between text-[9px] text-white/20 mb-1">
            <span>Day 1</span><span>Day 30</span><span>Day 60</span><span>Day 90</span>
          </div>
          <div className="relative h-2 bg-white/8 rounded-full overflow-hidden">
            {PHASES.map((p, i) => {
              const starts = [0, 11, 31, 61];
              const ends   = [10, 30, 60, 90];
              const left   = (starts[i] / 90) * 100;
              const width  = ((ends[i] - starts[i] + 1) / 90) * 100;
              return (
                <div key={p.id} className="absolute top-0 h-full rounded-sm opacity-30"
                  style={{ left: left + '%', width: width + '%', background: p.accent }} />
              );
            })}
            <div className="absolute top-0 h-full bg-orange-400 rounded-full transition-all duration-500"
              style={{ width: `${(day / 90) * 100}%` }} />
          </div>
          <div className="flex gap-3 mt-2 flex-wrap">
            {PHASES.map((p, i) => {
              const starts = [1, 11, 31, 61];
              const active = currentPhaseIdx === i;
              return (
                <span key={p.id} className={`text-[8px] font-bold px-1.5 py-0.5 rounded border ${active ? '' : 'opacity-40'}`}
                  style={{ color: p.accent, borderColor: p.accent + '30', background: p.accent + '10' }}>
                  {p.days}
                </span>
              );
            })}
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6">
          {[['phases','Phase Plan'],['loop','Growth Loop']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-orange-500 text-black' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── PHASES ── */}
        {view === 'phases' && (
          <div className="grid lg:grid-cols-[200px_1fr] gap-6">
            {/* Phase selector */}
            <div className="space-y-1.5">
              {PHASES.map((p, i) => {
                const done = PHASES[i].tasks.filter((_, ti) => tasks[`${p.id}_${ti}`]).length;
                const isActive = activePhase === p.id;
                return (
                  <button key={p.id} onClick={() => setActivePhase(p.id)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${isActive ? `${p.border} ${p.bg}` : 'border-white/6 bg-white/2 hover:bg-white/4'}`}>
                    <div className="flex items-center justify-between">
                      <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: isActive ? p.accent : 'rgba(255,255,255,0.25)' }}>{p.days}</p>
                      <span className="text-[7px] font-black px-1 py-0.5 rounded border"
                        style={{ color: p.accent, borderColor: p.accent+'30', background: p.accent+'10' }}>{p.badge}</span>
                    </div>
                    <p className={`text-xs font-bold mt-0.5 ${isActive ? 'text-white/70' : 'text-white/30'}`}>{p.label}</p>
                    <p style={{ color: isActive ? p.accent : 'rgba(255,255,255,0.2)' }} className="text-[9px] mt-0.5">{p.target}</p>
                    <div className="mt-2 h-1 bg-white/8 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{ width: `${(done / p.tasks.length) * 100}%`, background: p.accent }} />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Phase detail */}
            <div className="space-y-4">
              {/* North star */}
              <div className="p-4 rounded-2xl border" style={{ borderColor: phase.accent + '30', background: phase.accent + '06' }}>
                <p className="text-xs font-bold mb-1" style={{ color: phase.accent }}>{phase.days} — {phase.label}</p>
                <p className="text-white/60 text-sm leading-relaxed">{phase.north_star}</p>
              </div>

              {/* Truth */}
              <div className="p-3 rounded-xl border border-white/8 bg-black/20">
                <p className="text-white/45 text-xs italic leading-relaxed">&ldquo;{phase.truth}&rdquo;</p>
              </div>

              {/* Channels */}
              <div className="grid sm:grid-cols-2 gap-2">
                {phase.channels.map(ch => (
                  <div key={ch.name} className="p-3 rounded-xl border border-white/8 bg-white/2">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-white/55 text-xs font-semibold">{ch.name}</p>
                      <span className="text-[9px] font-bold" style={{ color: phase.accent }}>{ch.daily}</span>
                    </div>
                    <p className="text-white/25 text-[9px] leading-snug">{ch.desc}</p>
                  </div>
                ))}
              </div>

              {/* Tasks */}
              <div className="space-y-1.5">
                <p className="text-white/20 text-[9px] uppercase tracking-widest">Weekly Tasks</p>
                {phase.tasks.map((t, i) => {
                  const key  = `${phase.id}_${i}`;
                  const done = !!tasks[key];
                  return (
                    <button key={i} onClick={() => toggle(key)}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                        done ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/6 bg-white/2 hover:border-white/12'
                      }`}>
                      <div className={`w-4 h-4 rounded-md flex items-center justify-center shrink-0 transition-all ${done ? 'bg-emerald-500' : 'border border-white/20'}`}>
                        {done && <Check size={8} className="text-white" />}
                      </div>
                      <span className={`text-xs flex-1 ${done ? 'line-through text-white/25' : 'text-white/55'}`}>{t}</span>
                    </button>
                  );
                })}
              </div>

              {/* Script */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest">Outreach Script</p>
                  <CopyBtn text={phase.script} />
                </div>
                <pre className="p-4 rounded-xl border border-white/8 bg-black/30 text-white/50 text-xs leading-relaxed whitespace-pre-wrap font-sans">{phase.script}</pre>
              </div>

              {/* KPIs */}
              <div className="grid grid-cols-4 gap-2">
                {phase.kpis.map(kpi => (
                  <div key={kpi.k} className="p-3 rounded-xl border border-white/8 bg-white/2 text-center">
                    <p className="text-sm font-black" style={{ color: phase.accent }}>{kpi.v}</p>
                    <p className="text-white/25 text-[8px] mt-0.5">{kpi.k}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── GROWTH LOOP ── */}
        {view === 'loop' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-5">Core Growth Loop</p>
              <div className="flex items-center gap-2 flex-wrap">
                {LOOP.map((step, i) => (
                  <div key={step.label} className="flex items-center gap-2">
                    <div className="px-4 py-3 rounded-xl border text-center"
                      style={{ borderColor: step.color + '30', background: step.color + '08' }}>
                      <p className="text-xs font-bold" style={{ color: step.color }}>{step.label}</p>
                      <p className="text-[9px] mt-0.5 max-w-[100px]" style={{ color: step.color + '80' }}>{step.desc}</p>
                    </div>
                    {i < LOOP.length - 1 && <ArrowRight size={11} className="text-white/15 shrink-0" />}
                  </div>
                ))}
                <ArrowRight size={11} className="text-white/15" />
                <div className="px-3 py-3 rounded-xl border border-white/8 text-center">
                  <p className="text-[10px] text-white/20 font-bold">Repeat ∞</p>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-orange-500/20 bg-orange-500/5">
              <p className="text-orange-400 font-bold text-sm mb-3">The Core Truth</p>
              <div className="grid lg:grid-cols-3 gap-4">
                {[
                  { t: 'Not code.',    d: 'Your product is good enough. Ship less, sell more. Most SaaS fails at distribution, not product.' },
                  { t: 'Not ads.',     d: 'Ads work at $10K+ MRR when you know the LTV. Before that: outreach + referrals + content.' },
                  { t: 'Execution.',   d: 'The 90-day plan is simple. Run it every day. The companies that win are the ones that show up daily.' },
                ].map(({ t, d }) => (
                  <div key={t} className="p-4 rounded-xl bg-black/20 border border-white/6">
                    <p className="text-orange-400 font-black text-sm mb-2">{t}</p>
                    <p className="text-white/40 text-xs leading-relaxed">{d}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
