import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell, BellOff, Check, X, ChevronRight, Clock,
  Zap, TrendingUp, Users, RotateCcw, Calendar,
  AlertTriangle,
} from 'lucide-react';
import { useNotifications } from '../store/NotificationsContext';
import MobileHeader from '../components/MobileHeader';

const CATEGORY_COLORS = {
  'Daily Loop':  { color: 'text-indigo-400',  bg: 'bg-indigo-500/10',  border: 'border-indigo-500/20',  icon: Zap        },
  'Sales':       { color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', icon: TrendingUp  },
  'Recovery':    { color: 'text-red-400',     bg: 'bg-red-500/10',     border: 'border-red-500/20',     icon: AlertTriangle },
  'Motivation':  { color: 'text-yellow-400',  bg: 'bg-yellow-500/10',  border: 'border-yellow-500/20',  icon: Zap        },
  'Leaderboard': { color: 'text-purple-400',  bg: 'bg-purple-500/10',  border: 'border-purple-500/20',  icon: Users      },
  'Weekly':      { color: 'text-cyan-400',    bg: 'bg-cyan-500/10',    border: 'border-cyan-500/20',    icon: Calendar   },
};

function timeAgo(iso) {
  const diff = Math.floor((Date.now() - new Date(iso)) / 1000);
  if (diff < 60)  return 'just now';
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  return `${Math.floor(diff/86400)}d ago`;
}

function NotifCard({ n, onRead, onDismiss, onAction }) {
  const cat = CATEGORY_COLORS[n.category] ?? CATEGORY_COLORS['Daily Loop'];
  const Icon = cat.icon;
  return (
    <div
      className={`relative rounded-xl p-4 border transition-all ${
        n.read
          ? 'glass border-white/6 opacity-60'
          : `${cat.bg} border ${cat.border}`
      }`}
    >
      {!n.read && (
        <span className={`absolute top-3 right-3 w-2 h-2 rounded-full ${cat.color.replace('text-','bg-')}`} />
      )}
      <div className="flex items-start gap-3">
        <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${cat.bg} border ${cat.border}`}>
          <Icon size={14} className={cat.color} />
        </div>
        <div className="flex-1 min-w-0 pr-6">
          <p className={`text-sm font-semibold mb-0.5 ${n.read ? 'text-white/50' : 'text-white'}`}>{n.title}</p>
          <p className={`text-xs leading-relaxed ${n.read ? 'text-white/30' : 'text-white/55'}`}>{n.body}</p>
          <div className="flex items-center gap-3 mt-2">
            <span className="text-white/20 text-[10px] flex items-center gap-1">
              <Clock size={9} /> {timeAgo(n.receivedAt)}
            </span>
            <span className={`text-[10px] font-medium ${cat.color}`}>{n.category}</span>
            {n.action && (
              <button
                onClick={() => onAction(n)}
                className={`ml-auto text-[10px] font-semibold ${cat.color} flex items-center gap-0.5 hover:opacity-80`}
              >
                Take action <ChevronRight size={10} />
              </button>
            )}
          </div>
        </div>
      </div>
      {/* Quick actions */}
      <div className="flex gap-2 mt-3 border-t border-white/5 pt-3">
        {!n.read && (
          <button
            onClick={() => onRead(n.id)}
            className="flex items-center gap-1.5 text-[10px] text-white/30 hover:text-white/60 transition-colors"
          >
            <Check size={10} /> Mark read
          </button>
        )}
        <button
          onClick={() => onDismiss(n.id)}
          className="flex items-center gap-1.5 text-[10px] text-white/20 hover:text-red-400 transition-colors ml-auto"
        >
          <X size={10} /> Dismiss
        </button>
      </div>
    </div>
  );
}

function ScheduleRow({ s, onToggle }) {
  const cat = CATEGORY_COLORS[s.category] ?? CATEGORY_COLORS['Daily Loop'];
  return (
    <div className={`flex items-center gap-3 p-3.5 rounded-xl border transition-all ${
      s.enabled ? `glass border-white/8` : 'glass border-white/4 opacity-50'
    }`}>
      <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${s.enabled ? cat.bg : 'bg-white/5'}`}>
        <cat.icon size={13} className={s.enabled ? cat.color : 'text-white/25'} />
      </div>
      <div className="flex-1 min-w-0">
        <p className={`text-xs font-semibold truncate ${s.enabled ? 'text-white/80' : 'text-white/30'}`}>{s.title}</p>
        <div className="flex items-center gap-2 mt-0.5">
          {s.time && <span className="text-white/25 text-[10px]">{s.time} daily</span>}
          <span className={`text-[10px] ${cat.color}`}>{s.category}</span>
          <span className="text-[9px] bg-white/6 text-white/30 px-1.5 py-0.5 rounded-full">{s.type}</span>
        </div>
      </div>
      <button
        onClick={() => onToggle(s.id)}
        className={`relative w-10 h-5.5 rounded-full transition-all shrink-0 ${
          s.enabled ? 'bg-indigo-500' : 'bg-white/10'
        }`}
        style={{ height: '22px' }}
      >
        <span
          className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${
            s.enabled ? 'left-5' : 'left-0.5'
          }`}
          style={{ width: '18px', height: '18px' }}
        />
      </button>
    </div>
  );
}

export default function Notifications() {
  const { notifications, schedule, unreadCount, markRead, markAllRead, dismiss, toggleSchedule, pushNotification } = useNotifications();
  const navigate = useNavigate();
  const [tab, setTab] = useState('inbox'); // 'inbox' | 'schedule'
  const [filter, setFilter] = useState('all'); // 'all' | 'unread'

  const displayed = tab === 'inbox'
    ? (filter === 'unread' ? notifications.filter(n => !n.read) : notifications)
    : schedule;

  const handleAction = (n) => {
    markRead(n.id);
    if (n.action) navigate(n.action);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <MobileHeader title="Notifications" />

      {/* Desktop header */}
      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Notifications</h1>
          <p className="text-white/35 text-sm mt-0.5">Daily execution loop · Behavioral triggers</p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="text-indigo-400 text-xs hover:text-indigo-300 flex items-center gap-1.5">
            <Check size={12} /> Mark all read ({unreadCount})
          </button>
        )}
      </div>

      <div className="px-4 lg:px-6 space-y-4 pb-6">
        {/* Tabs */}
        <div className="flex items-center gap-2">
          <div className="flex p-1 bg-white/5 rounded-xl flex-1">
            {[['inbox','Inbox'],['schedule','Schedule']].map(([k,l]) => (
              <button key={k} onClick={() => setTab(k)}
                className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all ${tab===k ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
                {l} {k === 'inbox' && unreadCount > 0 && <span className="ml-1 bg-white/20 text-white px-1.5 py-0.5 rounded-full text-[9px]">{unreadCount}</span>}
              </button>
            ))}
          </div>
          {tab === 'inbox' && (
            <div className="flex p-1 bg-white/5 rounded-xl">
              {[['all','All'],['unread','Unread']].map(([k,l]) => (
                <button key={k} onClick={() => setFilter(k)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filter===k ? 'bg-white/10 text-white/80' : 'text-white/30 hover:text-white/60'}`}>
                  {l}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Inbox */}
        {tab === 'inbox' && (
          <>
            {unreadCount > 0 && (
              <div className="flex items-center justify-between">
                <p className="text-white/25 text-xs uppercase tracking-widest">{unreadCount} unread</p>
                <button onClick={markAllRead} className="text-indigo-400 text-xs hover:text-indigo-300">Mark all read</button>
              </div>
            )}

            {displayed.length === 0 ? (
              <div className="glass rounded-2xl p-10 text-center">
                <Bell size={28} className="text-white/15 mx-auto mb-3" />
                <p className="text-white/30 text-sm">No notifications</p>
                <p className="text-white/15 text-xs mt-1">You're all caught up.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {displayed.map((n) => (
                  <NotifCard key={n.id} n={n} onRead={markRead} onDismiss={dismiss} onAction={handleAction} />
                ))}
              </div>
            )}
          </>
        )}

        {/* Schedule */}
        {tab === 'schedule' && (
          <>
            <div className="glass rounded-xl p-4 border border-indigo-500/15">
              <div className="flex items-start gap-3">
                <Bell size={15} className="text-indigo-400 mt-0.5 shrink-0" />
                <div>
                  <p className="text-white text-sm font-semibold">Automated Notification Schedule</p>
                  <p className="text-white/35 text-xs mt-0.5">These run daily to enforce your execution loop. Toggle any off if needed.</p>
                </div>
              </div>
            </div>

            {/* Group by type */}
            {['Daily Loop','Sales','Recovery','Motivation','Leaderboard','Weekly'].map((cat) => {
              const items = schedule.filter(s => s.category === cat);
              if (!items.length) return null;
              const cfg = CATEGORY_COLORS[cat] ?? CATEGORY_COLORS['Daily Loop'];
              return (
                <div key={cat}>
                  <p className={`text-[10px] font-semibold uppercase tracking-widest mb-2 ${cfg.color}`}>{cat}</p>
                  <div className="space-y-2">
                    {items.map((s) => <ScheduleRow key={s.id} s={s} onToggle={toggleSchedule} />)}
                  </div>
                </div>
              );
            })}

            {/* Test notification */}
            <div className="glass rounded-xl p-4 mt-2">
              <p className="text-white/40 text-xs font-semibold mb-3">Send test notification</p>
              <div className="flex flex-wrap gap-2">
                {['morning_kickoff','recovery_alert','streak_praise','leaderboard_alert'].map((id) => (
                  <button
                    key={id}
                    onClick={() => pushNotification(id)}
                    className="px-3 py-1.5 glass rounded-lg text-xs text-white/50 hover:text-white/80 hover:bg-white/6 transition-all"
                  >
                    {id.replace(/_/g,' ')}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
