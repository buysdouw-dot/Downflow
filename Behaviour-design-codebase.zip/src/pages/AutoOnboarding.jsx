/**
 * AutoOnboarding — Automated Conversion Funnel
 * Goal: Signup → Active User in under 3 minutes, zero manual selling.
 * Flow: Welcome → Role Selection → Auto Plugin → First Task → Reward → Dashboard
 */
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../store/AuthContext';
import { useBehavior } from '../store/BehaviorContext';
import {
  Zap, TrendingUp, BarChart2, Bot, CheckCircle2, ArrowRight,
  Users, Target, Flame, Star, ChevronRight, Clock,
} from 'lucide-react';

// ── Role → Plugin mapping ─────────────────────────────────────────────────────
const ROLES = [
  {
    id: 'sales',
    icon: TrendingUp,
    emoji: '💼',
    title: 'Salesperson',
    subtitle: 'I close deals and manage pipeline',
    plugin: 'sales',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/25',
    firstTask: 'Send 1 outreach message to a new prospect',
    why: 'Sales teams improve follow-up volume by 3× in 7 days.',
  },
  {
    id: 'manager',
    icon: Users,
    emoji: '📊',
    title: 'Manager / Team Lead',
    subtitle: 'I oversee a team and track performance',
    plugin: 'sales',
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/25',
    firstTask: 'Review each team member\'s score from yesterday',
    why: 'Managers who use behavioral data reduce guesswork by 80%.',
  },
  {
    id: 'operator',
    icon: Target,
    emoji: '⚙️',
    title: 'Operator / Other',
    subtitle: 'I run processes, logistics, or operations',
    plugin: 'fitness',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/25',
    firstTask: 'Log your top 3 priorities for today',
    why: 'Teams that log daily priorities hit targets 40% more often.',
  },
];

// ── Funnel steps ──────────────────────────────────────────────────────────────
const STEPS = ['welcome', 'signup', 'role', 'plugin', 'task', 'reward'];

function ProgressBar({ step }) {
  const pct = (STEPS.indexOf(step) / (STEPS.length - 1)) * 100;
  return (
    <div className="h-0.5 w-full bg-white/8 rounded-full overflow-hidden">
      <div className="h-full bg-indigo-500 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
    </div>
  );
}

function StepWelcome({ onNext }) {
  return (
    <div className="text-center space-y-6 animate-fadeIn">
      {/* Logo */}
      <div className="flex justify-center">
        <div className="w-16 h-16 rounded-2xl bg-indigo-500 flex items-center justify-center shadow-xl shadow-indigo-500/30">
          <Zap size={28} className="text-white" />
        </div>
      </div>
      <div>
        <h1 className="text-3xl font-black mb-2">Welcome to Behavior Engine</h1>
        <p className="text-white/45 text-base max-w-xs mx-auto leading-relaxed">
          The system that converts daily actions into measurable performance.
        </p>
      </div>

      {/* 3 value props */}
      <div className="space-y-3 text-left max-w-xs mx-auto">
        {[
          { icon: Clock, color: 'text-indigo-400', text: 'Active in under 3 minutes' },
          { icon: Bot,   color: 'text-purple-400', text: 'AI coaching from day one' },
          { icon: Star,  color: 'text-yellow-400', text: '7-day pilot — completely free' },
        ].map(({ icon: Icon, color, text }) => (
          <div key={text} className="flex items-center gap-3">
            <Icon size={16} className={color} />
            <span className="text-white/60 text-sm">{text}</span>
          </div>
        ))}
      </div>

      <button onClick={onNext}
        className="w-full py-4 bg-indigo-500 hover:bg-indigo-400 rounded-2xl text-base font-bold text-white transition-all shadow-xl shadow-indigo-500/25 hover:shadow-indigo-500/40 hover:scale-[1.01] flex items-center justify-center gap-2">
        Start Free 7-Day Pilot <ArrowRight size={16} />
      </button>
      <p className="text-white/20 text-xs">No credit card · No setup fee · Cancel any time</p>
    </div>
  );
}

function StepSignup({ onNext }) {
  const [form, setForm] = useState({ email: '', password: '', company: '' });
  const [error, setError] = useState('');
  const { register } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) { setError('Email and password required'); return; }
    try {
      // Demo: use existing demo account for seamless UX
      onNext({ email: form.email, company: form.company });
    } catch (err) {
      setError('Something went wrong. Try again.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-black mb-2">Create Your Account</h2>
        <p className="text-white/35 text-sm">30 seconds. No card needed.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="text-white/40 text-xs uppercase tracking-widest block mb-1.5">Work Email</label>
          <input
            type="email"
            value={form.email}
            onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
            placeholder="you@company.com"
            className="w-full bg-white/4 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-indigo-500/50 transition-colors"
          />
        </div>
        <div>
          <label className="text-white/40 text-xs uppercase tracking-widest block mb-1.5">Password</label>
          <input
            type="password"
            value={form.password}
            onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
            placeholder="Choose a password"
            className="w-full bg-white/4 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-indigo-500/50 transition-colors"
          />
        </div>
        <div>
          <label className="text-white/40 text-xs uppercase tracking-widest block mb-1.5">Company / Team Code</label>
          <input
            type="text"
            value={form.company}
            onChange={e => setForm(f => ({ ...f, company: e.target.value }))}
            placeholder="acme-sales (or leave blank)"
            className="w-full bg-white/4 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-indigo-500/50 transition-colors"
          />
        </div>
        {error && <p className="text-red-400 text-xs">{error}</p>}
        <button type="submit"
          className="w-full py-3.5 bg-indigo-500 hover:bg-indigo-400 rounded-xl text-sm font-bold text-white transition-all mt-2">
          Create Account →
        </button>
      </form>

      <p className="text-white/20 text-xs text-center">
        Already have an account?{' '}
        <button className="text-indigo-400 hover:text-indigo-300 underline" onClick={() => window.location.href = '/login'}>
          Sign in
        </button>
      </p>
    </div>
  );
}

function StepRoleSelect({ onNext }) {
  const [selected, setSelected] = useState(null);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-black mb-2">What best describes you?</h2>
        <p className="text-white/35 text-sm">This auto-loads the right behavior plugin for your role.</p>
      </div>

      <div className="space-y-3">
        {ROLES.map((role) => {
          const Icon = role.icon;
          const isSelected = selected?.id === role.id;
          return (
            <button key={role.id} onClick={() => setSelected(role)}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border text-left transition-all ${
                isSelected
                  ? `${role.bg} ${role.border} scale-[1.01]`
                  : 'bg-white/2 border-white/8 hover:border-white/15 hover:bg-white/3'
              }`}>
              <div className={`w-11 h-11 rounded-xl ${role.bg} border ${role.border} flex items-center justify-center shrink-0`}>
                <span className="text-xl">{role.emoji}</span>
              </div>
              <div className="flex-1">
                <p className={`font-bold text-sm ${isSelected ? role.color : 'text-white'}`}>{role.title}</p>
                <p className="text-white/35 text-xs mt-0.5">{role.subtitle}</p>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                isSelected ? `${role.border} ${role.bg}` : 'border-white/15'
              }`}>
                {isSelected && <div className={`w-2 h-2 rounded-full ${role.color.replace('text-', 'bg-')}`} />}
              </div>
            </button>
          );
        })}
      </div>

      <button onClick={() => selected && onNext(selected)} disabled={!selected}
        className={`w-full py-3.5 rounded-xl text-sm font-bold transition-all ${
          selected
            ? 'bg-indigo-500 hover:bg-indigo-400 text-white'
            : 'bg-white/5 text-white/20 cursor-not-allowed'
        }`}>
        {selected ? `Continue as ${selected.title} →` : 'Select your role to continue'}
      </button>
    </div>
  );
}

function StepPluginAssigned({ role, onNext }) {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(timer); setTimeout(onNext, 400); return 100; }
        return p + 4;
      });
    }, 50);
    return () => clearInterval(timer);
  }, [onNext]);

  return (
    <div className="text-center space-y-6">
      <div className={`w-16 h-16 mx-auto rounded-2xl ${role.bg} border ${role.border} flex items-center justify-center`}>
        <span className="text-3xl">{role.emoji}</span>
      </div>
      <div>
        <h2 className="text-2xl font-black mb-2">Setting up your system</h2>
        <p className="text-white/40 text-sm">Loading {role.title} plugin for you…</p>
      </div>

      {/* Progress */}
      <div className="space-y-2">
        <div className="h-2 bg-white/8 rounded-full overflow-hidden">
          <div className={`h-full ${role.color.replace('text-', 'bg-')} rounded-full transition-all duration-100`}
            style={{ width: `${progress}%` }} />
        </div>
        <div className="flex justify-between text-xs text-white/25">
          {['Loading plugin', 'Configuring tasks', 'Starting AI coach', 'Ready'].map((label, i) => (
            <span key={label} className={progress >= (i + 1) * 25 ? role.color : ''}>{label}</span>
          ))}
        </div>
      </div>

      <div className="space-y-2 text-left">
        {[
          { label: 'Plugin',        value: `${role.emoji} ${role.title} Execution`  },
          { label: 'Daily Target',  value: '40 points'                              },
          { label: 'AI Coach',      value: '🔥 The Disciplinarian (default)'        },
          { label: 'First Session', value: 'Starting now'                           },
        ].map(({ label, value }) => (
          <div key={label} className="flex items-center justify-between py-2 border-b border-white/5">
            <span className="text-white/35 text-sm">{label}</span>
            <span className={`text-sm font-semibold ${progress >= 75 ? role.color : 'text-white/20'}`}>
              {progress >= 75 ? value : '...'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function StepFirstTask({ role, onComplete }) {
  const [done, setDone] = useState(false);
  const [timer, setTimer] = useState(60);
  const { logAction, plugins, activePlugin } = useBehavior();
  const plug = plugins[activePlugin];
  const firstTask = plug?.tasks?.[0];

  useEffect(() => {
    if (done) return;
    const t = setInterval(() => setTimer(prev => prev > 0 ? prev - 1 : 0), 1000);
    return () => clearInterval(t);
  }, [done]);

  const handleDone = () => {
    if (firstTask) logAction(firstTask.id, 1);
    setDone(true);
    setTimeout(onComplete, 1200);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 mb-4">
          <Clock size={12} className="text-orange-400" />
          <span className="text-orange-400 text-xs font-semibold">{timer}s to experience value</span>
        </div>
        <h2 className="text-2xl font-black mb-2">Your First Task</h2>
        <p className="text-white/35 text-sm">Complete this right now. It takes 60 seconds.</p>
      </div>

      <div className={`p-6 rounded-2xl ${role.bg} border ${role.border} relative overflow-hidden`}>
        <div className="absolute inset-0 bg-gradient-to-br from-white/2 to-transparent pointer-events-none" />
        <p className="text-white/40 text-xs uppercase tracking-widest mb-2">Task #1</p>
        <p className="text-white font-bold text-lg leading-snug mb-4">{role.firstTask}</p>
        <p className="text-white/30 text-xs italic">{role.why}</p>
      </div>

      {!done ? (
        <button onClick={handleDone}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 rounded-2xl text-base font-bold text-white transition-all shadow-xl shadow-emerald-500/25 flex items-center justify-center gap-2">
          <CheckCircle2 size={18} /> DONE — Mark Complete
        </button>
      ) : (
        <div className="flex flex-col items-center gap-3 py-4">
          <div className="w-14 h-14 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
            <CheckCircle2 size={28} className="text-emerald-400" />
          </div>
          <p className="text-emerald-400 font-bold text-lg">Task Complete!</p>
          <p className="text-white/35 text-sm">+{firstTask?.points ?? 5} pts · AI coaching loading…</p>
        </div>
      )}

      <button onClick={handleDone}
        className="w-full text-white/25 text-xs hover:text-white/45 transition-colors">
        Skip for now →
      </button>
    </div>
  );
}

function StepReward({ role, onFinish }) {
  const { getTodayScore, activeUserId } = useBehavior();
  const score = getTodayScore(activeUserId);

  return (
    <div className="text-center space-y-6">
      {/* Big celebration */}
      <div className="relative">
        <div className="w-20 h-20 mx-auto rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mb-4">
          <Flame size={36} className="text-emerald-400" />
        </div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 text-2xl animate-bounce">🎉</div>
      </div>

      <div>
        <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-2">First Action Logged</p>
        <h2 className="text-3xl font-black mb-2">Good. Keep going.</h2>
        <p className="text-white/40 text-sm max-w-xs mx-auto">
          You just started your streak. Every action from here compounds.
        </p>
      </div>

      {/* Score card preview */}
      <div className="mx-auto max-w-xs p-5 rounded-2xl bg-emerald-500/8 border border-emerald-500/20">
        <p className="text-white/35 text-xs uppercase tracking-widest mb-2">Today's Score</p>
        <p className="text-4xl font-black text-emerald-400">{score} pts</p>
        <div className="flex items-center justify-center gap-2 mt-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-emerald-400/60 text-xs font-semibold">Streak started · Day 1</span>
        </div>
      </div>

      {/* What's next */}
      <div className="space-y-2 text-left">
        <p className="text-white/25 text-xs uppercase tracking-widest px-1">Next up</p>
        {[
          { icon: Target,    label: 'Complete more tasks to hit GREEN status',    color: 'text-emerald-400' },
          { icon: BarChart2, label: 'Your AI coach will analyze your patterns',   color: 'text-indigo-400'  },
          { icon: Users,     label: 'Invite your team to compare on leaderboard', color: 'text-purple-400'  },
        ].map(({ icon: Icon, label, color }) => (
          <div key={label} className="flex items-center gap-3 p-3 rounded-xl bg-white/2 border border-white/6">
            <Icon size={14} className={color} />
            <span className="text-white/55 text-sm">{label}</span>
          </div>
        ))}
      </div>

      <button onClick={onFinish}
        className="w-full py-4 bg-indigo-500 hover:bg-indigo-400 rounded-2xl text-base font-bold text-white transition-all shadow-xl shadow-indigo-500/25 flex items-center justify-center gap-2">
        Go to My Dashboard <ArrowRight size={16} />
      </button>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function AutoOnboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState('welcome');
  const [userData, setUserData] = useState({});
  const [selectedRole, setSelectedRole] = useState(null);

  const next = (data = {}) => {
    const merged = { ...userData, ...data };
    setUserData(merged);
    const idx = STEPS.indexOf(step);
    if (idx < STEPS.length - 1) setStep(STEPS[idx + 1]);
  };

  const finish = () => navigate('/');

  const role = selectedRole ?? ROLES[0];

  return (
    <div className="min-h-screen bg-[#05080f] text-white flex flex-col">
      {/* Top bar */}
      <div className="px-4 pt-4 pb-2">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-indigo-500 flex items-center justify-center">
                <Zap size={12} className="text-white" />
              </div>
              <span className="text-white/60 text-xs font-bold">Behavior Engine</span>
            </div>
            <span className="text-white/20 text-xs capitalize">
              {STEPS.indexOf(step) + 1} / {STEPS.length}
            </span>
          </div>
          <ProgressBar step={step} />
        </div>
      </div>

      {/* Step content */}
      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">
          {step === 'welcome' && (
            <StepWelcome onNext={() => next()} />
          )}
          {step === 'signup' && (
            <StepSignup onNext={(data) => next(data)} />
          )}
          {step === 'role' && (
            <StepRoleSelect onNext={(role) => { setSelectedRole(role); next({ role }); }} />
          )}
          {step === 'plugin' && (
            <StepPluginAssigned role={role} onNext={() => next()} />
          )}
          {step === 'task' && (
            <StepFirstTask role={role} onComplete={() => next()} />
          )}
          {step === 'reward' && (
            <StepReward role={role} onFinish={finish} />
          )}
        </div>
      </div>
    </div>
  );
}
