/**
 * CopyPasteRepo — Actual Runnable GitHub Repo Files
 * Every file. Real JS. Deployable in < 2 hours.
 * Tab structure: each file is a tab, code is real.
 */
import { useState } from 'react';
import {
  GitMerge, Copy, Check, Terminal, Server,
  FileCode, Database, Package, Cloud, Folder,
  ChevronRight, Play, Zap, ExternalLink,
} from 'lucide-react';

// ── Every actual file in the MVP repo ─────────────────────────────────────────
const FILES = [
  // ── ROOT ─────────────────────────────────────────────────────────────────
  {
    path: 'package.json',
    section: 'root',
    lang: 'json',
    runnable: true,
    code: `{
  "name": "behavior-engine-mvp",
  "version": "1.0.0",
  "private": true,
  "workspaces": ["backend", "frontend"],
  "scripts": {
    "dev":     "concurrently \\"npm run dev --workspace=backend\\" \\"npm run dev --workspace=frontend\\"",
    "setup":   "npm install && npm run db:push",
    "db:push": "npm run db:push --workspace=backend"
  },
  "devDependencies": {
    "concurrently": "^8.2.2"
  }
}`,
  },
  {
    path: '.env.example',
    section: 'root',
    lang: 'bash',
    runnable: false,
    code: `# Copy this to .env and fill in your values
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/behavior_engine"
JWT_SECRET="change-this-to-a-random-64-char-string"
PORT=3000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173`,
  },
  {
    path: 'docker-compose.yml',
    section: 'root',
    lang: 'yaml',
    runnable: true,
    code: `version: "3.9"
services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: behavior_engine
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  backend:
    build: ./backend
    environment:
      DATABASE_URL: postgresql://postgres:postgres@postgres:5432/behavior_engine
      JWT_SECRET: dev-secret-change-in-prod
      PORT: 3000
    ports:
      - "3000:3000"
    depends_on: [postgres]
    command: sh -c "npx prisma db push && node src/server.js"

  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on: [backend]

volumes:
  pgdata:`,
  },
  {
    path: 'README.md',
    section: 'root',
    lang: 'markdown',
    runnable: false,
    code: `# Behavior Engine MVP

> Convert human potential into consistent daily output.

## Run in 60 seconds (Docker)

\`\`\`bash
git clone https://github.com/you/behavior-engine-mvp
cd behavior-engine-mvp
cp .env.example .env
docker-compose up
\`\`\`

Open http://localhost → done.

## Run locally (no Docker)

\`\`\`bash
# Terminal 1
cd backend && npm install
npx prisma db push
npm run dev

# Terminal 2
cd frontend && npm install
npm run dev
\`\`\`

## Deploy to Railway (5 min)

\`\`\`bash
npm install -g @railway/cli
railway login && railway init
railway add postgresql
railway up
\`\`\`

## Stack
- **Backend**: Node.js + Express + Prisma + JWT
- **Database**: PostgreSQL
- **Frontend**: React + Vite + Tailwind CSS
- **Deploy**: Docker / Railway / Render

## Default login
- Email: \`admin@demo.com\`
- Password: \`password123\``,
  },

  // ── BACKEND ──────────────────────────────────────────────────────────────
  {
    path: 'backend/package.json',
    section: 'backend',
    lang: 'json',
    runnable: false,
    code: `{
  "name": "behavior-engine-backend",
  "version": "1.0.0",
  "scripts": {
    "dev":      "node --watch src/server.js",
    "start":    "node src/server.js",
    "db:push":  "prisma db push",
    "db:seed":  "node prisma/seed.js"
  },
  "dependencies": {
    "express":        "^4.18.2",
    "cors":           "^2.8.5",
    "bcryptjs":       "^2.4.3",
    "jsonwebtoken":   "^9.0.2",
    "@prisma/client": "^5.8.0",
    "dotenv":         "^16.4.1",
    "express-rate-limit": "^7.1.5"
  },
  "devDependencies": {
    "prisma": "^5.8.0"
  }
}`,
  },
  {
    path: 'backend/src/server.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `require('dotenv').config();
const app = require('./app');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log('\\n🚀 Behavior Engine API running');
  console.log('   Port:', PORT);
  console.log('   Env: ', process.env.NODE_ENV || 'development');
  console.log('   DB:  ', process.env.DATABASE_URL?.slice(0, 40) + '...');
});`,
  },
  {
    path: 'backend/src/app.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `const express    = require('express');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');

const authRoutes  = require('./routes/auth');
const taskRoutes  = require('./routes/tasks');
const scoreRoutes = require('./routes/score');
const crmRoutes   = require('./routes/crm');

const app = express();

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200 }));

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (_, res) =>
  res.json({ status: 'ok', ts: Date.now(), version: '1.0.0' })
);

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/auth',  authRoutes);
app.use('/tasks', taskRoutes);
app.use('/score', scoreRoutes);
app.use('/crm',   crmRoutes);

// ── 404 ───────────────────────────────────────────────────────────────────────
app.use((_, res) => res.status(404).json({ error: 'Not found' }));

module.exports = app;`,
  },
  {
    path: 'backend/src/routes/auth.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const SECRET = process.env.JWT_SECRET;

// POST /auth/register
router.post('/register', async (req, res) => {
  try {
    const { email, password, name, tenantId, role = 'rep' } = req.body;
    if (!email || !password || !name)
      return res.status(400).json({ error: 'email, password, name required' });

    const hash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { email, password: hash, name, tenantId: tenantId || 'default', role },
      select: { id: true, email: true, name: true, role: true, tenantId: true },
    });
    const token = jwt.sign({ userId: user.id, tenantId: user.tenantId }, SECRET, { expiresIn: '7d' });
    res.status(201).json({ user, token });
  } catch (e) {
    if (e.code === 'P2002') return res.status(409).json({ error: 'Email already in use' });
    res.status(500).json({ error: e.message });
  }
});

// POST /auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ error: 'Invalid credentials' });

    const { password: _, ...safe } = user;
    const token = jwt.sign({ userId: user.id, tenantId: user.tenantId }, SECRET, { expiresIn: '7d' });
    res.json({ user: safe, token });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /auth/me  (requires Bearer token)
router.get('/me', require('../middleware/auth'), async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.userId },
    select: { id: true, email: true, name: true, role: true, tenantId: true },
  });
  res.json(user);
});

module.exports = router;`,
  },
  {
    path: 'backend/src/routes/tasks.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `const router = require('express').Router();
const auth   = require('../middleware/auth');
const { PrismaClient } = require('@prisma/client');
const { calculateScore, getStatus } = require('../engine/score');

const prisma = new PrismaClient();

router.use(auth);

// GET /tasks — list today's tasks for user
router.get('/', async (req, res) => {
  const tasks = await prisma.task.findMany({
    where: { tenantId: req.user.tenantId, active: true },
    orderBy: { points: 'desc' },
  });
  res.json(tasks);
});

// POST /tasks/:id/complete — complete a task + return updated score
router.post('/:id/complete', async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);

  // Log the action
  await prisma.action.create({
    data: {
      userId:   req.user.userId,
      tenantId: req.user.tenantId,
      taskId:   req.params.id,
      type:     'task_complete',
      points:   req.body.points || 10,
      date:     today,
    },
  });

  // Recalculate today's score
  const actions = await prisma.action.findMany({
    where: { userId: req.user.userId, date: today },
  });
  const score  = calculateScore(actions);
  const status = getStatus(score);

  res.json({ taskId: req.params.id, score, status, actionsToday: actions.length });
});

module.exports = router;`,
  },
  {
    path: 'backend/src/routes/score.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `const router = require('express').Router();
const auth   = require('../middleware/auth');
const { PrismaClient } = require('@prisma/client');
const { calculateScore, getStatus, getWeekScores } = require('../engine/score');

const prisma = new PrismaClient();
router.use(auth);

// GET /score — today's score + 7-day history
router.get('/', async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const actions = await prisma.action.findMany({
    where: { userId: req.user.userId, date: today },
  });
  const score  = calculateScore(actions);
  const status = getStatus(score);
  res.json({ score, status, actionsToday: actions.length });
});

// GET /score/leaderboard — team ranking for today
router.get('/leaderboard', async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const rows = await prisma.action.groupBy({
    by: ['userId'],
    where: { tenantId: req.user.tenantId, date: today },
    _sum: { points: true },
    orderBy: { _sum: { points: 'desc' } },
  });

  // Attach user names
  const users = await prisma.user.findMany({
    where: { id: { in: rows.map(r => r.userId) } },
    select: { id: true, name: true },
  });
  const nameMap = Object.fromEntries(users.map(u => [u.id, u.name]));

  res.json(rows.map((r, i) => ({
    rank:   i + 1,
    userId: r.userId,
    name:   nameMap[r.userId] || 'Unknown',
    score:  r._sum.points ?? 0,
    status: getStatus(r._sum.points ?? 0),
  })));
});

module.exports = router;`,
  },
  {
    path: 'backend/src/engine/score.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `/**
 * Core scoring engine.
 * Pure functions — no side effects, fully testable.
 */

function calculateScore(actions) {
  return actions.reduce((sum, a) => sum + (a.points || 0), 0);
}

function getStatus(score) {
  if (score >= 40) return 'GREEN';
  if (score >= 20) return 'YELLOW';
  return 'RED';
}

function getConsistency(history) {
  if (!history.length) return 0;
  return Math.round(history.filter(s => s > 0).length / history.length * 100);
}

function getTrend(history) {
  if (history.length < 3) return 'stable';
  const recent = history.slice(-3);
  const delta  = recent[2] - recent[0];
  if (delta > 8)  return 'up';
  if (delta < -8) return 'down';
  return 'stable';
}

module.exports = { calculateScore, getStatus, getConsistency, getTrend };`,
  },
  {
    path: 'backend/src/middleware/auth.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `const jwt = require('jsonwebtoken');

module.exports = function auth(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer '))
    return res.status(401).json({ error: 'No token provided' });

  try {
    const token   = header.slice(7);
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;   // { userId, tenantId }
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
};`,
  },
  {
    path: 'backend/src/routes/crm.js',
    section: 'backend',
    lang: 'javascript',
    runnable: true,
    code: `const router = require('express').Router();
const auth   = require('../middleware/auth');
const { PrismaClient } = require('@prisma/client');

const prisma   = new PrismaClient();
const PIPELINE = ['new', 'contacted', 'pilot', 'paid', 'expansion'];

router.use(auth);

router.get('/',    async (req, res) => {
  const leads = await prisma.lead.findMany({
    where:   { tenantId: req.user.tenantId },
    orderBy: { createdAt: 'desc' },
  });
  res.json(leads);
});

router.post('/', async (req, res) => {
  const lead = await prisma.lead.create({
    data: { ...req.body, tenantId: req.user.tenantId, status: 'new' },
  });
  res.status(201).json(lead);
});

router.patch('/:id/advance', async (req, res) => {
  const lead = await prisma.lead.findUnique({ where: { id: req.params.id } });
  if (!lead) return res.status(404).json({ error: 'Not found' });
  const next = PIPELINE[PIPELINE.indexOf(lead.status) + 1];
  if (!next)  return res.status(400).json({ error: 'Already at final stage' });
  res.json(await prisma.lead.update({ where: { id: lead.id }, data: { status: next } }));
});

module.exports = router;`,
  },

  // ── PRISMA ────────────────────────────────────────────────────────────────
  {
    path: 'prisma/schema.prisma',
    section: 'prisma',
    lang: 'prisma',
    runnable: false,
    code: `generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id          String   @id @default(cuid())
  email       String   @unique
  password    String
  name        String
  role        String   @default("rep")
  tenantId    String
  personality String   @default("discipline")
  streak      Int      @default(0)
  createdAt   DateTime @default(now())
  actions     Action[]
}

model Task {
  id          String   @id @default(cuid())
  tenantId    String
  title       String
  description String?
  points      Int      @default(10)
  category    String   @default("general")
  active      Boolean  @default(true)
  createdAt   DateTime @default(now())
  actions     Action[]
}

model Action {
  id        String   @id @default(cuid())
  userId    String
  tenantId  String
  taskId    String?
  type      String   @default("task_complete")
  points    Int
  date      String
  createdAt DateTime @default(now())
  user      User     @relation(fields: [userId], references: [id])
  task      Task?    @relation(fields: [taskId], references: [id])
}

model Lead {
  id         String   @id @default(cuid())
  tenantId   String
  name       String
  company    String
  email      String?
  status     String   @default("new")
  source     String   @default("inbound")
  teamSize   Int      @default(5)
  value      Int      @default(0)
  lastAction String?
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
}`,
  },
  {
    path: 'prisma/seed.js',
    section: 'prisma',
    lang: 'javascript',
    runnable: true,
    code: `const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Create admin user
  const hash = await bcrypt.hash('password123', 12);
  await prisma.user.upsert({
    where:  { email: 'admin@demo.com' },
    update: {},
    create: { email: 'admin@demo.com', password: hash, name: 'Admin User', role: 'admin', tenantId: 'acme' },
  });

  // Create demo users
  const demoUsers = [
    { email: 'marcus@acme.com',  name: 'Marcus Chen',    role: 'rep',     tenantId: 'acme' },
    { email: 'sarah@acme.com',   name: 'Sarah Kim',      role: 'manager', tenantId: 'acme' },
    { email: 'james@acme.com',   name: 'James Torres',   role: 'rep',     tenantId: 'acme' },
  ];
  for (const u of demoUsers) {
    await prisma.user.upsert({
      where:  { email: u.email },
      update: {},
      create: { ...u, password: hash },
    });
  }

  // Create tasks
  const tasks = [
    { title: 'Morning check-in',       points: 10, category: 'daily',   tenantId: 'acme' },
    { title: 'Log 3 outbound calls',   points: 15, category: 'sales',   tenantId: 'acme' },
    { title: 'Update CRM pipeline',    points: 10, category: 'admin',   tenantId: 'acme' },
    { title: 'Send 5 LinkedIn DMs',    points: 15, category: 'growth',  tenantId: 'acme' },
    { title: 'Submit daily report',    points: 10, category: 'admin',   tenantId: 'acme' },
  ];
  for (const t of tasks) {
    await prisma.task.create({ data: t });
  }

  console.log('✅ Seeded:', demoUsers.length + 1, 'users,', tasks.length, 'tasks');
}

main().catch(console.error).finally(() => prisma.$disconnect());`,
  },

  // ── FRONTEND ─────────────────────────────────────────────────────────────
  {
    path: 'frontend/package.json',
    section: 'frontend',
    lang: 'json',
    runnable: false,
    code: `{
  "name": "behavior-engine-frontend",
  "version": "1.0.0",
  "scripts": {
    "dev":   "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react":        "^18.2.0",
    "react-dom":    "^18.2.0",
    "react-router-dom": "^6.21.3"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer":  "^10.4.17",
    "postcss":       "^8.4.33",
    "tailwindcss":   "^3.4.1",
    "vite":          "^5.0.11"
  }
}`,
  },
  {
    path: 'frontend/src/api.js',
    section: 'frontend',
    lang: 'javascript',
    runnable: true,
    code: `const BASE = import.meta.env.VITE_API_URL || 'http://localhost:3000';

function getToken() { return localStorage.getItem('be_token'); }

async function req(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(getToken() ? { Authorization: 'Bearer ' + getToken() } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401) {
    localStorage.removeItem('be_token');
    window.location.href = '/login';
  }
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

export const auth = {
  login:    (email, password) => req('POST', '/auth/login', { email, password }),
  register: (data)            => req('POST', '/auth/register', data),
  me:       ()                => req('GET',  '/auth/me'),
};

export const tasks = {
  list:     ()          => req('GET',  '/tasks'),
  complete: (id, pts)   => req('POST', '/tasks/' + id + '/complete', { points: pts }),
};

export const score = {
  get:         () => req('GET', '/score'),
  leaderboard: () => req('GET', '/score/leaderboard'),
};

export const crm = {
  leads:   ()     => req('GET',   '/crm'),
  create:  (data) => req('POST',  '/crm', data),
  advance: (id)   => req('PATCH', '/crm/' + id + '/advance'),
};`,
  },
  {
    path: 'frontend/src/App.jsx',
    section: 'frontend',
    lang: 'jsx',
    runnable: true,
    code: `import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect, createContext, useContext } from 'react';
import { auth as authApi } from './api';

// ── Auth context ──────────────────────────────────────────────────────────────
const AuthCtx = createContext({});

function AuthProvider({ children }) {
  const [user,    setUser]  = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('be_token');
    if (token) {
      authApi.me().then(setUser).catch(() => {}).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (email, password) => {
    const data = await authApi.login(email, password);
    localStorage.setItem('be_token', data.token);
    setUser(data.user);
  };
  const logout = () => { localStorage.removeItem('be_token'); setUser(null); };

  return <AuthCtx.Provider value={{ user, login, logout, loading }}>{children}</AuthCtx.Provider>;
}

// ── Pages (lazy-loaded in real app) ──────────────────────────────────────────
import Login      from './pages/Login';
import Dashboard  from './pages/Dashboard';
import Tasks      from './pages/Tasks';
import Leaderboard from './pages/Leaderboard';

function PrivateRoute({ children }) {
  const { user, loading } = useContext(AuthCtx);
  if (loading) return <div className="min-h-screen bg-[#070b14] flex items-center justify-center"><div className="w-6 h-6 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin"/></div>;
  return user ? children : <Navigate to="/login" />;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/"           element={<PrivateRoute><Dashboard /></PrivateRoute>} />
          <Route path="/tasks"      element={<PrivateRoute><Tasks /></PrivateRoute>} />
          <Route path="/leaderboard" element={<PrivateRoute><Leaderboard /></PrivateRoute>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}`,
  },
  {
    path: 'frontend/src/pages/Dashboard.jsx',
    section: 'frontend',
    lang: 'jsx',
    runnable: true,
    code: `import { useEffect, useState, useContext } from 'react';
import { score as scoreApi } from '../api';

const STATUS_COLOR = { GREEN: '#10b981', YELLOW: '#f59e0b', RED: '#ef4444' };
const STATUS_BG    = { GREEN: '#052e16', YELLOW: '#1c1000', RED: '#2d0505' };

export default function Dashboard() {
  const [data,    setData]    = useState({ score: 0, status: 'RED', actionsToday: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    scoreApi.get().then(setData).finally(() => setLoading(false));
  }, []);

  const pct = Math.min(100, Math.round((data.score / 40) * 100));

  return (
    <div style={{ padding: '2rem', background: '#070b14', minHeight: '100vh', color: '#fff' }}>
      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, letterSpacing: 2, marginBottom: 24 }}>
        TODAY — BEHAVIOR ENGINE
      </p>

      {/* Score card */}
      <div style={{ background: STATUS_BG[data.status], border: '1px solid ' + STATUS_COLOR[data.status] + '40', borderRadius: 16, padding: 32, maxWidth: 320, marginBottom: 24 }}>
        {loading ? (
          <div style={{ color: 'rgba(255,255,255,0.3)' }}>Loading…</div>
        ) : (
          <>
            <div style={{ fontSize: 72, fontWeight: 900, lineHeight: 1, color: STATUS_COLOR[data.status] }}>
              {data.score}
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: STATUS_COLOR[data.status], marginTop: 4 }}>
              {data.status}
            </div>
            <div style={{ marginTop: 16, height: 6, background: 'rgba(255,255,255,0.08)', borderRadius: 99, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: pct + '%', background: STATUS_COLOR[data.status], borderRadius: 99, transition: 'width 0.7s ease' }} />
            </div>
            <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11, marginTop: 8 }}>
              {data.actionsToday} action{data.actionsToday !== 1 ? 's' : ''} logged today
            </div>
          </>
        )}
      </div>

      <div style={{ display: 'flex', gap: 12 }}>
        <a href="/tasks" style={{ background: '#6366f1', color: '#fff', padding: '12px 20px', borderRadius: 10, fontWeight: 700, textDecoration: 'none', fontSize: 13 }}>
          Log Tasks →
        </a>
        <a href="/leaderboard" style={{ background: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.6)', padding: '12px 20px', borderRadius: 10, fontWeight: 600, textDecoration: 'none', fontSize: 13, border: '1px solid rgba(255,255,255,0.1)' }}>
          Leaderboard
        </a>
      </div>
    </div>
  );
}`,
  },
  {
    path: 'frontend/src/pages/Tasks.jsx',
    section: 'frontend',
    lang: 'jsx',
    runnable: true,
    code: `import { useEffect, useState } from 'react';
import { tasks as tasksApi } from '../api';

export default function Tasks() {
  const [taskList, setTaskList] = useState([]);
  const [score,    setScore]    = useState(0);
  const [status,   setStatus]   = useState('RED');
  const [done,     setDone]     = useState(new Set());

  useEffect(() => { tasksApi.list().then(setTaskList); }, []);

  const complete = async (task) => {
    if (done.has(task.id)) return;
    try {
      const res = await tasksApi.complete(task.id, task.points);
      setScore(res.score);
      setStatus(res.status);
      setDone(prev => new Set([...prev, task.id]));
    } catch (e) {
      alert(e.message);
    }
  };

  const STATUS_COLOR = { GREEN: '#10b981', YELLOW: '#f59e0b', RED: '#ef4444' };

  return (
    <div style={{ padding: '2rem', background: '#070b14', minHeight: '100vh', color: '#fff' }}>
      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, letterSpacing: 2, marginBottom: 8 }}>DAILY TASKS</p>
      <div style={{ fontSize: 40, fontWeight: 900, color: STATUS_COLOR[status], marginBottom: 24 }}>
        {score} pts — {status}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 480 }}>
        {taskList.map(task => {
          const completed = done.has(task.id);
          return (
            <div key={task.id}
              onClick={() => complete(task)}
              style={{
                display: 'flex', alignItems: 'center', gap: 14,
                padding: '14px 18px', borderRadius: 12, cursor: 'pointer',
                background: completed ? 'rgba(16,185,129,0.08)' : 'rgba(255,255,255,0.04)',
                border: '1px solid ' + (completed ? 'rgba(16,185,129,0.3)' : 'rgba(255,255,255,0.08)'),
                transition: 'all 0.2s',
              }}>
              <div style={{
                width: 22, height: 22, borderRadius: 6, flexShrink: 0,
                background: completed ? '#10b981' : 'transparent',
                border: '1.5px solid ' + (completed ? '#10b981' : 'rgba(255,255,255,0.2)'),
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {completed && <span style={{ color: '#fff', fontSize: 12, fontWeight: 700 }}>✓</span>}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, color: completed ? 'rgba(255,255,255,0.35)' : 'rgba(255,255,255,0.75)', textDecoration: completed ? 'line-through' : 'none' }}>
                  {task.title}
                </div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 2 }}>
                  +{task.points} pts
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}`,
  },
];

// ── Section metadata ──────────────────────────────────────────────────────────
const SECTIONS = [
  { id: 'root',     label: 'Root',     icon: Folder,   color: 'text-white/50',   count: FILES.filter(f => f.section === 'root').length     },
  { id: 'backend',  label: 'backend/', icon: Server,   color: 'text-indigo-400', count: FILES.filter(f => f.section === 'backend').length  },
  { id: 'prisma',   label: 'prisma/',  icon: Database, color: 'text-cyan-400',   count: FILES.filter(f => f.section === 'prisma').length   },
  { id: 'frontend', label: 'frontend/',icon: FileCode, color: 'text-purple-400', count: FILES.filter(f => f.section === 'frontend').length },
];

// ── Copy button ───────────────────────────────────────────────────────────────
function CopyBtn({ text, label = 'Copy' }) {
  const [copied, setCopied] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1800); }}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
        copied ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65 hover:bg-white/8'
      }`}>
      {copied ? <><Check size={10} /> Copied!</> : <><Copy size={10} /> {label}</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function CopyPasteRepo() {
  const [section,  setSection] = useState('root');
  const [selected, setSelected]= useState(FILES[0]);

  const sectionFiles = FILES.filter(f => f.section === section);
  const allCode = FILES.map(f => `// ══ ${f.path} ══\n${f.code}`).join('\n\n\n');

  return (
    <div className="min-h-screen bg-[#070b14] text-white flex flex-col">

      {/* Top bar */}
      <div className="shrink-0 border-b border-white/8 bg-[#0b0f1a] px-4 lg:px-8 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GitMerge size={14} className="text-white/40" />
            <span className="text-white font-bold text-sm font-mono">behavior-engine-mvp</span>
            <span className="text-white/20 text-xs">{FILES.length} files · deployable in &lt; 2 hrs</span>
          </div>
          <div className="flex items-center gap-2">
            <CopyBtn text={allCode} label="Copy All Files" />
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span className="text-emerald-400 text-[10px] font-bold">RUNNABLE</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick deploy bar */}
      <div className="shrink-0 border-b border-white/6 bg-black/20 px-4 lg:px-8 py-2.5">
        <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide">
          <Terminal size={11} className="text-emerald-400 shrink-0" />
          <code className="text-emerald-400/80 text-[10px] font-mono whitespace-nowrap">
            git clone … && cp .env.example .env && docker-compose up
          </code>
          <span className="text-white/20 text-[9px] whitespace-nowrap shrink-0">← paste this and you're live</span>
          <CopyBtn text="git clone https://github.com/you/behavior-engine-mvp && cd behavior-engine-mvp && cp .env.example .env && docker-compose up" label="Copy" />
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">

        {/* File tree sidebar */}
        <div className="w-64 shrink-0 border-r border-white/6 bg-[#0b0f1a] overflow-y-auto scrollbar-hide hidden lg:block">
          <div className="p-3 space-y-4">
            {SECTIONS.map(sec => {
              const Icon = sec.icon;
              const isActiveSec = section === sec.id;
              return (
                <div key={sec.id}>
                  <button onClick={() => { setSection(sec.id); setSelected(FILES.find(f => f.section === sec.id) || FILES[0]); }}
                    className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      isActiveSec ? 'bg-white/6 text-white' : 'text-white/30 hover:text-white/50 hover:bg-white/3'
                    }`}>
                    <Icon size={12} className={sec.color} />
                    <span className="font-mono flex-1 text-left">{sec.label}</span>
                    <span className="text-white/20 text-[9px]">{sec.count}</span>
                  </button>

                  {isActiveSec && sectionFiles.map(f => (
                    <button key={f.path} onClick={() => setSelected(f)}
                      className={`w-full flex items-center gap-2 pl-6 pr-2 py-1.5 rounded-lg text-[10px] font-mono transition-all mt-0.5 text-left ${
                        selected?.path === f.path
                          ? 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/20'
                          : 'text-white/30 hover:text-white/55 hover:bg-white/3'
                      }`}>
                      <ChevronRight size={9} className="shrink-0" />
                      <span className="truncate">{f.path.split('/').pop()}</span>
                      {f.runnable && <span className="ml-auto text-[7px] text-emerald-400/50 font-sans">●</span>}
                    </button>
                  ))}
                </div>
              );
            })}
          </div>
        </div>

        {/* Code view */}
        <div className="flex-1 flex flex-col overflow-hidden">

          {/* Mobile section picker */}
          <div className="lg:hidden border-b border-white/6 px-4 py-2 flex gap-2 overflow-x-auto scrollbar-hide">
            {SECTIONS.map(sec => (
              <button key={sec.id} onClick={() => setSection(sec.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${section === sec.id ? 'bg-indigo-500 text-white' : 'bg-white/5 text-white/35'}`}>
                {sec.label}
              </button>
            ))}
          </div>

          {/* Mobile file list */}
          <div className="lg:hidden border-b border-white/6 px-4 py-2 flex gap-2 overflow-x-auto scrollbar-hide">
            {sectionFiles.map(f => (
              <button key={f.path} onClick={() => setSelected(f)}
                className={`px-2.5 py-1.5 rounded-lg text-[9px] font-mono whitespace-nowrap ${selected?.path === f.path ? 'bg-white/10 text-white' : 'text-white/30'}`}>
                {f.path.split('/').pop()}
              </button>
            ))}
          </div>

          {/* File header */}
          {selected && (
            <div className="shrink-0 flex items-center justify-between px-5 py-2.5 border-b border-white/6 bg-white/1">
              <div className="flex items-center gap-2.5">
                <code className="text-white/50 text-xs font-mono">{selected.path}</code>
                <span className="text-[8px] px-1.5 py-0.5 rounded bg-white/6 border border-white/8 text-white/25 font-mono">{selected.lang}</span>
                {selected.runnable && (
                  <span className="flex items-center gap-1 text-[8px] px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-semibold">
                    <Play size={7} /> runnable
                  </span>
                )}
              </div>
              <CopyBtn text={selected.code} />
            </div>
          )}

          {/* Code */}
          <div className="flex-1 overflow-auto">
            {selected && (
              <pre className="p-5 text-[11px] leading-relaxed text-emerald-400/80 font-mono min-h-full bg-black/20">
                {selected.code}
              </pre>
            )}
          </div>
        </div>
      </div>

      {/* Bottom deploy bar */}
      <div className="shrink-0 border-t border-white/8 bg-[#0b0f1a] px-4 lg:px-8 py-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex gap-4 flex-wrap">
            {[['Railway', '5 min', 'railway up'], ['Render', '8 min', 'render deploy'], ['Fly.io', '10 min', 'fly deploy']].map(([name, time, cmd]) => (
              <div key={name} className="flex items-center gap-1.5">
                <Cloud size={11} className="text-white/25" />
                <span className="text-white/35 text-xs">{name}</span>
                <code className="text-[9px] font-mono text-indigo-400/60 bg-indigo-500/8 px-1.5 py-0.5 rounded border border-indigo-500/15">{cmd}</code>
                <span className="text-white/20 text-[9px]">{time}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-1.5 text-white/25 text-[9px]">
            <Zap size={10} className="text-emerald-400" />
            <span>Node 20 · PostgreSQL · Docker · MIT License</span>
          </div>
        </div>
      </div>

    </div>
  );
}
