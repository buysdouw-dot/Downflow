import { useState } from 'react';
import { CheckCircle2, Plus, Clock, Flame, Zap, Bot, AlertTriangle } from 'lucide-react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus, getStatusConfig } from '../engine/core';
import StatusBadge from '../components/StatusBadge';
import ScoreRing from '../components/ScoreRing';
import MobileHeader from '../components/MobileHeader';

export default function Tasks() {
  const {
    activeUserId, activePlugin,
    plugins, getTodayScore, getTodayLogs, logAction, feedback,
  } = useBehavior();
  const { user } = useAuth();

  const score = getTodayScore(activeUserId);
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const todayLogs = getTodayLogs(activeUserId);
  const plug = plugins[activePlugin];

  const [logged, setLogged] = useState(null);

  const handleLog = (task) => {
    logAction(activeUserId, task);
    setLogged(task.id);
    setTimeout(() => setLogged(null), 900);
  };

  const taskCount = (taskId) => todayLogs.filter((l) => l.taskId === taskId).length;
  const taskPoints = (taskId) => todayLogs.filter((l) => l.taskId === taskId).reduce((s, l) => s + l.points, 0);
  const categories = [...new Set(plug.tasks.map((t) => t.category))];
  const remaining = Math.max(0, plug.dailyTarget - score);
  const targetHit = score >= plug.dailyTarget;

  return (
    <div className="max-w-4xl mx-auto">
      <MobileHeader title="Task Engine" />

      {/* Desktop header — minimal, execution-focused */}
      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-2">
        <div>
          <h1 className="text-2xl font-bold text-white">Task Engine</h1>
          <p className="text-white/35 text-sm mt-0.5">{plug?.icon} {plug?.name} · Log actions, build consistency</p>
        </div>
        <StatusBadge status={status} size="md" />
      </div>

      <div className="px-4 lg:px-6 pb-8">
        {/* Hero score block — big number, zero distraction */}
        <div className={`flex items-center gap-5 py-5 mb-5 border-b border-white/6`}>
          <ScoreRing score={score} target={plug.dailyTarget} size={90} />
          <div className="flex-1 min-w-0">
            <p className={`text-5xl font-black leading-none ${cfg.color}`}>{score}</p>
            <p className="text-white/30 text-sm mt-1">
              of {plug.dailyTarget} pts target
              {remaining > 0 ? ` · ${remaining} remaining` : ' · Target hit!'}
            </p>
            {targetHit && (
              <div className="flex items-center gap-1.5 mt-2">
                <Flame size={13} className="text-green-400" />
                <span className="text-green-400 text-xs font-semibold">Daily target reached · Green day locked in</span>
              </div>
            )}
          </div>
          <div className="hidden lg:block text-right">
            <p className="text-white/20 text-xs uppercase tracking-widest">Actions logged</p>
            <p className="text-white text-3xl font-black">{todayLogs.length}</p>
          </div>
        </div>

        {/* AI Coaching banner — inline, compact */}
        {feedback && (
          <div className={`flex items-start gap-3 p-3.5 rounded-xl border ${cfg.border} ${cfg.bg} mb-5`}
            style={{ animation: 'fadeIn 0.3s ease' }}>
            <Bot size={14} className={`${cfg.color} shrink-0 mt-0.5`} />
            <div className="flex-1 min-w-0">
              <p className={`text-xs font-bold ${cfg.color} mb-0.5`}>{feedback.tag}</p>
              <p className="text-white/80 text-sm leading-snug">{feedback.insight}</p>
              {feedback.action && (
                <p className="text-white/45 text-xs mt-1 flex items-center gap-1">
                  <Zap size={9} className="text-white/30" /> {feedback.action}
                </p>
              )}
            </div>
            {feedback.warning && (
              <AlertTriangle size={13} className="text-red-400 shrink-0 mt-0.5" />
            )}
          </div>
        )}

        <div className="grid lg:grid-cols-[1fr_240px] gap-6">
          {/* Task list — execution-focused, big tap targets */}
          <div className="space-y-6">
            {categories.map((cat) => (
              <div key={cat}>
                <div className="flex items-center gap-2 mb-3">
                  <p className="text-white/25 text-[10px] font-bold uppercase tracking-widest">{cat}</p>
                  <div className="h-px flex-1 bg-white/6" />
                </div>
                <div className="space-y-2">
                  {plug.tasks.filter((t) => t.category === cat).map((task) => {
                    const count = taskCount(task.id);
                    const earned = taskPoints(task.id);
                    const justLogged = logged === task.id;
                    const isHighValue = task.points >= 5;

                    return (
                      <div
                        key={task.id}
                        className={`rounded-2xl flex items-center gap-4 transition-all duration-200 glass cursor-pointer select-none ${
                          justLogged
                            ? `border-2 ${cfg.border} bg-white/5 scale-[1.01]`
                            : 'border border-white/6 hover:border-white/14 hover:bg-white/3'
                        }`}
                        onClick={() => handleLog(task)}
                      >
                        {/* Big left tap area */}
                        <div className="flex-1 min-w-0 px-5 py-4">
                          <div className="flex items-center gap-2.5 mb-1">
                            <p className={`font-semibold text-base leading-snug ${justLogged ? 'text-white' : 'text-white/80'}`}>
                              {task.name}
                            </p>
                            {isHighValue && (
                              <span className="text-[9px] bg-indigo-500/15 text-indigo-400 px-1.5 py-0.5 rounded-full border border-indigo-500/20 font-bold shrink-0">
                                HIGH VALUE
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3">
                            <span className={`text-sm font-bold ${justLogged ? cfg.color : 'text-indigo-400/70'}`}>
                              +{task.points} pts
                            </span>
                            {count > 0 && (
                              <span className="text-white/25 text-xs flex items-center gap-1">
                                <CheckCircle2 size={9} className="text-green-400" />
                                {count}× logged · {earned} pts
                              </span>
                            )}
                          </div>
                        </div>

                        {/* DONE button — big tap target */}
                        <div className={`px-5 py-4 flex items-center justify-center transition-all shrink-0 ${
                          justLogged
                            ? `${cfg.color}`
                            : 'text-white/20'
                        }`}>
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-xs transition-all ${
                            justLogged
                              ? `${cfg.bg} border-2 ${cfg.border} scale-110`
                              : 'bg-white/5 border border-white/8 hover:bg-indigo-500/15 hover:border-indigo-500/30 hover:text-indigo-400'
                          }`}>
                            {justLogged
                              ? <CheckCircle2 size={20} />
                              : <span className="text-[10px] font-black tracking-tight">DONE</span>
                            }
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Right sidebar — compact */}
          <div className="space-y-4">
            {/* Today's log */}
            <div className="glass rounded-xl p-4 border border-white/8">
              <div className="flex items-center gap-2 mb-3">
                <Clock size={12} className="text-white/25" />
                <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">Today's Log</p>
                <span className="ml-auto text-white/25 text-xs">{todayLogs.length} actions</span>
              </div>
              {todayLogs.length === 0 ? (
                <div className="text-center py-4">
                  <p className="text-white/15 text-xs">No actions logged.</p>
                  <p className="text-white/10 text-[10px] mt-1">Tap any task to start.</p>
                </div>
              ) : (
                <div className="space-y-1.5 max-h-52 overflow-y-auto scrollbar-hide">
                  {[...todayLogs].reverse().map((l) => (
                    <div key={l.id} className="flex items-center justify-between py-1 border-b border-white/4 last:border-0">
                      <p className="text-white/40 text-xs truncate flex-1">{l.taskName}</p>
                      <span className={`text-xs font-bold ml-2 ${cfg.color}`}>+{l.points}</span>
                    </div>
                  ))}
                </div>
              )}
              {todayLogs.length > 0 && (
                <div className="pt-2 mt-1 border-t border-white/6 flex justify-between">
                  <span className="text-white/25 text-xs">Total</span>
                  <span className={`text-sm font-black ${cfg.color}`}>{score} pts</span>
                </div>
              )}
            </div>

            {/* Recommended next action */}
            {!targetHit && (
              <div className="glass rounded-xl p-4 border border-indigo-500/20">
                <div className="flex items-center gap-1.5 mb-2">
                  <Zap size={11} className="text-indigo-400" />
                  <p className="text-indigo-400 text-[10px] font-bold uppercase tracking-widest">Next Best Action</p>
                </div>
                {(() => {
                  const topTask = [...plug.tasks].sort((a, b) => b.points - a.points)[0];
                  return (
                    <>
                      <p className="text-white/70 text-sm font-medium">{topTask.name}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-indigo-400 text-sm font-bold">+{topTask.points} pts</span>
                        <button
                          onClick={() => handleLog(topTask)}
                          className="text-[10px] font-bold text-indigo-400 bg-indigo-500/15 border border-indigo-500/25 px-2.5 py-1 rounded-lg hover:bg-indigo-500/25 transition-all"
                        >
                          LOG NOW
                        </button>
                      </div>
                    </>
                  );
                })()}
              </div>
            )}

            {/* Target hit celebration */}
            {targetHit && (
              <div className="glass rounded-xl p-4 border border-green-500/25 text-center">
                <div className="text-3xl mb-2">🎯</div>
                <p className="text-green-400 font-bold text-sm">Target Reached!</p>
                <p className="text-white/30 text-xs mt-1">Every extra action compounds your streak.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
}
