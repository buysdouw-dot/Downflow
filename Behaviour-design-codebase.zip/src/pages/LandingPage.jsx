import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../store/AuthContext';
import {
  CheckCircle2, ArrowRight, Zap, Shield, BarChart2, Bot,
  Users, TrendingUp, Star, Play, ChevronDown, Menu, X,
  Flame, Target, Activity, Sparkles, LogIn,
} from 'lucide-react';

// ── Design Tokens ─────────────────────────────────────────────────────────────
const COLORS = {
  primary:   '#6366f1',
  success:   '#10b981',
  warning:   '#f59e0b',
  danger:    '#ef4444',
  bg:        '#05080f',
  surface:   '#0b0f1a',
  border:    'rgba(255,255,255,0.06)',
};

const TYPOGRAPHY = {
  h1: 'text-4xl lg:text-[3.75rem] font-black leading-[1.04] tracking-tight',
  h2: 'text-3xl lg:text-4xl font-black leading-tight tracking-tight',
  h3: 'text-xl font-bold',
  body: 'text-base leading-relaxed',
  small: 'text-xs',
};

// ── Data ──────────────────────────────────────────────────────────────────────
const NAV_LINKS = ['Features', 'How It Works', 'Results', 'Pricing'];

const PROBLEMS = [
  { icon: '😤', stat: '82%', text: 'of managers can\'t see who\'s actually executing daily', source: 'HBR 2024' },
  { icon: '📉', stat: '67%', text: 'of sales reps miss quota due to poor daily activity habits', source: 'Salesforce' },
  { icon: '🔁', stat: '$1.5T', text: 'lost annually from inconsistent execution across teams', source: 'McKinsey' },
  { icon: '🏳️', stat: '73%', text: 'of behavior change programs fail without consistent tracking', source: 'MIT Sloan' },
];

const SOLUTIONS = [
  { icon: Target,    label: 'Daily Action Assignment',      desc: 'Every team member gets structured daily actions matched to their role and industry plugin.',    color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
  { icon: Activity,  label: 'Real-Time Execution Tracking', desc: 'See who is logging actions, when, and at what volume — live. No guessing, no Friday surprises.', color: 'text-purple-400', bg: 'bg-purple-500/10',  border: 'border-purple-500/20' },
  { icon: BarChart2, label: 'Behavior Scoring Engine',      desc: 'GREEN / YELLOW / RED status tells you instantly who is performing and who needs intervention.',  color: 'text-cyan-400',   bg: 'bg-cyan-500/10',   border: 'border-cyan-500/20' },
  { icon: Bot,       label: 'AI Personality Coaching',      desc: 'Three coach types (Discipline, Strategy, Motivation). Each user gets coaching that fits who they are.', color: 'text-emerald-400',bg: 'bg-emerald-500/10',border: 'border-emerald-500/20' },
  { icon: Flame,     label: 'Streak & Consistency System',  desc: 'Streaks reinforce habit formation. Break the chain and the AI flags it before it becomes a pattern.', color: 'text-orange-400', bg: 'bg-orange-500/10',border: 'border-orange-500/20' },
  { icon: Shield,    label: 'Multi-Tenant Admin Controls',  desc: 'Managers get a full admin dashboard: execution rate, at-risk users, behavioral trend charts.',  color: 'text-pink-400',   bg: 'bg-pink-500/10',   border: 'border-pink-500/20' },
];

const HOW_IT_WORKS = [
  { step: '01', title: 'Assign Daily Tasks',      desc: 'Pick a behavior plugin for your team type. Sales, Operations, Education, Fitness. Tasks are pre-configured and ready in minutes.', color: 'text-indigo-400',  bg: 'bg-indigo-500/8',  border: 'border-indigo-500/15',  glow: '#6366f1' },
  { step: '02', title: 'Users Execute & Log',     desc: 'Team members tap to log each action. No forms. No reports. One tap = one recorded behavior with a timestamp.', color: 'text-purple-400',  bg: 'bg-purple-500/8',  border: 'border-purple-500/15',  glow: '#a855f7' },
  { step: '03', title: 'Engine Tracks Patterns',  desc: 'Every action feeds the scoring engine. Patterns emerge automatically — slow starters, week faders, chronic underperformers.', color: 'text-cyan-400',   bg: 'bg-cyan-500/8',    border: 'border-cyan-500/15',    glow: '#06b6d4' },
  { step: '04', title: 'AI Coaches Each Person',  desc: 'Context-aware coaching per personality type. Not "do more." Real behavioral insight delivered at the moment it matters.', color: 'text-pink-400',   bg: 'bg-pink-500/8',    border: 'border-pink-500/15',    glow: '#ec4899' },
  { step: '05', title: 'Performance Compounds',   desc: 'Within 7 days teams report higher consistency, more pipeline activity, and measurable behavioral change that sticks.', color: 'text-emerald-400', bg: 'bg-emerald-500/8', border: 'border-emerald-500/15', glow: '#10b981' },
];

const RESULTS = [
  { metric: '+43%', label: 'Increase in daily task completion', color: 'text-indigo-400' },
  { metric: '7 days', label: 'Average time to visible behavior change', color: 'text-purple-400' },
  { metric: '3×', label: 'More follow-ups per rep per week', color: 'text-emerald-400' },
  { metric: '89%', label: 'Teams maintain GREEN status after 30 days', color: 'text-yellow-400' },
];

const TESTIMONIALS = [
  {
    name: 'Marcus T.',
    role: 'Sales Director, NovaSales',
    avatar: 'MT',
    text: 'After 2 weeks, our outreach volume doubled. The leaderboard made everyone want to stay green. It\'s become the thing the team talks about every morning.',
    gradient: 'from-indigo-500 to-purple-600',
    stars: 5,
  },
  {
    name: 'Priya R.',
    role: 'Head of Operations, LogiCore',
    avatar: 'PR',
    text: 'We could finally see who was actually executing and who was coasting. The admin dashboard changed how we run weekly reviews completely.',
    gradient: 'from-emerald-500 to-teal-600',
    stars: 5,
  },
  {
    name: 'James K.',
    role: 'Founder, Apex Academy',
    avatar: 'JK',
    text: 'My students\' consistency went up dramatically. The streak system is genuinely addictive. They don\'t want to break their chain — even on weekends.',
    gradient: 'from-amber-500 to-orange-600',
    stars: 5,
  },
];

const PLANS = [
  {
    name: 'Starter',
    price: 49,
    period: 'per team / mo',
    description: 'For small teams getting started with execution tracking.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    cta: 'Start Free Pilot',
    popular: false,
    features: ['Up to 10 users', 'Core behavior engine', 'Live leaderboard', 'Score dashboard', 'Email support'],
  },
  {
    name: 'Pro',
    price: 99,
    period: 'per team / mo',
    description: 'For growing teams that need AI coaching and full analytics.',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    cta: 'Start Free Pilot',
    popular: true,
    features: ['Up to 50 users', 'Everything in Starter', 'AI coach personalities', 'Admin analytics dashboard', 'Plugin marketplace', 'Priority support'],
  },
  {
    name: 'Enterprise',
    price: null,
    period: 'custom pricing',
    description: 'For large organizations with custom workflows.',
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    cta: 'Contact Sales',
    popular: false,
    features: ['Unlimited users', 'Custom plugins', 'White-label option', 'API integrations', 'Dedicated success manager', 'SLA + compliance'],
  },
];

const PLUGINS = [
  { icon: '💼', name: 'Sales Execution',       category: 'Sales',      color: 'text-indigo-400',  bg: 'bg-indigo-500/10',  tasks: 8 },
  { icon: '🏋️', name: 'Fitness & Performance', category: 'Health',     color: 'text-emerald-400', bg: 'bg-emerald-500/10', tasks: 8 },
  { icon: '🎓', name: 'Academic Execution',     category: 'Education',  color: 'text-amber-400',   bg: 'bg-amber-500/10',   tasks: 8 },
  { icon: '🚛', name: 'Logistics Ops',          category: 'Operations', color: 'text-orange-400',  bg: 'bg-orange-500/10',  tasks: 9 },
  { icon: '⚡', name: 'Developer Productivity', category: 'Tech',       color: 'text-cyan-400',    bg: 'bg-cyan-500/10',    tasks: 7 },
  { icon: '🔧', name: 'Custom Plugin',          category: 'Enterprise', color: 'text-purple-400',  bg: 'bg-purple-500/10',  tasks: null },
];

const HERO_USERS = [
  { name: 'Alex R.',   score: 82, status: 'GREEN',  color: 'text-green-400',  bg: 'bg-green-500/10',  border: 'border-green-500/20',  bar: 'bg-green-500',  rank: 1, streak: 7 },
  { name: 'Casey N.', score: 74, status: 'GREEN',  color: 'text-green-400',  bg: 'bg-green-500/10',  border: 'border-green-500/20',  bar: 'bg-green-500',  rank: 2, streak: 4 },
  { name: 'Sam O.',   score: 61, status: 'YELLOW', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', bar: 'bg-yellow-400', rank: 3, streak: 2 },
  { name: 'Jamie C.', score: 38, status: 'YELLOW', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', bar: 'bg-yellow-400', rank: 4, streak: 0 },
  { name: 'Morgan D.', score: 18, status: 'RED',   color: 'text-red-400',    bg: 'bg-red-500/10',    border: 'border-red-500/20',    bar: 'bg-red-500',    rank: 5, streak: 0 },
];

// ── Sub-components ────────────────────────────────────────────────────────────

function AnimatedCounter({ value, suffix = '' }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      let start = 0;
      const end = parseInt(value.replace(/\D/g, '')) || 0;
      if (end === 0) { setCount(value); return; }
      const duration = 1200;
      const step = Math.ceil(end / (duration / 16));
      const timer = setInterval(() => {
        start = Math.min(start + step, end);
        setCount(start);
        if (start >= end) clearInterval(timer);
      }, 16);
      observer.disconnect();
    }, { threshold: 0.5 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [value]);
  return <span ref={ref}>{typeof count === 'number' ? `${value.replace(/[\d]+/, count)}` : count}</span>;
}

function HeroMockup() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick(p => p + 1), 3000);
    return () => clearInterval(t);
  }, []);
  const flashIdx = tick % HERO_USERS.length;

  return (
    <div className="relative max-w-3xl mx-auto mt-16">
      {/* Glow beneath card */}
      <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-3/4 h-20 bg-indigo-500/15 rounded-full blur-2xl pointer-events-none" />

      <div className="rounded-2xl border border-white/10 bg-[#0b0f1a] overflow-hidden shadow-2xl shadow-black/50 relative">
        {/* Top gradient line */}
        <div className="h-0.5 bg-gradient-to-r from-transparent via-indigo-500 to-transparent" />

        {/* Mock browser bar */}
        <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/6">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-green-500/50" />
          <div className="flex-1 mx-4 h-5 rounded-md bg-white/4 flex items-center px-3 gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400/60" />
            <span className="text-white/15 text-[10px]">app.behaviorengine.io/dashboard</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
            <span className="text-indigo-400/60 text-[9px] font-semibold">LIVE</span>
          </div>
        </div>

        {/* Section header */}
        <div className="px-5 pt-4 pb-2 flex items-center justify-between">
          <p className="text-white/25 text-[10px] uppercase tracking-widest font-bold">Team Execution · Today</p>
          <div className="flex items-center gap-2">
            <span className="text-white/15 text-[9px]">Thu Apr 23 · 2:41 PM</span>
          </div>
        </div>

        {/* User cards */}
        <div className="p-4 grid grid-cols-5 gap-2.5">
          {HERO_USERS.map((u, i) => (
            <div
              key={u.name}
              className={`rounded-xl p-3 border ${u.border} ${u.bg} transition-all duration-500 ${flashIdx === i ? 'scale-[1.04] shadow-lg' : ''}`}
              style={{ boxShadow: flashIdx === i ? `0 0 20px ${u.bar.replace('bg-', '').replace('-500', '')}33` : 'none' }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/20 text-[8px] font-mono">#{u.rank}</span>
                <span className={`text-[7px] font-black ${u.color}`}>{u.status}</span>
              </div>
              <p className={`text-2xl font-black leading-none mb-1 ${u.color}`}>{u.score}</p>
              <p className="text-white/25 text-[8px] truncate">{u.name}</p>
              {/* Mini progress bar */}
              <div className="h-0.5 bg-white/8 rounded-full overflow-hidden mt-2">
                <div className={`h-full ${u.bar} rounded-full`} style={{ width: `${(u.score / 100) * 100}%` }} />
              </div>
              {u.streak > 0 && (
                <div className="flex items-center gap-0.5 mt-1">
                  <span className="text-orange-400 text-[7px]">🔥</span>
                  <span className="text-orange-400/60 text-[7px]">{u.streak}d</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* AI coaching toast preview */}
        <div className="mx-4 mb-4 p-3 rounded-xl bg-indigo-500/8 border border-indigo-500/20 flex items-start gap-3">
          <div className="w-7 h-7 rounded-lg bg-red-500/15 border border-red-500/20 flex items-center justify-center text-sm shrink-0">🔥</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <p className="text-red-400 text-[9px] font-bold uppercase tracking-wider">The Disciplinarian</p>
              <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">Unacceptable</span>
            </div>
            <p className="text-white/70 text-[10px] leading-snug">Below threshold. Others are pulling ahead while you hesitate.</p>
            <p className="text-red-400 text-[9px] font-semibold mt-1">→ 15 minutes. Maximum output. Go.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionLabel({ color, children }) {
  return (
    <p className={`text-xs font-bold uppercase tracking-[0.15em] mb-3 ${color}`}>
      {children}
    </p>
  );
}

function GlassCard({ className = '', children, glow = false }) {
  return (
    <div className={`rounded-2xl bg-white/2 border border-white/6 ${glow ? 'hover:border-indigo-500/25 hover:bg-white/3' : ''} transition-all ${className}`}>
      {children}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
const DEMO_ACCOUNTS = [
  { email: 'alex@sales.co',    label: 'Admin (Sales)',   role: 'admin',   color: 'indigo', icon: '💼' },
  { email: 'casey@sales.co',   label: 'Manager (Sales)', role: 'manager', color: 'amber',  icon: '📊' },
  { email: 'jamie@fitness.io', label: 'User (Fitness)',  role: 'user',    color: 'emerald',icon: '🏋️' },
];

export default function LandingPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [billingPeriod, setBillingPeriod] = useState('monthly');
  const [activeFaq, setActiveFaq] = useState(null);

  const demoLogin = (email) => {
    const ok = login(email, 'demo123');
    if (ok) navigate('/');
  };

  const faqs = [
    { q: 'How long does setup take?', a: 'Under 10 minutes. Pick a plugin, add your team, and they start logging immediately. No IT required. No configuration headaches.' },
    { q: 'What is the 7-day pilot?', a: 'We set up your entire team for free for 7 days. You see real execution data with your real people. If you see value, you stay. If not, you walk away with zero cost and zero pressure.' },
    { q: 'What industries does this work for?', a: 'We have pre-built plugins for Sales, Operations, Education, Fitness, Logistics, and Developer teams. Enterprise plans can build fully custom plugins for any workflow.' },
    { q: 'How is this different from a CRM?', a: 'Behavior Engine tracks execution behavior — not pipeline data. It complements your CRM by ensuring reps actually do the daily actions that feed your CRM. No actions = no CRM data.' },
    { q: 'How does the AI coaching work?', a: 'The AI analyzes each user\'s 7-day pattern — streak gaps, score trends, drop patterns (slow starters, week faders, chronic underperformers) — and delivers specific, actionable coaching matched to their personality type.' },
  ];

  return (
    <div className="min-h-screen bg-[#05080f] text-white overflow-x-hidden">

      {/* ── NAVIGATION ──────────────────────────────────────────────────────── */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/6 bg-[#05080f]/95 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-4 lg:px-6 flex items-center justify-between h-16">
          {/* Brand */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500 flex items-center justify-center shadow-lg shadow-indigo-500/40">
              <Zap size={15} className="text-white" />
            </div>
            <span className="text-white font-black text-base tracking-tight">Behavior Engine</span>
          </div>

          {/* Desktop links */}
          <div className="hidden lg:flex items-center gap-8">
            {NAV_LINKS.map(link => (
              <a key={link} href={`#${link.toLowerCase().replace(' ', '-')}`}
                className="text-white/40 hover:text-white/75 text-sm transition-colors">
                {link}
              </a>
            ))}
          </div>

          {/* Desktop CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            <button onClick={() => navigate('/login')} className="text-white/40 hover:text-white/75 text-sm transition-colors">
              Sign In
            </button>
            <button
              onClick={() => navigate('/start')}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-500 hover:bg-indigo-400 rounded-xl text-sm font-bold text-white transition-all shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40"
            >
              Start Free Pilot <ArrowRight size={13} />
            </button>
          </div>

          {/* Mobile menu toggle */}
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="lg:hidden text-white/40 hover:text-white/70 p-2">
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-white/6 bg-[#05080f] px-4 py-4 space-y-3">
            {NAV_LINKS.map(link => (
              <a key={link} href={`#${link.toLowerCase().replace(' ', '-')}`}
                onClick={() => setMobileMenuOpen(false)}
                className="block text-white/50 text-sm py-1.5">
                {link}
              </a>
            ))}
            <button onClick={() => navigate('/start')}
              className="w-full mt-2 py-3 bg-indigo-500 rounded-xl text-sm font-bold text-white">
              Start Free Pilot →
            </button>
          </div>
        )}
      </nav>

      {/* ── HERO ────────────────────────────────────────────────────────────── */}
      <section className="pt-32 pb-20 px-4 lg:px-6 relative overflow-hidden">
        {/* Ambient glow layers */}
        <div className="absolute top-16 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-indigo-500/8 rounded-full blur-[130px] pointer-events-none" />
        <div className="absolute top-40 left-[20%] w-[350px] h-[350px] bg-purple-500/6 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute top-60 right-[15%] w-[250px] h-[250px] bg-cyan-500/5 rounded-full blur-[80px] pointer-events-none" />

        <div className="max-w-4xl mx-auto text-center relative z-10">
          {/* Pill badge */}
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/25 mb-8">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
            <Sparkles size={11} className="text-indigo-300" />
            <span className="text-indigo-300 text-xs font-semibold">Now accepting pilot teams · 7 days free · No card needed</span>
          </div>

          {/* Headline */}
          <h1 className={`${TYPOGRAPHY.h1} mb-6`}>
            Turn Any Team Into a
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
              Daily Execution Machine
            </span>
          </h1>

          <p className="text-white/45 text-lg lg:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Track, measure, and improve real-world team performance through structured daily behavior systems and AI personality coaching.
            <br />
            <span className="text-white/65 font-semibold">Results in 7 days — or you don't pay.</span>
          </p>

          {/* CTA buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <button
              onClick={() => navigate('/start')}
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-8 py-4 bg-indigo-500 hover:bg-indigo-400 rounded-2xl text-base font-bold text-white transition-all shadow-2xl shadow-indigo-500/30 hover:shadow-indigo-500/50 hover:scale-[1.02]"
            >
              Start 7-Day Pilot <ArrowRight size={16} />
            </button>
            <button
              onClick={() => navigate('/login')}
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl border border-white/10 text-white/55 hover:text-white/80 hover:border-white/20 text-base transition-all"
            >
              <Play size={13} className="text-white/35" /> Watch 2-min Demo
            </button>
          </div>

          {/* Trust strip */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-white/25 text-xs mb-8">
            {['No credit card required', 'Setup in under 10 minutes', 'Cancel any time'].map(t => (
              <span key={t} className="flex items-center gap-1.5">
                <CheckCircle2 size={11} className="text-green-400" /> {t}
              </span>
            ))}
          </div>

          {/* Quick demo access */}
          <div className="inline-flex flex-col items-center gap-3 px-6 py-4 rounded-2xl border border-indigo-500/20 bg-indigo-500/5">
            <div className="flex items-center gap-1.5 text-white/30 text-[10px] font-semibold uppercase tracking-widest">
              <LogIn size={10} /> Quick Demo Access — One Click
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {DEMO_ACCOUNTS.map(({ email, label, color, icon }) => (
                <button key={email} onClick={() => demoLogin(email)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all
                    ${color === 'indigo'  ? 'border-indigo-500/30 bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20' :
                      color === 'amber'   ? 'border-amber-500/30  bg-amber-500/10  text-amber-300  hover:bg-amber-500/20'  :
                                           'border-emerald-500/30 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20'}`}>
                  <span>{icon}</span> {label}
                </button>
              ))}
            </div>
            <p className="text-white/15 text-[9px]">All passwords: demo123 · Try any role instantly</p>
          </div>
        </div>

        {/* Product mockup */}
        <HeroMockup />
      </section>

      {/* ── PROBLEM ─────────────────────────────────────────────────────────── */}
      <section id="features" className="py-24 px-4 lg:px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <SectionLabel color="text-red-400">The Real Problem</SectionLabel>
            <h2 className={`${TYPOGRAPHY.h2} mb-4`}>
              Teams don't fail because of skill.
              <br />
              <span className="text-white/35">They fail from inconsistent execution.</span>
            </h2>
            <p className="text-white/35 text-base max-w-lg mx-auto">The data is brutal. Here's what's costing teams every single week.</p>
          </div>
          <div className="grid lg:grid-cols-2 gap-4">
            {PROBLEMS.map(({ icon, stat, text, source }) => (
              <GlassCard key={stat} className="p-6" glow>
                <div className="flex items-start gap-4">
                  <span className="text-3xl shrink-0">{icon}</span>
                  <div>
                    <p className="text-red-400 font-black text-3xl leading-none mb-2">{stat}</p>
                    <p className="text-white/60 text-sm leading-snug mb-1">{text}</p>
                    <p className="text-white/15 text-[10px]">Source: {source}</p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* ── SOLUTION ────────────────────────────────────────────────────────── */}
      <section className="py-24 px-4 lg:px-6 bg-gradient-to-b from-transparent via-indigo-500/4 to-transparent">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <SectionLabel color="text-indigo-400">The Solution</SectionLabel>
            <h2 className={`${TYPOGRAPHY.h2} mb-4`}>Behavior Engine fixes this.</h2>
            <p className="text-white/40 text-lg max-w-xl mx-auto">
              One system that turns daily work into measurable, improvable behavior.
            </p>
          </div>
          <div className="grid lg:grid-cols-3 gap-4">
            {SOLUTIONS.map(({ icon: Icon, label, desc, color, bg, border }) => (
              <div key={label}
                className={`p-5 rounded-2xl ${bg} border ${border} hover:scale-[1.01] transition-all group cursor-default`}>
                <div className={`w-11 h-11 rounded-xl ${bg} border ${border} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon size={19} className={color} />
                </div>
                <p className={`font-bold text-sm ${color} mb-2`}>{label}</p>
                <p className="text-white/40 text-xs leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── AI PERSONALITY CALLOUT ──────────────────────────────────────────── */}
      <section className="py-16 px-4 lg:px-6">
        <div className="max-w-5xl mx-auto">
          <div className="rounded-3xl border border-indigo-500/20 bg-gradient-to-br from-indigo-500/8 via-purple-500/5 to-transparent p-8 lg:p-10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/8 rounded-full blur-[80px] pointer-events-none" />
            <div className="relative">
              <SectionLabel color="text-purple-400">Your Moat</SectionLabel>
              <h2 className="text-2xl lg:text-3xl font-black mb-3">
                Not generic AI. <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Personality-Driven Coaching.</span>
              </h2>
              <p className="text-white/45 text-base max-w-xl mb-8">
                Three coach archetypes adapt to each user's behavioral patterns. No two people get the same message.
              </p>
              <div className="grid lg:grid-cols-3 gap-4">
                {[
                  { emoji: '🔥', name: 'The Disciplinarian', tagline: 'No excuses. Execute or fall behind.', color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20', for: 'High-performers who need accountability.' },
                  { emoji: '🧠', name: 'The Strategist',     tagline: 'Analyze. Adjust. Execute precisely.', color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20', for: 'Thinkers who respond to data and logic.' },
                  { emoji: '⚡', name: 'The Motivator',      tagline: 'Every action builds the life you want.', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', for: 'Users who need emotional fuel and momentum.' },
                ].map(({ emoji, name, tagline, color, bg, border, for: forUser }) => (
                  <div key={name} className={`p-4 rounded-2xl ${bg} border ${border}`}>
                    <div className="text-2xl mb-2">{emoji}</div>
                    <p className={`font-bold text-sm ${color} mb-1`}>{name}</p>
                    <p className="text-white/50 text-xs italic mb-2">"{tagline}"</p>
                    <p className="text-white/25 text-[10px]">Best for: {forUser}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ────────────────────────────────────────────────────── */}
      <section id="how-it-works" className="py-24 px-4 lg:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <SectionLabel color="text-cyan-400">How It Works</SectionLabel>
            <h2 className={`${TYPOGRAPHY.h2}`}>From signup to behavior change in 7 days.</h2>
          </div>
          <div className="relative space-y-3">
            {/* Connecting line */}
            <div className="absolute left-[2.15rem] top-8 bottom-8 w-0.5 bg-gradient-to-b from-indigo-500/30 via-purple-500/20 to-transparent hidden lg:block" />
            {HOW_IT_WORKS.map(({ step, title, desc, color, bg, border }) => (
              <div key={step} className={`flex items-start gap-5 p-5 rounded-2xl ${bg} border ${border} transition-all hover:scale-[1.005] cursor-default`}>
                <div className={`w-9 h-9 rounded-xl ${bg} border ${border} flex items-center justify-center shrink-0 relative z-10`}>
                  <p className={`text-sm font-black font-mono ${color}`}>{step}</p>
                </div>
                <div className="pt-0.5">
                  <p className={`text-sm font-bold ${color} mb-1`}>{title}</p>
                  <p className="text-white/45 text-sm leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── RESULTS + TESTIMONIALS ──────────────────────────────────────────── */}
      <section id="results" className="py-24 px-4 lg:px-6 bg-gradient-to-b from-transparent via-emerald-500/3 to-transparent">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <SectionLabel color="text-emerald-400">Results</SectionLabel>
            <h2 className={`${TYPOGRAPHY.h2}`}>Teams change fast. Data proves it.</h2>
          </div>

          {/* Metric cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
            {RESULTS.map(({ metric, label, color }) => (
              <div key={label} className="text-center p-6 rounded-2xl bg-white/2 border border-white/6 hover:border-white/10 transition-all">
                <p className={`text-3xl lg:text-4xl font-black mb-2 ${color}`}>{metric}</p>
                <p className="text-white/30 text-xs leading-snug">{label}</p>
              </div>
            ))}
          </div>

          {/* Testimonials */}
          <div className="grid lg:grid-cols-3 gap-4">
            {TESTIMONIALS.map(({ name, role, avatar, text, gradient, stars }) => (
              <GlassCard key={name} className="p-5">
                <div className="flex mb-3 gap-0.5">
                  {[...Array(stars)].map((_, i) => (
                    <Star key={i} size={11} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-white/60 text-sm leading-relaxed mb-5">"{text}"</p>
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center text-[11px] font-bold text-white shrink-0`}>
                    {avatar}
                  </div>
                  <div>
                    <p className="text-white text-sm font-semibold">{name}</p>
                    <p className="text-white/25 text-xs">{role}</p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* ── PLUGIN PREVIEW ──────────────────────────────────────────────────── */}
      <section className="py-24 px-4 lg:px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <SectionLabel color="text-purple-400">Plugin Marketplace</SectionLabel>
            <h2 className={`${TYPOGRAPHY.h2} mb-4`}>Built for every industry.</h2>
            <p className="text-white/35 text-base max-w-xl mx-auto">
              Pre-built behavior systems for Sales, Education, Operations, and more. Enterprise teams build fully custom plugins.
            </p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
            {PLUGINS.map(({ icon, name, category, color, bg, tasks }) => (
              <div key={name}
                className={`p-4 rounded-2xl ${bg} border border-white/8 hover:border-white/15 transition-all group cursor-default`}>
                <div className="flex items-center gap-3 mb-2.5">
                  <span className="text-2xl">{icon}</span>
                  <div>
                    <p className="text-white font-semibold text-sm">{name}</p>
                    <p className={`text-[10px] font-bold ${color} uppercase tracking-wider`}>{category}</p>
                  </div>
                </div>
                {tasks ? (
                  <div className="flex items-center gap-2">
                    <div className={`h-0.5 flex-1 ${bg.replace('/10', '/30')} rounded-full`} />
                    <p className="text-white/25 text-[10px]">{tasks} daily tasks</p>
                  </div>
                ) : (
                  <p className={`text-[10px] font-semibold ${color}`}>Enterprise · Fully custom</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ─────────────────────────────────────────────────────────── */}
      <section id="pricing" className="py-24 px-4 lg:px-6 bg-gradient-to-b from-transparent via-indigo-500/4 to-transparent">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <SectionLabel color="text-indigo-400">Pricing</SectionLabel>
            <h2 className={`${TYPOGRAPHY.h2} mb-4`}>Simple, transparent pricing.</h2>
            <p className="text-white/35 text-base">Start with a free 7-day pilot. No credit card required.</p>

            <div className="inline-flex items-center gap-1 p-1 bg-white/5 rounded-xl mt-6 border border-white/6">
              {[['monthly', 'Monthly'], ['yearly', 'Yearly  −20%']].map(([k, l]) => (
                <button key={k} onClick={() => setBillingPeriod(k)}
                  className={`px-5 py-2 rounded-lg text-sm font-semibold transition-all ${billingPeriod === k ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' : 'text-white/35 hover:text-white/60'}`}>
                  {l}
                </button>
              ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-5">
            {PLANS.map((plan) => {
              const price = plan.price
                ? (billingPeriod === 'yearly' ? Math.round(plan.price * 0.8) : plan.price)
                : null;
              return (
                <div key={plan.name}
                  className={`relative rounded-2xl p-6 border transition-all ${
                    plan.popular
                      ? 'border-indigo-500/50 bg-indigo-500/6 shadow-xl shadow-indigo-500/10'
                      : 'border-white/8 bg-white/2 hover:border-white/12'
                  }`}>
                  {plan.popular && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-indigo-500 text-white text-[10px] font-black px-4 py-1 rounded-full shadow-lg shadow-indigo-500/30">
                      MOST POPULAR
                    </div>
                  )}
                  <div className="mb-6">
                    <p className="text-white font-bold text-xl mb-1">{plan.name}</p>
                    <p className="text-white/30 text-xs">{plan.description}</p>
                  </div>
                  <div className="mb-6">
                    {price ? (
                      <div className="flex items-end gap-1">
                        <span className={`text-4xl font-black ${plan.color}`}>${price}</span>
                        <span className="text-white/25 text-sm pb-1">/{plan.period}</span>
                      </div>
                    ) : (
                      <span className={`text-3xl font-black ${plan.color}`}>Custom</span>
                    )}
                  </div>
                  <div className="space-y-2.5 mb-8">
                    {plan.features.map(f => (
                      <div key={f} className="flex items-center gap-2.5">
                        <CheckCircle2 size={13} className="text-green-400 shrink-0" />
                        <span className="text-white/55 text-sm">{f}</span>
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => navigate('/start')}
                    className={`w-full py-3 rounded-xl text-sm font-bold transition-all ${
                      plan.popular
                        ? 'bg-indigo-500 hover:bg-indigo-400 text-white shadow-lg shadow-indigo-500/25'
                        : `${plan.bg} ${plan.color} border ${plan.border} hover:opacity-80`
                    }`}>
                    {plan.cta}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── FAQ ─────────────────────────────────────────────────────────────── */}
      <section className="py-24 px-4 lg:px-6">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <SectionLabel color="text-white/30">FAQ</SectionLabel>
            <h2 className="text-2xl lg:text-3xl font-black">Common questions.</h2>
          </div>
          <div className="space-y-2">
            {faqs.map(({ q, a }, i) => (
              <div key={q} className={`rounded-2xl border overflow-hidden transition-all ${activeFaq === i ? 'border-indigo-500/30 bg-indigo-500/4' : 'border-white/6 bg-white/1 hover:border-white/10'}`}>
                <button onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-5 py-4 text-left">
                  <p className="text-white/75 font-medium text-sm pr-4">{q}</p>
                  <ChevronDown size={14} className={`text-white/25 shrink-0 transition-transform duration-200 ${activeFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {activeFaq === i && (
                  <div className="px-5 pb-4 border-t border-white/5 pt-3">
                    <p className="text-white/45 text-sm leading-relaxed">{a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ───────────────────────────────────────────────────────── */}
      <section className="py-28 px-4 lg:px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-indigo-500/12 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[200px] bg-purple-500/10 rounded-full blur-[80px] pointer-events-none" />

        <div className="max-w-3xl mx-auto text-center relative">
          <SectionLabel color="text-indigo-400">Get Started Today</SectionLabel>
          <h2 className="text-3xl lg:text-5xl font-black mb-6 leading-tight">
            Start your 7-day
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
              execution pilot today.
            </span>
          </h2>
          <p className="text-white/40 text-lg mb-10 max-w-xl mx-auto leading-relaxed">
            No setup complexity. No long contracts.<br />
            Real behavioral change in days — or you walk away for free.
          </p>
          <button
            onClick={() => navigate('/start')}
            className="inline-flex items-center gap-3 px-10 py-5 bg-indigo-500 hover:bg-indigo-400 rounded-2xl text-lg font-bold text-white transition-all shadow-2xl shadow-indigo-500/35 hover:shadow-indigo-500/55 hover:scale-[1.03]"
          >
            Start Free 7-Day Pilot <ArrowRight size={18} />
          </button>
          <p className="text-white/20 text-xs mt-5">No credit card · Setup in 10 minutes · Cancel any time</p>

          {/* Trust logos / social proof */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
            {['Sales Teams', 'Agencies', 'Call Centers', 'Education', 'Operations', 'Fitness'].map(tag => (
              <span key={tag} className="text-white/15 text-xs px-3 py-1 rounded-full border border-white/6">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── FOOTER ──────────────────────────────────────────────────────────── */}
      <footer className="border-t border-white/6 py-10 px-4 lg:px-6">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-indigo-500 flex items-center justify-center">
              <Zap size={12} className="text-white" />
            </div>
            <span className="text-white font-black text-sm">Behavior Engine</span>
            <span className="text-white/15 text-xs hidden lg:inline">· The Execution OS for Teams</span>
          </div>
          <div className="flex items-center flex-wrap justify-center gap-6 text-white/20 text-xs">
            <span>© 2026 Behavior Engine</span>
            <button onClick={() => navigate('/start')} className="hover:text-white/50 transition-colors">Get Started</button>
            <button onClick={() => navigate('/login')} className="hover:text-white/50 transition-colors">Sign In</button>
            <a href="#pricing" className="hover:text-white/50 transition-colors">Pricing</a>
            <span className="text-white/10">Built with Behavior Engine</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
