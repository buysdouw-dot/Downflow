import { useState } from 'react';
import {
  CreditCard, CheckCircle2, XCircle, Zap, Shield, Copy, CheckCheck,
  ArrowRight, DollarSign, RefreshCw, Webhook, Code2, AlertTriangle,
  Star, Crown, Building2, ChevronRight,
} from 'lucide-react';

// ── Pricing tiers ─────────────────────────────────────────────────────────────
const TIERS = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    priceId: null,
    color: 'border-gray-700',
    badge: null,
    features: [
      '5 tasks/day',
      'Basic score tracking',
      'Email coach (weekly)',
      '1 user only',
    ],
    missing: ['AI coaching', 'Referrals', 'API access', 'Team features'],
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 29,
    priceId: 'price_pro_monthly',
    color: 'border-green-600',
    badge: 'Most Popular',
    features: [
      'Unlimited tasks',
      '100-pt execution score',
      'Daily AI coach (GPT-4o-mini)',
      'Viral share cards',
      'Referral program (+$10/referral)',
      'API access',
      'WhatsApp + email alerts',
    ],
    missing: ['Team analytics', 'Custom branding'],
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 199,
    priceId: 'price_enterprise_monthly',
    color: 'border-violet-600',
    badge: 'Teams',
    features: [
      'Everything in Pro',
      'Unlimited team seats',
      'Org-level analytics dashboard',
      'Custom AI coach persona',
      'White-label option',
      'Dedicated Slack support',
      'SSO + SCIM provisioning',
      'SLA 99.9% uptime',
    ],
    missing: [],
  },
];

// ── Code files ─────────────────────────────────────────────────────────────────
const CODE = {
  install: `# Install Stripe SDK
cd backend && npm install stripe

# Add to .env
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRO_PRICE_ID=price_...
STRIPE_ENT_PRICE_ID=price_...`,

  'services/stripe.js': `const Stripe = require('stripe');
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const PLANS = {
  pro:        process.env.STRIPE_PRO_PRICE_ID,
  enterprise: process.env.STRIPE_ENT_PRICE_ID,
};

/**
 * Create Stripe Checkout Session
 * Returns { url } — redirect user to url
 */
async function createCheckoutSession({ userId, email, plan, returnBase }) {
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    customer_email: email,
    payment_method_types: ['card'],
    line_items: [{ price: PLANS[plan], quantity: 1 }],
    metadata: { userId, plan },
    success_url: \`\${returnBase}/billing/success?session_id={CHECKOUT_SESSION_ID}\`,
    cancel_url:  \`\${returnBase}/billing/cancel\`,
    subscription_data: {
      trial_period_days: 7,
      metadata: { userId },
    },
  });
  return { url: session.url, sessionId: session.id };
}

/**
 * Create Customer Portal Session
 * Lets users manage/cancel their subscription
 */
async function createPortalSession({ stripeCustomerId, returnBase }) {
  const session = await stripe.billingPortal.sessions.create({
    customer:   stripeCustomerId,
    return_url: \`\${returnBase}/billing\`,
  });
  return { url: session.url };
}

/**
 * Retrieve subscription details
 */
async function getSubscription(subscriptionId) {
  return stripe.subscriptions.retrieve(subscriptionId);
}

module.exports = { createCheckoutSession, createPortalSession, getSubscription };`,

  'routes/billing.js': `const router   = require('express').Router();
const stripe   = require('stripe')(process.env.STRIPE_SECRET_KEY);
const express  = require('express');
const db       = require('../db/supabase');
const { requireAuth } = require('../middleware/auth');
const {
  createCheckoutSession,
  createPortalSession,
} = require('../services/stripe');

// POST /billing/checkout — start checkout
router.post('/checkout', requireAuth, async (req, res, next) => {
  try {
    const { plan } = req.body;
    if (!['pro', 'enterprise'].includes(plan))
      return res.status(400).json({ error: 'Invalid plan' });

    const { data: profile } = await db
      .from('profiles')
      .select('email, stripe_customer_id')
      .eq('id', req.user.sub)
      .single();

    const result = await createCheckoutSession({
      userId:     req.user.sub,
      email:      profile.email,
      plan,
      returnBase: process.env.FRONTEND_URL || 'http://localhost:5173',
    });
    res.json(result);
  } catch (err) { next(err); }
});

// POST /billing/portal — customer portal
router.post('/portal', requireAuth, async (req, res, next) => {
  try {
    const { data: profile } = await db
      .from('profiles')
      .select('stripe_customer_id')
      .eq('id', req.user.sub)
      .single();

    if (!profile.stripe_customer_id)
      return res.status(400).json({ error: 'No billing account found' });

    const result = await createPortalSession({
      stripeCustomerId: profile.stripe_customer_id,
      returnBase: process.env.FRONTEND_URL || 'http://localhost:5173',
    });
    res.json(result);
  } catch (err) { next(err); }
});

// GET /billing/status — current plan
router.get('/status', requireAuth, async (req, res, next) => {
  try {
    const { data } = await db
      .from('profiles')
      .select('plan, stripe_customer_id, subscription_status, trial_ends_at')
      .eq('id', req.user.sub)
      .single();
    res.json(data);
  } catch (err) { next(err); }
});

// POST /billing/webhook — Stripe events (raw body!)
router.post(
  '/webhook',
  express.raw({ type: 'application/json' }),
  async (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;
    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );
    } catch (err) {
      console.error('[Stripe Webhook] signature error:', err.message);
      return res.status(400).send('Webhook Error');
    }

    switch (event.type) {
      case 'checkout.session.completed': {
        const s = event.data.object;
        await db.from('profiles').update({
          plan:                 s.metadata.plan,
          stripe_customer_id:   s.customer,
          subscription_status:  'active',
        }).eq('id', s.metadata.userId);
        break;
      }
      case 'customer.subscription.deleted': {
        const sub = event.data.object;
        await db.from('profiles').update({
          plan:                'free',
          subscription_status: 'cancelled',
        }).eq('stripe_customer_id', sub.customer);
        break;
      }
      case 'invoice.payment_failed': {
        const inv = event.data.object;
        await db.from('profiles').update({
          subscription_status: 'past_due',
        }).eq('stripe_customer_id', inv.customer);
        break;
      }
      case 'customer.subscription.trial_will_end': {
        // send reminder email here
        console.log('[Billing] Trial ending soon:', event.data.object.customer);
        break;
      }
    }
    res.sendStatus(200);
  }
);

module.exports = router;`,

  'supabase/billing-migration.sql': `-- Add billing columns to profiles
alter table public.profiles
  add column if not exists plan                text not null default 'free',
  add column if not exists stripe_customer_id  text unique,
  add column if not exists subscription_status text not null default 'inactive',
  add column if not exists trial_ends_at       timestamptz;

-- Plan gate helper (use in RLS or API)
-- Returns true if user has feature access
create or replace function public.has_plan(user_id uuid, required text)
returns boolean language sql stable security definer as $$
  select exists (
    select 1 from public.profiles
    where id = user_id
      and plan in (
        case required
          when 'pro'        then array['pro','enterprise']
          when 'enterprise' then array['enterprise']
          else              array['free','pro','enterprise']
        end
      )
      and subscription_status in ('active', 'trialing')
  );
$$;

-- Webhook event log (idempotency)
create table if not exists public.stripe_events (
  id         text primary key,       -- stripe event id
  type       text not null,
  processed_at timestamptz default now()
);`,
};

const CODE_KEYS = Object.keys(CODE);

// ── Webhook events ─────────────────────────────────────────────────────────────
const WEBHOOK_EVENTS = [
  { event: 'checkout.session.completed',          action: 'Set plan = pro/enterprise, store customer_id',  status: 'critical' },
  { event: 'customer.subscription.deleted',       action: 'Downgrade to free, revoke access',              status: 'critical' },
  { event: 'invoice.payment_failed',              action: 'Mark past_due, send retry email',               status: 'critical' },
  { event: 'customer.subscription.trial_will_end',action: 'Send upgrade reminder 3 days before',           status: 'info'     },
  { event: 'invoice.paid',                        action: 'Renew subscription, log payment',               status: 'info'     },
  { event: 'customer.subscription.updated',       action: 'Sync plan changes (upgrades/downgrades)',       status: 'info'     },
];

export default function StripeBilling() {
  const [tab,     setTab]     = useState('pricing');  // pricing | code | webhooks | setup
  const [codeKey, setCodeKey] = useState('install');
  const [copied,  setCopied]  = useState('');

  function copy(key) {
    navigator.clipboard.writeText(CODE[key] || '');
    setCopied(key);
    setTimeout(() => setCopied(''), 1800);
  }

  const TABS = [
    { id: 'pricing',  label: 'Pricing Tiers'   },
    { id: 'code',     label: 'Backend Code'     },
    { id: 'webhooks', label: 'Webhook Events'   },
    { id: 'setup',    label: 'Setup Checklist'  },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white p-4 md:p-6">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="mb-6 flex items-start gap-4">
          <div className="p-2.5 bg-green-900/40 rounded-xl border border-green-700/50">
            <CreditCard size={24} className="text-green-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black">Stripe Billing System</h1>
            <p className="text-gray-400 text-sm mt-0.5">
              Full subscriptions — checkout, webhooks, portal, plan gating, trial
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-gray-900 p-1 rounded-xl w-fit border border-gray-800">
          {TABS.map(({ id, label }) => (
            <button key={id} onClick={() => setTab(id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition
                ${tab === id ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* ── PRICING ── */}
        {tab === 'pricing' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {TIERS.map(({ id, name, price, color, badge, features, missing }) => (
              <div key={id}
                className={`relative bg-gray-900 rounded-2xl border-2 ${color} p-6 flex flex-col`}>
                {badge && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5
                                   bg-green-600 text-white text-xs font-bold rounded-full">
                    {badge}
                  </span>
                )}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-1">
                    {id === 'free' && <Zap size={16} className="text-gray-400" />}
                    {id === 'pro' && <Star size={16} className="text-green-400" />}
                    {id === 'enterprise' && <Crown size={16} className="text-violet-400" />}
                    <span className="font-bold text-lg">{name}</span>
                  </div>
                  <p className="text-4xl font-black mt-2">
                    ${price}
                    <span className="text-base font-normal text-gray-400">/mo</span>
                  </p>
                  {id === 'pro' && (
                    <p className="text-xs text-green-400 mt-1">7-day free trial</p>
                  )}
                </div>
                <ul className="space-y-2 flex-1 mb-5">
                  {features.map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <CheckCircle2 size={14} className="text-green-400 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-200">{f}</span>
                    </li>
                  ))}
                  {missing.map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm opacity-40">
                      <XCircle size={14} className="text-gray-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-400">{f}</span>
                    </li>
                  ))}
                </ul>
                <div className={`py-2.5 rounded-xl text-center text-sm font-semibold
                  ${id === 'free' ? 'bg-gray-800 text-gray-300' :
                    id === 'pro' ? 'bg-green-600 text-white' :
                    'bg-violet-600 text-white'}`}>
                  {id === 'free' ? 'Current Plan' :
                   id === 'pro' ? 'Start Free Trial' : 'Contact Sales'}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── CODE ── */}
        {tab === 'code' && (
          <div className="flex gap-4 h-[70vh]">
            <div className="w-52 flex-shrink-0 bg-gray-900 rounded-xl border border-gray-800 overflow-y-auto">
              <p className="px-3 py-2 text-xs text-gray-500 uppercase tracking-wider border-b border-gray-800">
                Files
              </p>
              {CODE_KEYS.map(k => (
                <button key={k} onClick={() => setCodeKey(k)}
                  className={`w-full text-left px-3 py-2 text-xs font-mono transition
                    ${codeKey === k
                      ? 'bg-green-900/40 text-green-300 border-r-2 border-green-500'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}>
                  {k}
                </button>
              ))}
            </div>
            <div className="flex-1 bg-gray-900 rounded-xl border border-gray-800 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
                <span className="text-sm font-mono text-gray-300">{codeKey}</span>
                <button onClick={() => copy(codeKey)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-800
                             hover:bg-gray-700 text-xs transition">
                  {copied === codeKey ? <CheckCheck size={12} className="text-green-400"/> : <Copy size={12}/>}
                  {copied === codeKey ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="flex-1 overflow-auto p-4 text-xs text-gray-300 font-mono leading-relaxed">
                {CODE[codeKey]}
              </pre>
            </div>
          </div>
        )}

        {/* ── WEBHOOKS ── */}
        {tab === 'webhooks' && (
          <div className="space-y-4 max-w-3xl">
            <div className="bg-amber-900/20 border border-amber-700/40 rounded-xl p-4 flex gap-3">
              <AlertTriangle size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-amber-200">
                Webhooks must be registered in the{' '}
                <span className="font-mono">Stripe Dashboard → Developers → Webhooks</span>.
                Use{' '}
                <span className="font-mono">stripe listen --forward-to localhost:3000/billing/webhook</span>
                {' '}during local dev.
              </p>
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-800 flex items-center gap-2">
                <Webhook size={14} className="text-green-400" />
                <span className="text-sm font-semibold">Events to handle</span>
              </div>
              <div className="divide-y divide-gray-800">
                {WEBHOOK_EVENTS.map(({ event, action, status }) => (
                  <div key={event} className="flex items-start gap-4 px-4 py-3">
                    <div className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0
                      ${status === 'critical' ? 'bg-red-500' : 'bg-blue-400'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono text-green-300">{event}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{action}</p>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0
                      ${status === 'critical'
                        ? 'bg-red-900/50 text-red-300'
                        : 'bg-blue-900/50 text-blue-300'}`}>
                      {status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                {
                  title: 'Local Dev',
                  icon: Code2,
                  lines: [
                    'npm install -g stripe',
                    'stripe login',
                    'stripe listen \\',
                    '  --forward-to localhost:3000/billing/webhook',
                    '# Prints STRIPE_WEBHOOK_SECRET — copy to .env',
                  ],
                },
                {
                  title: 'Production',
                  icon: Shield,
                  lines: [
                    '1. Stripe Dashboard → Developers → Webhooks',
                    '2. Add endpoint: https://your-railway.app/billing/webhook',
                    '3. Select events (list above)',
                    '4. Copy signing secret → Railway env var',
                    '   STRIPE_WEBHOOK_SECRET=whsec_...',
                  ],
                },
              ].map(({ title, icon: Icon, lines }) => (
                <div key={title} className="bg-gray-900 rounded-xl border border-gray-800 p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Icon size={14} className="text-gray-400" />
                    <span className="text-sm font-semibold">{title}</span>
                  </div>
                  <pre className="bg-gray-950 rounded-lg p-3 text-xs text-gray-300 font-mono leading-relaxed overflow-x-auto">
                    {lines.join('\n')}
                  </pre>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── SETUP ── */}
        {tab === 'setup' && (
          <div className="space-y-4 max-w-2xl">
            {[
              {
                phase: 'Stripe Account',
                icon: CreditCard,
                color: 'text-green-400',
                steps: [
                  'Create account at stripe.com',
                  'Enable test mode for development',
                  'Create 2 products: Behavior Engine Pro ($29/mo) + Enterprise ($199/mo)',
                  'Copy Price IDs for each product',
                  'Activate Customer Portal in Stripe settings',
                ],
              },
              {
                phase: 'Environment Variables',
                icon: Shield,
                color: 'text-amber-400',
                steps: [
                  'STRIPE_SECRET_KEY=sk_test_... (from Stripe API keys)',
                  'STRIPE_WEBHOOK_SECRET=whsec_... (from stripe listen)',
                  'STRIPE_PRO_PRICE_ID=price_... (from Products dashboard)',
                  'STRIPE_ENT_PRICE_ID=price_... (from Products dashboard)',
                  'FRONTEND_URL=http://localhost:5173 (for redirect URLs)',
                ],
              },
              {
                phase: 'Supabase Migration',
                icon: DollarSign,
                color: 'text-blue-400',
                steps: [
                  'Run supabase/billing-migration.sql in SQL editor',
                  'This adds plan + stripe_customer_id + subscription_status to profiles',
                  'Creates has_plan() helper for feature gating',
                  'Creates stripe_events table for idempotency',
                ],
              },
              {
                phase: 'Backend Wiring',
                icon: RefreshCw,
                color: 'text-violet-400',
                steps: [
                  'npm install stripe (in backend folder)',
                  'Add services/stripe.js',
                  'Add routes/billing.js',
                  'Register in app.js: app.use("/billing", billingRoutes)',
                  'IMPORTANT: webhook route needs raw body — register before json middleware',
                ],
              },
            ].map(({ phase, icon: Icon, color, steps }) => (
              <div key={phase} className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
                <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-800">
                  <Icon size={16} className={color} />
                  <span className="font-semibold">{phase}</span>
                </div>
                <ul className="p-4 space-y-2">
                  {steps.map((s, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm">
                      <span className="w-5 h-5 rounded-full bg-gray-800 text-gray-400 text-xs
                                       flex items-center justify-center flex-shrink-0 font-bold mt-0.5">
                        {i + 1}
                      </span>
                      <span className={s.startsWith('STRIPE_') || s.startsWith('FRONTEND_')
                        ? 'font-mono text-amber-300 text-xs' : 'text-gray-300'}>
                        {s}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
