/**
 * AIChatCoach — Conversational AI Coach Interface
 * Personality-aware chat with behavioral memory, message history, and smart prompts.
 */
import { useState, useEffect, useRef } from 'react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus } from '../engine/core';
import { getPersonality } from '../engine/personality';
import {
  Send, Brain, Zap, RefreshCw, Star, Target,
  ChevronRight, MessageCircle, Sparkles, Clock,
  TrendingUp, AlertTriangle, CheckCircle2,
} from 'lucide-react';

// ── Response engine ───────────────────────────────────────────────────────────
const COACH_RESPONSES = {
  discipline: {
    greeting: (name, score, status) => [
      `${status === 'green' ? '\u2705' : status === 'yellow' ? '\u26a0\ufe0f' : '\uD83D\uDEA8'} ${name}. Score: ${score}. ${status === 'green' ? 'You\'re executing.' : status === 'yellow' ? 'You\'re coasting. Pick it up.' : 'You\'re off track. No excuses.'}`,
      `Here\'s what matters today: consistency. You\'ve built habits before. Apply them now.`,
    ],
    low_score: ['Your score reflects your effort. Simple. Raise both.', 'Three actions. Right now. That\'s all this requires.', 'Stop reviewing. Start executing.'],
    high_score: ['Strong. Now don\'t let up tomorrow.', 'Consistency over time. That\'s the whole game.', 'Results like this come from discipline, not motivation.'],
    streak: (n) => [`${n}-day streak. You\'ve built momentum. Protect it.`, 'Every streak ends unless you\'re intentional today.'],
    stuck: ['Identify the specific block. Then remove it. What\'s the real issue?', 'If you\'re stuck, it\'s usually clarity, not capability.'],
    motivation: ['Motivation is unreliable. Systems are not. Build the system.', 'You don\'t need to want to do it. You need to do it.'],
    goal: ['Define it with a number and a date. Anything else is a wish.', 'Break it into daily actions. Then just do the first one.'],
    help: ['What specifically do you need? Be precise.'],
    default: ['Execute the next task on your list. Everything else is noise.', 'What\'s the one thing you must complete today?'],
  },
  strategy: {
    greeting: (name, score, status) => [
      `Good to see you, ${name}. Current score: ${score} — ${status === 'green' ? 'you\'re in a strong position.' : status === 'yellow' ? 'there\'s room to optimize.' : 'let\'s rebuild momentum strategically.'}`,
      'Let\'s think about your execution system today. What\'s working, and what isn\'t?',
    ],
    low_score: ['Low scores often have a root cause. Let\'s find it. What changed recently?', 'Think in systems: what\'s the bottleneck in your current approach?'],
    high_score: ['Great output. Now document what\'s working so you can replicate it.', 'Consider raising the bar. If 70 is easy, aim for 80.'],
    streak: (n) => [`${n}-day streak suggests your system is working. Let\'s make sure it scales.`],
    stuck: ['Let\'s map the constraint. Is it time, energy, clarity, or resources?', 'Sometimes being stuck means the current approach is wrong, not you.'],
    motivation: ['Motivation is a byproduct of momentum. Start smaller, build faster.', 'Design your environment to make the right action the default action.'],
    goal: ['Reverse-engineer it. What does Day 30 look like if you hit it? Now work backwards.'],
    help: ['Let\'s break it down. What\'s the real problem underneath the surface?'],
    default: ['Think about leverage: which single action creates the most downstream impact today?', 'Strategy is choosing what NOT to do. What can you eliminate today?'],
  },
  motivation: {
    greeting: (name, score, status) => [
      `Hey ${name}! \uD83D\uDD25 Score: ${score} — ${status === 'green' ? 'you\'re on fire! Keep that energy!' : status === 'yellow' ? 'you\'ve got more in you — let\'s unlock it!' : 'every legend has down days. Today we reset!'}`,
      'I believe in your potential. Let\'s make today count. What\'s one win you can create right now?',
    ],
    low_score: ['This isn\'t your story — it\'s just a chapter. Rewrite it today.', 'Every high performer has low days. What makes them different is they don\'t stay there.'],
    high_score: ['YES! This is who you are. Carry this energy into tomorrow!', 'You just proved what\'s possible. Screenshot this feeling.'],
    streak: (n) => [`${n} days straight! You\'re building something real. That consistency is your superpower!`],
    stuck: ['Being stuck just means you care enough to notice. That\'s already half the battle!', 'Let\'s zoom out. What\'s the WHY behind this goal? Reconnect with that.'],
    motivation: ['You already have it — you just need to access it. What got you started? Remember that.', 'Energy follows intention. Set a clear intention for the next 60 minutes.'],
    goal: ['Dream it, then plan it, then execute it. Start with the dream — tell me your biggest goal!', 'Your goal is the destination. Let\'s build the GPS together.'],
    help: ['You\'ve got this and I\'ve got you. What do you need?'],
    default: ['What would make today a 10/10? Start there.', 'One action. Full focus. Five minutes. Go.'],
  },
};

const QUICK_PROMPTS = [
  { label: 'How do I improve my score?',        key: 'low_score'  },
  { label: 'I need motivation right now',        key: 'motivation' },
  { label: 'Help me set a goal',                 key: 'goal'       },
  { label: "I'm stuck — what should I do?",     key: 'stuck'      },
  { label: 'Review my streak progress',          key: 'streak'     },
];

const TOPIC_KEYWORDS = {
  low_score:  ['score', 'improve', 'better', 'increase', 'low', 'points'],
  high_score: ['great', 'good', 'excellent', 'well', 'proud', 'high'],
  streak:     ['streak', 'consecutive', 'days', 'row', 'record'],
  stuck:      ['stuck', 'blocked', 'can\'t', 'help', 'frustrated', 'hard', 'difficult'],
  motivation: ['motivation', 'motivated', 'inspire', 'energy', 'tired', 'burnout'],
  goal:       ['goal', 'target', 'objective', 'aim', 'achieve', 'want'],
};

function detectTopic(text) {
  const lower = text.toLowerCase();
  for (const [topic, keywords] of Object.entries(TOPIC_KEYWORDS)) {
    if (keywords.some(k => lower.includes(k))) return topic;
  }
  return 'default';
}

function getCoachReply(personalityId, topic, meta) {
  const coach = COACH_RESPONSES[personalityId] ?? COACH_RESPONSES.discipline;
  const responses = typeof coach[topic] === 'function' ? coach[topic](meta.streak ?? 0) : coach[topic] ?? coach.default;
  const arr = Array.isArray(responses) ? responses : [responses];
  return arr[Math.floor(Math.random() * arr.length)];
}

// ── Components ────────────────────────────────────────────────────────────────
function Message({ msg }) {
  const isUser = msg.role === 'user';
  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-sm shrink-0 mt-0.5">
          {msg.personality?.emoji ?? '🤖'}
        </div>
      )}
      <div className={`max-w-[78%] space-y-1 ${isUser ? 'items-end' : 'items-start'} flex flex-col`}>
        <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
          isUser
            ? 'bg-indigo-500 text-white rounded-br-sm'
            : 'bg-white/6 border border-white/8 text-white/80 rounded-bl-sm'
        }`}>
          {msg.text}
        </div>
        <p className="text-white/20 text-[9px] px-1">{msg.time}</p>
      </div>
    </div>
  );
}

function TypingIndicator({ personality }) {
  return (
    <div className="flex gap-3">
      <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-sm shrink-0">
        {personality?.emoji ?? '🤖'}
      </div>
      <div className="px-4 py-3 rounded-2xl bg-white/6 border border-white/8 flex items-center gap-1.5">
        {[0, 0.2, 0.4].map((d, i) => (
          <div key={i} className="w-1.5 h-1.5 rounded-full bg-white/30 animate-bounce" style={{ animationDelay: `${d}s` }} />
        ))}
      </div>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AIChatCoach() {
  const { getTodayScore, getWeekScores, activeUserId, personalityId } = useBehavior();
  const { user } = useAuth();

  const score      = getTodayScore(activeUserId);
  const weekScores = getWeekScores ? getWeekScores(activeUserId) : [];
  const status     = getStatus(score);
  const streak     = weekScores.filter(s => s > 20).length;
  const personality = getPersonality(personalityId);

  const [messages,  setMessages] = useState([]);
  const [input,     setInput]    = useState('');
  const [typing,    setTyping]   = useState(false);
  const [sessionN,  setSessionN] = useState(0);
  const bottomRef = useRef(null);
  const inputRef  = useRef(null);

  // Init greeting on mount
  useEffect(() => {
    const greetLines = COACH_RESPONSES[personality.id]?.greeting(
      user?.name?.split(' ')[0] ?? 'there', score, status
    ) ?? ['Hey! Ready to execute today?'];

    const initMsgs = greetLines.map((text, i) => ({
      id: i,
      role: 'coach',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      personality,
    }));
    setMessages(initMsgs);
    setSessionN(1);
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typing]);

  const sendMessage = (text) => {
    if (!text.trim()) return;
    const userMsg = {
      id: Date.now(),
      role: 'user',
      text: text.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setTyping(true);

    const topic = detectTopic(text);
    const delay = 800 + Math.random() * 800;

    setTimeout(() => {
      const reply = getCoachReply(personality.id, topic, { score, status, streak, name: user?.name?.split(' ')[0] });
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        role: 'coach',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        personality,
      }]);
      setTyping(false);
      setSessionN(n => n + 1);
    }, delay);
  };

  const handleQuickPrompt = (prompt) => {
    sendMessage(prompt.label);
    inputRef.current?.focus();
  };

  const clearChat = () => {
    const restart = (COACH_RESPONSES[personality.id]?.greeting(
      user?.name?.split(' ')[0] ?? 'there', score, status
    ) ?? ['Ready to go again.']).map((text, i) => ({
      id: Date.now() + i, role: 'coach', text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      personality,
    }));
    setMessages(restart);
    setSessionN(1);
  };

  const pColor = personality.id === 'discipline' ? 'text-red-400'
    : personality.id === 'strategy'   ? 'text-indigo-400'
    : 'text-emerald-400';
  const pBorder = personality.id === 'discipline' ? 'border-red-500/20'
    : personality.id === 'strategy'   ? 'border-indigo-500/20'
    : 'border-emerald-500/20';
  const pBg = personality.id === 'discipline' ? 'bg-red-500/8'
    : personality.id === 'strategy'   ? 'bg-indigo-500/8'
    : 'bg-emerald-500/8';

  return (
    <div className="min-h-screen bg-[#070b14] text-white flex flex-col" style={{ height: '100vh' }}>

      {/* Header */}
      <div className="shrink-0 px-4 lg:px-8 pt-6 pb-4 border-b border-white/6">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-2xl ${pBg} border ${pBorder} flex items-center justify-center text-xl`}>
              {personality.emoji}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-white font-bold text-base">{personality.name}</p>
                <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-400 text-[8px] font-bold">LIVE</span>
                </div>
              </div>
              <p className={`text-xs ${pColor}`}>{personality.tagline}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {/* Context pills */}
            <div className="hidden lg:flex items-center gap-2">
              <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-bold ${
                status === 'green' ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                : status === 'yellow' ? 'bg-yellow-500/10 border border-yellow-500/20 text-yellow-400'
                : 'bg-red-500/10 border border-red-500/20 text-red-400'
              }`}>
                <Target size={8} /> {score} pts
              </div>
              {streak > 0 && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-[9px] font-bold text-orange-400">
                  🔥 {streak}-day streak
                </div>
              )}
            </div>
            <button onClick={clearChat}
              className="p-2 rounded-xl bg-white/4 border border-white/8 text-white/30 hover:text-white/60 hover:bg-white/8 transition-all"
              title="New conversation">
              <RefreshCw size={13} />
            </button>
          </div>
        </div>
      </div>

      {/* Quick prompts */}
      <div className="shrink-0 px-4 lg:px-8 py-3 border-b border-white/4">
        <div className="max-w-3xl mx-auto flex gap-2 overflow-x-auto scrollbar-hide">
          {QUICK_PROMPTS.map((p) => (
            <button key={p.key} onClick={() => handleQuickPrompt(p)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/4 border border-white/8 text-white/40 hover:text-white/70 hover:bg-white/8 text-xs font-medium whitespace-nowrap transition-all shrink-0">
              <Sparkles size={9} /> {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 lg:px-8 py-5 scrollbar-hide">
        <div className="max-w-3xl mx-auto space-y-4">
          {messages.map(msg => <Message key={msg.id} msg={msg} />)}
          {typing && <TypingIndicator personality={personality} />}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* Input */}
      <div className="shrink-0 px-4 lg:px-8 pb-6 pt-3 border-t border-white/6">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/4 border border-white/10 focus-within:border-indigo-500/40 transition-all">
            <input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(input); } }}
              placeholder={`Message ${personality.name}…`}
              className="flex-1 bg-transparent text-white text-sm placeholder:text-white/20 focus:outline-none"
            />
            <button
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || typing}
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                input.trim() && !typing
                  ? 'bg-indigo-500 hover:bg-indigo-400 text-white shadow-lg shadow-indigo-500/25'
                  : 'bg-white/6 text-white/20 cursor-default'
              }`}>
              <Send size={13} />
            </button>
          </div>
          <div className="flex items-center justify-between mt-2 px-1">
            <p className="text-white/15 text-[9px]">Powered by Behavior Engine AI · {sessionN} messages</p>
            <p className="text-white/15 text-[9px]">Press Enter to send</p>
          </div>
        </div>
      </div>

    </div>
  );
}
