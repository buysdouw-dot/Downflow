/**
 * PitchDemo — Hosted Clickable Investor Demo System
 * Login → Dashboard → Team Performance → Leaderboard → AI Insights
 * Simulates a real live product. No backend needed.
 * This is your pitch weapon.
 */
import { useState } from 'react';
import {
  Zap, BarChart2, Users, Trophy, Brain, TrendingUp,
  CheckCircle2, Circle, ArrowRight, Play,
  Lock, Eye, EyeOff, AlertTriangle,
} from 'lucide-react';

// ── Demo constants ────────────────────────────────────────────────────────────
const DEMO_COMPANY  = 'Apex Sales Co.';
const DEMO_EMAIL    = 'demo@apexsales.com';
const DEMO_PASS     = 'demo1234';

// ── Team data ─────────────────────────────────────────────────────────────────
const TEAM = [
  { id: 1, name: 'Sarah M.',  role: 'Senior AE',  av: 'SM', scores: [38,34,40,35,39,37,41], trend: 'up',   color: '#34d399' },
  { id: 2, name: 'Daniel K.', role: 'AE',         av: 'DK', scores: [28,30,26,31,29,33,32], trend: 'up',   color: '#818cf8' },
  { id: 3, name: 'James R.',  role: 'BDR',        av: 'JR', scores: [22,19,16,14,18,15,12], trend: 'down', color: '#f87171' },
  { id: 4, name: 'Priya L.',  role: 'AE',         av: 'PL', scores: [35,36,35,38,34,37,39], trend: 'up',   color: '#22d3ee' },
  { id: 5, name: 'Tom B.',    role: 'Senior BDR', av: 'TB', scores: [31,29,33,30,31,28,34], trend: 'flat', color: '#fbbf24' },
  { id: 6, name: 'Anika W.',  role: 'AE',         av: 'AW', scores: [18,20,17,15,19,21,16], trend: 'flat', color: '#a78bfa' },
];

const INSIGHTS = [
  { id: 'i1', type: 'CRITICAL',    color: '#f87171', bg: 'rgba(248,113,113,0.07)',
    title: 'James R. is at risk — 5 consecutive declining sessions',
    body: 'Dropped from 22 \u2192 12 pts over 7 days. Pre-churn pattern. Recommend immediate 1:1.',
    cta: 'Send intervention' },
  { id: 'i2', type: 'INSIGHT',     color: '#22d3ee', bg: 'rgba(6,182,212,0.05)',
    title: 'Teams completing tasks before 10am score 31% higher',
    body: 'Sarah M. and Priya L. log first tasks at 7:30\u20138am. Revenue correlation: 0.89.',
    cta: 'Set morning reminder' },
  { id: 'i3', type: 'OPPORTUNITY', color: '#34d399', bg: 'rgba(16,185,129,0.05)',
    title: 'Sarah M. ready for stretch goal \u2014 6-week streak',
    body: 'Highest average. +15% target increase pushes her into top 10% nationally.',
    cta: 'Assign stretch goal' },
  { id: 'i4', type: 'SYSTEM',      color: '#818cf8', bg: 'rgba(99,102,241,0.05)',
    title: 'Team execution rate: 72% \u2014 up from 42% at onboarding',
    body: '+30 percentage points in 6 weeks. Industry benchmark: 44%.',
    cta: 'Generate case study' },
];

const EXEC_WEEKS = [42, 44, 48, 52, 55, 61, 67, 72];

// ── Helpers ───────────────────────────────────────────────────────────────────
function ScoreBar({ v, max = 45, color }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-white/6 rounded-full overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${(v/max)*100}%`, background: color }} />
      </div>
      <span className="text-[9px] font-bold w-5 text-right" style={{ color }}>{v}</span>
    </div>
  );
}

function TrendIcon({ dir }) {
  if (dir === 'up')   return <TrendingUp size={10} className="text-emerald-400" />;
  if (dir === 'down') return <TrendingUp size={10} className="text-red-400 scale-y-[-1]" />;
  return <span className="text-white/20 text-[9px]">—</span>;
}

// ── App screens ───────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail]     = useState(DEMO_EMAIL);
  const [pw,    setPw]        = useState(DEMO_PASS);
  const [show,  setShow]      = useState(false);
  const [err,   setErr]       = useState('');
  const [busy,  setBusy]      = useState(false);

  const submit = e => {
    e.preventDefault();
    setBusy(true);
    setTimeout(() => {
      if (email === DEMO_EMAIL && pw === DEMO_PASS) onLogin();
      else setErr('Try demo@apexsales.com / demo1234');
      setBusy(false);
    }, 700);
  };

  return (
    <div className="flex items-center justify-center px-6" style={{ minHeight: 520 }}>
      <div className="w-full max-w-xs space-y-5">
        <div className="text-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center mx-auto mb-3">
            <Zap size={18} className="text-indigo-400" />
          </div>
          <p className="text-white font-bold text-base">Behavior Engine</p>
          <p className="text-white/25 text-xs">Manager Portal</p>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <p className="text-white/25 text-[8px] uppercase tracking-widest mb-1">Email</p>
            <input value={email} onChange={e => setEmail(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm outline-none focus:border-indigo-500/40" />
          </div>
          <div>
            <p className="text-white/25 text-[8px] uppercase tracking-widest mb-1">Password</p>
            <div className="relative">
              <input type={show ? 'text' : 'password'} value={pw} onChange={e => setPw(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 pr-9 text-white text-sm outline-none focus:border-indigo-500/40" />
              <button type="button" onClick={() => setShow(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/25">
                {show ? <EyeOff size={11} /> : <Eye size={11} />}
              </button>
            </div>
          </div>
          {err && <p className="text-red-400 text-[9px]">{err}</p>}
          <button type="submit" disabled={busy}
            className="w-full py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all">
            {busy ? <><span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Signing in…</> : 'Sign In'}
          </button>
        </form>
        <div className="p-3 rounded-xl border border-indigo-500/15 bg-indigo-500/5">
          <p className="text-indigo-400 text-[8px] font-bold mb-0.5">Demo login</p>
          <p className="text-white/25 text-[8px]">{DEMO_EMAIL} / {DEMO_PASS}</p>
        </div>
      </div>
    </div>
  );
}

function DashboardScreen() {
  return (
    <div className="p-5 space-y-4">
      <div>
        <p className="text-white font-bold">{DEMO_COMPANY}</p>
        <p className="text-white/25 text-xs">Week 8 · Manager view</p>
      </div>
      <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-600/80 to-indigo-800/80 border border-indigo-500/20">
        <p className="text-indigo-200/50 text-xs mb-1">Team Execution Rate</p>
        <p className="text-4xl font-black text-white">72%</p>
        <p className="text-indigo-200/40 text-[9px] mt-1">+30% from onboarding at 42%</p>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[{ l: 'Active today', v: '5/6', c: '#34d399' }, { l: 'Avg score', v: '31', c: '#818cf8' }, { l: 'At risk', v: '1', c: '#f87171' }].map(m => (
          <div key={m.l} className="p-3 rounded-xl border border-white/8 bg-white/2 text-center">
            <p className="text-xl font-black" style={{ color: m.c }}>{m.v}</p>
            <p className="text-white/25 text-[8px] mt-0.5">{m.l}</p>
          </div>
        ))}
      </div>
      <div className="p-4 rounded-xl border border-white/8 bg-white/2">
        <p className="text-white/20 text-[8px] uppercase tracking-widest mb-2">8-Week Trend</p>
        <div className="flex items-end gap-1.5 h-14">
          {EXEC_WEEKS.map((v, i) => (
            <div key={i} className="flex-1 rounded-sm" style={{ height: `${(v/100)*52}px`, background: i === 7 ? '#818cf8' : 'rgba(99,102,241,0.2)' }} />
          ))}
        </div>
      </div>
    </div>
  );
}

function TeamScreen() {
  const sorted = [...TEAM].sort((a, b) => b.scores[6] - a.scores[6]);
  return (
    <div className="p-5 space-y-3">
      <div>
        <p className="text-white font-bold">Team Performance</p>
        <p className="text-white/25 text-xs">Real-time execution scores</p>
      </div>
      {sorted.map(rep => (
        <div key={rep.id} className={`flex items-center gap-3 p-3 rounded-xl border ${rep.trend === 'down' ? 'border-red-500/15 bg-red-500/4' : 'border-white/6 bg-white/2'}`}>
          <div className="w-8 h-8 rounded-xl flex items-center justify-center text-[9px] font-black shrink-0"
            style={{ background: rep.color + '18', color: rep.color }}>{rep.av}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="text-white/65 text-xs font-semibold">{rep.name}</span>
              <span className="text-white/20 text-[8px]">{rep.role}</span>
              {rep.trend === 'down' && <AlertTriangle size={9} className="text-red-400" />}
            </div>
            <ScoreBar v={rep.scores[6]} color={rep.color} />
          </div>
          <TrendIcon dir={rep.trend} />
        </div>
      ))}
    </div>
  );
}

function LeaderboardScreen() {
  const sorted = [...TEAM].sort((a, b) =>
    b.scores.reduce((s, x) => s + x, 0) - a.scores.reduce((s, x) => s + x, 0)
  );
  const medals = ['🥇', '🥈', '🥉'];
  return (
    <div className="p-5 space-y-3">
      <div>
        <p className="text-white font-bold">Leaderboard</p>
        <p className="text-white/25 text-xs">7-day total score</p>
      </div>
      <div className="flex items-end justify-center gap-4 pb-3">
        {sorted.slice(0, 3).map((rep, i) => {
          const total = rep.scores.reduce((s, x) => s + x, 0);
          const h = [80, 60, 48][i];
          return (
            <div key={rep.id} className="flex flex-col items-center gap-1.5">
              <p>{medals[i]}</p>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-[9px] font-black"
                style={{ background: rep.color + '20', color: rep.color }}>{rep.av}</div>
              <p className="text-white/40 text-[8px]">{rep.name.split(' ')[0]}</p>
              <div className="w-14 rounded-t-lg flex items-center justify-center"
                style={{ height: h, background: rep.color + '15', border: `1px solid ${rep.color}20` }}>
                <span className="text-[10px] font-black" style={{ color: rep.color }}>{total}</span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="space-y-1">
        {sorted.map((rep, i) => (
          <div key={rep.id} className="flex items-center gap-2 p-2 rounded-xl border border-white/5 bg-white/2">
            <span className="text-white/20 text-[8px] w-3">{i+1}</span>
            <div className="w-6 h-6 rounded-lg flex items-center justify-center text-[8px] font-black"
              style={{ background: rep.color + '18', color: rep.color }}>{rep.av}</div>
            <span className="flex-1 text-white/50 text-xs">{rep.name}</span>
            <span className="font-black text-xs" style={{ color: rep.color }}>
              {rep.scores.reduce((s, x) => s + x, 0)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AIInsightsScreen() {
  const [dismissed, setDismissed] = useState({});
  return (
    <div className="p-5 space-y-3">
      <div>
        <p className="text-white font-bold">AI Insights</p>
        <p className="text-white/25 text-xs">Last scan: 2 min ago</p>
      </div>
      {INSIGHTS.filter(i => !dismissed[i.id]).map(ins => (
        <div key={ins.id} className="p-4 rounded-2xl border" style={{ borderColor: ins.color + '20', background: ins.bg }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[8px] font-black px-1.5 py-0.5 rounded border"
              style={{ color: ins.color, borderColor: ins.color + '30', background: ins.color + '10' }}>{ins.type}</span>
            <button onClick={() => setDismissed(d => ({ ...d, [ins.id]: true }))} className="text-white/15 hover:text-white/35 text-[10px]">✕</button>
          </div>
          <p className="text-white/65 text-xs font-semibold mb-1">{ins.title}</p>
          <p className="text-white/30 text-[9px] leading-snug mb-2">{ins.body}</p>
          <button className="flex items-center gap-1 text-[8px] font-bold px-2 py-1 rounded-lg border hover:bg-white/5 transition-all"
            style={{ color: ins.color, borderColor: ins.color + '25' }}>
            {ins.cta} <ArrowRight size={7} />
          </button>
        </div>
      ))}
    </div>
  );
}

const SCREENS = [
  { id: 'dashboard',   label: 'Home',        Icon: BarChart2,  Comp: DashboardScreen  },
  { id: 'team',        label: 'Team',        Icon: Users,      Comp: TeamScreen       },
  { id: 'leaderboard', label: 'Rankings',    Icon: Trophy,     Comp: LeaderboardScreen },
  { id: 'insights',    label: 'AI',          Icon: Brain,      Comp: AIInsightsScreen  },
];

// ── Hosting stack ──────────────────────────────────────────────────────────────
const HOSTING = [
  { s: 'Vercel',   p: 'Frontend demo',    c: '#a1a1aa', cmd: 'vercel deploy --prod'       },
  { s: 'Railway',  p: 'Backend API',      c: '#818cf8', cmd: 'railway up'                 },
  { s: 'Supabase', p: 'PostgreSQL + Auth',c: '#34d399', cmd: 'supabase init && supabase db push' },
  { s: 'Twilio',   p: 'WhatsApp',         c: '#f472b6', cmd: 'npm install twilio'         },
  { s: 'OpenAI',   p: 'AI coaching',      c: '#22d3ee', cmd: 'export OPENAI_API_KEY=sk-...' },
];

// ── Main ──────────────────────────────────────────────────────────────────────
export default function PitchDemo() {
  const [tab,       setTab]    = useState('demo');
  const [loggedIn,  setLogin]  = useState(false);
  const [screen,    setScreen] = useState('dashboard');

  const cur = SCREENS.find(s => s.id === screen);
  const CurComp = cur?.Comp;

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Play size={13} className="text-pink-400" />
            <p className="text-pink-400 text-xs font-bold uppercase tracking-widest">Investor Demo System</p>
          </div>
          <h1 className="text-3xl font-black mb-1">Live Clickable Pitch Demo</h1>
          <p className="text-white/35 text-sm">Not the real product. Your <span className="text-pink-400 font-semibold">pitch weapon</span>. Hosted. Always on.</p>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['demo','Live Demo'],['howto','How to Demo'],['hosting','Deploy & Host']].map(([v,l]) => (
            <button key={v} onClick={() => setTab(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${tab===v ? 'bg-pink-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── LIVE DEMO ── */}
        {tab === 'demo' && (
          <div className="grid lg:grid-cols-[1fr_220px] gap-5">
            {/* Simulated phone/browser frame */}
            <div className="rounded-2xl border border-white/10 bg-[#0c1018] overflow-hidden" style={{ minHeight: 580 }}>
              {/* Browser chrome */}
              <div className="flex items-center justify-between px-4 py-2 border-b border-white/6 bg-white/2 shrink-0">
                <div className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-400/40" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-400/40" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-400/40" />
                </div>
                <p className="text-white/20 text-[8px] font-mono">app.behaviorengine.io</p>
                <div className="flex items-center gap-1">
                  <Lock size={7} className="text-white/15" />
                  <span className="text-white/15 text-[7px]">Secure</span>
                </div>
              </div>

              {/* App content */}
              <div className="overflow-y-auto" style={{ maxHeight: 570 }}>
                {!loggedIn ? (
                  <LoginScreen onLogin={() => setLogin(true)} />
                ) : (
                  <>
                    {/* Bottom nav */}
                    <div className="flex border-b border-white/6 bg-[#0b0f1a] sticky top-0 z-10">
                      {SCREENS.map(({ id, label, Icon }) => (
                        <button key={id} onClick={() => setScreen(id)}
                          className={`flex-1 flex flex-col items-center gap-0.5 py-2 text-[7px] transition-all ${
                            screen === id ? 'text-indigo-400 border-b-2 border-indigo-400' : 'text-white/25 hover:text-white/45'
                          }`}>
                          <Icon size={11} />
                          {label}
                        </button>
                      ))}
                    </div>
                    {CurComp && <CurComp />}
                  </>
                )}
              </div>
            </div>

            {/* Controls */}
            <div className="space-y-4">
              {loggedIn && (
                <div className="space-y-1">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Jump to Screen</p>
                  {SCREENS.map(({ id, label, Icon }) => (
                    <button key={id} onClick={() => setScreen(id)}
                      className={`w-full flex items-center gap-2 p-2.5 rounded-xl border text-xs text-left transition-all ${
                        screen === id ? 'border-indigo-500/25 bg-indigo-500/8 text-indigo-300' : 'border-white/5 text-white/30 hover:text-white/55 hover:bg-white/3'
                      }`}>
                      <Icon size={10} /> {label}
                    </button>
                  ))}
                </div>
              )}

              <div className="p-3 rounded-xl border border-white/8 bg-white/2">
                <p className="text-white/20 text-[8px] uppercase tracking-widest mb-1.5">Status</p>
                <div className="flex items-center gap-2 mb-1">
                  <div className={`w-2 h-2 rounded-full ${loggedIn ? 'bg-emerald-400' : 'bg-red-400/50'}`} />
                  <span className="text-white/30 text-[9px]">{loggedIn ? `Logged in — ${DEMO_COMPANY}` : 'Logged out'}</span>
                </div>
              </div>

              {loggedIn && (
                <button onClick={() => { setLogin(false); setScreen('dashboard'); }}
                  className="w-full py-2 rounded-xl border border-white/8 text-white/25 text-xs hover:text-white/45 transition-all">
                  Reset Demo ↺
                </button>
              )}

              <div className="p-3 rounded-xl border border-pink-500/15 bg-pink-500/5">
                <p className="text-pink-400 text-[8px] font-bold mb-1">Pitch tip</p>
                <p className="text-white/25 text-[8px] leading-snug">Show Dashboard \u2192 Team \u2192 AI Insights. Stop at the CRITICAL card. Let them react.</p>
              </div>
            </div>
          </div>
        )}

        {/* ── HOW TO DEMO ── */}
        {tab === 'howto' && (
          <div className="space-y-4">
            <div className="p-5 rounded-2xl border border-pink-500/20 bg-pink-500/5">
              <p className="text-pink-400 font-bold text-sm mb-3">The 5-Minute Demo Script</p>
              <div className="space-y-3">
                {[
                  { n: '0:00', t: 'Set the frame', s: '"I want to show you what your manager sees right now. 5 minutes."' },
                  { n: '0:30', t: 'Log in',        s: 'Click through login. No explanation needed. Speed signals confidence.' },
                  { n: '1:00', t: 'Dashboard',     s: 'Point to 72%. Say: "That was 42% at onboarding. 6 weeks."' },
                  { n: '2:00', t: 'Team screen',   s: 'Point to James R. Say: "This is what you see before Friday." Pause.' },
                  { n: '3:00', t: 'AI Insights',   s: 'Show CRITICAL card. Say: "The system caught this — not you."' },
                  { n: '4:00', t: 'Stop',          s: '"Does this match the problem you described?" Then shut up.' },
                ].map(({ n, t, s }) => (
                  <div key={n} className="flex items-start gap-3">
                    <span className="w-14 text-pink-400 text-[9px] font-bold shrink-0">{n}</span>
                    <div>
                      <p className="text-white/65 text-xs font-semibold">{t}</p>
                      <p className="text-white/30 text-[9px] leading-snug mt-0.5 italic">{s}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-3">
              {[
                { t: 'Common reaction', d: '"We already have Monday/Asana." Answer: "Those are project tools. Do they tell you which rep misses target before month end?"' },
                { t: 'Best reaction',   d: '"This is exactly what we need." Close immediately: "Let\'s run a 7-day pilot. 10 minutes to set up."' },
              ].map(({ t, d }) => (
                <div key={t} className="p-4 rounded-xl border border-white/8 bg-white/2">
                  <p className="text-white/55 text-xs font-bold mb-1">{t}</p>
                  <p className="text-white/30 text-[10px] leading-snug">{d}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── HOSTING ── */}
        {tab === 'hosting' && (
          <div className="space-y-4">
            <div className="grid lg:grid-cols-2 gap-3">
              {HOSTING.map(h => (
                <div key={h.s} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold" style={{ color: h.c }}>{h.s}</p>
                    <span className="text-white/20 text-[8px]">{h.p}</span>
                  </div>
                  <code className="block text-[9px] text-white/40 font-mono bg-black/30 px-2 py-1.5 rounded">{h.cmd}</code>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-xl border border-white/8 bg-black/20">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Deploy in 20 minutes</p>
              <pre className="text-[9px] text-emerald-400/75 font-mono leading-relaxed">{`# 1. Backend → Railway (auto-provisions Postgres)
cd backend
railway login
railway up
# Railway gives you: https://your-app.railway.app

# 2. Frontend → Vercel
cd frontend
VITE_API_URL=https://your-app.railway.app
vercel deploy --prod
# Vercel gives you: https://your-demo.vercel.app

# 3. Share the Vercel link.
# That IS your live investor demo.
# Always on. No laptop needed.`}</pre>
            </div>

            <div className="p-4 rounded-2xl border border-pink-500/20 bg-pink-500/5">
              <p className="text-pink-400 font-bold text-sm mb-1">What you now have</p>
              <p className="text-white/45 text-xs leading-relaxed">
                A live URL you can share before any investor call.
                They click it, log in with the demo creds, and experience the product without
                a screen share. <span className="text-white font-semibold">That is more powerful than any deck.</span>
              </p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
