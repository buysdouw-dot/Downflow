import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, TrendingUp, AlertTriangle, CheckCircle2, BarChart2,
  Zap, Crown, ArrowRight, ChevronRight, Activity, Target,
  Shield, CreditCard, Puzzle,
} from 'lucide-react';
import { useAuth } from '../store/AuthContext';
import { useBehavior } from '../store/BehaviorContext';
import { getStatus, getStatusConfig } from '../engine/core';
import MobileHeader from '../components/MobileHeader';
import { AreaChart, Area, ResponsiveContainer, Tooltip } from 'recharts';

const AVATAR_BG = [
  'from-indigo-500 to-purple-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-pink-500 to-rose-600',
  'from-cyan-500 to-blue-600',
];

export default function AdminDashboard() {
  const { user, allUsersInTenant, tenantInfo, tenants } = useAuth();
  const { getTodayScore, getWeekScores, activePlugin, plugins } = useBehavior();
  const navigate = useNavigate();
  const plug = plugins[activePlugin];

  // Compute per-user stats for all tenant users
  const teamStats = useMemo(() => {
    return allUsersInTenant.map((u) => {
      const score = getTodayScore(u.id);
      const weekData = getWeekScores(u.id);
      const weekScores = weekData.map((d) => d.score);
      const avg = Math.round(weekScores.reduce((a, b) => a + b, 0) / weekScores.length);
      const status = getStatus(score);
      const cfg = getStatusConfig(status);
      const target = plug?.dailyTarget ?? 40;
      const pct = Math.min(100, Math.round((score / target) * 100));
      const greenDays = weekScores.filter(s => s >= 40).length;
      return { ...u, score, avg, status, cfg, pct, weekScores, greenDays };
    }).sort((a, b) => b.score - a.score);
  }, [allUsersInTenant, getTodayScore, getWeekScores, plug]);

  const totalUsers = teamStats.length;
  const activeToday = teamStats.filter(u => u.score > 0).length;
  const greenUsers = teamStats.filter(u => u.status === 'GREEN').length;
  const atRisk = teamStats.filter(u => u.status === 'RED').length;
  const avgTeamScore = totalUsers > 0
    ? Math.round(teamStats.reduce((s, u) => s + u.score, 0) / totalUsers)
    : 0;
  const executionRate = totalUsers > 0 ? Math.round((activeToday / totalUsers) * 100) : 0;

  // 7-day team trend (avg score across all users per day)
  const teamTrend = useMemo(() => {
    if (!allUsersInTenant.length) return [];
    const days = getWeekScores(allUsersInTenant[0].id);
    return days.map((day, i) => ({
      label: day.label,
      avg: Math.round(
        allUsersInTenant.reduce((sum, u) => {
          const ws = getWeekScores(u.id);
          return sum + (ws[i]?.score ?? 0);
        }, 0) / allUsersInTenant.length
      ),
    }));
  }, [allUsersInTenant, getWeekScores]);

  const topPerformer = teamStats[0];
  const weakPerformers = teamStats.filter(u => u.status === 'RED');

  return (
    <div className="max-w-5xl mx-auto">
      <MobileHeader title="Admin" />

      {/* Desktop header */}
      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Shield size={16} className="text-indigo-400" />
            <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">Admin Dashboard</span>
          </div>
          <h1 className="text-2xl font-bold text-white">{tenantInfo?.icon} {tenantInfo?.name}</h1>
          <p className="text-white/35 text-sm mt-0.5">Company execution overview · Real-time performance</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/billing')}
            className="flex items-center gap-2 px-4 py-2 glass rounded-xl text-xs text-white/50 hover:text-white/80 border border-white/8 hover:border-white/15 transition-all"
          >
            <CreditCard size={12} /> Billing
          </button>
          <button
            onClick={() => navigate('/analytics')}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-500/20 rounded-xl text-xs text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/30 transition-all"
          >
            <BarChart2 size={12} /> Full Analytics
          </button>
        </div>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-5">
        {/* KPI tiles */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            {
              label: 'Execution Rate',
              value: `${executionRate}%`,
              sub: `${activeToday}/${totalUsers} active`,
              color: 'text-indigo-400',
              bg: 'bg-indigo-500/10',
              border: 'border-indigo-500/20',
              icon: Activity,
            },
            {
              label: 'Avg Team Score',
              value: avgTeamScore,
              sub: `of ${plug?.dailyTarget ?? 40} pt target`,
              color: getStatusConfig(getStatus(avgTeamScore)).color,
              bg: getStatusConfig(getStatus(avgTeamScore)).bg,
              border: getStatusConfig(getStatus(avgTeamScore)).border,
              icon: Target,
            },
            {
              label: 'GREEN Today',
              value: greenUsers,
              sub: `${totalUsers > 0 ? Math.round((greenUsers / totalUsers) * 100) : 0}% of team`,
              color: 'text-green-400',
              bg: 'bg-green-500/10',
              border: 'border-green-500/20',
              icon: CheckCircle2,
            },
            {
              label: 'At Risk',
              value: atRisk,
              sub: atRisk > 0 ? 'need intervention' : 'all on track',
              color: atRisk > 0 ? 'text-red-400' : 'text-white/40',
              bg: atRisk > 0 ? 'bg-red-500/10' : 'bg-white/4',
              border: atRisk > 0 ? 'border-red-500/20' : 'border-white/8',
              icon: AlertTriangle,
            },
          ].map(({ label, value, sub, color, bg, border, icon: Icon }) => (
            <div key={label} className={`glass rounded-xl p-4 border ${border}`}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-white/35 text-xs uppercase tracking-wider">{label}</p>
                <div className={`w-7 h-7 rounded-lg ${bg} flex items-center justify-center`}>
                  <Icon size={13} className={color} />
                </div>
              </div>
              <p className={`text-2xl font-bold ${color}`}>{value}</p>
              <p className="text-white/25 text-xs mt-0.5">{sub}</p>
            </div>
          ))}
        </div>

        {/* Team trend chart + top/risk panel */}
        <div className="grid lg:grid-cols-3 gap-4">
          {/* 7-day trend */}
          <div className="lg:col-span-2 glass rounded-xl p-4 border border-white/8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-white font-semibold text-sm">Team Execution Trend</p>
                <p className="text-white/30 text-xs mt-0.5">7-day average score across {totalUsers} users</p>
              </div>
              <button onClick={() => navigate('/analytics')} className="text-indigo-400 text-xs flex items-center gap-1 hover:text-indigo-300">
                Full view <ChevronRight size={11} />
              </button>
            </div>
            <ResponsiveContainer width="100%" height={120}>
              <AreaChart data={teamTrend} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="adminGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Tooltip
                  contentStyle={{ background: '#0f1421', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                  labelStyle={{ color: 'rgba(255,255,255,0.5)' }}
                  itemStyle={{ color: '#a5b4fc' }}
                  formatter={(v) => [`${v} pts avg`, '']}
                />
                <Area type="monotone" dataKey="avg" stroke="#6366f1" strokeWidth={2} fill="url(#adminGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
            <div className="flex justify-between mt-1">
              {teamTrend.map((d, i) => (
                <span key={i} className="text-white/20 text-[9px]">{d.label}</span>
              ))}
            </div>
          </div>

          {/* Quick stats */}
          <div className="space-y-3">
            {/* Top performer */}
            {topPerformer && (
              <div className="glass rounded-xl p-4 border border-yellow-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Crown size={13} className="text-yellow-400" />
                  <p className="text-yellow-400 text-[10px] font-semibold uppercase tracking-widest">Top Performer</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${AVATAR_BG[(topPerformer.id ?? 1) % AVATAR_BG.length]} flex items-center justify-center text-xs font-bold text-white`}>
                    {topPerformer.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-semibold truncate">{topPerformer.name}</p>
                    <p className="text-white/35 text-xs">{topPerformer.title}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-lg font-bold ${topPerformer.cfg.color}`}>{topPerformer.score}</p>
                    <p className="text-white/25 text-[9px]">pts</p>
                  </div>
                </div>
              </div>
            )}

            {/* Plugin active */}
            <div className="glass rounded-xl p-4 border border-white/8">
              <div className="flex items-center gap-2 mb-2">
                <Puzzle size={13} className="text-indigo-400" />
                <p className="text-white/35 text-[10px] font-semibold uppercase tracking-widest">Active Plugin</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-2xl">{plug?.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-semibold">{plug?.name}</p>
                  <p className="text-white/35 text-xs">{plug?.tasks?.length} tasks · {plug?.dailyTarget}pt target</p>
                </div>
                <button onClick={() => navigate('/plugins')} className="text-indigo-400 hover:text-indigo-300">
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* At-risk users */}
        {weakPerformers.length > 0 && (
          <div>
            <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-2 flex items-center gap-2">
              <AlertTriangle size={10} className="text-red-400" /> Needs Intervention
            </p>
            <div className="glass rounded-xl overflow-hidden border border-red-500/15">
              {weakPerformers.map((u, i) => (
                <div key={u.id} className={`flex items-center gap-3 px-4 py-3 ${i < weakPerformers.length - 1 ? 'border-b border-white/5' : ''}`}>
                  <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${AVATAR_BG[(u.id ?? 1) % AVATAR_BG.length]} flex items-center justify-center text-xs font-bold text-white shrink-0`}>
                    {u.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white/80 text-sm font-medium truncate">{u.name}</p>
                    <p className="text-white/30 text-xs">{u.title} · {u.score} pts today</p>
                  </div>
                  <div className="text-right">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${u.cfg.bg} ${u.cfg.color} border ${u.cfg.border}`}>
                      {u.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Full team table */}
        <div>
          <div className="flex items-center justify-between px-1 mb-2">
            <p className="text-white/25 text-[10px] uppercase tracking-widest">All Team Members</p>
            <button onClick={() => navigate('/leaderboard')} className="text-indigo-400 text-xs flex items-center gap-1 hover:text-indigo-300">
              Leaderboard <ArrowRight size={10} />
            </button>
          </div>
          <div className="glass rounded-xl overflow-hidden border border-white/8">
            <div className="grid grid-cols-[1fr_auto_auto_auto] gap-0 text-[10px] text-white/25 uppercase tracking-widest px-4 py-2.5 border-b border-white/6">
              <span>Member</span>
              <span className="text-right pr-6">Score</span>
              <span className="text-right pr-6">7d Avg</span>
              <span className="text-right">Status</span>
            </div>
            {teamStats.map((u, i) => (
              <div
                key={u.id}
                className={`grid grid-cols-[1fr_auto_auto_auto] gap-0 px-4 py-3 items-center ${i < teamStats.length - 1 ? 'border-b border-white/4' : ''} hover:bg-white/2 transition-colors`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${AVATAR_BG[(u.id ?? 1) % AVATAR_BG.length]} flex items-center justify-center text-[10px] font-bold text-white shrink-0`}>
                    {u.avatar}
                  </div>
                  <div className="min-w-0">
                    <p className="text-white/80 text-sm font-medium truncate">{u.name}</p>
                    <p className="text-white/25 text-[10px]">{u.role} · {u.title}</p>
                  </div>
                </div>
                <span className={`text-sm font-bold pr-6 ${u.cfg.color}`}>{u.score}</span>
                <span className="text-white/45 text-xs pr-6">{u.avg}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${u.cfg.bg} ${u.cfg.color} border ${u.cfg.border} whitespace-nowrap`}>
                  {u.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick admin links */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Analytics',      sub: 'Trends & insights',  icon: BarChart2,   to: '/analytics', color: 'text-indigo-400'  },
            { label: 'Billing',        sub: 'Plans & invoices',   icon: CreditCard,  to: '/billing',   color: 'text-emerald-400' },
            { label: 'Plugin Market',  sub: 'Manage plugins',     icon: Puzzle,      to: '/plugins',   color: 'text-purple-400'  },
            { label: 'Leaderboard',    sub: 'Team rankings',      icon: TrendingUp,  to: '/leaderboard',color: 'text-yellow-400' },
          ].map(({ label, sub, icon: Icon, to, color }) => (
            <button
              key={label}
              onClick={() => navigate(to)}
              className="glass rounded-xl p-4 border border-white/8 hover:border-white/15 hover:bg-white/3 transition-all text-left group"
            >
              <Icon size={18} className={`${color} mb-2 group-hover:scale-110 transition-transform`} />
              <p className="text-white/80 text-sm font-semibold">{label}</p>
              <p className="text-white/30 text-xs mt-0.5">{sub}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
