/**
 * MultiAgent — AI v2 Multi-Agent System Dashboard
 * 4 specialized agents: Coach · Analyst · Risk · Performance
 * Live orchestrator + self-optimization loop visualization.
 */
import { useState, useEffect } from 'react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus } from '../engine/core';
import {
  runAgents, coachAgent, analystAgent, riskAgent,
  performanceAgent, loadAgentState, saveAgentState,
} from '../engine/agents';
import {
  Brain, BarChart2, AlertTriangle, Zap, Cpu,
  RefreshCw, Play, ArrowRight, ChevronRight,
  TrendingUp, TrendingDown, Shield, Activity,
  Target, Clock, CheckCircle2, Star, Users,
} from 'lucide-react';

// ── Agent config ──────────────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'coach',
    label: 'Coach Agent',
    role: 'Motivates behavior, adjusts tone, gives feedback',
    icon: Brain,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    glow: 'shadow-indigo-500/10',
    step: '01',
  },
  {
    id: 'analyst',
    label: 'Analyst Agent',
    role: 'Finds patterns, detects trends, calculates gaps',
    icon: BarChart2,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/8',
    border: 'border-cyan-500/20',
    glow: 'shadow-cyan-500/10',
    step: '02',
  },
  {
    id: 'risk',
    label: 'Risk Agent',
    role: 'Detects drop-off risk, identifies inactive users',
    icon: AlertTriangle,
    color: 'text-orange-400',
    bg: 'bg-orange-500/8',
    border: 'border-orange-500/20',
    glow: 'shadow-orange-500/10',
    step: '03',
  },
  {
    id: 'performance',
    label: 'Performance Agent',
    role: 'Optimizes task difficulty, balances execution load',
    icon: Zap,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/8',
    border: 'border-emerald-500/20',
    glow: 'shadow-emerald-500/10',
    step: '04',
  },
];

// ── Agent output card ─────────────────────────────────────────────────────────
function AgentCard({ agent, output, active, onSelect, selected }) {
  const Icon = agent.icon;
  if (!output) return (
    <div className={`p-4 rounded-2xl border ${agent.border} ${agent.bg} opacity-40`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon size={14} className={agent.color} />
        <span className={`text-xs font-bold ${agent.color}`}>{agent.label}</span>
      </div>
      <p className="text-white/20 text-xs">Waiting for data…</p>
    </div>
  );

  return (
    <div
      onClick={() => onSelect(agent.id === selected ? null : agent.id)}
      className={`p-4 rounded-2xl border cursor-pointer transition-all ${
        selected === agent.id
          ? `${agent.border} ${agent.bg} shadow-lg ${agent.glow}`
          : active
          ? `${agent.border} ${agent.bg}`
          : 'border-white/6 bg-white/2 hover:border-white/10'
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-xl ${agent.bg} border ${agent.border} flex items-center justify-center`}>
            <Icon size={14} className={agent.color} />
          </div>
          <div>
            <p className={`text-xs font-bold ${agent.color}`}>{agent.label}</p>
            <p className="text-white/20 text-[9px]">{agent.role}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {active && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />}
          <ChevronRight size={11} className={`text-white/20 transition-transform ${selected === agent.id ? 'rotate-90' : ''}`} />
        </div>
      </div>

      {/* Preview */}
      {agent.id === 'coach' && output.message && (
        <p className="text-white/60 text-xs italic leading-snug line-clamp-2">"{output.message}"</p>
      )}
      {agent.id === 'analyst' && output.avgScore !== undefined && (
        <div className="flex gap-3">
          <div>
            <p className="text-white/20 text-[9px]">7-day avg</p>
            <p className={`text-base font-black ${output.trend === 'up' ? 'text-emerald-400' : output.trend === 'down' ? 'text-red-400' : 'text-white/60'}`}>
              {output.avgScore}
            </p>
          </div>
          <div>
            <p className="text-white/20 text-[9px]">Trend</p>
            <p className="text-white/60 text-xs font-semibold flex items-center gap-0.5">
              {output.trend === 'up' ? <TrendingUp size={11} className="text-emerald-400" /> : output.trend === 'down' ? <TrendingDown size={11} className="text-red-400" /> : <Activity size={11} />}
              {output.trend}
            </p>
          </div>
        </div>
      )}
      {agent.id === 'risk' && output.riskLevel && (
        <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full ${
          output.riskLevel === 'critical' ? 'bg-red-500/15 border border-red-500/25 text-red-400' :
          output.riskLevel === 'high'     ? 'bg-orange-500/15 border border-orange-500/25 text-orange-400' :
          output.riskLevel === 'medium'   ? 'bg-yellow-500/15 border border-yellow-500/25 text-yellow-400' :
          'bg-emerald-500/15 border border-emerald-500/25 text-emerald-400'
        }`}>
          <Shield size={9} />
          <span className="text-[9px] font-bold capitalize">{output.riskLevel} risk</span>
          <span className="text-[9px] opacity-70">({output.riskScore}/100)</span>
        </div>
      )}
      {agent.id === 'performance' && output.difficultyAdj && (
        <div className="flex items-center gap-2">
          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
            output.difficultyAdj === 'increase' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25' :
            output.difficultyAdj === 'reduce'   ? 'bg-yellow-500/15 text-yellow-400 border border-yellow-500/25' :
            'bg-white/6 text-white/40 border border-white/10'
          }`}>
            {output.difficultyAdj === 'increase' ? '↑ Increase difficulty' : output.difficultyAdj === 'reduce' ? '↓ Reduce load' : '→ Maintain pace'}
          </span>
        </div>
      )}

      {/* Expanded detail */}
      {selected === agent.id && (
        <div className="mt-3 pt-3 border-t border-white/8 space-y-2">
          {agent.id === 'coach' && (
            <>
              {output.streakNote && <p className="text-white/40 text-xs">{output.streakNote}</p>}
              {output.tone && (
                <div className="flex items-center gap-2">
                  <span className="text-white/20 text-[9px]">Tone:</span>
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/15`}>
                    {output.tone}
                  </span>
                </div>
              )}
            </>
          )}
          {agent.id === 'analyst' && (
            <div className="grid grid-cols-3 gap-2">
              {[
                ['Green', output.greenDays ?? 0, 'text-emerald-400'],
                ['Yellow', output.yellowDays ?? 0, 'text-yellow-400'],
                ['Red', output.redDays ?? 0, 'text-red-400'],
              ].map(([label, val, color]) => (
                <div key={label} className="text-center p-2 rounded-lg bg-white/3 border border-white/6">
                  <p className={`text-base font-black ${color}`}>{val}</p>
                  <p className="text-white/25 text-[9px]">{label}</p>
                </div>
              ))}
              {output.insights && output.insights.length > 0 && (
                <div className="col-span-3 space-y-1">
                  {output.insights.map((ins, i) => (
                    <div key={i} className="flex items-start gap-1.5">
                      <div className="w-1 h-1 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                      <p className="text-white/40 text-[10px]">{ins}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          {agent.id === 'risk' && (
            <div className="space-y-1.5">
              {output.factors && output.factors.map((f, i) => (
                <div key={i} className="flex items-start gap-1.5">
                  <AlertTriangle size={9} className="text-orange-400 mt-0.5 shrink-0" />
                  <p className="text-white/40 text-[10px]">{f}</p>
                </div>
              ))}
              {output.reEngageScript && (
                <div className="p-2 rounded-lg bg-white/3 border border-white/6 mt-2">
                  <p className="text-white/20 text-[8px] uppercase tracking-widest mb-1">Re-engage script</p>
                  <p className="text-white/50 text-[10px] italic">"{output.reEngageScript}"</p>
                </div>
              )}
            </div>
          )}
          {agent.id === 'performance' && (
            <div className="space-y-1.5">
              {[
                ['Recommended target', `${output.recommendedTarget} pts/day`, Target],
                ['Optimal tasks',      `${output.optimalTasks} per session`, CheckCircle2],
                ['Readiness score',    `${output.readinessScore ?? 50}%`, Star],
              ].map(([label, val, Icon]) => (
                <div key={label} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Icon size={9} className="text-white/20" />
                    <span className="text-white/30 text-[10px]">{label}</span>
                  </div>
                  <span className="text-white/60 text-[10px] font-semibold">{val}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function MultiAgent() {
  const { getTodayScore, getWeekScores, activeUserId } = useBehavior();
  const { user } = useAuth();

  const [outputs,     setOutputs]    = useState(null);
  const [orchestrator,setOrch]       = useState(null);
  const [running,     setRunning]    = useState(false);
  const [activeAgent, setActiveAgent]= useState(null);
  const [runCount,    setRunCount]   = useState(0);
  const [lastRun,     setLastRun]    = useState(null);
  const [agentLog,    setAgentLog]   = useState([]);

  const score      = getTodayScore(activeUserId);
  const weekScores = getWeekScores(activeUserId);
  const status     = getStatus(score);

  const userData = {
    id:            user?.id ?? activeUserId ?? 1,
    name:          user?.name ?? 'User',
    score,
    status,
    weekScores,
    streak:        weekScores.filter(s => s > 20).length,
    consistency:   weekScores.length ? Math.round(weekScores.filter(s => s > 0).length / weekScores.length * 100) : 0,
    personalityId: 'discipline',
    role:          user?.role ?? 'rep',
  };

  // Auto-run on mount
  useEffect(() => {
    triggerRun(false);
  }, [score]);

  const triggerRun = (animated = true) => {
    if (running) return;
    if (animated) setRunning(true);

    const exec = () => {
      const coach    = coachAgent(userData);
      const analyst  = analystAgent(userData);
      const risk     = riskAgent(userData);
      const perf     = performanceAgent(userData);
      const orch     = runAgents(userData);

      setOutputs({ coach, analyst, risk, performance: perf });
      setOrch(orch);
      setRunCount(p => p + 1);
      setLastRun(new Date().toLocaleTimeString());
      setAgentLog(prev => [
        { time: new Date().toLocaleTimeString(), action: orch.priorityAction, alert: orch.alertLevel },
        ...prev.slice(0, 9),
      ]);

      // Save to localStorage
      const uid = user?.id ?? activeUserId ?? 1;
      const prev = loadAgentState(uid);
      saveAgentState(uid, {
        ...prev,
        lastRun: new Date().toISOString(),
        runCount: (prev.runCount ?? 0) + 1,
        lastOutputs: { coach, analyst, risk, performance: perf },
        lastOrchestrator: orch,
      });

      if (animated) setRunning(false);
    };

    if (animated) {
      setTimeout(exec, 800);
    } else {
      exec();
    }
  };

  const LOOP_STEPS = [
    { label: 'Observe',   color: 'text-indigo-400',  desc: 'Collect behavioral signals'        },
    { label: 'Analyze',   color: 'text-cyan-400',    desc: 'Agents process in parallel'        },
    { label: 'Adapt',     color: 'text-purple-400',  desc: 'Orchestrator synthesizes'          },
    { label: 'Optimize',  color: 'text-emerald-400', desc: 'System improves next cycle'        },
    { label: 'Repeat',    color: 'text-white/40',    desc: 'Cycle runs every session'          },
  ];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={14} className="text-purple-400" />
              <p className="text-purple-400 text-xs font-bold uppercase tracking-widest">AI v2 Multi-Agent System</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Agent Orchestrator</h1>
            <p className="text-white/35 text-sm">
              4 specialized agents run in parallel — synthesized into 1 priority action.{' '}
              {lastRun && <span className="text-white/25">Last run: {lastRun}</span>}
            </p>
          </div>
          <button onClick={() => triggerRun(true)} disabled={running}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
              running
                ? 'bg-purple-500/10 border border-purple-500/20 text-purple-400'
                : 'bg-purple-500 hover:bg-purple-400 text-white shadow-lg shadow-purple-500/20'
            }`}>
            {running
              ? <><RefreshCw size={13} className="animate-spin" /> Running…</>
              : <><Play size={13} /> Run Agents</>}
          </button>
        </div>

        {/* Orchestrator output */}
        {orchestrator && (
          <div className="rounded-2xl border border-purple-500/25 bg-purple-500/5 p-5">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-2">
                <Cpu size={15} className="text-purple-400" />
                <p className="text-purple-400 font-bold text-sm">Orchestrator — Priority Action</p>
              </div>
              <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-bold border ${
                orchestrator.alertLevel === 'critical' ? 'bg-red-500/15 border-red-500/25 text-red-400' :
                orchestrator.alertLevel === 'warn'     ? 'bg-orange-500/15 border-orange-500/25 text-orange-400' :
                'bg-emerald-500/15 border-emerald-500/25 text-emerald-400'
              }`}>
                <div className={`w-1.5 h-1.5 rounded-full ${
                  orchestrator.alertLevel === 'critical' ? 'bg-red-400' :
                  orchestrator.alertLevel === 'warn'     ? 'bg-orange-400' : 'bg-emerald-400'
                } animate-pulse`} />
                {orchestrator.alertLevel?.toUpperCase() ?? 'OK'}
              </div>
            </div>
            <div className="grid lg:grid-cols-3 gap-4">
              <div className="lg:col-span-2">
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">Priority Action</p>
                <p className="text-white text-base font-semibold leading-snug">{orchestrator.priorityAction}</p>
              </div>
              <div className="space-y-2">
                {[
                  ['System Health', orchestrator.systemHealth, orchestrator.systemHealth >= 70 ? 'text-emerald-400' : orchestrator.systemHealth >= 40 ? 'text-yellow-400' : 'text-red-400'],
                  ['Agents Run', runCount, 'text-purple-400'],
                ].map(([label, val, color]) => (
                  <div key={label} className="flex items-center justify-between p-2 rounded-lg bg-white/3 border border-white/6">
                    <span className="text-white/30 text-xs">{label}</span>
                    <span className={`text-sm font-black ${color}`}>{typeof val === 'number' && label === 'System Health' ? `${val}%` : val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 4-agent grid */}
        <div>
          <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Agent Outputs</p>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {AGENTS.map(agent => (
              <AgentCard
                key={agent.id}
                agent={agent}
                output={outputs?.[agent.id]}
                active={!!outputs}
                onSelect={setActiveAgent}
                selected={activeAgent}
              />
            ))}
          </div>
        </div>

        {/* Self-improvement loop + Agent log */}
        <div className="grid lg:grid-cols-2 gap-6">

          {/* Loop visualization */}
          <div className="space-y-3">
            <p className="text-white/25 text-[9px] uppercase tracking-widest">Self-Optimization Loop</p>
            <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-4 space-y-2">
              {LOOP_STEPS.map((step, i) => (
                <div key={step.label}>
                  <div className={`flex items-center gap-3 p-3 rounded-xl ${
                    outputs ? 'bg-white/3 border border-white/6' : 'bg-white/1 border border-white/4 opacity-40'
                  }`}>
                    <span className={`text-[9px] font-black font-mono w-4 ${step.color}`}>{String(i+1).padStart(2,'0')}</span>
                    <div className="flex-1">
                      <p className={`text-xs font-bold ${step.color}`}>{step.label}</p>
                      <p className="text-white/20 text-[9px]">{step.desc}</p>
                    </div>
                    {outputs && <CheckCircle2 size={11} className="text-emerald-400/60" />}
                  </div>
                  {i < LOOP_STEPS.length - 1 && (
                    <div className="flex justify-center my-0.5">
                      <ArrowRight size={10} className="text-white/10 rotate-90" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Run log */}
          <div className="space-y-3">
            <p className="text-white/25 text-[9px] uppercase tracking-widest">Orchestrator Run Log</p>
            {agentLog.length === 0 ? (
              <div className="p-6 rounded-2xl border border-white/6 bg-white/2 text-center">
                <Cpu size={20} className="mx-auto text-white/10 mb-2" />
                <p className="text-white/20 text-sm">No runs yet</p>
                <p className="text-white/10 text-xs">Click "Run Agents" to start</p>
              </div>
            ) : (
              <div className="space-y-2">
                {agentLog.map((entry, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border transition-all ${
                    i === 0 ? 'border-purple-500/20 bg-purple-500/5' : 'border-white/5 bg-white/1'
                  }`}>
                    <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                      entry.alert === 'critical' ? 'bg-red-400' : entry.alert === 'warn' ? 'bg-orange-400' : 'bg-emerald-400'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-white/55 text-xs font-semibold leading-snug">{entry.action}</p>
                      <p className="text-white/20 text-[9px] mt-0.5">{entry.time}</p>
                    </div>
                    {i === 0 && <span className="text-[8px] font-black text-purple-400 bg-purple-500/10 border border-purple-500/15 px-1.5 py-0.5 rounded-full">LATEST</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Architecture concept panel */}
        <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-5 lg:p-6">
          <div className="flex items-center gap-2 mb-4">
            <Cpu size={14} className="text-purple-400" />
            <p className="text-purple-400 font-bold text-sm">The Agent Architecture</p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            {AGENTS.map(agent => {
              const Icon = agent.icon;
              return (
                <div key={agent.id} className={`p-3 rounded-xl ${agent.bg} border ${agent.border} text-center`}>
                  <Icon size={16} className={`${agent.color} mx-auto mb-1.5`} />
                  <p className={`text-[10px] font-bold ${agent.color}`}>{agent.label.replace(' Agent','')}</p>
                  <p className="text-white/20 text-[8px] mt-0.5 leading-snug">{agent.role.split(',')[0]}</p>
                </div>
              );
            })}
          </div>
          <div className="rounded-xl bg-black/40 border border-white/8 p-4">
            <pre className="text-[10px] text-purple-400/70 leading-relaxed overflow-x-auto scrollbar-hide">{`function runAgents(userData) {
  const coach       = coachAgent(userData);       // personality × status matrix
  const analysis    = analystAgent(userData);     // trend + gap detection
  const risk        = riskAgent(userData);        // churn / drop-off prediction
  const performance = performanceAgent(userData); // difficulty optimizer

  // Orchestrator: synthesize into 1 priority action
  return {
    priorityAction: synthesize(coach, analysis, risk, performance),
    alertLevel:     risk.riskLevel === 'critical' ? 'critical' : 'ok',
    systemHealth:   calcHealth(analysis, risk, performance),
  };
}`}</pre>
          </div>
          <p className="text-white/30 text-xs mt-3 leading-relaxed">
            <span className="text-white/55 font-semibold">Why this is the moat: </span>
            Every competitor gives the same coaching to everyone. This runs 4 specialized agents per user, then an orchestrator synthesizes them into 1 priority action. After 30 days, no two users get the same system.
          </p>
        </div>

      </div>
    </div>
  );
}
