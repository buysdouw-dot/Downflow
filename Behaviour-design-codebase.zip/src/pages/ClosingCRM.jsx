/**
 * ClosingCRM — Real Closing Scripts + Automation CRM Pipeline
 * Pipeline: Lead → Contacted → Demo → Pilot → Active → Converted → Expansion
 * CRM automation engine. Live lead tracker. Script library.
 */
import { useState } from 'react';
import {
  Users, MessageSquare, Copy, Check, ArrowRight,
  Phone, Mail, Link2, Plus, Trash2, ChevronRight,
  DollarSign, Zap, TrendingUp, Star, Target,
} from 'lucide-react';

// ── Pipeline stages ────────────────────────────────────────────────────────────
const STAGES = [
  { id: 'new',       label: 'New Lead',    color: '#a1a1aa', bg: 'rgba(161,161,170,0.08)',  border: 'rgba(161,161,170,0.18)',  icon: Users       },
  { id: 'contacted', label: 'Contacted',   color: '#818cf8', bg: 'rgba(99,102,241,0.08)',   border: 'rgba(99,102,241,0.2)',   icon: MessageSquare},
  { id: 'demo',      label: 'Demo',        color: '#22d3ee', bg: 'rgba(6,182,212,0.08)',    border: 'rgba(6,182,212,0.2)',   icon: Phone       },
  { id: 'pilot',     label: 'Pilot',       color: '#a78bfa', bg: 'rgba(139,92,246,0.08)',   border: 'rgba(139,92,246,0.2)',  icon: Zap         },
  { id: 'active',    label: 'Active',      color: '#fbbf24', bg: 'rgba(245,158,11,0.08)',   border: 'rgba(245,158,11,0.2)',  icon: Target      },
  { id: 'converted', label: 'Paying',      color: '#34d399', bg: 'rgba(16,185,129,0.08)',   border: 'rgba(16,185,129,0.2)',  icon: DollarSign  },
  { id: 'expansion', label: 'Expansion',   color: '#f472b6', bg: 'rgba(236,72,153,0.08)',   border: 'rgba(236,72,153,0.2)',  icon: TrendingUp  },
];

const STAGE_IDS = STAGES.map(s => s.id);

// ── Pipeline transitions (automation) ────────────────────────────────────────
const TRANSITIONS = {
  signup:        'contacted',
  demo_booked:   'demo',
  demo_done:     'pilot',
  first_task:    'active',
  day7_complete: 'converted',
  upsell:        'expansion',
};

const EVENT_LABELS = {
  signup:        'Signed Up',
  demo_booked:   'Demo Booked',
  demo_done:     'Demo Done',
  first_task:    'First Task',
  day7_complete: '7-Day Complete',
  upsell:        'Upsell',
};

// ── Scripts ────────────────────────────────────────────────────────────────────
const SCRIPTS = [
  {
    id: 'cold_dm',
    label: 'Cold Message (LinkedIn / WhatsApp)',
    stage: 'new',
    channel: 'DM',
    text: `Hey [Name],

I noticed you manage a sales team at [Company].

Quick question: how do you currently track whether your reps are executing consistently day-to-day?

We built a system that gives each rep a daily execution score. Teams using it went from 42% to 78% execution rate in 6 weeks.

Would you be open to a 15-minute call to see if it fits your team?`,
  },
  {
    id: 'cold_email',
    label: 'Cold Email (Decision Maker)',
    stage: 'new',
    channel: 'Email',
    text: `Subject: Quick question about your sales team

Hi [Name],

I'm working on a tool that helps sales teams improve execution consistency.

It tracks daily behavior and turns it into a score (like a fitness tracker for work performance). One team went from 42% to 78% execution in 6 weeks.

Would you be open to seeing a 15-minute demo this week?

No pitch. Just show you the dashboard and ask if it would be useful for your team.`,
  },
  {
    id: 'follow_up',
    label: 'Follow-Up (No Reply)',
    stage: 'contacted',
    channel: 'DM/Email',
    text: `Hey [Name],

Just following up on my message about the execution tracking system.

One line: we help sales teams see exactly who's executing and who isn't, in real time.

If it's not relevant right now, totally fine — just let me know.

If it is, I'll set your team up for free this week.`,
  },
  {
    id: 'demo_book',
    label: 'Book the Demo',
    stage: 'contacted',
    channel: 'DM',
    text: `Hey [Name],

Thanks for replying! Excited to show you what we've built.

Here's a 15-minute slot that works:
[Calendly link or suggest 2 times]

On the call I'll show you:
• The live execution dashboard
• How the AI coaching works
• What your team's score would look like

No slides. Just the product.`,
  },
  {
    id: 'pilot_offer',
    label: 'Pilot Offer (Post-Demo)',
    stage: 'demo',
    channel: 'Email',
    text: `Subject: Free 7-day pilot for [Company]

Hi [Name],

Great call earlier. I'd love to set up a free 7-day pilot for your team.

Here's what happens:
• Each rep gets a daily execution score
• You see a real-time dashboard of who's executing
• AI coach sends personalized nudges per person
• After 7 days, you get a full report

No credit card. No commitment. If there's no value, you walk away.

I can have it live in 10 minutes. Want to start today?`,
  },
  {
    id: 'close',
    label: 'The Close (Post-Pilot)',
    stage: 'active',
    channel: 'Email/Call',
    text: `Hi [Name],

Your team's 7-day pilot results are in:

• Execution rate: [X]% → [Y]%
• Most consistent rep: [Name] ([score]%)
• At-risk pattern flagged for: [Name]
• AI coaching triggered [N] times

To keep this going, it's $[price]/user/month.
Annual plan = 2 months free.

Based on your team of [N] people: $[total]/month.

Want me to send the invoice?`,
  },
  {
    id: 'upsell',
    label: 'Upsell (Expansion)',
    stage: 'converted',
    channel: 'Email',
    text: `Hi [Name],

Checking in on the team's progress.

Over the past [N] weeks, your team has:
• Averaged [X]% execution (up from [Y]%)
• Had [N] streaks of 5+ consecutive days
• [Rep name] hit [score]% — highest on the team

A few companies in your space are now rolling this out to their full org.

Would it make sense to extend to [adjacent team]? I can run a free 1-week pilot for them.`,
  },
];

// ── Automation engine ─────────────────────────────────────────────────────────
function runAutomation(lead, event) {
  const newStatus = TRANSITIONS[event];
  if (!newStatus) return lead;
  return {
    ...lead,
    status: newStatus,
    events: [...(lead.events || []), { event, ts: Date.now() }],
    updatedAt: Date.now(),
  };
}

function scoreLead(lead) {
  const ev = lead.events || [];
  let s = 0;
  if (ev.find(e => e.event === 'demo_booked'))   s += 20;
  if (ev.find(e => e.event === 'demo_done'))      s += 30;
  if (ev.find(e => e.event === 'first_task'))     s += 25;
  if (ev.find(e => e.event === 'day7_complete'))  s += 25;
  return s;
}

// ── Persistence ────────────────────────────────────────────────────────────────
const DEMO_LEADS = [
  { id: '1', name: 'James Park',    company: 'Acme Sales',    email: 'james@acme.co',    status: 'active',    events: [{event:'signup'},{event:'demo_booked'},{event:'demo_done'},{event:'first_task'}], createdAt: Date.now()-7*86400000 },
  { id: '2', name: 'Maria Gomez',   company: 'TechForce',     email: 'maria@tf.io',       status: 'pilot',     events: [{event:'signup'},{event:'demo_booked'},{event:'demo_done'}],                       createdAt: Date.now()-5*86400000 },
  { id: '3', name: 'Alex Chen',     company: 'RevOps Co',     email: 'alex@revops.com',   status: 'contacted', events: [{event:'signup'}],                                                                createdAt: Date.now()-3*86400000 },
  { id: '4', name: 'Sarah Kim',     company: 'GrowthLabs',    email: 'sarah@gl.io',       status: 'converted', events: [{event:'signup'},{event:'demo_booked'},{event:'demo_done'},{event:'first_task'},{event:'day7_complete'}], createdAt: Date.now()-14*86400000 },
  { id: '5', name: 'Tom Walker',    company: 'PipelineHQ',    email: 'tom@pipeline.co',   status: 'new',       events: [],                                                                                createdAt: Date.now()-86400000 },
];

function loadLeads() {
  try { return JSON.parse(localStorage.getItem('be_crm_leads2')) ?? DEMO_LEADS; }
  catch { return DEMO_LEADS; }
}
function saveLeads(leads) { try { localStorage.setItem('be_crm_leads2', JSON.stringify(leads)); } catch {} }

// ── Copy button ────────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1800); }}
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/60'
      }`}>
      {c ? <><Check size={9} /> Copied</> : <><Copy size={9} /> Copy</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function ClosingCRM() {
  const [view,       setView]       = useState('pipeline'); // 'pipeline' | 'scripts' | 'auto'
  const [leads,      setLeads_]     = useState(loadLeads);
  const [activeScript, setActiveScript] = useState(SCRIPTS[0]);
  const [scriptStage,  setScriptStage]  = useState('all');

  // Add lead form
  const [form, setForm] = useState({ name: '', email: '', company: '' });
  const [showAdd, setShowAdd] = useState(false);

  const setLeads = (l) => { setLeads_(l); saveLeads(l); };

  const addLead = () => {
    if (!form.name || !form.email) return;
    const lead = { id: Date.now().toString(), ...form, status: 'new', events: [], createdAt: Date.now() };
    setLeads([...leads, lead]);
    setForm({ name: '', email: '', company: '' });
    setShowAdd(false);
  };

  const fireEvent = (id, event) => {
    setLeads(leads.map(l => l.id === id ? runAutomation(l, event) : l));
  };

  const deleteLead = (id) => setLeads(leads.filter(l => l.id !== id));

  const byStage = (id) => leads.filter(l => l.status === id);
  const converted = leads.filter(l => l.status === 'converted' || l.status === 'expansion').length;
  const mrr = converted * 150;

  const filteredScripts = scriptStage === 'all' ? SCRIPTS : SCRIPTS.filter(s => s.stage === scriptStage);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <DollarSign size={14} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">CRM + Closing System</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Closing Scripts + CRM</h1>
            <p className="text-white/35 text-sm">Pipeline automation. Scripts that convert. Every lead tracked.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5 text-center">
              <p className="text-xl font-black text-emerald-400">${mrr.toLocaleString()}</p>
              <p className="text-white/25 text-[9px]">est. MRR</p>
            </div>
            <div className="p-3 rounded-xl border border-indigo-500/20 bg-indigo-500/5 text-center">
              <p className="text-xl font-black text-indigo-400">{leads.length}</p>
              <p className="text-white/25 text-[9px]">total leads</p>
            </div>
          </div>
        </div>

        {/* View tabs */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6">
            {[['pipeline','Pipeline'],['scripts','Scripts'],['auto','Automation']].map(([v, l]) => (
              <button key={v} onClick={() => setView(v)}
                className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-emerald-500 text-black' : 'text-white/35 hover:text-white/60'}`}>
                {l}
              </button>
            ))}
          </div>
          {view === 'pipeline' && (
            <button onClick={() => setShowAdd(!showAdd)}
              className="flex items-center gap-1.5 px-3 py-2 bg-white/5 border border-white/10 text-white/50 text-xs rounded-xl hover:border-white/20 hover:text-white/70 transition-all">
              <Plus size={11} /> Add Lead
            </button>
          )}
        </div>

        {/* Add lead form */}
        {showAdd && view === 'pipeline' && (
          <div className="p-4 rounded-2xl border border-white/10 bg-white/3 flex items-end gap-3 flex-wrap">
            <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Name" className="px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-xs outline-none placeholder-white/20 focus:border-indigo-500/40 w-36" />
            <input value={form.email} onChange={e => setForm({...form, email: e.target.value})} placeholder="Email" className="px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-xs outline-none placeholder-white/20 focus:border-indigo-500/40 w-44" />
            <input value={form.company} onChange={e => setForm({...form, company: e.target.value})} placeholder="Company" className="px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-xs outline-none placeholder-white/20 focus:border-indigo-500/40 w-36" />
            <button onClick={addLead} className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl transition-all">Add</button>
          </div>
        )}

        {/* ── PIPELINE ─────────────────────────────────────────── */}
        {view === 'pipeline' && (
          <div className="overflow-x-auto">
            <div className="flex gap-3 min-w-max pb-2">
              {STAGES.map(stage => {
                const stageLeads = byStage(stage.id);
                const StageIcon = stage.icon;
                return (
                  <div key={stage.id} className="w-52 shrink-0">
                    {/* Column header */}
                    <div className="flex items-center gap-2 mb-2 px-1">
                      <div style={{ background: stage.bg, border: `1px solid ${stage.border}` }}
                        className="w-6 h-6 rounded-lg flex items-center justify-center">
                        <StageIcon size={10} style={{ color: stage.color }} />
                      </div>
                      <p style={{ color: stage.color }} className="text-xs font-bold">{stage.label}</p>
                      <span className="ml-auto text-white/20 text-[9px] font-semibold">{stageLeads.length}</span>
                    </div>

                    {/* Lead cards */}
                    <div className="space-y-2">
                      {stageLeads.map(lead => {
                        const score = scoreLead(lead);
                        const nextEvents = Object.entries(TRANSITIONS)
                          .filter(([, to]) => to !== lead.status)
                          .filter(([ev]) => !lead.events?.find(e => e.event === ev))
                          .slice(0, 2);

                        return (
                          <div key={lead.id} style={{ border: `1px solid ${stage.border}`, background: stage.bg }}
                            className="p-3 rounded-xl">
                            <div className="flex items-start justify-between mb-1.5">
                              <div>
                                <p className="text-xs font-semibold text-white/70">{lead.name}</p>
                                <p className="text-[9px] text-white/30">{lead.company}</p>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <span style={{ color: stage.color }} className="text-[9px] font-bold">{score}pts</span>
                                <button onClick={() => deleteLead(lead.id)} className="text-white/10 hover:text-white/35 transition-all">
                                  <Trash2 size={8} />
                                </button>
                              </div>
                            </div>

                            {/* Next action buttons */}
                            {nextEvents.length > 0 && (
                              <div className="space-y-1 mt-2">
                                {nextEvents.map(([ev]) => (
                                  <button key={ev} onClick={() => fireEvent(lead.id, ev)}
                                    className="w-full text-[9px] px-2 py-1 rounded-lg border border-white/8 bg-white/3 text-white/35 hover:text-white/60 hover:border-white/15 transition-all text-left font-semibold">
                                    ▶ {EVENT_LABELS[ev]}
                                  </button>
                                ))}
                              </div>
                            )}

                            <p className="text-white/15 text-[8px] mt-1.5 font-mono">{lead.email}</p>
                          </div>
                        );
                      })}

                      {stageLeads.length === 0 && (
                        <div className="p-4 rounded-xl border border-white/5 bg-white/1 text-center">
                          <p className="text-white/15 text-[9px]">Empty</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── SCRIPTS ──────────────────────────────────────────── */}
        {view === 'scripts' && (
          <div className="grid lg:grid-cols-[200px_1fr] gap-6">
            {/* Filter + list */}
            <div className="space-y-2">
              {/* Stage filter */}
              <div className="space-y-1">
                <p className="text-white/20 text-[9px] uppercase tracking-widest mb-1">Filter by stage</p>
                {['all', ...STAGE_IDS.slice(0, 6)].map(s => (
                  <button key={s} onClick={() => setScriptStage(s)}
                    className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition-all ${scriptStage === s ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400' : 'text-white/30 hover:text-white/55'}`}>
                    {s === 'all' ? 'All Scripts' : STAGES.find(st => st.id === s)?.label}
                  </button>
                ))}
              </div>

              <div className="border-t border-white/5 pt-2 space-y-1">
                {filteredScripts.map(s => (
                  <button key={s.id} onClick={() => setActiveScript(s)}
                    className={`w-full text-left p-2.5 rounded-xl border transition-all ${
                      activeScript.id === s.id ? 'border-emerald-500/20 bg-emerald-500/6 text-emerald-300' : 'border-white/5 bg-white/2 text-white/35 hover:text-white/55'
                    }`}>
                    <p className="text-[10px] font-semibold leading-snug">{s.label}</p>
                    <span className="text-[8px] opacity-60 font-mono">{s.channel}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Script viewer */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/60 text-sm font-semibold">{activeScript.label}</p>
                  <p className="text-white/25 text-xs">Channel: {activeScript.channel} · Stage: {STAGES.find(s => s.id === activeScript.stage)?.label}</p>
                </div>
                <CopyBtn text={activeScript.text} />
              </div>
              <div className="p-5 rounded-2xl border border-white/8 bg-black/30">
                <pre className="text-white/55 text-xs leading-relaxed whitespace-pre-wrap font-sans">{activeScript.text}</pre>
              </div>
              <div className="p-4 rounded-xl border border-emerald-500/15 bg-emerald-500/5">
                <p className="text-emerald-400 text-xs font-semibold mb-1">Pro Tip</p>
                <p className="text-white/35 text-xs leading-relaxed">
                  Personalize the [brackets] every time. Generic scripts get ignored.
                  The best salespeople use scripts as frameworks, not scripts.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ── AUTOMATION ───────────────────────────────────────── */}
        {view === 'auto' && (
          <div className="space-y-5">
            {/* Pipeline flow */}
            <div className="p-5 rounded-2xl border border-white/8 bg-[#0b0f1a]">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">CRM Flow (Auto-Triggered)</p>
              <div className="flex items-center gap-2 flex-wrap">
                {STAGES.map((s, i) => {
                  const Icon = s.icon;
                  return (
                    <div key={s.id} className="flex items-center gap-2">
                      <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl border" style={{ borderColor: s.border, background: s.bg }}>
                        <Icon size={10} style={{ color: s.color }} />
                        <p className="text-xs font-semibold" style={{ color: s.color }}>{s.label}</p>
                      </div>
                      {i < STAGES.length - 1 && <ArrowRight size={10} className="text-white/15 shrink-0" />}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Event → transition table */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Automation Rules</p>
              <div className="space-y-2">
                {Object.entries(TRANSITIONS).map(([event, to]) => {
                  const toStage = STAGES.find(s => s.id === to);
                  return (
                    <div key={event} className="flex items-center gap-3 p-3 rounded-xl border border-white/6 bg-white/1">
                      <code className="text-indigo-400 text-[10px] font-mono w-32 shrink-0">event: {event}</code>
                      <ArrowRight size={9} className="text-white/15 shrink-0" />
                      <div className="flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: toStage?.color }} />
                        <p className="text-xs text-white/45">Move to <span style={{ color: toStage?.color }} className="font-semibold">{toStage?.label}</span></p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Pipeline function code */}
            <div className="p-5 rounded-2xl border border-white/8 bg-black/30">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Backend: pipeline() function</p>
              <pre className="text-[10px] text-purple-400/80 font-mono leading-relaxed">{`function pipeline(lead, event) {
  const transitions = {
    signup:        'contacted',
    demo_booked:   'demo',
    demo_done:     'pilot',
    first_task:    'active',
    day7_complete: 'converted',
    upsell:        'expansion',
    churned:       'lost',
  };

  if (transitions[event]) {
    lead.status    = transitions[event];
    lead.updatedAt = Date.now();
    lead.events    = [
      ...(lead.events || []),
      { event, ts: Date.now() }
    ];
  }

  return lead;
}

// Usage: route PATCH /api/crm/leads/:id/event
// Body: { event: "demo_booked" }
// Auto-moves lead → next stage`}</pre>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
