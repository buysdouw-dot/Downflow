import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, AlertTriangle, Zap, Activity, ArrowRight, Bot, Users, Target } from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus, getStatusConfig, needsRecovery } from '../engine/core';
import { generateFeedback, getMotivationalQuote as getAIQuote } from '../engine/ai';
import StatusBadge from '../components/StatusBadge';
import ScoreRing from '../components/ScoreRing';
import MobileHeader from '../components/MobileHeader';

export default function Dashboard() {
  const { leaderboard, getTodayScore, getWeekScores, activeUserId, plugins, activePlugin } = useBehavior();
  const { user, tenantInfo, allUsersInTenant } = useAuth();

  const score = getTodayScore(activeUserId);
  const status = getStatus(score);
  const cfg = getStatusConfig(status);
  const plug = plugins[activePlugin];
  const weekData = getWeekScores(activeUserId);
  const recovery = needsRecovery(weekData.map((d) => d.score));

  const quote = useMemo(() => getAIQuote(status), [status]);

  const stats = useMemo(() => {
    const scores = weekData.map((d) => d.score);
    const avg = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
    const best = Math.max(...scores);
    const streak = (() => {
      let s = 0;
      for (let i = scores.length - 1; i >= 0; i--) {
        if (scores[i] >= (plug?.dailyTarget ?? 40)) s++;
        else break;
      }
      return s;
    })();
    const teamGreen = leaderboard.filter((u) => u.status === 'GREEN').length;
    return { avg, best, streak, teamGreen, teamTotal: leaderboard.length };
  }, [weekData, leaderboard, plug]);

  const aiFeedback = useMemo(
    () => generateFeedback(score, null, plug?.dailyTarget ?? 40),
    [score, plug]
  );

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload?.length) {
      const s = payload[0].value;
      const st = getStatus(s);
      const c = getStatusConfig(st);
      return (
        <div className="glass rounded-xl px-3 py-2 text-sm border border-white/10">
          <p className="text-white/50 text-xs">{label}</p>
          <p className={`font-bold ${c.color}`}>{s} pts</p>
          <StatusBadge status={st} size="xs" />
        </div>
      );
    }
    return null;
  };

  return (
    <div className="max-w-5xl">
      <MobileHeader />
    <div className="p-4 lg:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">
            Welcome back, {user?.name?.split(' ')[0]}
          </h1>
          <p className="text-white/35 text-sm mt-0.5">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            {tenantInfo && <span className="ml-2 text-white/20">· {tenantInfo.icon} {tenantInfo.name}</span>}
          </p>
        </div>
        <StatusBadge status={status} size="md" />
      </div>

      {/* Recovery alert */}
      {recovery && (
        <div className="flex items-center gap-3 p-4 rounded-xl bg-red-500/8 border border-red-500/25">
          <AlertTriangle size={18} className="text-red-400 shrink-0" />
          <div className="flex-1">
            <p className="text-red-300 text-sm font-semibold">Recovery Protocol Active</p>
            <p className="text-red-400/60 text-xs mt-0.5">2+ consecutive days below 25 pts. Log actions to break out of RED.</p>
          </div>
          <Link to="/tasks" className="text-red-400 text-xs font-semibold flex items-center gap-1 whitespace-nowrap hover:text-red-300">
            Take action <ArrowRight size={12} />
          </Link>
        </div>
      )}

      {/* Score ring + stats */}
      <div className="grid grid-cols-3 gap-4">
        {/* Ring */}
        <div className={`glass rounded-2xl p-5 flex flex-col items-center justify-center ${cfg.glow} border ${cfg.border}`}>
          <p className="text-white/30 text-[10px] uppercase tracking-widest mb-3">Today's Score</p>
          <ScoreRing score={score} target={plug?.dailyTarget ?? 40} size={120} />
          <p className="text-white/30 text-xs mt-3">{plug?.dailyTarget - score > 0 ? `${plug.dailyTarget - score} pts to target` : '✓ Target achieved'}</p>
        </div>

        {/* Stats grid */}
        <div className="col-span-2 grid grid-cols-2 gap-3">
          {[
            { label: '7-Day Avg', value: stats.avg, suffix: 'pts', icon: TrendingUp, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
            { label: 'Best Day', value: stats.best, suffix: 'pts', icon: Zap, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
            { label: 'Green Streak', value: stats.streak, suffix: 'days', icon: Activity, color: 'text-green-400', bg: 'bg-green-500/10' },
            { label: 'Team on Track', value: `${stats.teamGreen}/${stats.teamTotal}`, suffix: 'members', icon: Users, color: 'text-purple-400', bg: 'bg-purple-500/10' },
          ].map(({ label, value, suffix, icon: Icon, color, bg }) => (
            <div key={label} className="glass rounded-xl p-4 flex flex-col">
              <div className={`w-7 h-7 rounded-lg ${bg} flex items-center justify-center mb-2`}>
                <Icon size={13} className={color} />
              </div>
              <p className={`text-xl font-bold ${color}`}>{value}</p>
              <p className="text-white/20 text-[10px] mt-0.5">{suffix}</p>
              <p className="text-white/40 text-xs mt-auto pt-2">{label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* AI Feedback panel + leaderboard preview */}
      <div className="grid grid-cols-5 gap-4">
        {/* AI Insight */}
        <div className={`col-span-3 glass rounded-2xl p-5 border ${cfg.border}`}>
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-7 h-7 rounded-lg ${cfg.bg} flex items-center justify-center`}>
              <Bot size={13} className={cfg.color} />
            </div>
            <p className="text-white/50 text-xs font-semibold uppercase tracking-widest">AI Engine Analysis</p>
            <span className={`ml-auto text-[9px] font-bold px-1.5 py-0.5 rounded-full ${cfg.bg} ${cfg.color} border ${cfg.border}`}>
              {aiFeedback.tag}
            </span>
          </div>
          <p className="text-white text-sm font-medium leading-relaxed mb-3">{aiFeedback.message}</p>

          {/* Progress bar */}
          <div className="h-1.5 bg-white/6 rounded-full overflow-hidden mb-3">
            <div
              className={`h-full rounded-full ${cfg.bar} transition-all duration-1000`}
              style={{ width: `${aiFeedback.pctToTarget}%` }}
            />
          </div>

          {/* Quote */}
          <div className="pt-3 border-t border-white/6">
            <p className="text-white/25 text-xs italic leading-relaxed">{quote}</p>
          </div>
        </div>

        {/* Leaderboard preview */}
        <div className="col-span-2 glass rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-white/50 text-xs font-semibold uppercase tracking-widest">Team Today</p>
            <Link to="/leaderboard" className="text-indigo-400 text-xs hover:text-indigo-300 flex items-center gap-1">
              Full <ArrowRight size={10} />
            </Link>
          </div>
          <div className="space-y-2.5">
            {leaderboard.slice(0, 4).map((u) => {
              const uc = getStatusConfig(u.status);
              return (
                <div key={u.id} className="flex items-center gap-2.5">
                  <span className="text-white/15 text-xs font-mono w-4 text-center">{u.rank}</span>
                  <div className={`w-6 h-6 rounded-full bg-indigo-500/25 flex items-center justify-center text-[9px] font-bold text-indigo-300 shrink-0`}>
                    {u.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs font-medium truncate ${u.id === activeUserId ? 'text-indigo-300' : 'text-white/70'}`}>
                      {u.name.split(' ')[0]}
                      {u.id === activeUserId && <span className="text-indigo-400/50 ml-1 text-[9px]">you</span>}
                    </p>
                    <div className="h-1 bg-white/6 rounded-full mt-1 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${uc.bar}`}
                        style={{ width: `${Math.min(100, (u.score / (plug?.dailyTarget ?? 40)) * 100)}%` }}
                      />
                    </div>
                  </div>
                  <span className={`text-xs font-bold ${uc.color}`}>{u.score}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Weekly chart */}
      <div className="glass rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-white font-semibold text-sm">7-Day Performance</h2>
            <p className="text-white/25 text-xs mt-0.5">Score vs {plug?.dailyTarget ?? 40}pt daily target</p>
          </div>
          <div className="flex items-center gap-4 text-xs text-white/25">
            <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-indigo-400 inline-block" /> Score</span>
            <span className="flex items-center gap-1.5"><span className="w-4 h-px bg-white/20 inline-block border-dashed border-t border-white/25" /> Target</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={150}>
          <AreaChart data={weekData} margin={{ top: 5, right: 0, bottom: 0, left: -20 }}>
            <defs>
              <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="label" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 65]} />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine y={plug?.dailyTarget ?? 40} stroke="rgba(255,255,255,0.12)" strokeDasharray="4 4" />
            <Area type="monotone" dataKey="score" stroke="#6366f1" strokeWidth={2} fill="url(#scoreGrad)"
              dot={{ r: 3, fill: '#6366f1', strokeWidth: 0 }} activeDot={{ r: 5 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
    </div>
  );
}
