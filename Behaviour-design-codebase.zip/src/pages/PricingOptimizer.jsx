/**
 * PricingOptimizer — Monetization Optimizer
 * Value-based pricing. Dynamic tier logic. Revenue simulation.
 * Core principle: price behavior improvement, not features.
 */
import { useState } from 'react';
import {
  DollarSign, TrendingUp, Users, Zap, Target, ArrowRight,
  CheckCircle2, X, Star, BarChart2, RefreshCw, Flame,
  ChevronUp, ChevronDown, Info, Award, Sliders,
} from 'lucide-react';

// ── Plans ─────────────────────────────────────────────────────────────────────
const TIERS = [
  {
    id: 'starter',
    name: 'Starter',
    basePrice: 8,
    unit: 'user/mo',
    color: 'text-white/60',
    bg: 'bg-white/4',
    border: 'border-white/10',
    bar: 'bg-white/30',
    cta: 'Start Free Trial',
    tagline: 'For small teams getting started',
    features: [
      { text: 'Daily task tracking',       included: true  },
      { text: 'Score + status system',     included: true  },
      { text: 'Basic leaderboard',         included: true  },
      { text: 'Mobile app access',         included: true  },
      { text: 'AI feedback engine',        included: false },
      { text: 'CRM pipeline',              included: false },
      { text: 'Team analytics',            included: false },
      { text: 'Multi-agent AI',            included: false },
    ],
    sweet_spot: '2–5 person teams',
    users: 6,
  },
  {
    id: 'pro',
    name: 'Pro',
    basePrice: 22,
    unit: 'user/mo',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    bar: 'bg-indigo-400',
    cta: 'Start 7-Day Pilot',
    tagline: 'For sales teams serious about execution',
    badge: 'Most Popular',
    features: [
      { text: 'Everything in Starter',     included: true  },
      { text: 'AI coaching engine',        included: true  },
      { text: 'Coach personality system',  included: true  },
      { text: 'Full analytics dashboard',  included: true  },
      { text: 'CRM pipeline',              included: true  },
      { text: 'Memory engine (per-user)',   included: true  },
      { text: 'Multi-agent AI',            included: false },
      { text: 'White-label + API access',  included: false },
    ],
    sweet_spot: '5–30 person teams',
    users: 8,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    basePrice: 55,
    unit: 'user/mo',
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/8',
    border: 'border-yellow-500/20',
    bar: 'bg-yellow-400',
    cta: 'Book a Demo',
    tagline: 'For large teams that need full AI power',
    features: [
      { text: 'Everything in Pro',         included: true  },
      { text: 'Multi-agent orchestrator',  included: true  },
      { text: 'White-label branding',      included: true  },
      { text: 'API + webhook access',      included: true  },
      { text: 'Custom plugin development', included: true  },
      { text: 'Dedicated success manager', included: true  },
      { text: 'SLA + priority support',    included: true  },
      { text: 'On-premise deploy option',  included: true  },
    ],
    sweet_spot: '30–500 person teams',
    users: 3,
  },
];

// ── Optimizer rules ───────────────────────────────────────────────────────────
function optimizePricing({ engagement, churn, growth, mrr }) {
  const actions = [];
  let recommendation = 'stable';

  if (engagement > 70 && churn < 5) {
    actions.push({ type: 'increase', label: 'Raise Pro price by 10%', impact: '+$' + Math.round(mrr * 0.1) + '/mo', priority: 'high', color: 'text-emerald-400' });
    recommendation = 'increase';
  }
  if (engagement > 80 && growth > 20) {
    actions.push({ type: 'increase', label: 'Add Enterprise tier at 20% premium', impact: 'Unlock +$' + Math.round(mrr * 0.2) + '/mo', priority: 'high', color: 'text-emerald-400' });
  }
  if (churn > 15) {
    actions.push({ type: 'value', label: 'Add value: AI memory feature to Starter', impact: 'Reduce churn by ~5%', priority: 'urgent', color: 'text-red-400' });
    recommendation = 'add-value';
  }
  if (churn > 20) {
    actions.push({ type: 'discount', label: 'Offer 2-month free for annual plans', impact: 'Reduce monthly churn by 40%', priority: 'urgent', color: 'text-orange-400' });
  }
  if (engagement < 40) {
    actions.push({ type: 'engagement', label: 'Launch AI re-engagement sequence', impact: 'Reduce risk of churn cascade', priority: 'medium', color: 'text-yellow-400' });
  }
  if (growth < 5 && churn < 10) {
    actions.push({ type: 'growth', label: 'Launch referral: 1 free month per referral', impact: '+15–25 users in 30 days', priority: 'medium', color: 'text-indigo-400' });
  }

  if (actions.length === 0) {
    actions.push({ type: 'stable', label: 'Pricing is optimal — maintain current model', impact: 'No change needed', priority: 'low', color: 'text-white/40' });
  }

  return { actions, recommendation };
}

// ── Revenue simulator ─────────────────────────────────────────────────────────
function simulateRevenue(users, mix, multiplier = 1) {
  const starter    = Math.round(users * mix.starter / 100);
  const pro        = Math.round(users * mix.pro / 100);
  const enterprise = users - starter - pro;
  const mrr = (starter * TIERS[0].basePrice * multiplier)
            + (pro     * TIERS[1].basePrice * multiplier)
            + (enterprise * TIERS[2].basePrice * multiplier);
  return { starter, pro, enterprise, mrr };
}

// ── Sub-components ────────────────────────────────────────────────────────────
function TierCard({ tier, priceMultiplier, highlighted }) {
  const price = Math.round(tier.basePrice * priceMultiplier);
  return (
    <div className={`p-5 rounded-2xl border transition-all ${
      highlighted ? `${tier.border} ${tier.bg} shadow-xl` : 'border-white/8 bg-white/2'
    } relative`}>
      {tier.badge && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-indigo-500 text-white text-[9px] font-black whitespace-nowrap">
          {tier.badge}
        </div>
      )}
      <div className="mb-4">
        <p className={`text-xs font-bold uppercase tracking-widest ${tier.color} mb-1`}>{tier.name}</p>
        <div className="flex items-end gap-1.5">
          <span className={`text-3xl font-black ${tier.color}`}>${price}</span>
          <span className="text-white/30 text-xs mb-1.5">/{tier.unit}</span>
        </div>
        <p className="text-white/30 text-xs">{tier.tagline}</p>
      </div>
      <div className="space-y-1.5 mb-5">
        {tier.features.map((f) => (
          <div key={f.text} className="flex items-center gap-2">
            {f.included
              ? <CheckCircle2 size={11} className={tier.color} />
              : <X size={11} className="text-white/15" />}
            <span className={`text-xs ${f.included ? 'text-white/60' : 'text-white/20'}`}>{f.text}</span>
          </div>
        ))}
      </div>
      <div className="text-[9px] text-white/20 border-t border-white/6 pt-3">
        Sweet spot: <span className={tier.color}>{tier.sweet_spot}</span>
      </div>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function PricingOptimizer() {
  const [view,       setView]       = useState('tiers'); // 'tiers' | 'optimizer' | 'simulator'
  const [engagement, setEngagement] = useState(65);
  const [churn,      setChurn]      = useState(8);
  const [growth,     setGrowth]     = useState(14);
  const [totalUsers, setTotalUsers] = useState(85);
  const [mix,        setMix]        = useState({ starter: 35, pro: 48, enterprise: 17 });
  const [multiplier, setMultiplier] = useState(1.0);

  const sim = simulateRevenue(totalUsers, mix, multiplier);
  const mrr = sim.mrr;
  const { actions, recommendation } = optimizePricing({ engagement, churn, growth, mrr });

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <DollarSign size={14} className="text-yellow-400" />
            <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest">Pricing Optimizer</p>
          </div>
          <h1 className="text-3xl font-black mb-1">Monetization Engine</h1>
          <p className="text-white/35 text-sm">You don't price features. You price behavior improvement per user.</p>
        </div>

        {/* Core principle */}
        <div className="p-4 rounded-2xl border border-yellow-500/20 bg-yellow-500/5">
          <div className="flex items-start gap-3">
            <Info size={14} className="text-yellow-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-yellow-400 font-bold text-sm">The Pricing Principle</p>
              <p className="text-white/50 text-xs mt-1 leading-relaxed">
                A team manager pays $22/user/month not for features — they pay for <span className="text-white font-semibold">behavior improvement</span>.
                If your tool moves a team from 40% execution to 75%, that team closes more deals.
                At $50k/year in extra revenue, $22/user is nothing.
                <span className="text-yellow-400 font-semibold"> Price the outcome, not the tool.</span>
              </p>
            </div>
          </div>
        </div>

        {/* View toggle */}
        <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
          {[['tiers','Pricing Tiers'],['optimizer','Optimizer'],['simulator','Revenue Sim']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-yellow-500 text-black' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── TIERS ─────────────────────────────────────────────────── */}
        {view === 'tiers' && (
          <div className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-5">
              {TIERS.map(t => <TierCard key={t.id} tier={t} priceMultiplier={multiplier} highlighted={t.id === 'pro'} />)}
            </div>

            {/* Pricing tips */}
            <div className="grid lg:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-white/2 border border-white/6 space-y-3">
                <p className="text-white/40 text-xs font-bold uppercase tracking-widest">When to raise prices</p>
                {[
                  ['Engagement > 70%',           'Users are getting real value. Raise Pro by 10%.'],
                  ['Churn < 5%',                 'Product-market fit confirmed. Increase Starter.'],
                  ['NPS > 50',                   'Users love it. Enterprise can go to $80/user.'],
                  ['Waiting list forms',         'Demand exceeds supply. Raise immediately.'],
                ].map(([trigger, action]) => (
                  <div key={trigger} className="flex gap-2">
                    <TrendingUp size={11} className="text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-white/60 text-xs font-semibold">{trigger}: </span>
                      <span className="text-white/35 text-xs">{action}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-5 rounded-2xl bg-white/2 border border-white/6 space-y-3">
                <p className="text-white/40 text-xs font-bold uppercase tracking-widest">When to add value (not discount)</p>
                {[
                  ['Churn > 15%',               'Add a high-value feature to the plan they\'re cancelling.'],
                  ['Trial → Paid < 20%',        'Upgrade the trial experience, not the price.'],
                  ['Support tickets > 5/user',  'Build the feature they keep asking for.'],
                  ['DAU/MAU < 30%',             'Engagement problem, not pricing problem.'],
                ].map(([trigger, action]) => (
                  <div key={trigger} className="flex gap-2">
                    <Zap size={11} className="text-yellow-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-white/60 text-xs font-semibold">{trigger}: </span>
                      <span className="text-white/35 text-xs">{action}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── OPTIMIZER ─────────────────────────────────────────────── */}
        {view === 'optimizer' && (
          <div className="grid lg:grid-cols-[1fr_320px] gap-6">
            <div className="space-y-5">
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Input Metrics</p>
              {[
                { label: 'Team Engagement Rate', key: 'engagement', value: engagement, set: setEngagement, color: engagement >= 70 ? 'text-emerald-400' : engagement >= 40 ? 'text-yellow-400' : 'text-red-400', unit: '%' },
                { label: 'Monthly Churn Rate',   key: 'churn',      value: churn,      set: setChurn,      color: churn <= 5 ? 'text-emerald-400' : churn <= 15 ? 'text-yellow-400' : 'text-red-400',              unit: '%' },
                { label: 'Month-over-Month Growth', key: 'growth',  value: growth,     set: setGrowth,     color: growth >= 20 ? 'text-emerald-400' : growth >= 5 ? 'text-yellow-400' : 'text-red-400',             unit: '%' },
              ].map(({ label, key, value, set, color, unit }) => (
                <div key={key} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-white/40 text-xs">{label}</label>
                    <span className={`text-base font-black ${color}`}>{value}{unit}</span>
                  </div>
                  <input type="range" min={0} max={100} value={value}
                    onChange={e => set(Number(e.target.value))}
                    className="w-full h-1.5 accent-indigo-500 cursor-pointer" />
                </div>
              ))}

              {/* Optimizer output */}
              <div className="space-y-2 pt-2">
                <p className="text-white/40 text-xs font-bold uppercase tracking-widest">AI Recommendations</p>
                {actions.map((a, i) => (
                  <div key={i} className={`flex items-start gap-3 p-4 rounded-xl border ${
                    a.priority === 'urgent' ? 'border-red-500/20 bg-red-500/5'
                    : a.priority === 'high'   ? 'border-emerald-500/20 bg-emerald-500/5'
                    : 'border-white/8 bg-white/2'
                  }`}>
                    <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                      a.priority === 'urgent' ? 'bg-red-400' : a.priority === 'high' ? 'bg-emerald-400' : 'bg-white/30'
                    }`} />
                    <div className="flex-1">
                      <p className={`text-sm font-semibold ${a.color}`}>{a.label}</p>
                      <p className="text-white/30 text-xs mt-0.5">{a.impact}</p>
                    </div>
                    <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full border uppercase ${
                      a.priority === 'urgent' ? 'bg-red-500/15 border-red-500/25 text-red-400'
                      : a.priority === 'high'   ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400'
                      : 'bg-white/5 border-white/10 text-white/30'
                    }`}>{a.priority}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Optimizer logic panel */}
            <div className="space-y-4">
              <p className="text-white/25 text-[9px] uppercase tracking-widest">Optimizer Logic</p>
              <div className="p-4 rounded-2xl bg-black/30 border border-white/8">
                <pre className="text-[9px] text-indigo-400/70 leading-relaxed overflow-x-auto scrollbar-hide">{`function optimizePricing({
  engagement, churn, growth
}) {
  // Rule 1: High engagement = raise price
  if (engagement > 70 && churn < 5)
    return increasePrice(10%)

  // Rule 2: High churn = add value
  if (churn > 15)
    return addValueFeature()

  // Rule 3: Low growth = referral
  if (growth < 5 && churn < 10)
    return launchReferralProgram()

  return stablePricing()
}`}</pre>
              </div>
              <div className="p-4 rounded-2xl bg-white/2 border border-white/6 space-y-2">
                <p className="text-white/25 text-[9px] uppercase tracking-widest">Current Signal</p>
                <div className={`p-3 rounded-xl border ${
                  recommendation === 'increase'  ? 'border-emerald-500/20 bg-emerald-500/8 text-emerald-400'
                  : recommendation === 'add-value' ? 'border-red-500/20 bg-red-500/8 text-red-400'
                  : 'border-white/8 bg-white/3 text-white/40'
                } text-xs font-bold`}>
                  {recommendation === 'increase'  ? 'Raise prices now'
                  : recommendation === 'add-value' ? 'Add value — do not discount'
                  : 'Pricing stable — maintain'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── SIMULATOR ─────────────────────────────────────────────── */}
        {view === 'simulator' && (
          <div className="space-y-5">
            <div className="grid lg:grid-cols-[1fr_280px] gap-6">
              <div className="space-y-5">
                {/* Inputs */}
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <div className="flex justify-between">
                      <label className="text-white/40 text-xs">Total Users</label>
                      <span className="text-white font-bold text-sm">{totalUsers}</span>
                    </div>
                    <input type="range" min={5} max={500} value={totalUsers}
                      onChange={e => setTotalUsers(Number(e.target.value))}
                      className="w-full accent-indigo-500" />
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex justify-between">
                      <label className="text-white/40 text-xs">Price Multiplier (1.0 = base)</label>
                      <span className="text-yellow-400 font-bold text-sm">{multiplier.toFixed(1)}x</span>
                    </div>
                    <input type="range" min={0.5} max={2.0} step={0.1} value={multiplier}
                      onChange={e => setMultiplier(Number(e.target.value))}
                      className="w-full accent-yellow-500" />
                  </div>
                  {/* Plan mix sliders */}
                  {[
                    { key: 'starter',    label: 'Starter %',    tier: TIERS[0] },
                    { key: 'pro',        label: 'Pro %',        tier: TIERS[1] },
                  ].map(({ key, label, tier }) => (
                    <div key={key} className="space-y-1.5">
                      <div className="flex justify-between">
                        <label className="text-white/40 text-xs">{label}</label>
                        <span className={`font-bold text-sm ${tier.color}`}>{mix[key]}%</span>
                      </div>
                      <input type="range" min={0} max={80} value={mix[key]}
                        onChange={e => setMix(prev => ({
                          starter:    key === 'starter'    ? Number(e.target.value) : prev.starter,
                          pro:        key === 'pro'        ? Number(e.target.value) : prev.pro,
                          enterprise: 100 - (key === 'starter' ? Number(e.target.value) : prev.starter) - (key === 'pro' ? Number(e.target.value) : prev.pro),
                        }))}
                        className="w-full accent-indigo-500" />
                    </div>
                  ))}
                </div>

                {/* Breakdown bar */}
                <div>
                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Revenue Breakdown</p>
                  <div className="h-4 rounded-full overflow-hidden flex">
                    {TIERS.map((t, i) => {
                      const cnt = i === 0 ? sim.starter : i === 1 ? sim.pro : sim.enterprise;
                      const pct = totalUsers ? (cnt / totalUsers) * 100 : 0;
                      return <div key={t.id} className={`${t.bar} transition-all duration-500`} style={{ width: `${pct}%` }} />;
                    })}
                  </div>
                  <div className="flex gap-4 mt-2">
                    {TIERS.map((t, i) => {
                      const cnt = i === 0 ? sim.starter : i === 1 ? sim.pro : sim.enterprise;
                      const rev = cnt * Math.round(t.basePrice * multiplier);
                      return (
                        <div key={t.id} className="flex items-center gap-1.5">
                          <div className={`w-2 h-2 rounded-full ${t.bar}`} />
                          <span className="text-white/30 text-[9px]">{t.name}: {cnt} users · ${rev.toLocaleString()}/mo</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Annual projections */}
                <div className="p-4 rounded-2xl bg-white/2 border border-white/6">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Annual Projections</p>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      ['MRR',   '$' + sim.mrr.toLocaleString(),      'text-emerald-400'],
                      ['ARR',   '$' + (sim.mrr * 12).toLocaleString(),'text-indigo-400' ],
                      ['LTV',   '$' + Math.round(sim.mrr / totalUsers * 18 || 0).toLocaleString() + ' avg', 'text-yellow-400'],
                    ].map(([l, v, c]) => (
                      <div key={l} className="text-center p-3 rounded-xl bg-white/3 border border-white/6">
                        <p className={`text-lg font-black ${c}`}>{v}</p>
                        <p className="text-white/25 text-[9px]">{l}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Milestone table */}
              <div className="space-y-3">
                <p className="text-white/25 text-[9px] uppercase tracking-widest">Revenue Milestones</p>
                <div className="space-y-2">
                  {[
                    { label: '$1K MRR',    users: Math.ceil(1000 / (sim.mrr / Math.max(1, totalUsers))),   milestone: 'Proof of concept'   },
                    { label: '$5K MRR',    users: Math.ceil(5000 / (sim.mrr / Math.max(1, totalUsers))),   milestone: 'Real traction'       },
                    { label: '$10K MRR',   users: Math.ceil(10000 / (sim.mrr / Math.max(1, totalUsers))),  milestone: 'Fundable'            },
                    { label: '$50K MRR',   users: Math.ceil(50000 / (sim.mrr / Math.max(1, totalUsers))),  milestone: 'Series A territory'  },
                    { label: '$100K MRR',  users: Math.ceil(100000 / (sim.mrr / Math.max(1, totalUsers))), milestone: 'Scale phase'         },
                  ].map(({ label, users: needed, milestone }) => {
                    const reached = totalUsers >= needed;
                    return (
                      <div key={label} className={`flex items-center justify-between p-3 rounded-xl border ${
                        reached ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/6 bg-white/2'
                      }`}>
                        <div>
                          <p className={`text-xs font-bold ${reached ? 'text-emerald-400' : 'text-white/50'}`}>
                            {reached ? '✅ ' : ''}{label}
                          </p>
                          <p className="text-white/20 text-[9px]">{milestone}</p>
                        </div>
                        <div className="text-right">
                          <p className={`text-[9px] font-semibold ${reached ? 'text-emerald-400' : 'text-white/25'}`}>
                            {reached ? 'Reached' : `${needed} users`}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
