/**
 * PixelOnboarding — Pixel-Level Onboarding UI
 * 5 screens: Welcome → Role → Goal → First Task (90s timer) → First Reward
 * Designed to convert users to active in under 90 seconds.
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBehavior } from '../store/BehaviorContext';
import {
  Zap, TrendingUp, Users, Target, Flame, CheckCircle2,
  ArrowRight, Clock, BarChart2, Star, Shield, Bot,
} from 'lucide-react';

// ── Screen definitions ────────────────────────────────────────────────────────
const SCREENS = ['welcome', 'role', 'goal', 'task', 'reward'];

const ROLES = [
  {
    id: 'sales',
    emoji: '💼',
    title: 'Salesperson',
    desc: 'I close deals and manage pipeline',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/12',
    border: 'border-indigo-500/30',
    activeGlow: 'shadow-indigo-500/20',
    task: 'Send 1 outreach message to a new prospect',
    taskPoints: 10,
  },
  {
    id: 'manager',
    emoji: '📊',
    title: 'Manager',
    desc: 'I oversee team performance and execution',
    color: 'text-purple-400',
    bg: 'bg-purple-500/12',
    border: 'border-purple-500/30',
    activeGlow: 'shadow-purple-500/20',
    task: 'Review yesterday\'s team execution scores',
    taskPoints: 8,
  },
  {
    id: 'operator',
    emoji: '⚙️',
    title: 'Operator',
    desc: 'I run operations, logistics or processes',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/12',
    border: 'border-emerald-500/30',
    activeGlow: 'shadow-emerald-500/20',
    task: 'Write down your top 3 priorities for today',
    taskPoints: 8,
  },
];

const GOALS = [
  {
    id: 'consistency',
    emoji: '📅',
    title: 'Build Consistency',
    desc: 'I want to show up every day, no matter what',
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/12',
    border: 'border-cyan-500/30',
  },
  {
    id: 'output',
    emoji: '🚀',
    title: 'Increase Output',
    desc: 'I want to produce more — calls, tasks, revenue',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/12',
    border: 'border-indigo-500/30',
  },
  {
    id: 'discipline',
    emoji: '🔥',
    title: 'Lock In Discipline',
    desc: 'I want to eliminate excuses and track real performance',
    color: 'text-red-400',
    bg: 'bg-red-500/12',
    border: 'border-red-500/30',
  },
];

// ── Reusable components ───────────────────────────────────────────────────────
function TopBar({ step, total }) {
  const pct = ((step) / (total - 1)) * 100;
  return (
    <div className="px-6 pt-6 pb-2">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-indigo-500 flex items-center justify-center">
            <Zap size={12} className="text-white" />
          </div>
          <span className="text-white/50 text-xs font-bold">Behavior Engine</span>
        </div>
        <span className="text-white/20 text-xs">{step + 1} / {total}</span>
      </div>
      <div className="h-0.5 bg-white/8 rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
          style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function SelectCard({ emoji, title, desc, color, bg, border, selected, onClick, activeGlow }) {
  return (
    <button onClick={onClick}
      className={`w-full flex items-center gap-4 p-4 rounded-2xl border text-left transition-all duration-200 ${
        selected
          ? `${bg} ${border} ${activeGlow ? `shadow-lg ${activeGlow}` : ''} scale-[1.01]`
          : 'bg-white/2 border-white/8 hover:bg-white/4 hover:border-white/15'
      }`}>
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0 ${selected ? bg : 'bg-white/4'} border ${selected ? border : 'border-white/6'}`}>
        {emoji}
      </div>
      <div className="flex-1 min-w-0">
        <p className={`font-bold text-sm ${selected ? color : 'text-white/80'}`}>{title}</p>
        <p className="text-white/30 text-xs mt-0.5 leading-snug">{desc}</p>
      </div>
      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
        selected ? `${border} ${bg}` : 'border-white/15'
      }`}>
        {selected && <div className={`w-2 h-2 rounded-full ${color.replace('text-', 'bg-')}`} />}
      </div>
    </button>
  );
}

// ── Screen 1: Welcome ─────────────────────────────────────────────────────────
function WelcomeScreen({ onNext }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 py-8 text-center space-y-8">
      {/* Animated icon */}
      <div className="relative">
        <div className="w-24 h-24 rounded-3xl bg-indigo-500 flex items-center justify-center shadow-2xl shadow-indigo-500/40 mx-auto">
          <Zap size={40} className="text-white" />
        </div>
        <div className="absolute -top-2 -right-2 w-8 h-8 rounded-xl bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/30">
          <TrendingUp size={14} className="text-white" />
        </div>
        <div className="absolute -bottom-2 -left-2 w-8 h-8 rounded-xl bg-purple-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
          <Bot size={14} className="text-white" />
        </div>
      </div>

      <div className="space-y-3 max-w-xs">
        <h1 className="text-3xl font-black leading-tight">
          Behavior Engine
        </h1>
        <p className="text-white/45 text-base leading-relaxed">
          Turn daily actions into measurable performance.
        </p>
      </div>

      {/* Feature pills */}
      <div className="flex flex-wrap justify-center gap-2">
        {[
          { icon: '📊', text: 'Live Scoring'    },
          { icon: '🤖', text: 'AI Coaching'     },
          { icon: '🏆', text: 'Leaderboards'    },
          { icon: '🔥', text: 'Streak Tracking' },
        ].map(({ icon, text }) => (
          <div key={text} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/8 text-xs text-white/50">
            <span>{icon}</span> {text}
          </div>
        ))}
      </div>

      <div className="w-full space-y-3 pt-2">
        <button onClick={onNext}
          className="w-full py-4 bg-indigo-500 hover:bg-indigo-400 rounded-2xl text-base font-bold text-white transition-all shadow-2xl shadow-indigo-500/30 hover:scale-[1.01] flex items-center justify-center gap-2">
          Get Started <ArrowRight size={16} />
        </button>
        <p className="text-white/15 text-xs text-center">Free 7-day pilot · No card required</p>
      </div>
    </div>
  );
}

// ── Screen 2: Role Selection ──────────────────────────────────────────────────
function RoleScreen({ onNext }) {
  const [selected, setSelected] = useState(null);
  return (
    <div className="flex-1 flex flex-col px-6 py-8 space-y-6">
      <div className="text-center space-y-1">
        <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">Step 1</p>
        <h2 className="text-2xl font-black">What is your role?</h2>
        <p className="text-white/30 text-sm">This loads your behavior plugin automatically.</p>
      </div>

      <div className="flex-1 flex flex-col justify-center space-y-3">
        {ROLES.map(role => (
          <SelectCard key={role.id} {...role} selected={selected?.id === role.id} onClick={() => setSelected(role)} />
        ))}
      </div>

      <button onClick={() => selected && onNext(selected)}
        disabled={!selected}
        className={`w-full py-4 rounded-2xl text-base font-bold transition-all ${
          selected
            ? `${selected.bg} ${selected.color} border ${selected.border} hover:opacity-90 shadow-lg`
            : 'bg-white/5 text-white/20 cursor-not-allowed'
        }`}>
        {selected ? `Continue as ${selected.title} →` : 'Select your role'}
      </button>
    </div>
  );
}

// ── Screen 3: Goal Selection ──────────────────────────────────────────────────
function GoalScreen({ onNext }) {
  const [selected, setSelected] = useState(null);
  return (
    <div className="flex-1 flex flex-col px-6 py-8 space-y-6">
      <div className="text-center space-y-1">
        <p className="text-purple-400 text-xs font-bold uppercase tracking-widest">Step 2</p>
        <h2 className="text-2xl font-black">What do you want to improve?</h2>
        <p className="text-white/30 text-sm">Your AI coach adapts its style to match your goal.</p>
      </div>

      <div className="flex-1 flex flex-col justify-center space-y-3">
        {GOALS.map(goal => (
          <SelectCard key={goal.id} {...goal} selected={selected?.id === goal.id} onClick={() => setSelected(goal)} />
        ))}
      </div>

      <button onClick={() => selected && onNext(selected)}
        disabled={!selected}
        className={`w-full py-4 rounded-2xl text-base font-bold transition-all ${
          selected
            ? `${selected.bg} ${selected.color} border ${selected.border} hover:opacity-90 shadow-lg`
            : 'bg-white/5 text-white/20 cursor-not-allowed'
        }`}>
        {selected ? `Set goal: ${selected.title} →` : 'Choose your goal'}
      </button>
    </div>
  );
}

// ── Screen 4: First Task ──────────────────────────────────────────────────────
function TaskScreen({ role, onComplete }) {
  const [done, setDone]     = useState(false);
  const [timer, setTimer]   = useState(90);
  const [urgent, setUrgent] = useState(false);
  const { logAction, plugins, activePlugin } = useBehavior();
  const plug = plugins[activePlugin];

  useEffect(() => {
    if (done) return;
    const interval = setInterval(() => {
      setTimer(prev => {
        const next = prev - 1;
        if (next <= 30) setUrgent(true);
        if (next <= 0) { clearInterval(interval); return 0; }
        return next;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [done]);

  const handleDone = () => {
    const firstTask = plug?.tasks?.[0];
    if (firstTask) logAction(firstTask.id, 1);
    setDone(true);
    setTimeout(onComplete, 900);
  };

  const urgentPulse = urgent && !done && timer > 0;
  const timerColor  = timer > 60 ? 'text-emerald-400' : timer > 30 ? 'text-yellow-400' : 'text-red-400';
  const timerBg     = timer > 60 ? 'bg-emerald-500/10 border-emerald-500/20' : timer > 30 ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-red-500/10 border-red-500/20 animate-pulse';

  return (
    <div className="flex-1 flex flex-col px-6 py-8 space-y-6">
      <div className="text-center space-y-1">
        <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest">Step 3 — Critical</p>
        <h2 className="text-2xl font-black">Your First Task</h2>
        <p className="text-white/30 text-sm">Do this right now. It takes 60 seconds.</p>
      </div>

      {/* Timer */}
      {!done && (
        <div className={`flex items-center justify-center gap-2 py-2 px-4 rounded-xl border w-fit mx-auto ${timerBg}`}>
          <Clock size={12} className={timerColor} />
          <span className={`text-sm font-black font-mono ${timerColor}`}>{timer}s</span>
          {urgentPulse && <span className="text-[9px] text-red-400 font-bold animate-pulse">URGENT</span>}
        </div>
      )}

      {/* Task card */}
      <div className={`p-6 rounded-2xl border-2 relative overflow-hidden transition-all ${
        done
          ? 'border-emerald-500/50 bg-emerald-500/8'
          : urgentPulse
          ? 'border-red-500/50 bg-red-500/5'
          : `${role.border} ${role.bg}`
      }`}>
        {done && (
          <div className="absolute inset-0 bg-emerald-500/5 pointer-events-none" />
        )}
        <p className="text-white/30 text-[10px] uppercase tracking-widest mb-3">Task #1 · {role.emoji} {role.title}</p>
        <p className={`text-xl font-bold leading-snug mb-4 ${done ? 'text-emerald-400' : 'text-white'}`}>
          {done && '✓ '}{role.task}
        </p>
        <div className="flex items-center gap-2">
          <div className={`text-xs font-bold px-2.5 py-1 rounded-full ${done ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25' : `${role.bg} ${role.color} border ${role.border}`}`}>
            +{role.taskPoints} pts
          </div>
          {done && <span className="text-emerald-400 text-xs font-semibold">Logged ✓</span>}
        </div>
      </div>

      {/* Action button */}
      {!done ? (
        <button onClick={handleDone}
          className={`w-full py-5 rounded-2xl text-lg font-black text-white transition-all flex items-center justify-center gap-3 shadow-2xl ${
            urgentPulse
              ? 'bg-red-500 hover:bg-red-400 shadow-red-500/30 animate-pulse'
              : 'bg-emerald-500 hover:bg-emerald-400 shadow-emerald-500/30'
          }`}>
          <CheckCircle2 size={22} />
          DONE — Mark Complete
        </button>
      ) : (
        <div className="flex flex-col items-center gap-2 py-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
            <CheckCircle2 size={30} className="text-emerald-400" />
          </div>
          <p className="text-emerald-400 font-bold">Task Complete!</p>
          <p className="text-white/25 text-sm">Loading your reward…</p>
        </div>
      )}

      {timer === 0 && !done && (
        <p className="text-red-400/60 text-center text-xs">
          Time's up — but you can still complete it! Every logged action counts.
        </p>
      )}
    </div>
  );
}

// ── Screen 5: First Reward ────────────────────────────────────────────────────
function RewardScreen({ role, goal, onFinish }) {
  const { getTodayScore, activeUserId } = useBehavior();
  const score = getTodayScore(activeUserId);
  const [showNext, setShowNext] = useState(false);

  useEffect(() => {
    setTimeout(() => setShowNext(true), 800);
  }, []);

  return (
    <div className="flex-1 flex flex-col px-6 py-8 items-center space-y-6">
      {/* Celebration */}
      <div className="text-center space-y-4 w-full">
        <div className="relative w-fit mx-auto">
          <div className="w-24 h-24 rounded-3xl bg-emerald-500/15 border-2 border-emerald-500/40 flex items-center justify-center mx-auto">
            <CheckCircle2 size={44} className="text-emerald-400" />
          </div>
          <div className="absolute -top-3 -right-3 text-3xl animate-bounce">🎉</div>
          <div className="absolute -bottom-2 -left-3 text-2xl">⚡</div>
        </div>
        <div>
          <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-1">Task Completed</p>
          <h2 className="text-3xl font-black mb-2">You are now active.</h2>
          <p className="text-white/40 text-sm">
            Every action from here compounds. Don't break the chain.
          </p>
        </div>
      </div>

      {/* Score card */}
      <div className="w-full p-5 rounded-2xl bg-emerald-500/8 border border-emerald-500/25">
        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <p className="text-2xl font-black text-emerald-400">{score}</p>
            <p className="text-white/25 text-[9px] uppercase tracking-wide mt-0.5">Today's Score</p>
          </div>
          <div>
            <p className="text-2xl font-black text-orange-400">🔥 1</p>
            <p className="text-white/25 text-[9px] uppercase tracking-wide mt-0.5">Day Streak</p>
          </div>
          <div>
            <p className="text-2xl font-black text-indigo-400">+{role.taskPoints}</p>
            <p className="text-white/25 text-[9px] uppercase tracking-wide mt-0.5">Points Earned</p>
          </div>
        </div>
        <div className="mt-3 h-1.5 bg-white/8 rounded-full overflow-hidden">
          <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min(100, (score / 40) * 100)}%` }} />
        </div>
        <p className="text-white/20 text-[9px] text-center mt-1">{score} / 40 pts to GREEN status</p>
      </div>

      {/* Profile summary */}
      <div className="w-full p-4 rounded-xl bg-white/3 border border-white/6 space-y-2">
        <p className="text-white/25 text-[9px] uppercase tracking-widest">Your Setup</p>
        <div className="grid grid-cols-2 gap-2">
          {[
            { icon: role.emoji,  label: 'Role',  value: role.title   },
            { icon: goal.emoji,  label: 'Goal',  value: goal.title   },
            { icon: '🔥',        label: 'Coach', value: 'Disciplinarian' },
            { icon: '📅',        label: 'Target','value': '40 pts / day' },
          ].map(({ icon, label, value }) => (
            <div key={label} className="flex items-center gap-2">
              <span className="text-base">{icon}</span>
              <div>
                <p className="text-white/25 text-[8px]">{label}</p>
                <p className="text-white/70 text-xs font-semibold">{value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      {showNext && (
        <button onClick={onFinish}
          className="w-full py-4 bg-indigo-500 hover:bg-indigo-400 rounded-2xl text-base font-bold text-white transition-all shadow-xl shadow-indigo-500/25 flex items-center justify-center gap-2">
          Open My Dashboard <ArrowRight size={16} />
        </button>
      )}
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export default function PixelOnboarding() {
  const navigate = useNavigate();
  const [screenIdx, setScreenIdx] = useState(0);
  const [role,  setRole]  = useState(null);
  const [goal,  setGoal]  = useState(null);

  const next = useCallback(() => {
    setScreenIdx(i => Math.min(i + 1, SCREENS.length - 1));
  }, []);

  const finish = useCallback(() => {
    navigate('/');
  }, [navigate]);

  const currentRole = role ?? ROLES[0];
  const currentGoal = goal ?? GOALS[0];

  return (
    <div className="min-h-screen bg-[#05080f] text-white flex flex-col">
      {/* Top bar with progress */}
      <TopBar step={screenIdx} total={SCREENS.length} />

      {/* Screen content */}
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full">
        {screenIdx === 0 && <WelcomeScreen onNext={next} />}
        {screenIdx === 1 && (
          <RoleScreen onNext={r => { setRole(r); next(); }} />
        )}
        {screenIdx === 2 && (
          <GoalScreen onNext={g => { setGoal(g); next(); }} />
        )}
        {screenIdx === 3 && (
          <TaskScreen role={currentRole} onComplete={next} />
        )}
        {screenIdx === 4 && (
          <RewardScreen role={currentRole} goal={currentGoal} onFinish={finish} />
        )}
      </div>
    </div>
  );
}
