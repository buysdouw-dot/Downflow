import { useState, useMemo } from 'react';
import {
  Users, Plus, Search, Phone, Mail, Building2,
  ChevronRight, Clock, CheckCircle2, X, Edit3,
  TrendingUp, Flame, ArrowRight, Filter, MoreHorizontal,
  Star, AlertCircle, Circle,
} from 'lucide-react';
import MobileHeader from '../components/MobileHeader';

// ── Pipeline stages ───────────────────────────────────────────────────────────
const STAGES = [
  { id: 'lead',      label: 'Lead',      color: 'text-white/40',  bg: 'bg-white/5',       border: 'border-white/8',       dot: 'bg-white/30' },
  { id: 'contacted', label: 'Contacted', color: 'text-blue-400',  bg: 'bg-blue-500/10',   border: 'border-blue-500/20',   dot: 'bg-blue-400' },
  { id: 'trial',     label: 'Trial',     color: 'text-yellow-400',bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', dot: 'bg-yellow-400' },
  { id: 'active',    label: 'Active',    color: 'text-indigo-400',bg: 'bg-indigo-500/10', border: 'border-indigo-500/20', dot: 'bg-indigo-400' },
  { id: 'paying',    label: 'Paying',    color: 'text-green-400', bg: 'bg-green-500/10',  border: 'border-green-500/20',  dot: 'bg-green-400' },
  { id: 'churned',   label: 'Churned',   color: 'text-red-400',   bg: 'bg-red-500/10',    border: 'border-red-500/20',    dot: 'bg-red-400' },
];

const SOURCES = ['LinkedIn', 'Cold Email', 'WhatsApp', 'Referral', 'Inbound', 'Twitter', 'Other'];
const INDUSTRIES = ['Sales Team', 'Agency', 'Coaching', 'Call Center', 'Operations', 'Education', 'Fitness', 'Tech'];

const AVATARS = ['from-indigo-500 to-purple-600','from-emerald-500 to-teal-600','from-amber-500 to-orange-600','from-pink-500 to-rose-600','from-cyan-500 to-blue-600'];

// ── Seed data ─────────────────────────────────────────────────────────────────
const SEED_LEADS = [
  { id: 1, name: 'Marcus Thompson', company: 'NovaSales Inc.', email: 'marcus@novasales.co', phone: '+1 555 0102', status: 'paying', source: 'LinkedIn', industry: 'Sales Team', users: 14, value: 700, notes: 'Converted from pilot. Very happy with leaderboard. Wants AI upgrade.', lastContact: '2026-04-22', followUp: '2026-05-01', starred: true },
  { id: 2, name: 'Sarah Kim', company: 'GrowthCraft Agency', email: 'sarah@growthcraft.io', phone: '+1 555 0201', status: 'trial', source: 'Cold Email', industry: 'Agency', users: 8, value: 400, notes: 'Day 4 of pilot. Team is engaged. Follow up with results data.', lastContact: '2026-04-21', followUp: '2026-04-25', starred: true },
  { id: 3, name: 'James Okafor', company: 'PeakOps Ltd.', email: 'james@peakops.com', phone: '+1 555 0303', status: 'contacted', source: 'WhatsApp', industry: 'Operations', users: 22, value: 1100, notes: 'Interested but wants to see demo. Book call this week.', lastContact: '2026-04-20', followUp: '2026-04-24', starred: false },
  { id: 4, name: 'Priya Sharma', company: 'Elite Coaching Co.', email: 'priya@elitecoach.com', phone: '+44 7700 900123', status: 'active', source: 'Referral', industry: 'Coaching', users: 6, value: 300, notes: 'Running active trial. No payment yet. Check in on results.', lastContact: '2026-04-19', followUp: '2026-04-26', starred: false },
  { id: 5, name: 'David Chen', company: 'CallFlow Center', email: 'david@callflow.net', phone: '+1 555 0505', status: 'lead', source: 'Twitter', industry: 'Call Center', users: 45, value: 2250, notes: 'Responded to post. Seems interested. Send cold DM script.', lastContact: '2026-04-18', followUp: '2026-04-24', starred: false },
  { id: 6, name: 'Amara Diallo', company: 'EduMax Schools', email: 'amara@edumax.org', phone: '+27 82 555 0606', status: 'paying', source: 'Inbound', industry: 'Education', users: 30, value: 1500, notes: 'Happy customer. Wants to expand to 2nd campus. Upsell opportunity.', lastContact: '2026-04-23', followUp: '2026-05-01', starred: true },
  { id: 7, name: 'Luca Ferrari', company: 'IronFit Gym', email: 'luca@ironfit.it', phone: '+39 02 5550707', status: 'churned', source: 'LinkedIn', industry: 'Fitness', users: 5, value: 0, notes: 'Churned after month 2. Said team didn\'t adopt. Need re-engagement strategy.', lastContact: '2026-03-15', followUp: null, starred: false },
  { id: 8, name: 'Nina Roberts', company: 'TechStack Devs', email: 'nina@techstack.dev', phone: '+1 555 0808', status: 'trial', source: 'Cold Email', industry: 'Tech', users: 12, value: 600, notes: 'Day 1 of pilot. Engineer team. Very metric-driven — send data.', lastContact: '2026-04-23', followUp: '2026-04-26', starred: false },
];

function stageConfig(stageId) {
  return STAGES.find(s => s.id === stageId) ?? STAGES[0];
}

function initials(name) {
  return name.trim().split(' ').map(p => p[0]).join('').toUpperCase().slice(0, 2);
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const diff = Math.round((new Date(dateStr) - new Date()) / 86400000);
  return diff;
}

// ── Lead Form ─────────────────────────────────────────────────────────────────
function LeadForm({ lead, onSave, onClose }) {
  const [form, setForm] = useState(lead ?? {
    name: '', company: '', email: '', phone: '',
    status: 'lead', source: 'LinkedIn', industry: 'Sales Team',
    users: '', value: '', notes: '', followUp: '', starred: false,
  });
  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-lg glass rounded-2xl border border-white/12 overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/6">
          <p className="text-white font-bold text-sm">{lead ? 'Edit Lead' : 'Add New Lead'}</p>
          <button onClick={onClose} className="text-white/30 hover:text-white/70"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-3 max-h-[70vh] overflow-y-auto scrollbar-hide">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Name', key: 'name', type: 'text', placeholder: 'Full name' },
              { label: 'Company', key: 'company', type: 'text', placeholder: 'Company name' },
              { label: 'Email', key: 'email', type: 'email', placeholder: 'email@company.com' },
              { label: 'Phone', key: 'phone', type: 'text', placeholder: '+1 555 0100' },
            ].map(({ label, key, type, placeholder }) => (
              <div key={key}>
                <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">{label}</p>
                <input
                  type={type}
                  value={form[key]}
                  onChange={e => set(key, e.target.value)}
                  placeholder={placeholder}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm placeholder:text-white/20 outline-none focus:border-indigo-500/50"
                />
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">Stage</p>
              <select value={form.status} onChange={e => set('status', e.target.value)}
                className="w-full bg-[#0b0f1a] border border-white/10 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-indigo-500/50">
                {STAGES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">Source</p>
              <select value={form.source} onChange={e => set('source', e.target.value)}
                className="w-full bg-[#0b0f1a] border border-white/10 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-indigo-500/50">
                {SOURCES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">Industry</p>
              <select value={form.industry} onChange={e => set('industry', e.target.value)}
                className="w-full bg-[#0b0f1a] border border-white/10 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-indigo-500/50">
                {INDUSTRIES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">Team Size</p>
              <input type="number" value={form.users} onChange={e => set('users', e.target.value)}
                placeholder="10" className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm placeholder:text-white/20 outline-none focus:border-indigo-500/50" />
            </div>
            <div>
              <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">MRR Value ($)</p>
              <input type="number" value={form.value} onChange={e => set('value', e.target.value)}
                placeholder="500" className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm placeholder:text-white/20 outline-none focus:border-indigo-500/50" />
            </div>
          </div>
          <div>
            <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">Follow-up Date</p>
            <input type="date" value={form.followUp ?? ''} onChange={e => set('followUp', e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm outline-none focus:border-indigo-500/50" />
          </div>
          <div>
            <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">Notes</p>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={3}
              placeholder="Context, next steps, objections..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm placeholder:text-white/20 outline-none focus:border-indigo-500/50 resize-none" />
          </div>
        </div>
        <div className="px-5 py-4 border-t border-white/6 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl glass border border-white/8 text-white/40 text-sm hover:text-white/70 transition-all">Cancel</button>
          <button onClick={() => onSave(form)} className="flex-1 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white text-sm font-semibold transition-all">
            {lead ? 'Save Changes' : 'Add Lead'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main CRM ──────────────────────────────────────────────────────────────────
export default function CRM() {
  const [leads, setLeads] = useState(SEED_LEADS);
  const [search, setSearch] = useState('');
  const [filterStage, setFilterStage] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editLead, setEditLead] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [view, setView] = useState('list'); // 'list' | 'pipeline'

  const filtered = useMemo(() => leads.filter(l => {
    const matchSearch = !search || l.name.toLowerCase().includes(search.toLowerCase()) || l.company.toLowerCase().includes(search.toLowerCase());
    const matchStage = filterStage === 'all' || l.status === filterStage;
    return matchSearch && matchStage;
  }), [leads, search, filterStage]);

  const pipelineCounts = useMemo(() => {
    const counts = {};
    STAGES.forEach(s => { counts[s.id] = leads.filter(l => l.status === s.id).length; });
    return counts;
  }, [leads]);

  const totalMRR = leads.filter(l => l.status === 'paying').reduce((s, l) => s + (l.value || 0), 0);
  const pipelineValue = leads.filter(l => ['contacted', 'trial', 'active'].includes(l.status)).reduce((s, l) => s + (l.value || 0), 0);
  const conversionRate = leads.length > 0 ? Math.round((leads.filter(l => l.status === 'paying').length / leads.length) * 100) : 0;
  const dueFollowUps = leads.filter(l => l.followUp && daysUntil(l.followUp) <= 1 && l.status !== 'churned').length;

  const saveLead = (form) => {
    if (editLead) {
      setLeads(prev => prev.map(l => l.id === editLead.id ? { ...l, ...form } : l));
    } else {
      setLeads(prev => [...prev, { ...form, id: Date.now(), lastContact: new Date().toISOString().split('T')[0] }]);
    }
    setShowForm(false);
    setEditLead(null);
  };

  const moveStage = (leadId, direction) => {
    setLeads(prev => prev.map(l => {
      if (l.id !== leadId) return l;
      const idx = STAGES.findIndex(s => s.id === l.status);
      const newIdx = Math.max(0, Math.min(STAGES.length - 1, idx + direction));
      return { ...l, status: STAGES[newIdx].id, lastContact: new Date().toISOString().split('T')[0] };
    }));
  };

  const toggleStar = (id) => setLeads(prev => prev.map(l => l.id === id ? { ...l, starred: !l.starred } : l));
  const deleteLead = (id) => setLeads(prev => prev.filter(l => l.id !== id));

  return (
    <div className="max-w-5xl mx-auto">
      <MobileHeader title="CRM" />

      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users size={16} className="text-indigo-400" />
            <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">Sales CRM</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Pipeline & Leads</h1>
          <p className="text-white/35 text-sm mt-0.5">Track every company from cold outreach to paying client</p>
        </div>
        <button
          onClick={() => { setEditLead(null); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-500 hover:bg-indigo-400 rounded-xl text-sm font-semibold text-white transition-all"
        >
          <Plus size={14} /> Add Lead
        </button>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-4">
        {/* KPI row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'MRR',           value: `$${totalMRR.toLocaleString()}`, sub: `${leads.filter(l=>l.status==='paying').length} paying clients`, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
            { label: 'Pipeline Value', value: `$${pipelineValue.toLocaleString()}`, sub: 'Active opportunities', color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
            { label: 'Conv. Rate',    value: `${conversionRate}%`,  sub: 'Lead to paying', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
            { label: 'Follow-ups Due',value: dueFollowUps,          sub: dueFollowUps > 0 ? 'Need action today' : 'All clear', color: dueFollowUps > 0 ? 'text-red-400' : 'text-white/30', bg: dueFollowUps > 0 ? 'bg-red-500/10' : 'bg-white/4', border: dueFollowUps > 0 ? 'border-red-500/20' : 'border-white/8' },
          ].map(({ label, value, sub, color, bg, border }) => (
            <div key={label} className={`glass rounded-xl p-4 border ${border}`}>
              <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1">{label}</p>
              <p className={`text-2xl font-black ${color}`}>{value}</p>
              <p className="text-white/25 text-xs mt-0.5">{sub}</p>
            </div>
          ))}
        </div>

        {/* Pipeline stage visual */}
        <div className="glass rounded-xl p-4 border border-white/8">
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
            {STAGES.map((s, i) => {
              const count = pipelineCounts[s.id] ?? 0;
              const pct = leads.length > 0 ? Math.round((count / leads.length) * 100) : 0;
              return (
                <button
                  key={s.id}
                  onClick={() => setFilterStage(filterStage === s.id ? 'all' : s.id)}
                  className={`flex-1 min-w-[80px] px-3 py-2.5 rounded-xl border transition-all ${
                    filterStage === s.id ? `${s.bg} ${s.border}` : 'bg-white/3 border-white/6 hover:bg-white/5'
                  }`}
                >
                  <div className={`w-1.5 h-1.5 rounded-full ${s.dot} mx-auto mb-1`} />
                  <p className={`text-[9px] font-bold uppercase tracking-wider ${filterStage === s.id ? s.color : 'text-white/25'}`}>{s.label}</p>
                  <p className={`text-sm font-black ${filterStage === s.id ? s.color : 'text-white/40'}`}>{count}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Search + view toggle */}
        <div className="flex gap-3">
          <div className="flex-1 flex items-center gap-2.5 glass rounded-xl px-3.5 py-2.5 border border-white/8">
            <Search size={13} className="text-white/25 shrink-0" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search leads or companies..."
              className="flex-1 bg-transparent text-sm text-white placeholder:text-white/20 outline-none"
            />
          </div>
          <div className="flex p-1 bg-white/5 rounded-xl">
            {[['list', 'List'], ['pipeline', 'Board']].map(([v, l]) => (
              <button key={v} onClick={() => setView(v)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-indigo-500 text-white' : 'text-white/30 hover:text-white/60'}`}>
                {l}
              </button>
            ))}
          </div>
          <button onClick={() => { setEditLead(null); setShowForm(true); }} className="lg:hidden flex items-center gap-1.5 px-3 py-2 bg-indigo-500 rounded-xl text-xs font-semibold text-white">
            <Plus size={13} /> Add
          </button>
        </div>

        {/* List view */}
        {view === 'list' && (
          <div className="glass rounded-xl overflow-hidden border border-white/8">
            <div className="hidden lg:grid grid-cols-[1fr_auto_auto_auto_auto_auto] px-4 py-2.5 border-b border-white/6 text-[10px] text-white/20 uppercase tracking-widest gap-4">
              <span>Lead</span>
              <span className="w-24 text-center">Stage</span>
              <span className="w-20 text-center">MRR</span>
              <span className="w-20 text-center">Follow-up</span>
              <span className="w-16 text-center">Source</span>
              <span className="w-20 text-right">Actions</span>
            </div>
            {filtered.length === 0 && (
              <div className="py-12 text-center">
                <p className="text-white/15 text-sm">No leads found.</p>
                <button onClick={() => setShowForm(true)} className="mt-3 text-indigo-400 text-xs hover:text-indigo-300">Add your first lead</button>
              </div>
            )}
            {filtered.sort((a, b) => (b.starred ? 1 : 0) - (a.starred ? 1 : 0)).map((lead, i) => {
              const sc = stageConfig(lead.status);
              const isExpanded = expandedId === lead.id;
              const followUpDays = daysUntil(lead.followUp);
              const isDue = followUpDays !== null && followUpDays <= 1;
              const avIdx = lead.id % AVATARS.length;

              return (
                <div key={lead.id} className={i < filtered.length - 1 ? 'border-b border-white/4' : ''}>
                  <div
                    className="grid grid-cols-[1fr_auto] lg:grid-cols-[1fr_auto_auto_auto_auto_auto] px-4 py-3.5 items-center gap-4 hover:bg-white/2 cursor-pointer transition-colors"
                    onClick={() => setExpandedId(isExpanded ? null : lead.id)}
                  >
                    {/* Lead identity */}
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${AVATARS[avIdx]} flex items-center justify-center text-[11px] font-bold text-white shrink-0`}>
                        {initials(lead.name)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-white/85 text-sm font-semibold truncate">{lead.name}</p>
                          {lead.starred && <Star size={10} className="text-yellow-400 fill-yellow-400 shrink-0" />}
                        </div>
                        <div className="flex items-center gap-2">
                          <Building2 size={9} className="text-white/20 shrink-0" />
                          <p className="text-white/30 text-xs truncate">{lead.company}</p>
                          <span className="text-white/15 text-[9px]">{lead.industry}</span>
                        </div>
                      </div>
                    </div>

                    {/* Stage badge */}
                    <div className="hidden lg:flex w-24 justify-center">
                      <span className={`text-[9px] font-bold px-2.5 py-1 rounded-full ${sc.bg} ${sc.color} border ${sc.border} whitespace-nowrap`}>
                        {sc.label}
                      </span>
                    </div>

                    {/* MRR */}
                    <div className="hidden lg:block w-20 text-center">
                      {lead.status === 'paying'
                        ? <span className="text-green-400 font-bold text-sm">${lead.value}/mo</span>
                        : <span className="text-white/25 text-xs">{lead.users ? `${lead.users} users` : '—'}</span>
                      }
                    </div>

                    {/* Follow-up */}
                    <div className="hidden lg:block w-20 text-center">
                      {lead.followUp
                        ? <span className={`text-xs font-semibold ${isDue ? 'text-red-400' : 'text-white/30'}`}>
                            {followUpDays === 0 ? 'Today' : followUpDays === 1 ? 'Tomorrow' : followUpDays < 0 ? 'Overdue' : `${followUpDays}d`}
                          </span>
                        : <span className="text-white/15 text-xs">—</span>
                      }
                    </div>

                    {/* Source */}
                    <div className="hidden lg:block w-16 text-center">
                      <span className="text-white/25 text-[10px]">{lead.source}</span>
                    </div>

                    {/* Actions */}
                    <div className="hidden lg:flex w-20 items-center justify-end gap-1" onClick={e => e.stopPropagation()}>
                      <button onClick={() => moveStage(lead.id, -1)} title="Move back" className="w-6 h-6 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/25 hover:text-white/60 transition-all">
                        <ChevronRight size={10} className="rotate-180" />
                      </button>
                      <button onClick={() => moveStage(lead.id, 1)} title="Move forward" className="w-6 h-6 rounded-lg bg-white/5 hover:bg-indigo-500/20 flex items-center justify-center text-white/25 hover:text-indigo-400 transition-all">
                        <ChevronRight size={10} />
                      </button>
                      <button onClick={() => { setEditLead(lead); setShowForm(true); }} className="w-6 h-6 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/25 hover:text-white/60 transition-all">
                        <Edit3 size={9} />
                      </button>
                    </div>

                    {/* Mobile chevron */}
                    <div className="lg:hidden flex items-center gap-2">
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${sc.bg} ${sc.color} border ${sc.border}`}>{sc.label}</span>
                      <ChevronRight size={12} className={`text-white/20 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                    </div>
                  </div>

                  {/* Expanded detail */}
                  {isExpanded && (
                    <div className="px-4 pb-4 border-t border-white/5 pt-3 bg-white/2">
                      <div className="grid lg:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          {[
                            { icon: Mail, val: lead.email },
                            { icon: Phone, val: lead.phone },
                            { icon: Users, val: lead.users ? `${lead.users} users · $${lead.value}/mo est.` : 'Size unknown' },
                          ].map(({ icon: Icon, val }) => (
                            <div key={val} className="flex items-center gap-2.5">
                              <Icon size={11} className="text-white/20 shrink-0" />
                              <p className="text-white/50 text-xs">{val}</p>
                            </div>
                          ))}
                        </div>
                        <div className="lg:col-span-2">
                          {lead.notes && <p className="text-white/45 text-xs leading-relaxed mb-3">{lead.notes}</p>}
                          <div className="flex items-center gap-2 flex-wrap">
                            {STAGES.map((s, si) => (
                              <button
                                key={s.id}
                                onClick={() => setLeads(prev => prev.map(l => l.id === lead.id ? { ...l, status: s.id } : l))}
                                className={`text-[9px] font-bold px-2 py-1 rounded-lg border transition-all ${lead.status === s.id ? `${s.bg} ${s.color} ${s.border}` : 'bg-white/4 text-white/20 border-white/8 hover:border-white/20'}`}
                              >
                                {s.label}
                              </button>
                            ))}
                            <button onClick={() => { setEditLead(lead); setShowForm(true); }} className="text-[9px] font-bold text-indigo-400 px-2 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/20 hover:bg-indigo-500/20">
                              Edit
                            </button>
                            <button onClick={() => toggleStar(lead.id)} className={`text-[9px] font-bold px-2 py-1 rounded-lg border transition-all ${lead.starred ? 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' : 'text-white/20 bg-white/4 border-white/8'}`}>
                              {lead.starred ? '★ Starred' : '☆ Star'}
                            </button>
                            <button onClick={() => deleteLead(lead.id)} className="text-[9px] font-bold text-red-400/60 px-2 py-1 rounded-lg bg-red-500/5 border border-red-500/10 hover:border-red-500/20 ml-auto">
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Pipeline/Kanban view */}
        {view === 'pipeline' && (
          <div className="overflow-x-auto">
            <div className="flex gap-3 min-w-max pb-2">
              {STAGES.map(stage => {
                const stageLeads = leads.filter(l => l.status === stage.id);
                return (
                  <div key={stage.id} className="w-56">
                    <div className={`flex items-center justify-between px-3 py-2 rounded-xl ${stage.bg} border ${stage.border} mb-2`}>
                      <div className="flex items-center gap-2">
                        <div className={`w-1.5 h-1.5 rounded-full ${stage.dot}`} />
                        <p className={`text-xs font-bold ${stage.color}`}>{stage.label}</p>
                      </div>
                      <span className={`text-[10px] font-bold ${stage.color}`}>{stageLeads.length}</span>
                    </div>
                    <div className="space-y-2">
                      {stageLeads.map(lead => {
                        const avIdx = lead.id % AVATARS.length;
                        return (
                          <div key={lead.id} className="glass rounded-xl p-3 border border-white/8 hover:border-white/15 transition-all cursor-pointer"
                            onClick={() => { setEditLead(lead); setShowForm(true); }}>
                            <div className="flex items-center gap-2 mb-2">
                              <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${AVATARS[avIdx]} flex items-center justify-center text-[9px] font-bold text-white shrink-0`}>
                                {initials(lead.name)}
                              </div>
                              <div className="min-w-0">
                                <p className="text-white/80 text-xs font-semibold truncate">{lead.name}</p>
                                <p className="text-white/25 text-[9px] truncate">{lead.company}</p>
                              </div>
                            </div>
                            {lead.value > 0 && <p className="text-green-400 text-xs font-bold">${lead.value}/mo</p>}
                            {lead.followUp && daysUntil(lead.followUp) <= 2 && (
                              <div className="flex items-center gap-1 mt-1">
                                <Clock size={9} className="text-red-400" />
                                <span className="text-red-400 text-[9px]">Follow-up {daysUntil(lead.followUp) <= 0 ? 'overdue' : 'due soon'}</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                      {stageLeads.length === 0 && (
                        <div className="rounded-xl border border-dashed border-white/6 py-6 text-center">
                          <p className="text-white/15 text-[10px]">Empty</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {(showForm || editLead) && (
        <LeadForm lead={editLead} onSave={saveLead} onClose={() => { setShowForm(false); setEditLead(null); }} />
      )}
    </div>
  );
}
