/**
 * AIv3 — Fully Autonomous AI SaaS v3 (No Human Input System)
 * The endgame. System runs itself. Observe → Analyze → Adjust → Deploy → Improve → Repeat.
 * 4 agents run in parallel. Orchestrator synthesizes. Memory compounds.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Brain, TrendingUp, DollarSign, Users, Zap, RefreshCw,
  Play, CheckCircle2, ArrowRight, Activity, Cpu, Eye,
  Settings, Target, Shield, GitBranch, Layers, Lock,
  BarChart2, MessageSquare, Repeat, ChevronRight, Sparkles,
} from 'lucide-react';

// ── 4 Agents (full v3 spec) ────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'behavior',
    name: 'Behavior Agent',
    role: 'Tracks user execution',
    color: '#22d3ee',
    bg: 'rgba(6,182,212,0.07)',
    border: 'rgba(6,182,212,0.18)',
    icon: Activity,
    observe: (d) => `${d.completionRate}% completion, ${d.streak} streak, ${d.burnout ? 'burnout risk' : 'healthy'}`,
    analyze: (d) => d.completionRate < 40
      ? 'CRITICAL: Team in execution crisis. Immediate intervention required.'
      : d.completionRate < 65
      ? 'WARNING: Inconsistency detected. Routine needs restructuring.'
      : 'HEALTHY: Execution rhythm stable. Ready to increase challenge.',
    adapt: (d) => d.completionRate < 40
      ? 'Reduce daily tasks to 3. Trigger high-priority coach message.'
      : d.completionRate < 65
      ? 'Rebalance task mix. Add streak incentive. Send pattern alert.'
      : 'Increase task complexity by 10%. Schedule milestone celebration.',
  },
  {
    id: 'coach',
    name: 'Coach Agent',
    role: 'Talks to users',
    color: '#818cf8',
    bg: 'rgba(99,102,241,0.07)',
    border: 'rgba(99,102,241,0.18)',
    icon: Brain,
    observe: (d) => `Personality: ${d.personality}. Last response: ${d.lastResponseType}. Engagement: ${d.engagement}%`,
    analyze: (d) => d.engagement < 40
      ? 'User disengaging. Current coaching style not resonating.'
      : d.engagement < 70
      ? 'Moderate engagement. Tone adjustment may improve retention.'
      : 'High engagement. Coaching style is working. Maintain pattern.',
    adapt: (d) => d.engagement < 40
      ? `Switch to ${d.personality === 'discipline' ? 'motivator' : 'discipline'} mode. Reduce message frequency.`
      : d.engagement < 70
      ? 'Increase specificity of messages. Add performance data to context.'
      : 'User is self-sustaining. Shift to weekly check-ins only.',
  },
  {
    id: 'growth',
    name: 'Growth Agent',
    role: 'Improves onboarding automatically',
    color: '#34d399',
    bg: 'rgba(16,185,129,0.07)',
    border: 'rgba(16,185,129,0.18)',
    icon: TrendingUp,
    observe: (d) => `Trial activation: ${d.activation}%. Day-1 retention: ${d.d1ret}%. Onboarding steps completed: ${d.onbSteps}/6`,
    analyze: (d) => d.activation < 50
      ? 'FUNNEL BROKEN: Most trials not activating. Onboarding too complex.'
      : d.d1ret < 60
      ? 'DAY-1 DROP: Users not seeing value fast enough.'
      : 'FUNNEL HEALTHY: Activation strong. Optimize for Day-7 retention.',
    adapt: (d) => d.activation < 50
      ? 'Cut onboarding from 6 steps to 3. Surface score on Step 1.'
      : d.d1ret < 60
      ? 'Add value reveal at minute 2. Show team score immediately after signup.'
      : 'Activate referral loop at Day 5 streak milestone.',
  },
  {
    id: 'revenue',
    name: 'Revenue Agent',
    role: 'Adjusts pricing dynamically',
    color: '#fbbf24',
    bg: 'rgba(245,158,11,0.07)',
    border: 'rgba(245,158,11,0.18)',
    icon: DollarSign,
    observe: (d) => `MRR: $${d.mrr}. Churn: ${d.churn}%. ARPU: $${d.arpu}. Expansion rev: ${d.expansion}%`,
    analyze: (d) => d.churn > 8
      ? 'CHURN RISK: Above healthy threshold. Intervention needed before billing.'
      : d.arpu < 30
      ? 'UNDERPRICED: Value delivery exceeds pricing. Raise prices on new users.'
      : 'REVENUE HEALTHY: Focus on expansion and upsell opportunities.',
    adapt: (d) => d.churn > 8
      ? 'Trigger at-risk cohort message 7 days before renewal. Offer pause, not cancel.'
      : d.arpu < 30
      ? 'Increase Starter price by 15% for new signups. Grandfather existing users.'
      : 'Surface upgrade prompt at team expansion (5 → 10 users). Annual plan push.',
  },
];

// ── Loop steps ─────────────────────────────────────────────────────────────────
const LOOP = [
  { id: 'observe',  label: 'Observe',  desc: 'Collect all live signals from users',    Icon: Eye,        color: '#818cf8' },
  { id: 'analyze',  label: 'Analyze',  desc: 'Agents process patterns in parallel',    Icon: Activity,   color: '#22d3ee' },
  { id: 'adjust',   label: 'Adjust',   desc: 'Orchestrator decides best adaptations',  Icon: Settings,   color: '#a78bfa' },
  { id: 'deploy',   label: 'Deploy',   desc: 'Changes go live — no human required',   Icon: Zap,        color: '#34d399' },
  { id: 'improve',  label: 'Improve',  desc: 'Results stored in memory, loop smarter', Icon: TrendingUp, color: '#fbbf24' },
  { id: 'repeat',   label: 'Repeat',   desc: 'System runs again, compounds over time', Icon: Repeat,     color: '#f472b6' },
];

// ── Orchestrator logic ─────────────────────────────────────────────────────────
function runOrchestrator(data, agentOutputs) {
  const crises   = agentOutputs.filter(o => o.analysis.startsWith('CRITICAL') || o.analysis.startsWith('CHURN') || o.analysis.startsWith('FUNNEL BROKEN'));
  const warnings = agentOutputs.filter(o => o.analysis.startsWith('WARNING') || o.analysis.startsWith('DAY-1') || o.analysis.startsWith('UNDERPRICED'));

  if (crises.length > 0) {
    return {
      priority: 'CRITICAL',
      color: '#f87171',
      bg: 'rgba(239,68,68,0.08)',
      border: 'rgba(239,68,68,0.2)',
      action: `${crises.length} critical signal${crises.length > 1 ? 's' : ''} detected. Deploying emergency adaptations from: ${crises.map(c => c.name).join(', ')}.`,
      deploy: crises.map(c => c.adaptation).join(' | '),
    };
  }
  if (warnings.length > 0) {
    return {
      priority: 'WARNING',
      color: '#fbbf24',
      bg: 'rgba(245,158,11,0.08)',
      border: 'rgba(245,158,11,0.2)',
      action: `${warnings.length} warning${warnings.length > 1 ? 's' : ''} flagged. Applying targeted adjustments from: ${warnings.map(w => w.name).join(', ')}.`,
      deploy: warnings.map(w => w.adaptation).join(' | '),
    };
  }
  return {
    priority: 'HEALTHY',
    color: '#34d399',
    bg: 'rgba(16,185,129,0.08)',
    border: 'rgba(16,185,129,0.2)',
    action: 'All systems nominal. Incremental optimizations deployed. System compounding.',
    deploy: agentOutputs.map(o => o.adaptation).join(' | '),
  };
}

// ── Default signal presets ─────────────────────────────────────────────────────
const PRESETS = [
  { label: 'Healthy Team',  color: 'text-emerald-400', values: { completionRate:82, streak:9, burnout:false, personality:'discipline', lastResponseType:'growth', engagement:78, activation:71, d1ret:68, onbSteps:5, mrr:4200, churn:3, arpu:48, expansion:22 } },
  { label: 'At-Risk Team',  color: 'text-yellow-400',  values: { completionRate:47, streak:2, burnout:false, personality:'motivation', lastResponseType:'generic', engagement:41, activation:38, d1ret:44, onbSteps:2, mrr:1800, churn:11, arpu:22, expansion:5  } },
  { label: 'Crisis State',  color: 'text-red-400',     values: { completionRate:18, streak:0, burnout:true,  personality:'discipline', lastResponseType:'warning', engagement:15, activation:22, d1ret:28, onbSteps:1, mrr:600,  churn:19, arpu:14, expansion:1  } },
];

// ── Persistence ────────────────────────────────────────────────────────────────
function loadState()  { try { return JSON.parse(localStorage.getItem('be_aiv3')) ?? { cycles: 0, log: [] }; } catch { return { cycles: 0, log: [] }; } }
function saveState(s) { try { localStorage.setItem('be_aiv3', JSON.stringify(s)); } catch {} }

// ── Signal slider ─────────────────────────────────────────────────────────────
function Slider({ label, value, min, max, onChange, color = '#818cf8' }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-white/30 text-[10px]">{label}</span>
        <span className="text-xs font-bold" style={{ color }}>{value}{label.includes('%') || label.includes('rate') || label.includes('Retention') || label.includes('Activation') || label.includes('Engagement') || label.includes('Churn') || label.includes('Completion') ? '%' : label.includes('MRR') ? '' : ''}</span>
      </div>
      <input type="range" min={min} max={max} value={value} onChange={e => onChange(+e.target.value)}
        className="w-full cursor-pointer" style={{ accentColor: color }} />
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AIv3() {
  const [signals, setSignals] = useState(PRESETS[0].values);
  const [running,     setRunning]     = useState(false);
  const [loopStep,    setLoopStep]    = useState(-1);
  const [activeAgents,setActiveAgents]= useState([]);
  const [orchResult,  setOrchResult]  = useState(null);
  const [agentOutputs,setAgentOutputs]= useState([]);
  const [sysState,    setSysState_]   = useState(loadState);
  const timerRef = useRef(null);

  const setSysState = (s) => { setSysState_(s); saveState(s); };

  const runCycle = () => {
    if (running) return;
    setRunning(true);
    setOrchResult(null);
    setAgentOutputs([]);
    setActiveAgents([]);

    let step = 0;
    setLoopStep(0);

    timerRef.current = setInterval(() => {
      step++;
      if (step < LOOP.length) {
        setLoopStep(step);
        // At 'analyze' step, activate all agents simultaneously
        if (step === 1) {
          setActiveAgents(AGENTS.map(a => a.id));
        }
      } else {
        clearInterval(timerRef.current);

        // Compute agent outputs
        const outputs = AGENTS.map(a => ({
          id:         a.id,
          name:       a.name,
          color:      a.color,
          signal:     a.observe(signals),
          analysis:   a.analyze(signals),
          adaptation: a.adapt(signals),
        }));
        setAgentOutputs(outputs);

        const orch = runOrchestrator(signals, outputs);
        setOrchResult(orch);

        const newState = {
          cycles: sysState.cycles + 1,
          log: [
            { cycle: sysState.cycles + 1, priority: orch.priority, ts: new Date().toLocaleTimeString(), completion: signals.completionRate, mrr: signals.mrr },
            ...sysState.log.slice(0, 9),
          ],
        };
        setSysState(newState);
        setRunning(false);
        setLoopStep(5); // rest on "repeat"
      }
    }, 420);
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  const applyPreset = (preset) => {
    setSignals(preset.values);
    setOrchResult(null);
    setAgentOutputs([]);
    setActiveAgents([]);
    setLoopStep(-1);
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={13} className="text-pink-400" />
              <p className="text-pink-400 text-xs font-bold uppercase tracking-widest">Autonomous AI v3</p>
            </div>
            <h1 className="text-3xl font-black mb-1">No Human Input System</h1>
            <p className="text-white/35 text-sm">
              System runs itself. {sysState.cycles} cycles complete. Memory compounds every loop.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl border border-pink-500/20 bg-pink-500/5">
              <p className="text-xl font-black text-pink-400">{sysState.cycles}</p>
              <p className="text-white/20 text-[9px]">cycles run</p>
            </div>
            <button onClick={runCycle} disabled={running}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all ${
                running
                  ? 'bg-pink-500/10 border border-pink-500/20 text-pink-400'
                  : 'bg-pink-500 hover:bg-pink-400 text-white shadow-lg shadow-pink-500/20'
              }`}>
              {running
                ? <><RefreshCw size={13} className="animate-spin" /> Running…</>
                : <><Play size={13} /> Run Cycle</>}
            </button>
          </div>
        </div>

        {/* Loop visualizer */}
        <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
          <p className="text-white/20 text-[9px] uppercase tracking-widest mb-4">Autonomous Loop</p>
          <div className="flex items-center gap-2 flex-wrap">
            {LOOP.map((step, i) => {
              const StepIcon = step.Icon;
              const isActive = running && loopStep === i;
              const isDone   = !running && loopStep >= i && loopStep >= 0;
              return (
                <div key={step.id} className="flex items-center gap-2">
                  <div
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition-all duration-300 ${isActive ? 'scale-105' : ''}`}
                    style={{
                      background:   isActive ? `${step.color}12` : isDone ? 'rgba(16,185,129,0.05)' : 'rgba(255,255,255,0.02)',
                      borderColor:  isActive ? step.color         : isDone ? 'rgba(16,185,129,0.18)' : 'rgba(255,255,255,0.06)',
                    }}>
                    <StepIcon size={10} style={{ color: isActive ? step.color : isDone ? '#34d399' : 'rgba(255,255,255,0.18)' }} />
                    <span className="text-[10px] font-semibold" style={{ color: isActive ? step.color : isDone ? '#34d399' : 'rgba(255,255,255,0.28)' }}>
                      {step.label}
                    </span>
                    {isActive && <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: step.color }} />}
                  </div>
                  {i < LOOP.length - 1 && (
                    <ArrowRight size={9} className={isDone ? 'text-emerald-400/40' : 'text-white/10'} />
                  )}
                </div>
              );
            })}
          </div>
          {running && loopStep >= 0 && (
            <p className="text-white/30 text-xs mt-3 italic">{LOOP[loopStep]?.desc}</p>
          )}
        </div>

        {/* Presets + Signal controls */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Presets */}
          <div>
            <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Load Scenario</p>
            <div className="flex gap-2 mb-4">
              {PRESETS.map(p => (
                <button key={p.label} onClick={() => applyPreset(p)}
                  className={`flex-1 py-2 px-3 rounded-xl border border-white/8 bg-white/3 text-xs font-semibold transition-all hover:border-white/18 ${p.color}`}>
                  {p.label}
                </button>
              ))}
            </div>

            <div className="space-y-3 p-4 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-1">Live Signals</p>
              <Slider label="Completion Rate" min={0} max={100} value={signals.completionRate} onChange={v => setSignals({...signals, completionRate: v})} color="#22d3ee" />
              <Slider label="Engagement" min={0} max={100} value={signals.engagement} onChange={v => setSignals({...signals, engagement: v})} color="#818cf8" />
              <Slider label="Trial Activation" min={0} max={100} value={signals.activation} onChange={v => setSignals({...signals, activation: v})} color="#34d399" />
              <Slider label="Churn Rate" min={0} max={30} value={signals.churn} onChange={v => setSignals({...signals, churn: v})} color="#fbbf24" />
              <Slider label="MRR" min={0} max={20000} value={signals.mrr} onChange={v => setSignals({...signals, mrr: v})} color="#f472b6" />
            </div>
          </div>

          {/* Orchestrator result */}
          <div>
            <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Orchestrator Output</p>
            {!orchResult ? (
              <div className="h-full p-6 rounded-2xl border border-white/6 bg-white/2 flex flex-col items-center justify-center text-center gap-3">
                <Cpu size={22} className="text-white/10" />
                <p className="text-white/20 text-sm">Run a cycle to see orchestrator output</p>
                <p className="text-white/10 text-xs">4 agents run in parallel → synthesized decision</p>
              </div>
            ) : (
              <div className="p-5 rounded-2xl border" style={{ borderColor: orchResult.border, background: orchResult.bg }}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: orchResult.color }} />
                  <span className="text-xs font-black uppercase tracking-widest" style={{ color: orchResult.color }}>
                    {orchResult.priority}
                  </span>
                </div>
                <p className="text-white/65 text-sm leading-relaxed mb-4">{orchResult.action}</p>
                <div className="p-3 rounded-xl bg-black/25 border border-white/5">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Deployed Adaptations</p>
                  <p className="text-white/45 text-xs leading-relaxed">{orchResult.deploy}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 4-Agent grid */}
        {agentOutputs.length > 0 && (
          <div>
            <p className="text-white/20 text-[9px] uppercase tracking-widest mb-3">Agent Reports</p>
            <div className="grid lg:grid-cols-2 gap-3">
              {agentOutputs.map(agent => {
                const AgentIcon = AGENTS.find(a => a.id === agent.id)?.icon ?? Brain;
                const meta = AGENTS.find(a => a.id === agent.id);
                return (
                  <div key={agent.id} className="p-4 rounded-2xl border" style={{ borderColor: meta.border, background: meta.bg }}>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: meta.bg, border: `1px solid ${meta.border}` }}>
                        <AgentIcon size={12} style={{ color: agent.color }} />
                      </div>
                      <div>
                        <p className="text-xs font-bold" style={{ color: agent.color }}>{agent.name}</p>
                        <p className="text-[9px] text-white/25">{meta.role}</p>
                      </div>
                    </div>
                    <div className="space-y-2 text-[10px]">
                      <div>
                        <p className="text-white/20 uppercase tracking-widest text-[8px] mb-0.5">Observed</p>
                        <p className="text-white/45 font-mono">{agent.signal}</p>
                      </div>
                      <div>
                        <p className="text-white/20 uppercase tracking-widest text-[8px] mb-0.5">Analysis</p>
                        <p className="leading-snug" style={{ color: agent.color }}>{agent.analysis}</p>
                      </div>
                      <div className="p-2 rounded-lg bg-black/20 border border-white/5">
                        <p className="text-white/20 uppercase tracking-widest text-[8px] mb-0.5">Adaptation Applied</p>
                        <p className="text-white/50 leading-snug">{agent.adaptation}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Architecture code */}
        <div className="grid lg:grid-cols-2 gap-6">
          <div>
            <p className="text-white/20 text-[9px] uppercase tracking-widest mb-3">v3 Orchestrator (JS)</p>
            <div className="p-4 rounded-2xl bg-black/40 border border-white/8">
              <pre className="text-[9px] text-pink-400/75 font-mono leading-relaxed overflow-x-auto">{`// Runs on every user session.
// No human triggers this.

async function autonomousSystem(data) {

  // All 4 agents run in parallel
  const [behavior, coaching,
         growth,   revenue] =
    await Promise.all([
      behaviorAgent.run(data),
      coachAgent.run(data),
      growthAgent.run(data),
      revenueAgent.run(data),
    ])

  // Orchestrator synthesizes
  const decision = orchestrate({
    behavior, coaching, growth, revenue
  })

  // Deploy live — zero manual step
  await applyAdaptations(decision)

  // Store to memory (compounds)
  await memory.append({ data, decision })

  return decision
}

// Triggered by: session start,
// daily cron, event webhook.
// Never by a human.`}</pre>
            </div>
          </div>

          {/* Cycle log */}
          <div>
            <p className="text-white/20 text-[9px] uppercase tracking-widest mb-3">Cycle Memory Log</p>
            {sysState.log.length === 0 ? (
              <div className="p-6 rounded-2xl border border-white/6 bg-white/2 text-center">
                <Layers size={18} className="mx-auto text-white/10 mb-2" />
                <p className="text-white/20 text-sm">No cycles logged</p>
                <p className="text-white/10 text-xs">Run a cycle above to start</p>
              </div>
            ) : (
              <div className="space-y-2">
                {sysState.log.map((entry, i) => {
                  const priorityColor = entry.priority === 'CRITICAL' ? 'text-red-400' : entry.priority === 'WARNING' ? 'text-yellow-400' : 'text-emerald-400';
                  const priorityBorder = entry.priority === 'CRITICAL' ? 'border-red-500/15' : entry.priority === 'WARNING' ? 'border-yellow-500/15' : 'border-emerald-500/15';
                  return (
                    <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border bg-white/1 ${priorityBorder}`}>
                      <span className="text-white/15 text-[9px] font-mono w-6 shrink-0">#{entry.cycle}</span>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-[9px] font-black uppercase ${priorityColor}`}>{entry.priority}</span>
                          <span className="text-white/20 text-[9px]">·</span>
                          <span className="text-white/30 text-[9px]">{entry.completion}% exec</span>
                          <span className="text-white/20 text-[9px]">·</span>
                          <span className="text-white/30 text-[9px]">${entry.mrr} MRR</span>
                        </div>
                        <p className="text-white/15 text-[8px] font-mono">{entry.ts}</p>
                      </div>
                      {i === 0 && <span className="text-[8px] font-black text-pink-400 bg-pink-500/10 border border-pink-500/15 px-1.5 py-0.5 rounded-full shrink-0">LATEST</span>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* The endgame truth */}
        <div className="p-5 rounded-2xl border border-pink-500/20 bg-pink-500/5">
          <p className="text-pink-400 font-bold text-sm mb-3">The Endgame</p>
          <div className="grid lg:grid-cols-3 gap-4 mb-4">
            {[
              { title: 'You are not building software',  body: 'You are building a self-improving SaaS company system. The product gets better every session without you touching it.',     color: 'text-white/60'  },
              { title: 'The moat is behavioral memory',  body: 'After 90 days your system knows your customers better than any competitor who just started. That data cannot be copied.',     color: 'text-pink-400'  },
              { title: 'Success = execution speed',      body: 'Not complexity. Not features. How fast you get users, how fast you onboard them, how fast you distribute results.',          color: 'text-white/60'  },
            ].map(({ title, body, color }) => (
              <div key={title} className="p-4 rounded-xl bg-black/20 border border-white/6">
                <p className={`text-xs font-bold ${color} mb-2`}>{title}</p>
                <p className="text-white/35 text-xs leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
          <div className="p-4 rounded-xl border border-pink-500/15 bg-black/20">
            <p className="text-white/50 text-xs leading-relaxed">
              <span className="text-white font-semibold">You now have</span> a full engineering system, a 30-day acquisition plan, a closing + CRM system, and a self-improving AI.
              The question is no longer &quot;what to build&quot;.
              The question is <span className="text-pink-400 font-semibold">how fast you execute</span>.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
