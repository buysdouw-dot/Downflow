/**
 * GoalEngine — OKR / Goal Tracking System
 * Set objectives, track key results, align team performance to business goals.
 */
import { useState, useEffect } from 'react';
import {
  Target, Plus, Zap, CheckCircle2, Circle, TrendingUp,
  Edit3, Trash2, ChevronDown, ChevronRight, Star,
  ArrowRight, Calendar, Users, Award, BarChart2, X,
} from 'lucide-react';

// ── Data model ────────────────────────────────────────────────────────────────
const QUARTERS = ['Q1 2026', 'Q2 2026', 'Q3 2026', 'Q4 2026'];

const DEFAULT_OKRS = [
  {
    id: 1,
    quarter: 'Q2 2026',
    objective: 'Achieve top-tier team execution consistency',
    owner: 'Marcus Chen',
    status: 'on-track',
    keyResults: [
      { id: 11, text: 'Maintain 80%+ daily GREEN rate across team', progress: 72, target: 80, unit: '%', status: 'on-track' },
      { id: 12, text: 'Zero RED days for top 5 performers', progress: 3, target: 0, unit: 'red days', status: 'at-risk' },
      { id: 13, text: 'Complete 100 team tasks this quarter', progress: 74, target: 100, unit: 'tasks', status: 'on-track' },
    ],
  },
  {
    id: 2,
    quarter: 'Q2 2026',
    objective: 'Grow paying customer base to 50 accounts',
    owner: 'Sarah Kim',
    status: 'at-risk',
    keyResults: [
      { id: 21, text: 'Close 20 new pilot accounts', progress: 8, target: 20, unit: 'accounts', status: 'at-risk' },
      { id: 22, text: 'Achieve 60% pilot → paid conversion', progress: 44, target: 60, unit: '%', status: 'at-risk' },
      { id: 23, text: 'Reach $5,000 MRR', progress: 2800, target: 5000, unit: '$', status: 'on-track' },
    ],
  },
  {
    id: 3,
    quarter: 'Q2 2026',
    objective: 'Launch AI v2 multi-agent system to all users',
    owner: 'Daniel Park',
    status: 'completed',
    keyResults: [
      { id: 31, text: 'Deploy 4-agent orchestration system', progress: 100, target: 100, unit: '%', status: 'completed' },
      { id: 32, text: 'Achieve < 200ms agent response time', progress: 100, target: 100, unit: '%', status: 'completed' },
      { id: 33, text: 'Run 1,000 agent cycles in production', progress: 100, target: 100, unit: '%', status: 'completed' },
    ],
  },
];

const STATUS_CFG = {
  'on-track': { label: 'On Track',  color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', bar: 'bg-emerald-400' },
  'at-risk':  { label: 'At Risk',   color: 'text-yellow-400',  bg: 'bg-yellow-500/10',  border: 'border-yellow-500/20',  bar: 'bg-yellow-400'  },
  'off-track':{ label: 'Off Track', color: 'text-red-400',     bg: 'bg-red-500/10',     border: 'border-red-500/20',     bar: 'bg-red-400'     },
  'completed':{ label: 'Completed', color: 'text-indigo-400',  bg: 'bg-indigo-500/10',  border: 'border-indigo-500/20',  bar: 'bg-indigo-400'  },
};

// ── Storage ───────────────────────────────────────────────────────────────────
function loadOKRs()   { try { return JSON.parse(localStorage.getItem('be_okrs')) ?? DEFAULT_OKRS; } catch { return DEFAULT_OKRS; } }
function saveOKRs(d)  { try { localStorage.setItem('be_okrs', JSON.stringify(d)); } catch {} }

// ── Sub-components ────────────────────────────────────────────────────────────
function ProgressRing({ pct, color, size = 48 }) {
  const r = (size - 6) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={3} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color}
        strokeWidth={3} strokeLinecap="round"
        strokeDasharray={`${dash} ${circ}`} style={{ transition: 'stroke-dasharray 0.7s ease' }} />
    </svg>
  );
}

function KRRow({ kr, objId, onUpdate }) {
  const pct = kr.unit === '%' ? kr.progress : Math.min(100, Math.round((kr.progress / kr.target) * 100));
  const cfg = STATUS_CFG[kr.status];
  return (
    <div className="space-y-1.5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2 flex-1 min-w-0">
          {pct >= 100
            ? <CheckCircle2 size={13} className="text-indigo-400 shrink-0 mt-0.5" />
            : <Circle size={13} className="text-white/20 shrink-0 mt-0.5" />}
          <p className="text-white/60 text-xs leading-snug">{kr.text}</p>
        </div>
        <div className="text-right shrink-0">
          <p className={`text-xs font-bold ${cfg.color}`}>
            {kr.unit === '$' ? `$${kr.progress.toLocaleString()}` : `${kr.progress}${kr.unit === '%' ? '%' : ''}`}
            <span className="text-white/20"> / {kr.unit === '$' ? `$${kr.target.toLocaleString()}` : `${kr.target}${kr.unit === '%' ? '%' : ` ${kr.unit}`}`}</span>
          </p>
        </div>
      </div>
      <div className="ml-5 h-1.5 bg-white/6 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${cfg.bar} transition-all duration-700`} style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
      <div className="ml-5 flex items-center gap-3">
        <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full ${cfg.bg} border ${cfg.border} ${cfg.color}`}>{pct}%</span>
        <input
          type="range" min={0} max={kr.target} value={kr.progress}
          onChange={e => onUpdate(objId, kr.id, Number(e.target.value))}
          className="flex-1 h-1 accent-indigo-500 cursor-pointer"
        />
      </div>
    </div>
  );
}

function OKRCard({ okr, onUpdateKR, onDelete }) {
  const [open, setOpen] = useState(true);
  const cfg = STATUS_CFG[okr.status];

  const avgPct = Math.round(
    okr.keyResults.reduce((s, kr) => {
      const p = kr.unit === '%' ? kr.progress : Math.min(100, (kr.progress / kr.target) * 100);
      return s + p;
    }, 0) / okr.keyResults.length
  );

  const ringColor = cfg.bar.replace('bg-', '#').includes('emerald') ? '#34d399'
    : cfg.bar.includes('yellow') ? '#facc15'
    : cfg.bar.includes('indigo') ? '#818cf8'
    : '#f87171';

  return (
    <div className={`rounded-2xl border ${cfg.border} ${cfg.bg} overflow-hidden`}>
      {/* Header */}
      <div className="flex items-center gap-4 p-4 cursor-pointer" onClick={() => setOpen(v => !v)}>
        <ProgressRing pct={avgPct} color={ringColor} size={48} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full ${cfg.bg} border ${cfg.border} ${cfg.color}`}>{cfg.label}</span>
            <span className="text-white/20 text-[9px]">{okr.quarter} · {okr.owner}</span>
          </div>
          <p className="text-white font-bold text-sm leading-snug">{okr.objective}</p>
          <p className="text-white/30 text-[10px] mt-0.5">{okr.keyResults.length} key results · {avgPct}% complete</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button onClick={e => { e.stopPropagation(); onDelete(okr.id); }}
            className="p-1.5 rounded-lg text-white/15 hover:text-red-400 hover:bg-red-500/10 transition-all">
            <Trash2 size={12} />
          </button>
          {open ? <ChevronDown size={14} className="text-white/25" /> : <ChevronRight size={14} className="text-white/25" />}
        </div>
      </div>

      {/* Key results */}
      {open && (
        <div className="px-4 pb-4 space-y-4 border-t border-white/6 pt-4">
          {okr.keyResults.map(kr => (
            <KRRow key={kr.id} kr={kr} objId={okr.id} onUpdate={onUpdateKR} />
          ))}
        </div>
      )}
    </div>
  );
}

function AddOKRModal({ onClose, onAdd, quarter }) {
  const [obj,   setObj]   = useState('');
  const [owner, setOwner] = useState('');
  const [krs,   setKRs]   = useState([{ text: '', progress: 0, target: 100, unit: '%' }]);

  const addKR  = () => setKRs(p => [...p, { text: '', progress: 0, target: 100, unit: '%' }]);
  const updKR  = (i, field, val) => setKRs(p => p.map((k, idx) => idx === i ? { ...k, [field]: val } : k));
  const removeKR = i => setKRs(p => p.filter((_, idx) => idx !== i));

  const submit = () => {
    if (!obj.trim()) return;
    onAdd({
      id: Date.now(),
      quarter,
      objective: obj,
      owner: owner || 'Team',
      status: 'on-track',
      keyResults: krs.filter(k => k.text.trim()).map((k, i) => ({ ...k, id: Date.now() + i, status: 'on-track' })),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="max-w-lg w-full rounded-2xl border border-white/15 bg-[#0b0f1a] p-6 space-y-4 max-h-[90vh] overflow-y-auto scrollbar-hide" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <p className="text-white font-bold text-base">New Objective</p>
          <button onClick={onClose} className="text-white/25 hover:text-white/50"><X size={16} /></button>
        </div>

        <div className="space-y-1">
          <label className="text-white/30 text-[9px] uppercase tracking-widest">Objective</label>
          <textarea value={obj} onChange={e => setObj(e.target.value)} rows={2}
            placeholder="What do you want to achieve this quarter?"
            className="w-full bg-white/4 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm placeholder:text-white/20 focus:outline-none focus:border-indigo-500/50 resize-none" />
        </div>

        <div className="space-y-1">
          <label className="text-white/30 text-[9px] uppercase tracking-widest">Owner</label>
          <input value={owner} onChange={e => setOwner(e.target.value)}
            placeholder="Name or team"
            className="w-full bg-white/4 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm placeholder:text-white/20 focus:outline-none focus:border-indigo-500/50" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-white/30 text-[9px] uppercase tracking-widest">Key Results</label>
            <button onClick={addKR} className="text-indigo-400 text-[10px] font-bold hover:text-indigo-300 flex items-center gap-1">
              <Plus size={9} /> Add KR
            </button>
          </div>
          {krs.map((kr, i) => (
            <div key={i} className="flex gap-2">
              <input value={kr.text} onChange={e => updKR(i, 'text', e.target.value)}
                placeholder={`Key result ${i + 1}…`}
                className="flex-1 bg-white/4 border border-white/10 rounded-xl px-3 py-2 text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-indigo-500/50" />
              <input type="number" value={kr.target} onChange={e => updKR(i, 'target', Number(e.target.value))} min={1}
                className="w-16 bg-white/4 border border-white/10 rounded-xl px-2 py-2 text-white text-xs text-center focus:outline-none focus:border-indigo-500/50" />
              <select value={kr.unit} onChange={e => updKR(i, 'unit', e.target.value)}
                className="w-16 bg-white/4 border border-white/10 rounded-xl px-1 py-2 text-white/50 text-xs focus:outline-none focus:border-indigo-500/50">
                <option value="%">%</option>
                <option value="$">$</option>
                <option value="users">users</option>
                <option value="tasks">tasks</option>
              </select>
              {krs.length > 1 && (
                <button onClick={() => removeKR(i)} className="text-white/15 hover:text-red-400 p-1">
                  <X size={11} />
                </button>
              )}
            </div>
          ))}
        </div>

        <button onClick={submit}
          className="w-full py-3 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all">
          <Target size={14} /> Add Objective
        </button>
      </div>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function GoalEngine() {
  const [okrs,     setOKRs]    = useState(loadOKRs);
  const [quarter,  setQuarter] = useState('Q2 2026');
  const [showAdd,  setShowAdd] = useState(false);
  const [view,     setView]    = useState('okrs'); // 'okrs' | 'summary'

  useEffect(() => { saveOKRs(okrs); }, [okrs]);

  const updateKR = (objId, krId, newProgress) => {
    setOKRs(prev => prev.map(o => o.id !== objId ? o : {
      ...o,
      keyResults: o.keyResults.map(kr => kr.id !== krId ? kr : {
        ...kr,
        progress: newProgress,
        status: newProgress >= kr.target ? 'completed' : newProgress >= kr.target * 0.7 ? 'on-track' : newProgress >= kr.target * 0.4 ? 'at-risk' : 'off-track',
      }),
    }));
  };

  const deleteOKR = (id) => setOKRs(prev => prev.filter(o => o.id !== id));
  const addOKR    = (okr) => setOKRs(prev => [...prev, okr]);

  const filtered = okrs.filter(o => o.quarter === quarter);

  const overallPct = filtered.length ? Math.round(
    filtered.reduce((s, o) => {
      const avg = o.keyResults.reduce((ks, kr) => {
        const p = kr.unit === '%' ? kr.progress : Math.min(100, (kr.progress / kr.target) * 100);
        return ks + p;
      }, 0) / o.keyResults.length;
      return s + avg;
    }, 0) / filtered.length
  ) : 0;

  const statusCounts = {
    'on-track':  filtered.filter(o => o.status === 'on-track').length,
    'at-risk':   filtered.filter(o => o.status === 'at-risk').length,
    'off-track': filtered.filter(o => o.status === 'off-track').length,
    'completed': filtered.filter(o => o.status === 'completed').length,
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Target size={14} className="text-indigo-400" />
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">Goal Engine</p>
            </div>
            <h1 className="text-3xl font-black mb-1">OKR Tracker</h1>
            <p className="text-white/35 text-sm">Align team execution to business objectives.</p>
          </div>
          <button onClick={() => setShowAdd(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white text-sm font-bold transition-all shadow-lg shadow-indigo-500/20">
            <Plus size={13} /> New Objective
          </button>
        </div>

        {/* Quarter tabs + view toggle */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
            {QUARTERS.map(q => (
              <button key={q} onClick={() => setQuarter(q)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${quarter === q ? 'bg-indigo-500 text-white' : 'text-white/30 hover:text-white/60'}`}>
                {q}
              </button>
            ))}
          </div>
          <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
            {[['okrs','OKRs'],['summary','Summary']].map(([v,l])=>(
              <button key={v} onClick={() => setView(v)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-white/10 text-white' : 'text-white/30 hover:text-white/60'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Quarter progress bar */}
        <div className="p-4 rounded-2xl bg-white/2 border border-white/6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-white/40 text-xs font-bold">{quarter} — OVERALL PROGRESS</p>
            <p className={`text-lg font-black ${overallPct >= 70 ? 'text-emerald-400' : overallPct >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>{overallPct}%</p>
          </div>
          <div className="h-2 bg-white/6 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-700 ${overallPct >= 70 ? 'bg-emerald-400' : overallPct >= 40 ? 'bg-yellow-400' : 'bg-red-400'}`}
              style={{ width: `${overallPct}%` }} />
          </div>
          <div className="flex gap-4 mt-2 flex-wrap">
            {Object.entries(statusCounts).map(([status, count]) => {
              if (!count) return null;
              const cfg = STATUS_CFG[status];
              return (
                <div key={status} className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-full ${cfg.bar}`} />
                  <span className="text-white/30 text-[10px]">{count} {cfg.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* OKRs view */}
        {view === 'okrs' && (
          <div className="space-y-4">
            {filtered.length === 0 ? (
              <div className="p-10 rounded-2xl border border-dashed border-white/10 text-center space-y-3">
                <Target size={24} className="mx-auto text-white/15" />
                <p className="text-white/25">No objectives for {quarter}</p>
                <button onClick={() => setShowAdd(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm font-semibold hover:bg-indigo-500/15 transition-all">
                  <Plus size={13} /> Add first objective
                </button>
              </div>
            ) : (
              filtered.map(okr => (
                <OKRCard key={okr.id} okr={okr} onUpdateKR={updateKR} onDelete={deleteOKR} />
              ))
            )}
          </div>
        )}

        {/* Summary view */}
        {view === 'summary' && (
          <div className="grid lg:grid-cols-2 gap-4">
            {filtered.map(okr => {
              const avgPct = Math.round(
                okr.keyResults.reduce((s, kr) => s + Math.min(100, kr.unit === '%' ? kr.progress : (kr.progress / kr.target) * 100), 0)
                / okr.keyResults.length
              );
              const cfg = STATUS_CFG[okr.status];
              return (
                <div key={okr.id} className={`p-4 rounded-2xl border ${cfg.border} ${cfg.bg}`}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="relative w-10 h-10 shrink-0">
                      <svg width={40} height={40} className="-rotate-90">
                        <circle cx={20} cy={20} r={16} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={3} />
                        <circle cx={20} cy={20} r={16} fill="none"
                          stroke={cfg.bar.includes('emerald') ? '#34d399' : cfg.bar.includes('yellow') ? '#facc15' : cfg.bar.includes('indigo') ? '#818cf8' : '#f87171'}
                          strokeWidth={3} strokeLinecap="round"
                          strokeDasharray={`${(avgPct / 100) * 2 * Math.PI * 16} ${2 * Math.PI * 16}`} />
                      </svg>
                      <span className={`absolute inset-0 flex items-center justify-center text-[9px] font-black ${cfg.color}`}>{avgPct}%</span>
                    </div>
                    <div>
                      <p className="text-white text-xs font-bold leading-snug">{okr.objective}</p>
                      <p className="text-white/25 text-[9px] mt-0.5">{okr.owner} · {okr.keyResults.length} KRs</p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    {okr.keyResults.map(kr => {
                      const p = kr.unit === '%' ? kr.progress : Math.min(100, (kr.progress / kr.target) * 100);
                      const kc = STATUS_CFG[kr.status];
                      return (
                        <div key={kr.id} className="flex items-center gap-2">
                          <div className="flex-1 h-1 bg-white/6 rounded-full overflow-hidden">
                            <div className={`h-full ${kc.bar} rounded-full`} style={{ width: `${p}%` }} />
                          </div>
                          <span className="text-white/20 text-[8px] font-mono w-7 text-right">{p}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

      {showAdd && <AddOKRModal onClose={() => setShowAdd(false)} onAdd={addOKR} quarter={quarter} />}
    </div>
  );
}
