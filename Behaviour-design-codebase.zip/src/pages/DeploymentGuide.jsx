import { useState } from 'react';
import {
  Server, Database, Globe, Key, Terminal, CheckCircle2,
  Copy, ArrowRight, Zap, Cloud, Smartphone, ShieldCheck,
  ChevronDown, ChevronUp, ExternalLink,
} from 'lucide-react';
import MobileHeader from '../components/MobileHeader';

const STEPS = [
  {
    number: '01',
    icon: Database,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    title: 'Database — Supabase',
    sub: '5 minutes · Free tier available',
    link: 'https://supabase.com',
    linkLabel: 'supabase.com',
    instructions: [
      'Go to supabase.com and create a new project',
      'Copy your DATABASE_URL from Settings → Database',
      'Copy your ANON KEY from Settings → API',
      'Save both — you\'ll need them in Step 3',
    ],
    code: null,
    tip: 'Use the free tier. It supports up to 500MB and is fully production-grade.',
  },
  {
    number: '02',
    icon: Server,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    title: 'Backend Deploy — Railway',
    sub: '10 minutes · $5/mo after free trial',
    link: 'https://railway.app',
    linkLabel: 'railway.app',
    instructions: [
      'Push this repo to GitHub (if not already)',
      'Go to railway.app → New Project → Deploy from GitHub',
      'Select your repository',
      'Railway auto-detects Node.js and deploys it',
    ],
    code: null,
    tip: 'Railway gives you a live HTTPS URL in under 2 minutes.',
  },
  {
    number: '03',
    icon: Key,
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/20',
    title: 'Environment Variables',
    sub: 'Critical — do not skip',
    link: null,
    linkLabel: null,
    instructions: [
      'In Railway dashboard → your project → Variables tab',
      'Add all 3 required environment variables:',
    ],
    code: `DATABASE_URL=your_supabase_postgres_url
JWT_SECRET=your_super_secret_key_min_32_chars
OPENAI_API_KEY=sk-... (optional, for AI upgrade)`,
    tip: 'Never commit .env files to GitHub. Use Railway\'s variable panel only.',
  },
  {
    number: '04',
    icon: Terminal,
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    title: 'Run Migrations',
    sub: '1 command · sets up all tables',
    link: null,
    linkLabel: null,
    instructions: [
      'In your Railway project, open the terminal tab',
      'Run the Prisma migration command:',
    ],
    code: `npx prisma migrate deploy
# Tables created: users, tenants, logs, plugins, billing`,
    tip: 'This creates all database tables automatically. Run once per environment.',
  },
  {
    number: '05',
    icon: Globe,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
    title: 'Get Your Live API URL',
    sub: 'Your backend is now live',
    link: null,
    linkLabel: null,
    instructions: [
      'Railway gives you a URL like: https://your-app.up.railway.app',
      'Test it: open the URL in browser — you should see the API response',
      'Copy this URL for the next step',
    ],
    code: `# Test your live API
curl https://your-app.up.railway.app/health
# Expected: { "status": "ok", "version": "1.0.0" }`,
    tip: 'All your API endpoints are now live and accessible from anywhere.',
  },
  {
    number: '06',
    icon: Smartphone,
    color: 'text-pink-400',
    bg: 'bg-pink-500/10',
    border: 'border-pink-500/20',
    title: 'Connect Frontend',
    sub: 'Replace localhost with live URL',
    link: null,
    linkLabel: null,
    instructions: [
      'In your frontend codebase, create or update .env:',
      'Then update your API calls to use import.meta.env.VITE_API_URL',
    ],
    code: `# .env (frontend)
VITE_API_URL=https://your-app.up.railway.app

# In your code:
const API = import.meta.env.VITE_API_URL;`,
    tip: 'All your auth, plugins, and analytics will now run against the live backend.',
  },
  {
    number: '07',
    icon: Cloud,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    title: 'Deploy Frontend — Vercel',
    sub: 'Free · Instant · Auto-redeploy on push',
    link: 'https://vercel.com',
    linkLabel: 'vercel.com',
    instructions: [
      'Go to vercel.com → New Project → Import Git Repository',
      'Select your frontend repo',
      'Add VITE_API_URL in Environment Variables',
      'Click Deploy — done in 60 seconds',
    ],
    code: null,
    tip: 'Every git push auto-redeploys. Your team always has the latest version.',
  },
];

const ENV_VARS = [
  { key: 'DATABASE_URL', description: 'Supabase PostgreSQL connection string', required: true },
  { key: 'JWT_SECRET', description: 'Secret key for signing auth tokens (32+ chars)', required: true },
  { key: 'OPENAI_API_KEY', description: 'OpenAI API key for AI coaching engine', required: false },
  { key: 'PORT', description: 'Server port (Railway sets this automatically)', required: false },
];

function CodeBlock({ code }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="relative mt-3 rounded-xl bg-black/40 border border-white/8 overflow-hidden">
      <button
        onClick={copy}
        className="absolute top-2 right-2 flex items-center gap-1 text-[10px] text-white/30 hover:text-white/60 transition-colors px-2 py-1 glass rounded-lg"
      >
        <Copy size={10} /> {copied ? 'Copied!' : 'Copy'}
      </button>
      <pre className="text-xs text-emerald-300/80 p-4 overflow-x-auto font-mono leading-relaxed">
        {code}
      </pre>
    </div>
  );
}

export default function DeploymentGuide() {
  const [openStep, setOpenStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState(new Set());

  const toggleComplete = (i) => {
    setCompletedSteps(prev => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  const completedCount = completedSteps.size;
  const totalSteps = STEPS.length;
  const progressPct = Math.round((completedCount / totalSteps) * 100);

  return (
    <div className="max-w-3xl mx-auto">
      <MobileHeader title="Deploy" />

      <div className="hidden lg:block px-6 pt-6 pb-4">
        <div className="flex items-center gap-2 mb-1">
          <Server size={16} className="text-indigo-400" />
          <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">Deployment Guide</span>
        </div>
        <h1 className="text-2xl font-bold text-white">Live in 1 Day</h1>
        <p className="text-white/35 text-sm mt-0.5">Backend + Database + Frontend · Production-ready in 7 steps</p>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-5">
        {/* Progress bar */}
        <div className="glass rounded-xl p-4 border border-indigo-500/20">
          <div className="flex items-center justify-between mb-2">
            <p className="text-white text-sm font-semibold">Deployment Progress</p>
            <span className="text-indigo-400 text-sm font-bold">{completedCount}/{totalSteps} steps</span>
          </div>
          <div className="h-2 bg-white/6 rounded-full overflow-hidden">
            <div
              className="h-full bg-indigo-500 rounded-full transition-all duration-700"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <p className="text-white/25 text-xs mt-1.5">
            {completedCount === 0 ? 'Start with Step 01 — Database setup takes 5 minutes.' :
             completedCount === totalSteps ? '🎉 Your SaaS is live! Share your URL.' :
             `${totalSteps - completedCount} steps remaining. Keep going.`}
          </p>
        </div>

        {/* Stack overview */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Backend', value: 'Node.js + Express', icon: Server, color: 'text-indigo-400' },
            { label: 'Database', value: 'Supabase Postgres', icon: Database, color: 'text-emerald-400' },
            { label: 'Hosting', value: 'Railway + Vercel', icon: Cloud, color: 'text-cyan-400' },
            { label: 'Auth', value: 'JWT (built-in)', icon: ShieldCheck, color: 'text-yellow-400' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="glass rounded-xl p-3 border border-white/8">
              <Icon size={14} className={`${color} mb-1.5`} />
              <p className="text-white/30 text-[10px] uppercase tracking-wider">{label}</p>
              <p className="text-white text-xs font-semibold mt-0.5">{value}</p>
            </div>
          ))}
        </div>

        {/* Step-by-step accordion */}
        <div className="space-y-3">
          {STEPS.map((step, i) => {
            const isOpen = openStep === i;
            const isDone = completedSteps.has(i);
            const Icon = step.icon;
            return (
              <div
                key={i}
                className={`glass rounded-xl border overflow-hidden transition-all ${isDone ? 'border-green-500/20' : step.border}`}
              >
                <button
                  onClick={() => setOpenStep(isOpen ? -1 : i)}
                  className="w-full flex items-center gap-3 p-4 text-left"
                >
                  <div className={`w-10 h-10 rounded-xl ${isDone ? 'bg-green-500/15' : step.bg} border ${isDone ? 'border-green-500/20' : step.border} flex items-center justify-center shrink-0`}>
                    {isDone ? <CheckCircle2 size={16} className="text-green-400" /> : <Icon size={16} className={step.color} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-white/20 text-[10px] font-mono">{step.number}</span>
                      <p className={`text-sm font-semibold ${isDone ? 'text-white/50 line-through' : 'text-white'}`}>{step.title}</p>
                    </div>
                    <p className="text-white/30 text-xs mt-0.5">{step.sub}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {step.link && (
                      <a
                        href={step.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={e => e.stopPropagation()}
                        className={`hidden lg:flex items-center gap-1 text-[10px] ${step.color} hover:opacity-70 transition-opacity`}
                      >
                        <ExternalLink size={9} /> {step.linkLabel}
                      </a>
                    )}
                    {isOpen ? <ChevronUp size={14} className="text-white/30" /> : <ChevronDown size={14} className="text-white/30" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 space-y-3 border-t border-white/5 pt-3">
                    <ol className="space-y-2">
                      {step.instructions.map((inst, j) => (
                        <li key={j} className="flex items-start gap-2.5">
                          <span className={`text-[10px] font-bold ${step.color} mt-0.5 shrink-0`}>{j + 1}.</span>
                          <p className="text-white/60 text-sm leading-snug">{inst}</p>
                        </li>
                      ))}
                    </ol>

                    {step.code && <CodeBlock code={step.code} />}

                    {step.tip && (
                      <div className="flex items-start gap-2 px-3 py-2.5 bg-white/3 rounded-xl border border-white/6">
                        <Zap size={11} className={`${step.color} mt-0.5 shrink-0`} />
                        <p className="text-white/40 text-xs leading-snug">{step.tip}</p>
                      </div>
                    )}

                    <button
                      onClick={() => {
                        toggleComplete(i);
                        if (!completedSteps.has(i) && i < STEPS.length - 1) setOpenStep(i + 1);
                      }}
                      className={`w-full py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
                        isDone
                          ? 'bg-white/6 text-white/30 border border-white/8'
                          : `${step.bg} ${step.color} border ${step.border} hover:opacity-80`
                      }`}
                    >
                      {isDone ? (
                        <><CheckCircle2 size={12} /> Completed — Undo</>
                      ) : (
                        <>Mark Complete <ArrowRight size={12} /></>
                      )}
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Environment variable reference */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3">Environment Variables Reference</p>
          <div className="glass rounded-xl overflow-hidden border border-white/8">
            {ENV_VARS.map((v, i) => (
              <div key={v.key} className={`flex items-start gap-3 px-4 py-3 ${i < ENV_VARS.length - 1 ? 'border-b border-white/5' : ''}`}>
                <code className="text-xs font-mono text-emerald-400 shrink-0 pt-0.5">{v.key}</code>
                <div className="flex-1 min-w-0">
                  <p className="text-white/50 text-xs">{v.description}</p>
                </div>
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full shrink-0 ${v.required ? 'text-red-400 bg-red-500/10 border border-red-500/20' : 'text-white/20 bg-white/5 border border-white/8'}`}>
                  {v.required ? 'Required' : 'Optional'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Launch checklist */}
        <div className="glass rounded-xl p-5 border border-indigo-500/20">
          <p className="text-white font-semibold text-sm mb-3">Pre-Launch Checklist</p>
          <div className="space-y-2">
            {[
              'Database connected and migrations run',
              'JWT_SECRET set (never hardcode it)',
              'CORS configured for your frontend domain',
              'Test login with demo accounts',
              'Test task logging and score update',
              'Verify leaderboard loads for all tenants',
              'Share URL with your first pilot user',
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-2.5">
                <div className="w-4 h-4 rounded border border-white/15 shrink-0" />
                <p className="text-white/50 text-sm">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
