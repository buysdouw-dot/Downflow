/**
 * RealtimePulse — Live Team Activity Feed + Performance Heatmap
 * Shows who's executing right now, team energy score, and 30-day heatmap.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Activity, Zap, Users, TrendingUp, TrendingDown,
  CheckCircle2, Clock, AlertCircle, Flame, BarChart2,
  Circle, ChevronRight, RefreshCw, Eye,
} from 'lucide-react';

// ── Simulated live team ───────────────────────────────────────────────────────
const TEAM = [
  { id: 1,  name: 'Marcus Chen',    avatar: 'MC', dept: 'Sales',   baseScore: 84, trend: 'up'   },
  { id: 2,  name: 'Sarah Kim',      avatar: 'SK', dept: 'Sales',   baseScore: 71, trend: 'up'   },
  { id: 3,  name: 'James Torres',   avatar: 'JT', dept: 'Ops',     baseScore: 58, trend: 'flat' },
  { id: 4,  name: 'Leila Nkosi',    avatar: 'LN', dept: 'Sales',   baseScore: 92, trend: 'up'   },
  { id: 5,  name: 'Daniel Park',    avatar: 'DP', dept: 'Ops',     baseScore: 43, trend: 'down' },
  { id: 6,  name: 'Aisha Williams', avatar: 'AW', dept: 'Sales',   baseScore: 77, trend: 'up'   },
  { id: 7,  name: 'Tom Bennett',    avatar: 'TB', dept: 'Finance', baseScore: 35, trend: 'down' },
  { id: 8,  name: 'Priya Sharma',   avatar: 'PS', dept: 'Ops',     baseScore: 66, trend: 'flat' },
  { id: 9,  name: 'Carlos Ruiz',    avatar: 'CR', dept: 'Finance', baseScore: 88, trend: 'up'   },
  { id: 10, name: 'Nina Okafor',    avatar: 'NO', dept: 'Sales',   baseScore: 52, trend: 'flat' },
];

const ACTIONS = [
  'completed morning check-in',
  'logged a sales call',
  'hit daily target',
  'submitted activity report',
  'updated CRM pipeline',
  'completed team task',
  'reached 5-day streak',
  'logged outbound calls',
  'finished training module',
  'beat personal best',
];

const DEPTS = ['All', 'Sales', 'Ops', 'Finance'];

function getStatus(score) {
  if (score >= 70) return 'green';
  if (score >= 40) return 'yellow';
  return 'red';
}

const STATUS_CFG = {
  green:  { color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', bar: 'bg-emerald-400', dot: 'bg-emerald-400', label: 'GREEN'  },
  yellow: { color: 'text-yellow-400',  bg: 'bg-yellow-500/10',  border: 'border-yellow-500/20',  bar: 'bg-yellow-400',  dot: 'bg-yellow-400',  label: 'YELLOW' },
  red:    { color: 'text-red-400',     bg: 'bg-red-500/10',     border: 'border-red-500/20',     bar: 'bg-red-400',     dot: 'bg-red-400',     label: 'RED'    },
};

const AVATAR_COLORS = [
  'from-indigo-500 to-purple-600', 'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',  'from-pink-500 to-rose-600',
  'from-cyan-500 to-blue-600',     'from-violet-500 to-purple-600',
  'from-fuchsia-500 to-pink-600',  'from-sky-500 to-indigo-600',
  'from-orange-500 to-red-600',    'from-teal-500 to-cyan-600',
];

// 30-day heatmap data generator
function genHeatmap() {
  const today = new Date();
  return Array.from({ length: 30 }, (_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (29 - i));
    const dow = d.getDay();
    const isWeekend = dow === 0 || dow === 6;
    const base = isWeekend ? 20 : 55 + Math.random() * 40;
    return {
      date: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      score: Math.round(isWeekend ? base * 0.4 : base),
      day: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][dow],
      isWeekend,
    };
  });
}

// ── Sub-components ────────────────────────────────────────────────────────────
function MemberRow({ member, score, online, lastAction, rank }) {
  const status = getStatus(score);
  const cfg = STATUS_CFG[status];
  return (
    <div className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${cfg.border} ${cfg.bg}`}>
      <span className="text-white/15 text-[9px] font-mono w-4 shrink-0">#{rank}</span>
      <div className="relative shrink-0">
        <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${AVATAR_COLORS[member.id - 1]} flex items-center justify-center text-[10px] font-bold text-white`}>
          {member.avatar}
        </div>
        <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#070b14] ${online ? 'bg-emerald-400' : 'bg-white/20'}`} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <p className="text-white text-xs font-semibold truncate">{member.name}</p>
          <span className="text-white/20 text-[9px]">{member.dept}</span>
        </div>
        <p className="text-white/30 text-[9px] truncate">{online ? lastAction : 'Offline'}</p>
      </div>
      <div className="text-right shrink-0">
        <p className={`text-sm font-black ${cfg.color}`}>{score}</p>
        <div className={`text-[8px] font-bold px-1 py-0.5 rounded-full ${cfg.bg} border ${cfg.border} ${cfg.color}`}>
          {cfg.label}
        </div>
      </div>
      <div className="w-1 h-8 rounded-full bg-white/8 relative overflow-hidden shrink-0">
        <div className={`absolute bottom-0 left-0 right-0 rounded-full ${cfg.bar} transition-all duration-700`}
          style={{ height: `${Math.min(100, score)}%` }} />
      </div>
    </div>
  );
}

function HeatmapCell({ entry }) {
  const s = entry.score;
  const intensity = entry.isWeekend ? 'opacity-20' : s >= 80 ? 'opacity-100' : s >= 60 ? 'opacity-70' : s >= 40 ? 'opacity-45' : 'opacity-20';
  const color = s >= 70 ? 'bg-emerald-400' : s >= 40 ? 'bg-yellow-400' : 'bg-red-400';
  return (
    <div className="group relative">
      <div className={`w-5 h-5 rounded-sm ${color} ${intensity} transition-all hover:scale-125 cursor-default`} />
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 rounded-lg bg-[#0b0f1a] border border-white/15 text-[9px] text-white/70 whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-10 shadow-xl">
        {entry.date}: {entry.score}
      </div>
    </div>
  );
}

function StatPill({ icon: Icon, label, value, color }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/3 border border-white/6">
      <Icon size={12} className={color} />
      <div>
        <p className={`text-sm font-black ${color}`}>{value}</p>
        <p className="text-white/25 text-[9px]">{label}</p>
      </div>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function RealtimePulse() {
  const [scores,    setScores]   = useState(() => Object.fromEntries(TEAM.map(m => [m.id, m.baseScore])));
  const [online,    setOnline]   = useState(() => Object.fromEntries(TEAM.map(m => [m.id, Math.random() > 0.3])));
  const [actions,   setActions]  = useState(() => Object.fromEntries(TEAM.map(m => [m.id, ACTIONS[Math.floor(Math.random() * ACTIONS.length)]])));
  const [feed,      setFeed]     = useState([]);
  const [dept,      setDept]     = useState('All');
  const [heatmap]               = useState(genHeatmap);
  const [tick,      setTick]     = useState(0);
  const [liveMode,  setLiveMode] = useState(true);
  const feedRef = useRef(null);

  // Simulate live updates every 4s
  useEffect(() => {
    if (!liveMode) return;
    const interval = setInterval(() => {
      const member = TEAM[Math.floor(Math.random() * TEAM.length)];
      const delta  = Math.round((Math.random() - 0.4) * 8);
      const action = ACTIONS[Math.floor(Math.random() * ACTIONS.length)];

      setScores(prev => ({
        ...prev,
        [member.id]: Math.max(0, Math.min(100, (prev[member.id] ?? member.baseScore) + delta)),
      }));
      setOnline(prev => ({ ...prev, [member.id]: true }));
      setActions(prev => ({ ...prev, [member.id]: action }));
      setFeed(prev => [
        { id: Date.now(), name: member.name, avatar: member.avatar, color: AVATAR_COLORS[member.id - 1], action, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), delta },
        ...prev.slice(0, 24),
      ]);
      setTick(t => t + 1);
    }, 4000);
    return () => clearInterval(interval);
  }, [liveMode]);

  // Scroll feed to top on new entry
  useEffect(() => {
    if (feedRef.current) feedRef.current.scrollTop = 0;
  }, [feed.length]);

  const filtered = TEAM
    .filter(m => dept === 'All' || m.dept === dept)
    .sort((a, b) => (scores[b.id] ?? 0) - (scores[a.id] ?? 0));

  const teamAvg    = Math.round(filtered.reduce((s, m) => s + (scores[m.id] ?? 0), 0) / filtered.length);
  const greenCount = filtered.filter(m => getStatus(scores[m.id] ?? 0) === 'green').length;
  const redCount   = filtered.filter(m => getStatus(scores[m.id] ?? 0) === 'red').length;
  const teamEnergy = Math.round((greenCount / filtered.length) * 100);

  const heatAvg  = Math.round(heatmap.reduce((s, d) => s + d.score, 0) / heatmap.length);
  const heatBest = heatmap.reduce((b, d) => d.score > b.score ? d : b, heatmap[0]);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">
                {liveMode ? 'Live' : 'Paused'} · {tick} updates
              </p>
            </div>
            <h1 className="text-3xl font-black mb-1">Team Pulse</h1>
            <p className="text-white/35 text-sm">Real-time activity feed + performance heatmap for your entire team.</p>
          </div>
          <button
            onClick={() => setLiveMode(v => !v)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all border ${
              liveMode
                ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400 hover:bg-emerald-500/15'
                : 'bg-white/5 border-white/10 text-white/40 hover:text-white/60'
            }`}>
            {liveMode ? <><Activity size={13} /> Live</> : <><RefreshCw size={13} /> Resume</>}
          </button>
        </div>

        {/* KPI row */}
        <div className="flex flex-wrap gap-3">
          <StatPill icon={Flame}       label="Team Energy"  value={`${teamEnergy}%`}    color="text-orange-400" />
          <StatPill icon={BarChart2}   label="Avg Score"    value={teamAvg}              color="text-indigo-400" />
          <StatPill icon={CheckCircle2}label="In Green"     value={greenCount}           color="text-emerald-400"/>
          <StatPill icon={AlertCircle} label="At Risk"      value={redCount}             color="text-red-400"    />
          <StatPill icon={Eye}         label="Online Now"   value={Object.values(online).filter(Boolean).length} color="text-cyan-400" />
        </div>

        {/* Team energy bar */}
        <div className="p-4 rounded-2xl bg-white/2 border border-white/6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-white/40 text-xs font-bold">TEAM ENERGY</p>
            <p className={`text-sm font-black ${teamEnergy >= 70 ? 'text-emerald-400' : teamEnergy >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
              {teamEnergy}%
            </p>
          </div>
          <div className="h-3 bg-white/6 rounded-full overflow-hidden flex gap-0.5">
            <div className="h-full bg-emerald-400 rounded-full transition-all duration-700" style={{ width: `${(greenCount / filtered.length) * 100}%` }} />
            <div className="h-full bg-yellow-400 rounded-full transition-all duration-700" style={{ width: `${(filtered.filter(m => getStatus(scores[m.id] ?? 0) === 'yellow').length / filtered.length) * 100}%` }} />
            <div className="h-full bg-red-400 rounded-full transition-all duration-700" style={{ width: `${(redCount / filtered.length) * 100}%` }} />
          </div>
          <div className="flex gap-4 mt-2">
            {[['Green', greenCount, 'text-emerald-400'], ['Yellow', filtered.filter(m => getStatus(scores[m.id] ?? 0) === 'yellow').length, 'text-yellow-400'], ['Red', redCount, 'text-red-400']].map(([label, count, color]) => (
              <div key={label} className="flex items-center gap-1.5">
                <div className={`w-2 h-2 rounded-full ${color.replace('text-','bg-')}`} />
                <span className="text-white/30 text-[10px]">{count} {label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Main grid */}
        <div className="grid lg:grid-cols-[1fr_300px] gap-6">

          {/* Left: leaderboard + heatmap */}
          <div className="space-y-5">

            {/* Dept filter */}
            <div className="flex items-center gap-2">
              {DEPTS.map(d => (
                <button key={d} onClick={() => setDept(d)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    dept === d ? 'bg-indigo-500 text-white' : 'bg-white/4 border border-white/8 text-white/35 hover:text-white/60'
                  }`}>{d}</button>
              ))}
            </div>

            {/* Member rows */}
            <div className="space-y-2">
              {filtered.map((member, i) => (
                <MemberRow
                  key={member.id}
                  member={member}
                  score={scores[member.id] ?? member.baseScore}
                  online={online[member.id]}
                  lastAction={actions[member.id]}
                  rank={i + 1}
                />
              ))}
            </div>

            {/* 30-day heatmap */}
            <div className="rounded-2xl border border-white/8 bg-white/2 p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-white/40 text-xs font-bold uppercase tracking-widest">30-Day Performance Heatmap</p>
                  <p className="text-white/20 text-[9px] mt-0.5">Avg: {heatAvg} · Best day: {heatBest.date} ({heatBest.score})</p>
                </div>
                <div className="flex items-center gap-2 text-[9px] text-white/25">
                  <div className="w-2.5 h-2.5 rounded-sm bg-emerald-400 opacity-100" /> Green
                  <div className="w-2.5 h-2.5 rounded-sm bg-yellow-400 opacity-70 ml-1" /> Yellow
                  <div className="w-2.5 h-2.5 rounded-sm bg-red-400 opacity-45 ml-1" /> Red
                </div>
              </div>
              <div className="flex flex-wrap gap-1">
                {heatmap.map((entry, i) => <HeatmapCell key={i} entry={entry} />)}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map(day => {
                  const dayEntries = heatmap.filter(e => e.day === day);
                  const avg = dayEntries.length ? Math.round(dayEntries.reduce((s, e) => s + e.score, 0) / dayEntries.length) : 0;
                  return (
                    <div key={day} className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/4 border border-white/6">
                      <span className="text-white/30 text-[9px]">{day}</span>
                      <span className={`text-[9px] font-bold ${avg >= 70 ? 'text-emerald-400' : avg >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>{avg}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right: live feed */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Live Activity Feed</p>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-400 text-[9px] font-bold">{feed.length} events</span>
              </div>
            </div>

            <div ref={feedRef} className="space-y-2 max-h-[600px] overflow-y-auto scrollbar-hide">
              {feed.length === 0 ? (
                <div className="p-6 rounded-2xl border border-white/6 bg-white/2 text-center space-y-2">
                  <Activity size={20} className="mx-auto text-white/15" />
                  <p className="text-white/25 text-sm">Waiting for events…</p>
                  <p className="text-white/15 text-xs">Live mode is {liveMode ? 'on' : 'off'}</p>
                </div>
              ) : (
                feed.map((entry, i) => (
                  <div key={entry.id}
                    className={`flex items-start gap-2.5 p-3 rounded-xl border transition-all ${
                      i === 0 ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/5 bg-white/1'
                    }`}>
                    <div className={`w-7 h-7 rounded-full bg-gradient-to-br ${entry.color} flex items-center justify-center text-[9px] font-bold text-white shrink-0`}>
                      {entry.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white/60 text-[10px] leading-snug">
                        <span className="font-semibold text-white/80">{entry.name}</span>{' '}
                        {entry.action}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <p className="text-white/20 text-[9px]">{entry.time}</p>
                        {entry.delta > 0 && <span className="text-emerald-400 text-[9px] font-bold">+{entry.delta} pts</span>}
                        {entry.delta < 0 && <span className="text-red-400 text-[9px] font-bold">{entry.delta} pts</span>}
                      </div>
                    </div>
                    {i === 0 && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0 mt-1" />}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
