import { useState } from 'react';
import {
  FolderOpen, FileCode, Copy, CheckCheck, Terminal,
  Database, Globe, Server, Package, ChevronRight, ChevronDown,
  Rocket, ArrowRight, ExternalLink, AlertTriangle, Info,
} from 'lucide-react';

// ── File tree ──────────────────────────────────────────────────────────────────
const TREE = [
  {
    group: 'Root',
    files: [
      { path: 'vercel.json',   label: 'vercel.json',   icon: Globe   },
      { path: 'railway.json',  label: 'railway.json',  icon: Server  },
      { path: 'README.md',     label: 'README.md',     icon: FileCode },
      { path: '.gitignore',    label: '.gitignore',    icon: FileCode },
    ],
  },
  {
    group: 'backend/',
    files: [
      { path: 'backend/package.json',          label: 'package.json',            icon: Package  },
      { path: 'backend/.env.example',          label: '.env.example',            icon: FileCode },
      { path: 'backend/src/index.js',          label: 'src/index.js',            icon: FileCode },
      { path: 'backend/src/app.js',            label: 'src/app.js',              icon: FileCode },
      { path: 'backend/src/middleware/auth.js',label: 'src/middleware/auth.js',  icon: FileCode },
      { path: 'backend/src/routes/auth.js',    label: 'src/routes/auth.js',      icon: FileCode },
      { path: 'backend/src/routes/tasks.js',   label: 'src/routes/tasks.js',     icon: FileCode },
      { path: 'backend/src/routes/ai.js',      label: 'src/routes/ai.js',        icon: FileCode },
      { path: 'backend/src/engine/score.js',   label: 'src/engine/score.js',     icon: FileCode },
      { path: 'backend/src/engine/coach.js',   label: 'src/engine/coach.js',     icon: FileCode },
      { path: 'backend/src/db/supabase.js',    label: 'src/db/supabase.js',      icon: Database },
    ],
  },
  {
    group: 'frontend/',
    files: [
      { path: 'frontend/package.json',                        label: 'package.json',             icon: Package  },
      { path: 'frontend/vite.config.js',                      label: 'vite.config.js',           icon: FileCode },
      { path: 'frontend/.env.example',                        label: '.env.example',             icon: FileCode },
      { path: 'frontend/index.html',                          label: 'index.html',               icon: FileCode },
      { path: 'frontend/tailwind.config.js',                  label: 'tailwind.config.js',       icon: FileCode },
      { path: 'frontend/postcss.config.js',                   label: 'postcss.config.js',        icon: FileCode },
      { path: 'frontend/src/main.jsx',                        label: 'src/main.jsx',             icon: FileCode },
      { path: 'frontend/src/App.jsx',                         label: 'src/App.jsx',              icon: FileCode },
      { path: 'frontend/src/api.js',                          label: 'src/api.js',               icon: FileCode },
      { path: 'frontend/src/pages/Login.jsx',                 label: 'src/pages/Login.jsx',      icon: FileCode },
      { path: 'frontend/src/pages/Dashboard.jsx',             label: 'src/pages/Dashboard.jsx',  icon: FileCode },
      { path: 'frontend/src/pages/Tasks.jsx',                 label: 'src/pages/Tasks.jsx',      icon: FileCode },
      { path: 'frontend/src/pages/AICoach.jsx',               label: 'src/pages/AICoach.jsx',    icon: FileCode },
      { path: 'frontend/src/components/ScoreCard.jsx',        label: 'src/components/ScoreCard.jsx',  icon: FileCode },
      { path: 'frontend/src/components/TaskList.jsx',         label: 'src/components/TaskList.jsx',   icon: FileCode },
      { path: 'frontend/src/components/ProtectedRoute.jsx',   label: 'src/components/ProtectedRoute.jsx', icon: FileCode },
    ],
  },
  {
    group: 'supabase/',
    files: [
      { path: 'supabase/schema.sql',    label: 'schema.sql',    icon: Database },
      { path: 'supabase/seed.sql',      label: 'seed.sql',      icon: Database },
      { path: 'supabase/policies.sql',  label: 'policies.sql',  icon: Database },
    ],
  },
];

// ── File contents ──────────────────────────────────────────────────────────────
const FILES = {
  // ── Root ──
  'vercel.json': `{
  "version": 2,
  "builds": [
    {
      "src": "frontend/package.json",
      "use": "@vercel/static-build",
      "config": { "distDir": "dist" }
    }
  ],
  "routes": [
    { "src": "/api/(.*)", "dest": "https://your-railway-app.railway.app/api/$1" },
    { "src": "/(.*)",     "dest": "/index.html" }
  ],
  "env": {
    "VITE_API_URL": "@vite_api_url"
  }
}`,

  'railway.json': `{
  "build": {
    "builder": "NIXPACKS",
    "buildCommand": "cd backend && npm install"
  },
  "deploy": {
    "startCommand": "cd backend && node src/index.js",
    "healthcheckPath": "/health",
    "healthcheckTimeout": 300,
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 3
  }
}`,

  'README.md': `# Behavior Engine SaaS

Production-ready SaaS kit. Deploy in under 30 minutes.

## Stack
- **Backend**: Node.js + Express on Railway
- **Frontend**: React + Vite + Tailwind on Vercel
- **Database**: Supabase (Postgres + Auth + Row-Level Security)

## Quick Deploy

### 1. Supabase Setup
1. Create project at supabase.com
2. Run \`supabase/schema.sql\` in SQL editor
3. Run \`supabase/policies.sql\` in SQL editor
4. Copy your Project URL + anon key

### 2. Deploy Backend (Railway)
\`\`\`bash
# Push to GitHub, then connect repo in Railway dashboard
# Set environment variables:
SUPABASE_URL=your_project_url
SUPABASE_SERVICE_KEY=your_service_role_key
JWT_SECRET=your_32_char_random_string
PORT=3000
\`\`\`

### 3. Deploy Frontend (Vercel)
\`\`\`bash
# Import repo in Vercel dashboard
# Set root directory: frontend
# Set environment variable:
VITE_API_URL=https://your-railway-app.railway.app
\`\`\`

### 4. Local Dev
\`\`\`bash
# Backend
cd backend && npm install && cp .env.example .env
node src/index.js

# Frontend
cd frontend && npm install && cp .env.example .env
npm run dev
\`\`\`

## Architecture
- JWT auth (Supabase Auth + custom middleware)
- Row-Level Security on all tables
- Score engine: 100-point daily execution scoring
- AI coach: GPT-4o-mini coaching messages via OpenAI
- REST API with full CRUD for tasks

## Environment Variables

### Backend (.env)
| Variable | Description |
|---|---|
| SUPABASE_URL | Your Supabase project URL |
| SUPABASE_SERVICE_KEY | Service role key (backend only) |
| JWT_SECRET | 32+ char random string |
| OPENAI_API_KEY | For AI coach endpoint |
| PORT | Server port (Railway sets automatically) |

### Frontend (.env)
| Variable | Description |
|---|---|
| VITE_API_URL | Railway backend URL |
| VITE_SUPABASE_URL | Supabase project URL |
| VITE_SUPABASE_ANON_KEY | Supabase anon/public key |
`,

  '.gitignore': `# Dependencies
node_modules/
.pnp
.pnp.js

# Environment
.env
.env.local
.env.*.local

# Build output
dist/
build/
.next/
out/

# Logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# OS
.DS_Store
Thumbs.db

# Editor
.vscode/
.idea/
*.swp
*.swo

# Vercel
.vercel

# Railway
.railway
`,

  // ── Backend ──
  'backend/package.json': `{
  "name": "behavior-engine-backend",
  "version": "1.0.0",
  "description": "Behavior Engine SaaS — backend API",
  "main": "src/index.js",
  "scripts": {
    "start": "node src/index.js",
    "dev":   "nodemon src/index.js"
  },
  "dependencies": {
    "@supabase/supabase-js": "^2.39.0",
    "cors":     "^2.8.5",
    "dotenv":   "^16.4.1",
    "express":  "^4.18.2",
    "jsonwebtoken": "^9.0.2",
    "openai":   "^4.28.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.3"
  },
  "engines": { "node": ">=18.0.0" }
}`,

  'backend/.env.example': `# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your_service_role_key_here

# Auth
JWT_SECRET=replace_with_32_char_random_string

# OpenAI (for AI coach)
OPENAI_API_KEY=sk-...

# Server
PORT=3000
NODE_ENV=development`,

  'backend/src/index.js': `require('dotenv').config();
const app = require('./app');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(\`[BE] Behavior Engine running on port \${PORT}\`);
  console.log(\`[BE] Environment: \${process.env.NODE_ENV || 'development'}\`);
});`,

  'backend/src/app.js': `const express = require('express');
const cors    = require('cors');

const authRoutes  = require('./routes/auth');
const taskRoutes  = require('./routes/tasks');
const aiRoutes    = require('./routes/ai');

const app = express();

// ── Middleware ──────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json());

// ── Routes ──────────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', ts: Date.now() }));

app.use('/auth',  authRoutes);
app.use('/tasks', taskRoutes);
app.use('/ai',    aiRoutes);

// ── Global error handler ────────────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('[ERROR]', err.message);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

module.exports = app;`,

  'backend/src/middleware/auth.js': `const jwt = require('jsonwebtoken');

/**
 * requireAuth — verifies Bearer token issued by Supabase Auth.
 * Attaches decoded payload to req.user.
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid Authorization header' });
  }

  const token = header.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token expired or invalid' });
  }
}

module.exports = { requireAuth };`,

  'backend/src/routes/auth.js': `const router  = require('express').Router();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// POST /auth/register
router.post('/register', async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email + password required' });

  try {
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });
    if (error) throw error;
    res.status(201).json({ user: data.user });
  } catch (err) {
    next(err);
  }
});

// POST /auth/login
router.post('/login', async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email + password required' });

  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    res.json({ token: data.session.access_token, user: data.user });
  } catch (err) {
    next(err);
  }
});

module.exports = router;`,

  'backend/src/routes/tasks.js': `const router        = require('express').Router();
const { requireAuth } = require('../middleware/auth');
const db              = require('../db/supabase');
const { calcScore }   = require('../engine/score');

// GET /tasks — list user tasks
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const { data, error } = await db
      .from('tasks')
      .select('*')
      .eq('user_id', req.user.sub)
      .order('created_at', { ascending: false });

    if (error) throw error;
    res.json(data);
  } catch (err) { next(err); }
});

// POST /tasks — create task
router.post('/', requireAuth, async (req, res, next) => {
  const { title, points = 1 } = req.body;
  if (!title) return res.status(400).json({ error: 'title required' });

  try {
    const { data, error } = await db
      .from('tasks')
      .insert({ user_id: req.user.sub, title, points })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json(data);
  } catch (err) { next(err); }
});

// POST /tasks/:id/complete — mark done + update score
router.post('/:id/complete', requireAuth, async (req, res, next) => {
  try {
    // mark task complete
    const { data: task, error: taskErr } = await db
      .from('tasks')
      .update({ completed: true, completed_at: new Date().toISOString() })
      .eq('id', req.params.id)
      .eq('user_id', req.user.sub)
      .select()
      .single();

    if (taskErr) throw taskErr;

    // fetch all today tasks for score recalc
    const today = new Date().toISOString().split('T')[0];
    const { data: todayTasks } = await db
      .from('tasks')
      .select('*')
      .eq('user_id', req.user.sub)
      .gte('created_at', today);

    const score = calcScore(todayTasks || []);

    // upsert daily score
    await db.from('scores').upsert(
      { user_id: req.user.sub, score, updated_at: new Date().toISOString() },
      { onConflict: 'user_id' }
    );

    res.json({ task, score });
  } catch (err) { next(err); }
});

// DELETE /tasks/:id
router.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    const { error } = await db
      .from('tasks')
      .delete()
      .eq('id', req.params.id)
      .eq('user_id', req.user.sub);

    if (error) throw error;
    res.status(204).end();
  } catch (err) { next(err); }
});

module.exports = router;`,

  'backend/src/routes/ai.js': `const router          = require('express').Router();
const { requireAuth } = require('../middleware/auth');
const db              = require('../db/supabase');
const { coach }       = require('../engine/coach');
const OpenAI          = require('openai');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// GET /ai/coach — get AI coaching message
router.get('/coach', requireAuth, async (req, res, next) => {
  try {
    // fetch current score
    const { data: scoreRow } = await db
      .from('scores')
      .select('score')
      .eq('user_id', req.user.sub)
      .single();

    const score       = scoreRow?.score ?? 0;
    const localAdvice = coach({ score, consistency: score });

    // optional: enrich with GPT-4o-mini
    let aiMessage = localAdvice;
    if (process.env.OPENAI_API_KEY) {
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        max_tokens: 80,
        messages: [
          {
            role: 'system',
            content: 'You are a brutally honest sales execution coach. 1-2 sentences max. No fluff.',
          },
          {
            role: 'user',
            content: \`Execution score: \${score}/100. Today's advice: \${localAdvice}\`,
          },
        ],
      });
      aiMessage = completion.choices[0].message.content.trim();
    }

    res.json({ score, message: aiMessage });
  } catch (err) { next(err); }
});

module.exports = router;`,

  'backend/src/engine/score.js': `/**
 * calcScore — compute 0-100 execution score from today's task list.
 *
 * Rules:
 *  - 10 points per completed task (max 70)
 *  - +20 if all tasks completed
 *  - +10 consistency bonus (passed in separately)
 */
function calcScore(tasks = []) {
  const total     = tasks.length;
  const completed = tasks.filter(t => t.completed).length;

  if (total === 0) return 0;

  const taskPoints   = Math.min(completed * 10, 70);
  const perfectBonus = completed === total ? 20 : 0;
  const baseScore    = taskPoints + perfectBonus;

  return Math.min(baseScore, 100);
}

/**
 * calcStreak — count consecutive days with score >= threshold.
 */
function calcStreak(dailyScores = [], threshold = 60) {
  let streak = 0;
  const sorted = [...dailyScores].sort(
    (a, b) => new Date(b.date) - new Date(a.date)
  );

  for (const day of sorted) {
    if (day.score >= threshold) streak++;
    else break;
  }
  return streak;
}

module.exports = { calcScore, calcStreak };`,

  'backend/src/engine/coach.js': `/**
 * coach — rule-based coaching message.
 * Falls back to this when OpenAI key is absent.
 *
 * @param {{ score: number, consistency: number }} user
 * @returns {string}
 */
function coach({ score = 0, consistency = 0 }) {
  if (score === 0)        return 'No tasks logged yet. Start with 1 task right now.';
  if (score < 20)         return 'Focus on 1 task only today. Small wins compound.';
  if (consistency < 40)   return 'Build routine before scaling output.';
  if (score >= 80)        return 'Elite execution. Maintain this rhythm.';
  if (score >= 60)        return 'Solid. Push for perfect completion today.';
  return 'Maintain execution rhythm. No skipping core tasks.';
}

module.exports = { coach };`,

  'backend/src/db/supabase.js': `const { createClient } = require('@supabase/supabase-js');

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) {
  throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_KEY in environment');
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY,
  {
    auth: { persistSession: false },
  }
);

module.exports = supabase;`,

  // ── Frontend ──
  'frontend/package.json': `{
  "name": "behavior-engine-frontend",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev":     "vite",
    "build":   "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "@supabase/supabase-js": "^2.39.0",
    "react":        "^18.3.1",
    "react-dom":    "^18.3.1",
    "react-router-dom": "^6.22.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer":  "^10.4.17",
    "postcss":       "^8.4.35",
    "tailwindcss":   "^3.4.1",
    "vite":          "^5.1.0"
  }
}`,

  'frontend/vite.config.js': `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: process.env.VITE_API_URL || 'http://localhost:3000',
        changeOrigin: true,
        rewrite: path => path.replace(/^\\/api/, ''),
      },
    },
  },
});`,

  'frontend/.env.example': `VITE_API_URL=http://localhost:3000
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here`,

  'frontend/index.html': `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Behavior Engine</title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>`,

  'frontend/tailwind.config.js': `/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50:  '#f0fdf4',
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
        },
      },
    },
  },
  plugins: [],
};`,

  'frontend/postcss.config.js': `export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};`,

  'frontend/src/main.jsx': `import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './index.css';
import App from './App';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);`,

  'frontend/src/App.jsx': `import { Routes, Route, Navigate } from 'react-router-dom';
import Login     from './pages/Login';
import Dashboard from './pages/Dashboard';
import Tasks     from './pages/Tasks';
import AICoach   from './pages/AICoach';
import ProtectedRoute from './components/ProtectedRoute';

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />
      <Route path="/tasks" element={
        <ProtectedRoute>
          <Tasks />
        </ProtectedRoute>
      } />
      <Route path="/coach" element={
        <ProtectedRoute>
          <AICoach />
        </ProtectedRoute>
      } />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}`,

  'frontend/src/api.js': `const BASE = import.meta.env.VITE_API_URL || '';

function getToken() {
  return localStorage.getItem('be_token');
}

async function request(path, options = {}) {
  const token = getToken();
  const res = await fetch(\`\${BASE}\${path}\`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: \`Bearer \${token}\` } : {}),
      ...options.headers,
    },
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || \`HTTP \${res.status}\`);
  return data;
}

export const api = {
  // Auth
  login:    (email, password)         => request('/auth/login',    { method: 'POST', body: JSON.stringify({ email, password }) }),
  register: (email, password)         => request('/auth/register', { method: 'POST', body: JSON.stringify({ email, password }) }),

  // Tasks
  getTasks:     ()           => request('/tasks'),
  createTask:   (title, pts) => request('/tasks', { method: 'POST', body: JSON.stringify({ title, points: pts }) }),
  completeTask: (id)         => request(\`/tasks/\${id}/complete\`, { method: 'POST' }),
  deleteTask:   (id)         => request(\`/tasks/\${id}\`, { method: 'DELETE' }),

  // AI
  getCoach: () => request('/ai/coach'),
};`,

  'frontend/src/pages/Login.jsx': `import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';

export default function Login() {
  const [email, setEmail]     = useState('');
  const [pass,  setPass]      = useState('');
  const [mode,  setMode]      = useState('login'); // 'login' | 'register'
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function submit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const fn = mode === 'login' ? api.login : api.register;
      const data = await fn(email, pass);
      if (data.token) {
        localStorage.setItem('be_token', data.token);
        navigate('/');
      } else {
        setMode('login');
        setError('Account created — please sign in.');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 px-4">
      <div className="w-full max-w-sm">
        <h1 className="text-2xl font-bold text-white mb-1">Behavior Engine</h1>
        <p className="text-gray-400 text-sm mb-8">Execute at 80%+ every day.</p>
        <form onSubmit={submit} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            className="w-full px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white
                       placeholder-gray-500 focus:outline-none focus:border-green-500"
          />
          <input
            type="password"
            placeholder="Password"
            value={pass}
            onChange={e => setPass(e.target.value)}
            required
            className="w-full px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white
                       placeholder-gray-500 focus:outline-none focus:border-green-500"
          />
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-green-600 hover:bg-green-500 text-white font-semibold
                       disabled:opacity-50 transition"
          >
            {loading ? 'Working...' : mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
          <button
            type="button"
            onClick={() => setMode(m => m === 'login' ? 'register' : 'login')}
            className="w-full text-sm text-gray-400 hover:text-white transition"
          >
            {mode === 'login' ? "Don't have an account? Register" : 'Already have an account? Sign in'}
          </button>
        </form>
      </div>
    </div>
  );
}`,

  'frontend/src/pages/Dashboard.jsx': `import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../api';
import ScoreCard from '../components/ScoreCard';

export default function Dashboard() {
  const [score,   setScore]   = useState(null);
  const [message, setMessage] = useState('');
  const [tasks,   setTasks]   = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([api.getCoach(), api.getTasks()])
      .then(([coach, t]) => {
        setScore(coach.score);
        setMessage(coach.message);
        setTasks(t);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  function logout() {
    localStorage.removeItem('be_token');
    navigate('/login');
  }

  const completed  = tasks.filter(t => t.completed).length;
  const total      = tasks.length;
  const pct        = total ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">Behavior Engine</h1>
          <button onClick={logout} className="text-sm text-gray-400 hover:text-white transition">
            Sign out
          </button>
        </div>

        {loading ? (
          <p className="text-gray-500 animate-pulse">Loading...</p>
        ) : (
          <>
            <ScoreCard score={score ?? 0} label="Today's Execution Score" />

            <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
              <p className="text-sm text-gray-400 mb-1">AI Coach</p>
              <p className="text-white">{message || 'No coaching data yet.'}</p>
            </div>

            <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
              <div className="flex justify-between items-center mb-3">
                <p className="text-sm font-semibold">Today's Tasks</p>
                <span className="text-xs text-gray-400">{completed}/{total} done</span>
              </div>
              <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden mb-4">
                <div
                  className="h-2 bg-green-500 rounded-full transition-all"
                  style={{ width: \`\${pct}%\` }}
                />
              </div>
              <div className="flex gap-3">
                <Link to="/tasks" className="flex-1 py-2 text-center rounded-lg bg-gray-800 hover:bg-gray-700 text-sm transition">
                  Manage Tasks
                </Link>
                <Link to="/coach" className="flex-1 py-2 text-center rounded-lg bg-green-600 hover:bg-green-500 text-sm font-semibold transition">
                  AI Coach
                </Link>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}`,

  'frontend/src/pages/Tasks.jsx': `import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../api';
import TaskList from '../components/TaskList';

export default function Tasks() {
  const [tasks,   setTasks]   = useState([]);
  const [title,   setTitle]   = useState('');
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);

  useEffect(() => {
    api.getTasks()
      .then(setTasks)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  async function addTask(e) {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    try {
      const t = await api.createTask(title.trim());
      setTasks(prev => [t, ...prev]);
      setTitle('');
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  async function complete(id) {
    try {
      const { task } = await api.completeTask(id);
      setTasks(prev => prev.map(t => t.id === id ? task : t));
    } catch (err) { console.error(err); }
  }

  async function remove(id) {
    try {
      await api.deleteTask(id);
      setTasks(prev => prev.filter(t => t.id !== id));
    } catch (err) { console.error(err); }
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Link to="/" className="text-gray-400 hover:text-white text-sm transition">
            &larr; Dashboard
          </Link>
          <h1 className="text-xl font-bold">Tasks</h1>
        </div>

        <form onSubmit={addTask} className="flex gap-2">
          <input
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="Add a task..."
            className="flex-1 px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white
                       placeholder-gray-500 focus:outline-none focus:border-green-500"
          />
          <button
            type="submit"
            disabled={saving}
            className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 font-semibold
                       disabled:opacity-50 transition"
          >
            Add
          </button>
        </form>

        {loading ? (
          <p className="text-gray-500 animate-pulse">Loading tasks...</p>
        ) : (
          <TaskList tasks={tasks} onComplete={complete} onDelete={remove} />
        )}
      </div>
    </div>
  );
}`,

  'frontend/src/pages/AICoach.jsx': `import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import ScoreCard from '../components/ScoreCard';

export default function AICoach() {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    setLoading(true);
    api.getCoach()
      .then(setData)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [refresh]);

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Link to="/" className="text-gray-400 hover:text-white text-sm transition">
            &larr; Dashboard
          </Link>
          <h1 className="text-xl font-bold">AI Coach</h1>
        </div>

        {loading ? (
          <p className="text-gray-500 animate-pulse">Fetching coaching...</p>
        ) : data ? (
          <>
            <ScoreCard score={data.score} label="Current Execution Score" />
            <div className="bg-gray-900 rounded-xl p-6 border border-green-800">
              <p className="text-xs text-green-400 mb-2 font-semibold uppercase tracking-wider">
                Coach Message
              </p>
              <p className="text-white text-lg leading-relaxed">{data.message}</p>
            </div>
          </>
        ) : (
          <p className="text-gray-500">Could not load coaching data.</p>
        )}

        <button
          onClick={() => setRefresh(r => r + 1)}
          className="w-full py-2.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-sm transition"
        >
          Refresh Coach
        </button>
      </div>
    </div>
  );
}`,

  'frontend/src/components/ScoreCard.jsx': `export default function ScoreCard({ score = 0, label = 'Score' }) {
  const pct   = Math.min(Math.max(score, 0), 100);
  const color = pct >= 80 ? 'text-green-400' : pct >= 50 ? 'text-yellow-400' : 'text-red-400';
  const ring  = pct >= 80 ? 'border-green-500' : pct >= 50 ? 'border-yellow-500' : 'border-red-500';
  const bg    = pct >= 80 ? 'bg-green-500'     : pct >= 50 ? 'bg-yellow-500'     : 'bg-red-500';
  const status = pct >= 80 ? 'ELITE' : pct >= 60 ? 'ACTIVE' : pct >= 30 ? 'BUILDING' : 'START';

  return (
    <div className={\`bg-gray-900 rounded-xl p-6 border \${ring} border-2\`}>
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">{label}</p>
          <p className={\`text-5xl font-black \${color}\`}>{pct}</p>
          <p className="text-gray-500 text-sm mt-1">out of 100</p>
        </div>
        <span className={\`px-3 py-1 rounded-full text-xs font-bold \${bg} text-white\`}>
          {status}
        </span>
      </div>
      <div className="w-full h-3 bg-gray-800 rounded-full overflow-hidden">
        <div
          className={\`h-3 rounded-full transition-all duration-700 \${bg}\`}
          style={{ width: \`\${pct}%\` }}
        />
      </div>
    </div>
  );
}`,

  'frontend/src/components/TaskList.jsx': `export default function TaskList({ tasks = [], onComplete, onDelete }) {
  if (!tasks.length) {
    return (
      <div className="text-center py-12 text-gray-600">
        <p className="text-4xl mb-3">0</p>
        <p className="text-sm">No tasks yet. Add one above.</p>
      </div>
    );
  }

  const pending   = tasks.filter(t => !t.completed);
  const completed = tasks.filter(t =>  t.completed);

  function TaskRow({ task }) {
    return (
      <div className={\`flex items-center gap-3 p-3 rounded-lg \${task.completed ? 'opacity-50' : 'bg-gray-900'}\`}>
        <button
          onClick={() => !task.completed && onComplete(task.id)}
          disabled={task.completed}
          className={\`w-5 h-5 rounded-full border-2 flex-shrink-0 transition
            \${task.completed
              ? 'border-green-500 bg-green-500'
              : 'border-gray-600 hover:border-green-500'}\`}
        />
        <span className={\`flex-1 text-sm \${task.completed ? 'line-through text-gray-500' : 'text-white'}\`}>
          {task.title}
        </span>
        <span className="text-xs text-gray-600">{task.points}pt</span>
        <button
          onClick={() => onDelete(task.id)}
          className="text-gray-600 hover:text-red-400 text-xs transition"
        >
          ×
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-1">
      {pending.map(t   => <TaskRow key={t.id} task={t} />)}
      {completed.length > 0 && (
        <p className="text-xs text-gray-600 pt-3 pb-1 uppercase tracking-wider">Completed</p>
      )}
      {completed.map(t => <TaskRow key={t.id} task={t} />)}
    </div>
  );
}`,

  'frontend/src/components/ProtectedRoute.jsx': `import { Navigate } from 'react-router-dom';

export default function ProtectedRoute({ children }) {
  const token = localStorage.getItem('be_token');
  if (!token) return <Navigate to="/login" replace />;
  return children;
}`,

  // ── Supabase ──
  'supabase/schema.sql': `-- ╔══════════════════════════════════════════════════════╗
-- ║  Behavior Engine SaaS — Supabase Schema              ║
-- ║  Run this in: Supabase Dashboard → SQL Editor        ║
-- ╚══════════════════════════════════════════════════════╝

-- Enable UUID extension (already on in Supabase)
create extension if not exists "pgcrypto";

-- ── Users ────────────────────────────────────────────────────────────────────
-- Supabase Auth manages auth.users. We mirror public profile here.
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text unique not null,
  name       text,
  plan       text not null default 'free',    -- free | pro | enterprise
  created_at timestamptz not null default now()
);

-- ── Tasks ────────────────────────────────────────────────────────────────────
create table if not exists public.tasks (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  title        text not null,
  completed    boolean not null default false,
  completed_at timestamptz,
  points       int not null default 1,
  created_at   timestamptz not null default now()
);

create index if not exists tasks_user_created on public.tasks(user_id, created_at desc);

-- ── Daily Scores ─────────────────────────────────────────────────────────────
create table if not exists public.scores (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id) on delete cascade,
  score      int not null default 0,
  date       date not null default current_date,
  updated_at timestamptz not null default now(),
  unique(user_id, date)
);

create index if not exists scores_user_date on public.scores(user_id, date desc);

-- ── Auto-profile on signup ───────────────────────────────────────────────────
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles(id, email)
  values (new.id, new.email)
  on conflict do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();`,

  'supabase/policies.sql': `-- ╔══════════════════════════════════════════════════════╗
-- ║  Row-Level Security Policies                         ║
-- ║  Run AFTER schema.sql                                ║
-- ╚══════════════════════════════════════════════════════╝

-- Enable RLS
alter table public.profiles enable row level security;
alter table public.tasks     enable row level security;
alter table public.scores    enable row level security;

-- ── Profiles: own row only ───────────────────────────────────────────────────
create policy "profiles: select own"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles: update own"
  on public.profiles for update
  using (auth.uid() = id);

-- ── Tasks: full CRUD on own rows ─────────────────────────────────────────────
create policy "tasks: select own"
  on public.tasks for select
  using (auth.uid() = user_id);

create policy "tasks: insert own"
  on public.tasks for insert
  with check (auth.uid() = user_id);

create policy "tasks: update own"
  on public.tasks for update
  using (auth.uid() = user_id);

create policy "tasks: delete own"
  on public.tasks for delete
  using (auth.uid() = user_id);

-- ── Scores: select + upsert own ─────────────────────────────────────────────
create policy "scores: select own"
  on public.scores for select
  using (auth.uid() = user_id);

create policy "scores: upsert own"
  on public.scores for insert
  with check (auth.uid() = user_id);

create policy "scores: update own"
  on public.scores for update
  using (auth.uid() = user_id);`,

  'supabase/seed.sql': `-- ╔══════════════════════════════════════════════════════╗
-- ║  Seed data for local dev / demo                      ║
-- ║  Optional — run after schema.sql                     ║
-- ╚══════════════════════════════════════════════════════╝

-- Demo user (create via Supabase Auth first, then paste real UUID below)
-- insert into public.profiles(id, email, name, plan)
-- values('00000000-0000-0000-0000-000000000001', 'demo@example.com', 'Demo User', 'pro');

-- insert into public.tasks(user_id, title, points)
-- values
--   ('00000000-0000-0000-0000-000000000001', '20 outreach messages', 2),
--   ('00000000-0000-0000-0000-000000000001', 'Demo call at 10am', 3),
--   ('00000000-0000-0000-0000-000000000001', 'Follow up 5 leads', 1);

-- Uncomment and replace UUID after creating user in Supabase Auth.
select 'Seed file ready — uncomment rows and replace UUIDs to use.' as info;`,
};

// ── Deploy steps ───────────────────────────────────────────────────────────────
const DEPLOY_STEPS = [
  {
    step: 1,
    title: 'Supabase Setup',
    icon: Database,
    color: 'text-emerald-400',
    commands: [
      '1. Create project at supabase.com',
      '2. SQL Editor → run supabase/schema.sql',
      '3. SQL Editor → run supabase/policies.sql',
      '4. Settings → API → copy Project URL + service_role key + anon key',
    ],
    note: 'The trigger auto-creates a profile row on every signup.',
  },
  {
    step: 2,
    title: 'Backend → Railway',
    icon: Server,
    color: 'text-violet-400',
    commands: [
      'Push repo to GitHub',
      'railway.app → New Project → GitHub repo',
      'Set env vars:',
      '  SUPABASE_URL=<your url>',
      '  SUPABASE_SERVICE_KEY=<service_role key>',
      '  JWT_SECRET=<32 char random>',
      '  OPENAI_API_KEY=<sk-... optional>',
      'Deploy → copy Railway public URL',
    ],
    note: 'railway.json auto-configures build + start command.',
  },
  {
    step: 3,
    title: 'Frontend → Vercel',
    icon: Globe,
    color: 'text-blue-400',
    commands: [
      'vercel.com → Import Git Repository',
      'Root directory: frontend',
      'Set env vars:',
      '  VITE_API_URL=<Railway URL>',
      '  VITE_SUPABASE_URL=<your url>',
      '  VITE_SUPABASE_ANON_KEY=<anon key>',
      'Deploy',
    ],
    note: 'vercel.json proxies /api/* to Railway, serves SPA from index.html.',
  },
  {
    step: 4,
    title: 'Local Dev',
    icon: Terminal,
    color: 'text-amber-400',
    commands: [
      '# Backend',
      'cd backend && npm install',
      'cp .env.example .env  # fill in values',
      'npm run dev',
      '',
      '# Frontend (new terminal)',
      'cd frontend && npm install',
      'cp .env.example .env  # fill in values',
      'npm run dev',
      '',
      '# App runs at http://localhost:5173',
    ],
    note: 'Vite proxies /api to localhost:3000 automatically.',
  },
];

// ── Component ──────────────────────────────────────────────────────────────────
export default function DeployableRepo() {
  const [tab,          setTab]      = useState('files');   // files | deploy | overview
  const [activeFile,   setActive]   = useState('vercel.json');
  const [openGroups,   setGroups]   = useState({ 'Root': true, 'backend/': true, 'frontend/': false, 'supabase/': false });
  const [copied,       setCopied]   = useState('');
  const [copiedAll,    setCopiedAll] = useState(false);

  function copyFile(path) {
    const content = FILES[path] || '';
    navigator.clipboard.writeText(content);
    setCopied(path);
    setTimeout(() => setCopied(''), 1800);
  }

  function copyAll() {
    const all = Object.entries(FILES)
      .map(([p, c]) => `// ═══ ${p} ═══\n${c}`)
      .join('\n\n');
    navigator.clipboard.writeText(all);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  }

  function toggleGroup(g) {
    setGroups(prev => ({ ...prev, [g]: !prev[g] }));
  }

  const allFiles = TREE.flatMap(g => g.files);

  const TABS = [
    { id: 'files',    label: 'File Viewer',    icon: FileCode },
    { id: 'deploy',   label: 'Deploy Guide',   icon: Rocket   },
    { id: 'overview', label: 'Architecture',   icon: Server   },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white p-4 md:p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-900/40 rounded-lg border border-green-700/50">
              <Package size={22} className="text-green-400" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-white">Deployable SaaS Repo</h1>
              <p className="text-gray-400 text-sm">behavior-engine-saas — copy, configure, deploy</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 mt-3">
            {['Node + Express', 'React + Vite', 'Supabase', 'Railway', 'Vercel', 'JWT Auth', 'Row-Level Security'].map(t => (
              <span key={t} className="px-2 py-0.5 bg-gray-800 border border-gray-700 rounded text-xs text-gray-300">{t}</span>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-gray-900 p-1 rounded-xl w-fit border border-gray-800">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition
                ${tab === id ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'}`}
            >
              <Icon size={14} />
              {label}
            </button>
          ))}
        </div>

        {/* ── FILE VIEWER ── */}
        {tab === 'files' && (
          <div className="flex gap-4 h-[72vh]">
            {/* Sidebar */}
            <div className="w-56 flex-shrink-0 bg-gray-900 rounded-xl border border-gray-800 overflow-y-auto">
              <div className="p-3 border-b border-gray-800">
                <p className="text-xs text-gray-400 font-semibold uppercase tracking-wider">
                  {allFiles.length} files
                </p>
              </div>
              {TREE.map(({ group, files }) => (
                <div key={group}>
                  <button
                    onClick={() => toggleGroup(group)}
                    className="w-full flex items-center gap-1 px-3 py-2 text-xs font-semibold
                               text-gray-400 hover:text-white transition"
                  >
                    {openGroups[group] ? <ChevronDown size={12}/> : <ChevronRight size={12}/>}
                    {group}
                  </button>
                  {openGroups[group] && files.map(({ path, label, icon: Icon }) => (
                    <button
                      key={path}
                      onClick={() => setActive(path)}
                      className={`w-full flex items-center gap-2 pl-6 pr-3 py-1.5 text-left text-xs transition
                        ${activeFile === path
                          ? 'bg-green-900/40 text-green-300 border-r-2 border-green-500'
                          : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
                    >
                      <Icon size={11} className="flex-shrink-0" />
                      <span className="truncate">{label}</span>
                    </button>
                  ))}
                </div>
              ))}
            </div>

            {/* Code panel */}
            <div className="flex-1 bg-gray-900 rounded-xl border border-gray-800 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
                <span className="text-sm font-mono text-gray-300">{activeFile}</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => copyFile(activeFile)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-800
                               hover:bg-gray-700 text-xs text-gray-300 transition"
                  >
                    {copied === activeFile ? <CheckCheck size={12} className="text-green-400"/> : <Copy size={12}/>}
                    {copied === activeFile ? 'Copied' : 'Copy'}
                  </button>
                  <button
                    onClick={copyAll}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-700
                               hover:bg-green-600 text-xs text-white font-semibold transition"
                  >
                    {copiedAll ? <CheckCheck size={12}/> : <Copy size={12}/>}
                    Copy All Files
                  </button>
                </div>
              </div>
              <pre className="flex-1 overflow-auto p-4 text-xs text-gray-300 font-mono leading-relaxed">
                {FILES[activeFile] || '// File content not found'}
              </pre>
            </div>
          </div>
        )}

        {/* ── DEPLOY GUIDE ── */}
        {tab === 'deploy' && (
          <div className="space-y-4 max-w-3xl">
            <div className="bg-amber-900/20 border border-amber-700/40 rounded-xl p-4 flex gap-3">
              <AlertTriangle size={18} className="text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-200">
                <strong>Before deploying:</strong> create your Supabase project first.
                All other steps depend on the Supabase URL + keys.
              </div>
            </div>

            {DEPLOY_STEPS.map(({ step, title, icon: Icon, color, commands, note }) => (
              <div key={step} className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
                <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-800">
                  <div className="w-7 h-7 rounded-full bg-gray-800 flex items-center justify-center
                                  text-xs font-bold text-white">
                    {step}
                  </div>
                  <Icon size={18} className={color} />
                  <h3 className="font-semibold text-white">{title}</h3>
                </div>
                <div className="p-4">
                  <pre className="bg-gray-950 rounded-lg p-4 text-xs text-gray-300 font-mono
                                  leading-relaxed overflow-x-auto">
                    {commands.join('\n')}
                  </pre>
                  {note && (
                    <div className="flex gap-2 mt-3 text-xs text-gray-400">
                      <Info size={13} className="flex-shrink-0 mt-0.5" />
                      {note}
                    </div>
                  )}
                </div>
              </div>
            ))}

            <div className="bg-green-900/20 border border-green-700/40 rounded-xl p-5">
              <h3 className="font-semibold text-green-300 mb-3 flex items-center gap-2">
                <Rocket size={16}/> What you get after deploy
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                {[
                  { label: 'Backend URL',  val: 'your-app.railway.app',    icon: Server  },
                  { label: 'Frontend URL', val: 'your-app.vercel.app',     icon: Globe   },
                  { label: 'Database',     val: 'your-project.supabase.co',icon: Database},
                ].map(({ label, val, icon: Icon }) => (
                  <div key={label} className="bg-gray-900 rounded-lg p-3">
                    <p className="text-gray-500 text-xs mb-1 flex items-center gap-1">
                      <Icon size={11}/> {label}
                    </p>
                    <p className="font-mono text-green-300 text-xs">{val}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── ARCHITECTURE ── */}
        {tab === 'overview' && (
          <div className="space-y-6 max-w-3xl">
            {/* Stack */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                {
                  title: 'Backend',
                  host: 'Railway',
                  color: 'border-violet-700/50 bg-violet-900/10',
                  icon: Server,
                  items: [
                    'Node.js 18 + Express',
                    'JWT auth middleware',
                    'Supabase JS client (service role)',
                    'Score engine (calcScore)',
                    'Coach engine (rule-based + GPT-4o-mini)',
                    'OpenAI SDK optional',
                    'CORS + JSON body parser',
                  ],
                },
                {
                  title: 'Frontend',
                  host: 'Vercel',
                  color: 'border-blue-700/50 bg-blue-900/10',
                  icon: Globe,
                  items: [
                    'React 18 + React Router v6',
                    'Vite 5 + Tailwind CSS 3',
                    'Protected routes (JWT gate)',
                    'api.js — typed fetch wrapper',
                    'ScoreCard + TaskList components',
                    'Login / Dashboard / Tasks / AICoach',
                    'Supabase anon client (optional)',
                  ],
                },
                {
                  title: 'Database',
                  host: 'Supabase',
                  color: 'border-emerald-700/50 bg-emerald-900/10',
                  icon: Database,
                  items: [
                    'Postgres (managed)',
                    'Supabase Auth (email + password)',
                    'profiles table (mirrors auth.users)',
                    'tasks table (per-user CRUD)',
                    'scores table (daily upsert)',
                    'Row-Level Security on all tables',
                    'Auto-profile trigger on signup',
                  ],
                },
              ].map(({ title, host, color, icon: Icon, items }) => (
                <div key={title} className={`rounded-xl border p-4 ${color}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <Icon size={16} className="text-gray-300" />
                    <h3 className="font-semibold text-white">{title}</h3>
                    <span className="ml-auto text-xs text-gray-500">{host}</span>
                  </div>
                  <ul className="space-y-1.5">
                    {items.map(i => (
                      <li key={i} className="flex items-start gap-2 text-xs text-gray-300">
                        <ArrowRight size={10} className="mt-0.5 flex-shrink-0 text-gray-600" />
                        {i}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Request flow */}
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
              <h3 className="font-semibold mb-4">Request Flow</h3>
              <div className="flex flex-wrap items-center gap-2 text-sm">
                {['Browser', 'Vercel CDN', 'Vite SPA', 'api.js fetch', 'Railway Express', 'requireAuth JWT', 'Supabase DB', 'JSON Response'].map((node, i, arr) => (
                  <div key={node} className="flex items-center gap-2">
                    <span className="px-2 py-1 bg-gray-800 rounded text-xs text-gray-300">{node}</span>
                    {i < arr.length - 1 && <ArrowRight size={12} className="text-gray-600" />}
                  </div>
                ))}
              </div>
            </div>

            {/* Env vars summary */}
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
              <h3 className="font-semibold mb-4">Environment Variables Checklist</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    title: 'backend/.env',
                    vars: ['SUPABASE_URL', 'SUPABASE_SERVICE_KEY', 'JWT_SECRET', 'OPENAI_API_KEY', 'PORT'],
                  },
                  {
                    title: 'frontend/.env',
                    vars: ['VITE_API_URL', 'VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'],
                  },
                ].map(({ title, vars }) => (
                  <div key={title}>
                    <p className="text-xs text-gray-400 mb-2 font-mono">{title}</p>
                    <div className="space-y-1">
                      {vars.map(v => (
                        <div key={v} className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0" />
                          <span className="text-xs font-mono text-gray-300">{v}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
