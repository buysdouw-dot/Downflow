/**
 * HundredKPlan — $100K/Month Execution Breakdown
 * Unit economics + scaling math + daily actions + 90-day path
 */
import { useState } from 'react';
import {
  DollarSign, TrendingUp, Users, Target, Check,
  CheckCircle2, Circle, ArrowRight, BarChart2,
  Zap, Calendar, Clock, ChevronRight,
} from 'lucide-react';

// ── Pricing tiers ─────────────────────────────────────────────────────────────
const TIERS = [
  { id: 'indie',      label: 'Individual',  price: 20,   unit: 'user',  desc: 'Solo reps, freelancers, founders. Lowest friction.', color: '#a1a1aa' },
  { id: 'smb',        label: 'SMB Team',    price: 200,  unit: 'team',  desc: '10-seat minimum. Sales teams, startup ops.', color: '#818cf8' },
  { id: 'growth',     label: 'Growth',      price: 500,  unit: 'team',  desc: '25-50 seat teams. Custom onboarding included.', color: '#22d3ee' },
  { id: 'enterprise', label: 'Enterprise',  price: 2000, unit: 'deal',  desc: '100+ seats. Annual contract. Implementation.', color: '#fbbf24' },
];

// ── Scale scenarios to $100K ──────────────────────────────────────────────────
const SCENARIOS = [
  {
    id: 's1', label: 'Pure Individual', color: '#a1a1aa',
    mix: [{ tier: 'Individual', n: 5000, price: 20, sub: '$20 × 5,000 users' }],
    mrr: 100000, note: 'Long tail. Hard to reach 5K solo users. Content + product-led growth.'
  },
  {
    id: 's2', label: 'SMB Focused', color: '#818cf8',
    mix: [
      { tier: 'SMB Team',    n: 300,  price: 200,   sub: '$200 × 300 teams'     },
      { tier: 'Individual',  n: 1000, price: 20,    sub: '$20 × 1,000 users'    },
    ],
    mrr: 80000, note: '300 SMBs is very achievable in 90 days with outreach + pilots.'
  },
  {
    id: 's3', label: 'Enterprise Path', color: '#fbbf24',
    mix: [
      { tier: 'Enterprise',  n: 30,   price: 2000,  sub: '$2,000 × 30 companies' },
      { tier: 'Growth',      n: 40,   price: 500,   sub: '$500 × 40 teams'       },
    ],
    mrr: 80000, note: 'Fewer deals but faster path. 30 enterprise = 90 days of hard selling.'
  },
  {
    id: 's4', label: 'Mixed (Realistic)', color: '#34d399',
    mix: [
      { tier: 'Enterprise',  n: 10,  price: 2000, sub: '$2,000 × 10 companies' },
      { tier: 'Growth',      n: 50,  price: 500,  sub: '$500 × 50 teams'       },
      { tier: 'SMB Team',    n: 100, price: 200,  sub: '$200 × 100 teams'      },
      { tier: 'Individual',  n: 500, price: 20,   sub: '$20 × 500 users'       },
    ],
    mrr: 75000, note: 'Realistic 90-day target. Build all 4 channels simultaneously.'
  },
];

// ── 90-day phases ─────────────────────────────────────────────────────────────
const PHASES = [
  {
    id: 'p1', days: 'Days 1–15', target: '$1K MRR', color: '#a1a1aa',
    focus: 'Validation',
    actions: [
      'Send 30 DMs/day on LinkedIn + WhatsApp to target buyer',
      'Book 3–5 demo calls per day. Do them same-day.',
      'Offer 7-day free pilot to every call. Close pilot, not sale.',
      'Set up Stripe. Charge first paying customer by Day 10.',
      'Write 1 case study after every successful pilot.',
    ],
    kpi: '50 users or 5 teams paying',
  },
  {
    id: 'p2', days: 'Days 15–45', target: '$10K MRR', color: '#818cf8',
    focus: 'Replication',
    actions: [
      'Identify your 3 highest-converting channels. Double down.',
      'Start LinkedIn content: 1 post per day with execution data.',
      'Hire 1 part-time SDR to handle inbound + outreach at scale.',
      'Build case study library: 5 before/after stories.',
      'Add referral mechanism: existing users get 1 free month per referral.',
    ],
    kpi: '10 SMB teams × $200 + 500 individuals',
  },
  {
    id: 'p3', days: 'Days 45–75', target: '$50K MRR', color: '#22d3ee',
    focus: 'Scale',
    actions: [
      'Start enterprise outreach: VP Sales, RevOps, HR Directors.',
      'Build 1-pager for enterprise: ROI case, data, proof.',
      'Launch annual plan: 3 months free for annual commit.',
      'Set up paid ads: LinkedIn to bottom-of-funnel landing page.',
      'Activate Revenue Agent: auto-detect upgrade candidates weekly.',
    ],
    kpi: '3–5 enterprise deals + 50 SMB teams',
  },
  {
    id: 'p4', days: 'Days 75–90', target: '$100K MRR', color: '#34d399',
    focus: 'Compound',
    actions: [
      'All 4 AI agents running autonomously.',
      'Referrals generating 20%+ of new pipeline.',
      'Enterprise pipeline: 5+ deals in final stages.',
      'Content flywheel: 10K+ reach per post, inbound leads daily.',
      'System Agent proposing product improvements weekly.',
    ],
    kpi: '$100K MRR — 300+ SMBs or 30 enterprise + 500 solo',
  },
];

// ── Daily non-negotiables ─────────────────────────────────────────────────────
const DAILY = [
  { time: '7:00am',  action: 'Review yesterday execution score. Are you executing at 80%+?',          icon: BarChart2 },
  { time: '7:30am',  action: '30 DMs sent. LinkedIn + WhatsApp. 10 new, 20 follow-ups.',               icon: Users     },
  { time: '9:00am',  action: '2–3 demo calls. Use exact call structure (Open → Problem → Demo → Pilot).', icon: Clock  },
  { time: '12:00pm', action: 'Post 1 piece of content. Execution insight with real data.',              icon: TrendingUp},
  { time: '2:00pm',  action: 'Follow up with all demos not responded in 24h.',                          icon: Zap       },
  { time: '5:00pm',  action: 'Check active pilots. Proactively message 1 pilot user about their data.', icon: Target   },
  { time: '6:00pm',  action: 'Record 1 new case study data point from any active customer.',            icon: Check     },
];

// ── Key unit metrics ──────────────────────────────────────────────────────────
const METRICS = [
  { label: 'Avg MRR per SMB',        v: '$200',  sub: '10 seats × $20',      color: '#818cf8' },
  { label: 'Pilot → Paid rate',      v: '68%',   sub: 'historical avg',       color: '#22d3ee' },
  { label: 'Time to first payment',  v: '9 days', sub: 'from cold DM',        color: '#fbbf24' },
  { label: 'CAC (outreach)',         v: '$22',    sub: 'time cost at $500/wk', color: '#34d399' },
  { label: 'LTV (12mo)',             v: '$2,400', sub: 'SMB $200 × 12mo',     color: '#f472b6' },
  { label: 'LTV:CAC ratio',         v: '109x',   sub: 'very healthy',         color: '#a78bfa' },
];

export default function HundredKPlan() {
  const [view,          setView]    = useState('math');     // 'math' | 'phases' | 'daily'
  const [activeScenario,setScenario] = useState('s4');
  const [activePhase,   setPhase]   = useState('p1');
  const [tasks, setTasks] = useState(() => {
    try { return JSON.parse(localStorage.getItem('be_100k_tasks')) ?? {}; } catch { return {}; }
  });

  const saveTasks = t => { setTasks(t); try { localStorage.setItem('be_100k_tasks', JSON.stringify(t)); } catch {} };

  const scenario = SCENARIOS.find(s => s.id === activeScenario);
  const phase    = PHASES.find(p => p.id === activePhase);

  const toggleTask = (key) => {
    const next = { ...tasks, [key]: !tasks[key] };
    saveTasks(next);
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <DollarSign size={13} className="text-amber-400" />
              <p className="text-amber-400 text-xs font-bold uppercase tracking-widest">$100K/Month Execution Plan</p>
            </div>
            <h1 className="text-3xl font-black mb-1">The Exact Path to $100K MRR</h1>
            <p className="text-white/35 text-sm">Unit economics. Daily actions. 90-day breakdown. No fluff.</p>
          </div>
          <div className="p-3 rounded-xl border border-amber-500/20 bg-amber-500/5 text-center">
            <p className="text-2xl font-black text-amber-400">$100K</p>
            <p className="text-white/20 text-[9px]">target MRR</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['math','Unit Economics'],['phases','90-Day Plan'],['daily','Daily Non-Negotiables']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-amber-500 text-black font-bold' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── MATH ── */}
        {view === 'math' && (
          <div className="space-y-5">
            {/* Pricing tiers */}
            <div className="grid lg:grid-cols-4 gap-3">
              {TIERS.map(t => (
                <div key={t.id} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                  <p className="text-[9px] font-black uppercase tracking-widest mb-1" style={{ color: t.color }}>{t.label}</p>
                  <p className="text-2xl font-black" style={{ color: t.color }}>${t.price.toLocaleString()}</p>
                  <p className="text-white/20 text-[9px]">/{t.unit}/month</p>
                  <p className="text-white/30 text-[9px] mt-2 leading-snug">{t.desc}</p>
                </div>
              ))}
            </div>

            {/* Scenario selector */}
            <div className="flex gap-2 flex-wrap">
              {SCENARIOS.map(s => (
                <button key={s.id} onClick={() => setScenario(s.id)}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold border transition-all`}
                  style={activeScenario === s.id
                    ? { background: s.color + '15', borderColor: s.color + '25', color: s.color }
                    : { borderColor: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.3)' }}>
                  {s.label}
                </button>
              ))}
            </div>

            {/* Scenario detail */}
            {scenario && (
              <div className="p-5 rounded-2xl border bg-white/2" style={{ borderColor: scenario.color + '20' }}>
                <div className="flex items-center justify-between mb-4">
                  <p className="text-white/70 font-bold">{scenario.label}</p>
                  <p className="text-2xl font-black" style={{ color: scenario.color }}>
                    ~${(scenario.mrr / 1000).toFixed(0)}K MRR
                  </p>
                </div>
                <div className="space-y-2 mb-4">
                  {scenario.mix.map((m, i) => {
                    const pct = (m.n * m.price) / scenario.mrr * 100;
                    return (
                      <div key={i}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-white/35 text-[10px]">{m.sub}</span>
                          <span className="text-white/55 text-[10px] font-bold">${(m.n * m.price).toLocaleString()}/mo</span>
                        </div>
                        <div className="h-1.5 bg-white/6 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: scenario.color }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
                <p className="text-white/30 text-[9px] leading-snug italic">{scenario.note}</p>
              </div>
            )}

            {/* Key metrics */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
              {METRICS.map(m => (
                <div key={m.label} className="p-4 rounded-xl border border-white/8 bg-white/2 text-center">
                  <p className="text-xl font-black" style={{ color: m.color }}>{m.v}</p>
                  <p className="text-white/35 text-[9px] mt-0.5">{m.label}</p>
                  <p className="text-white/15 text-[8px]">{m.sub}</p>
                </div>
              ))}
            </div>

            {/* The core truth */}
            <div className="p-5 rounded-2xl border border-amber-500/20 bg-amber-500/5">
              <p className="text-amber-400 font-bold text-sm mb-2">The Core Scaling Truth</p>
              <p className="text-white/50 text-xs leading-relaxed">
                You do not need 5,000 users. You need <span className="text-white font-bold">300 SMB teams</span> at $200/month.
                That is 300 sales calls. That is 90 days of 3 calls per day.
                <span className="text-amber-400 font-semibold"> You are not missing product. You are missing pipeline.</span>
              </p>
            </div>
          </div>
        )}

        {/* ── PHASES ── */}
        {view === 'phases' && (
          <div className="grid lg:grid-cols-[200px_1fr] gap-5">
            {/* Phase picker */}
            <div className="space-y-2">
              {PHASES.map(p => {
                const isActive = activePhase === p.id;
                const done = Object.keys(tasks).filter(k => k.startsWith(p.id) && tasks[k]).length;
                const total = p.actions.length;
                return (
                  <button key={p.id} onClick={() => setPhase(p.id)}
                    className={`w-full p-3 rounded-xl border text-left transition-all ${
                      isActive ? 'border-white/12 bg-white/5' : 'border-white/5 hover:bg-white/3'
                    }`}>
                    <p className="text-[9px] font-black uppercase tracking-widest mb-0.5" style={{ color: isActive ? p.color : 'rgba(255,255,255,0.25)' }}>{p.days}</p>
                    <p className="text-white/55 text-[10px] font-semibold">{p.focus}</p>
                    <div className="flex items-center justify-between mt-1.5">
                      <p className="text-[8px] font-bold" style={{ color: p.color }}>{p.target}</p>
                      <span className="text-white/20 text-[8px]">{done}/{total}</span>
                    </div>
                    <div className="h-0.5 bg-white/6 rounded-full mt-1.5 overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${total > 0 ? (done/total*100) : 0}%`, background: p.color }} />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Phase detail */}
            {phase && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl border" style={{ borderColor: phase.color + '20', background: phase.color + '05' }}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[9px] font-black uppercase tracking-widest mb-0.5" style={{ color: phase.color }}>{phase.days}</p>
                      <p className="text-white/70 text-base font-bold">{phase.focus}</p>
                    </div>
                    <p className="text-2xl font-black" style={{ color: phase.color }}>{phase.target}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest">Daily Actions</p>
                  {phase.actions.map((action, i) => {
                    const key = `${phase.id}_${i}`;
                    const done = !!tasks[key];
                    return (
                      <button key={i} onClick={() => toggleTask(key)}
                        className="w-full flex items-start gap-3 p-3 rounded-xl border border-white/6 hover:bg-white/3 text-left transition-all">
                        {done
                          ? <CheckCircle2 size={14} style={{ color: phase.color }} className="shrink-0 mt-0.5" />
                          : <Circle size={14} className="text-white/20 shrink-0 mt-0.5" />}
                        <p className={`text-xs leading-snug ${done ? 'text-white/30 line-through' : 'text-white/60'}`}>{action}</p>
                      </button>
                    );
                  })}
                </div>

                <div className="p-3 rounded-xl border border-white/8 bg-white/2">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest mb-1">Phase KPI</p>
                  <p className="text-white/60 text-xs font-semibold">{phase.kpi}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── DAILY ── */}
        {view === 'daily' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl border border-amber-500/20 bg-amber-500/5">
              <p className="text-amber-400 font-bold text-sm">The Iron Rule</p>
              <p className="text-white/50 text-xs mt-1 leading-relaxed">
                You will not reach $100K doing 4-hour workdays and &ldquo;working on the product.&rdquo;
                You will reach $100K by executing these 7 actions, every single day, for 90 days straight.
                Miss one day — fine. Miss three — you lose momentum and it compounds down.
              </p>
            </div>

            <div className="space-y-2">
              {DAILY.map(({ time, action, icon: DIcon }, i) => {
                const key = `daily_${i}`;
                const done = !!tasks[key];
                return (
                  <button key={i} onClick={() => toggleTask(key)}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl border border-white/6 bg-white/2 hover:bg-white/3 text-left transition-all">
                    <div className="w-16 shrink-0">
                      <p className="text-amber-400 text-[10px] font-bold">{time}</p>
                    </div>
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 bg-amber-500/8 border border-amber-500/15">
                      <DIcon size={12} className="text-amber-400/70" />
                    </div>
                    <p className={`flex-1 text-xs leading-snug ${done ? 'text-white/25 line-through' : 'text-white/60'}`}>{action}</p>
                    {done
                      ? <CheckCircle2 size={14} className="text-amber-400 shrink-0" />
                      : <Circle size={14} className="text-white/15 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">What $100K/Month Looks Like Per Hour</p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { l: 'Revenue per hour', v: '$138', s: '$100K ÷ 720hrs/mo', c: '#fbbf24' },
                  { l: 'Deals to close daily', v: '2–3', s: 'pilots at $200 avg', c: '#34d399' },
                  { l: 'DMs to revenue ratio', v: '~1%', s: '1 paying per 100 DMs', c: '#818cf8' },
                ].map(m => (
                  <div key={m.l} className="text-center">
                    <p className="text-xl font-black" style={{ color: m.c }}>{m.v}</p>
                    <p className="text-white/30 text-[9px] mt-0.5">{m.l}</p>
                    <p className="text-white/15 text-[8px]">{m.s}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
