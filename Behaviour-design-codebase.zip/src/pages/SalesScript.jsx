import { useState } from 'react';
import {
  Phone, Copy, CheckCircle2, ChevronRight, Zap, MessageSquare,
  ArrowRight, TrendingUp, AlertCircle, Star, Flame,
} from 'lucide-react';
import MobileHeader from '../components/MobileHeader';

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
      className="flex items-center gap-1.5 text-[10px] font-semibold px-3 py-1.5 glass rounded-lg border border-white/8 hover:border-white/20 text-white/35 hover:text-white/70 transition-all shrink-0"
    >
      {copied ? <CheckCircle2 size={10} className="text-green-400" /> : <Copy size={10} />}
      {copied ? 'Copied' : 'Copy'}
    </button>
  );
}

const SCRIPT_PHASES = [
  {
    phase: '01',
    label: 'Cold Outreach',
    icon: MessageSquare,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    glow: 'shadow-indigo-500/10',
    goal: 'Get a response. Nothing else.',
    channel: 'WhatsApp / LinkedIn / Email',
    script: `Hey [Name],

Quick question — does your team track daily sales activity or just results?

I built a system that forces daily execution and shows you who's actually doing the work.

Testing it with 2 pilot companies this week. Interested?`,
    breakdown: [
      { line: 'Line 1: Disrupt with a question', tip: 'Don\'t open with "I built..." — ask something they have an opinion on.' },
      { line: 'Line 2: One-sentence value', tip: 'State the outcome, not the tool. Execution visibility = the real pain.' },
      { line: 'Line 3: Social proof + urgency', tip: '"2 pilot companies this week" creates scarcity and trust simultaneously.' },
    ],
    warning: null,
    metric: '15–25% response rate',
  },
  {
    phase: '02',
    label: 'If They Reply Interested',
    icon: ArrowRight,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    glow: 'shadow-emerald-500/10',
    goal: 'Get them to agree to a pilot — not a demo, a pilot.',
    channel: 'Reply in same thread',
    script: `Perfect. Here's exactly how it works:

→ Each team member gets daily execution tasks
→ We track who's doing the work in real time
→ You see a live leaderboard and performance scores
→ AI coaches each person based on their behavior patterns

It takes 10 minutes to set up for your team.

Would you like me to run a 7-day pilot with your team this week?`,
    breakdown: [
      { line: 'Arrow format', tip: 'Easy to scan. Decision-makers skim. Never use paragraphs in a reply.' },
      { line: '10 minutes to set up', tip: 'Reduce perceived effort to zero. This objection kills most pilots before they start.' },
      { line: '7-day pilot (not demo)', tip: 'You\'re not showing them slides. You\'re asking them to use it. Big psychological difference.' },
    ],
    warning: null,
    metric: '60–70% pilot conversion from interested leads',
  },
  {
    phase: '03',
    label: 'Closing the Pilot',
    icon: CheckCircle2,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
    glow: 'shadow-cyan-500/10',
    goal: 'Remove all risk. Make yes the easiest decision.',
    channel: 'Call or WhatsApp voice note',
    script: `I'll set it up for your team today. Here's the deal:

7 days. Zero cost. Zero obligation.

I add your users, configure the plugin for your team type (Sales, Ops, whatever), and you run it live.

At the end of 7 days:

If you see value → we talk about a plan that works for your budget.
If you don't → you walk away. No pitch, no invoice, nothing.

Sound fair?`,
    breakdown: [
      { line: '"Zero cost. Zero obligation."', tip: 'The pilot offer must eliminate every risk barrier. Say this clearly.' },
      { line: '"I add your users"', tip: 'High-touch onboarding signals you\'re serious. Reduces their effort to zero.' },
      { line: '"Sound fair?"', tip: 'Closes without pressure. They feel in control. 80%+ say yes to this framing.' },
    ],
    warning: 'Do not pitch pricing here. The pilot IS the close. Pricing comes after results.',
    metric: '70–80% of pilots convert to paid',
  },
  {
    phase: '04',
    label: 'Post-Pilot Upsell',
    icon: TrendingUp,
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/20',
    glow: 'shadow-yellow-500/10',
    goal: 'Turn a successful pilot into a monthly retainer.',
    channel: 'Video call — show them the admin data',
    script: `[Name], look at what your team produced in 7 days:

→ [X] total actions logged
→ [Y] users hit GREEN status
→ [Z]% execution rate (vs. typical [industry average])

Before this system, you had no visibility into any of this.

Here's what I recommend:

We scale this to your full team with:
→ AI coaching per person
→ Full admin analytics dashboard
→ Plugin customization for your workflow

Investment: [Starter/Pro price] per month.

This is the infrastructure that makes your team run without you micromanaging it.

Want to move forward?`,
    breakdown: [
      { line: 'Lead with their data', tip: 'Numbers they generated during the pilot. Don\'t pitch features — show their own results back.' },
      { line: '"Before this system"', tip: 'Create contrast. What was missing before vs. what\'s possible now.' },
      { line: '"Infrastructure"', tip: 'Positioning shift: not a tool, an operating system. Justifies higher price and long-term commitment.' },
    ],
    warning: null,
    metric: 'Average contract: $200–$500/mo per team',
  },
  {
    phase: '05',
    label: 'Handling Objections',
    icon: AlertCircle,
    color: 'text-pink-400',
    bg: 'bg-pink-500/10',
    border: 'border-pink-500/20',
    glow: 'shadow-pink-500/10',
    goal: 'Turn every "no" into a "not yet — tell me more."',
    channel: 'Any channel',
    script: `OBJECTION: "We already have a CRM."
REPLY: This isn't a CRM. It tracks the behavior that makes your CRM work.
Your CRM has no data if your reps aren't doing the actions.

---

OBJECTION: "My team won't adopt it."
REPLY: It takes 1 tap per action. The leaderboard creates natural adoption.
After 3 days, they're competing. You don't need to push it.

---

OBJECTION: "I need to think about it."
REPLY: Totally fair. But we're running pilots this week.
I can hold a spot for your team through Friday — after that I move on.

---

OBJECTION: "What's the cost?"
REPLY: The pilot is free. After 7 days, if you see results, we talk pricing.
The pilot shows you whether it's worth a conversation about cost.`,
    breakdown: [
      { line: 'CRM objection', tip: 'Don\'t compete with CRM. Position as the behavior layer that feeds it.' },
      { line: 'Adoption objection', tip: 'Gamification handles this. The leaderboard creates organic competition.' },
      { line: '"Think about it"', tip: 'Always give a time-bounded "hold a spot" offer. Creates gentle urgency.' },
    ],
    warning: null,
    metric: '40–50% of objection conversations convert with these replies',
  },
];

const DEAL_SIZES = [
  { type: 'SME Sales Team (10 users)', range: '$200–$500/mo', annual: '$2,400–$6,000', close: '5–10 days' },
  { type: 'Agency (20 users)', range: '$400–$800/mo', annual: '$4,800–$9,600', close: '7–14 days' },
  { type: 'Call Center (50+ users)', range: '$1,000–$2,500/mo', annual: '$12,000–$30,000', close: '2–4 weeks' },
  { type: 'Enterprise (100+ users)', range: '$3,000–$10,000/mo', annual: '$36,000–$120,000', close: '4–8 weeks' },
];

export default function SalesScript() {
  const [activePhase, setActivePhase] = useState(0);
  const active = SCRIPT_PHASES[activePhase];
  const Icon = active.icon;

  return (
    <div className="max-w-3xl mx-auto">
      <MobileHeader title="Sales Scripts" />

      <div className="hidden lg:block px-6 pt-6 pb-4">
        <div className="flex items-center gap-2 mb-1">
          <Phone size={16} className="text-indigo-400" />
          <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">Sales Closing System</span>
        </div>
        <h1 className="text-2xl font-bold text-white">Company Sales Scripts</h1>
        <p className="text-white/35 text-sm mt-0.5">5 phases · Cold to close · Objection handlers included</p>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-5">
        {/* Golden rule */}
        <div className="glass rounded-xl p-4 border border-yellow-500/20">
          <div className="flex items-start gap-3">
            <Star size={14} className="text-yellow-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest mb-1">The Golden Rule</p>
              <p className="text-white/70 text-sm leading-relaxed">
                Never sell software. Sell the <span className="text-yellow-400 font-semibold">pilot</span>. A 7-day free pilot closes 3× faster than any demo because it removes all risk. The product sells itself once they see live data.
              </p>
            </div>
          </div>
        </div>

        {/* Phase selector */}
        <div className="flex gap-1 p-1 bg-white/5 rounded-xl overflow-x-auto scrollbar-hide">
          {SCRIPT_PHASES.map((p, i) => (
            <button
              key={p.phase}
              onClick={() => setActivePhase(i)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${activePhase === i ? 'bg-indigo-500 text-white' : 'text-white/30 hover:text-white/60'}`}
            >
              <span className="font-mono opacity-50">{p.phase}</span> {p.label}
            </button>
          ))}
        </div>

        {/* Active script card */}
        <div className={`glass rounded-2xl border ${active.border} overflow-hidden`}>
          {/* Header */}
          <div className={`px-5 py-4 ${active.bg} border-b ${active.border}`}>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl ${active.bg} border ${active.border} flex items-center justify-center`}>
                  <Icon size={16} className={active.color} />
                </div>
                <div>
                  <p className="text-white font-bold text-base">{active.label}</p>
                  <p className={`text-xs ${active.color}`}>{active.channel}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${active.bg} ${active.color} border ${active.border}`}>
                  {active.metric}
                </span>
              </div>
            </div>
            <div className={`mt-3 flex items-center gap-2 text-xs ${active.color} opacity-70`}>
              <Zap size={10} />
              <span>Goal: {active.goal}</span>
            </div>
          </div>

          {/* Script body */}
          <div className="p-5 space-y-4">
            {/* Warning if present */}
            {active.warning && (
              <div className="flex items-start gap-2.5 px-4 py-3 rounded-xl bg-red-500/8 border border-red-500/20">
                <AlertCircle size={13} className="text-red-400 shrink-0 mt-0.5" />
                <p className="text-red-300/80 text-xs leading-snug font-medium">{active.warning}</p>
              </div>
            )}

            {/* Script text */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-white/25 text-[10px] uppercase tracking-widest">Script</p>
                <CopyBtn text={active.script} />
              </div>
              <pre className={`text-white/80 text-sm leading-relaxed whitespace-pre-wrap font-sans p-4 rounded-xl ${active.bg} border ${active.border}`}>
                {active.script}
              </pre>
            </div>

            {/* Line-by-line breakdown */}
            <div>
              <p className="text-white/25 text-[10px] uppercase tracking-widest mb-3">Why It Works</p>
              <div className="space-y-2.5">
                {active.breakdown.map(({ line, tip }) => (
                  <div key={line} className="flex items-start gap-3 p-3 rounded-xl bg-white/3 border border-white/6">
                    <ChevronRight size={12} className={`${active.color} mt-0.5 shrink-0`} />
                    <div>
                      <p className={`text-xs font-semibold ${active.color} mb-0.5`}>{line}</p>
                      <p className="text-white/40 text-xs leading-snug">{tip}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between pt-2 border-t border-white/6">
              <button
                onClick={() => setActivePhase(i => Math.max(0, i - 1))}
                disabled={activePhase === 0}
                className="text-xs text-white/25 hover:text-white/50 disabled:opacity-0 transition-all"
              >
                ← Previous
              </button>
              <div className="flex gap-1">
                {SCRIPT_PHASES.map((_, i) => (
                  <div key={i} className={`w-1.5 h-1.5 rounded-full transition-all ${activePhase === i ? active.color.replace('text-', 'bg-') : 'bg-white/15'}`} />
                ))}
              </div>
              {activePhase < SCRIPT_PHASES.length - 1 && (
                <button
                  onClick={() => setActivePhase(i => Math.min(SCRIPT_PHASES.length - 1, i + 1))}
                  className={`text-xs font-semibold ${active.color} flex items-center gap-1 hover:opacity-80 transition-all`}
                >
                  Next phase <ChevronRight size={11} />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Deal size reference */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3 flex items-center gap-1.5">
            <Flame size={10} className="text-orange-400" /> Deal Size Reference
          </p>
          <div className="glass rounded-xl overflow-hidden border border-white/8">
            <div className="grid grid-cols-[1fr_auto_auto_auto] text-[10px] text-white/20 uppercase tracking-widest px-4 py-2.5 border-b border-white/6 gap-3">
              <span>Target</span>
              <span className="text-right">Monthly</span>
              <span className="text-right">Annual</span>
              <span className="text-right">Close</span>
            </div>
            {DEAL_SIZES.map((d, i) => (
              <div key={d.type} className={`grid grid-cols-[1fr_auto_auto_auto] px-4 py-3 items-center gap-3 ${i < DEAL_SIZES.length - 1 ? 'border-b border-white/4' : ''}`}>
                <p className="text-white/65 text-sm">{d.type}</p>
                <p className="text-emerald-400 text-xs font-bold text-right">{d.range}</p>
                <p className="text-white/35 text-xs text-right">{d.annual}</p>
                <p className="text-white/25 text-xs text-right">{d.close}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Pipeline velocity tip */}
        <div className="glass rounded-xl p-5 border border-indigo-500/20">
          <p className="text-white font-semibold text-sm mb-3">Pipeline Velocity Rule</p>
          <div className="space-y-2">
            {[
              { label: 'Send 20 cold messages', result: '3–5 responses (15–25%)' },
              { label: '3–5 responses → book calls', result: '2–3 pilot agreements (60–70%)' },
              { label: '2–3 pilots complete', result: '1–2 convert to paid (70–80%)' },
              { label: '1–2 paid clients ask 1 referral each', result: '1–2 more clients (compounding)' },
            ].map(({ label, result }) => (
              <div key={label} className="flex items-center gap-3">
                <ChevronRight size={10} className="text-indigo-400 shrink-0" />
                <div className="flex-1 flex items-center justify-between gap-3 flex-wrap">
                  <p className="text-white/60 text-sm">{label}</p>
                  <p className="text-indigo-400 text-xs font-semibold">{result}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-white/6">
            <p className="text-emerald-400/70 text-xs">
              20 messages → $500–$1,000/mo in 2–3 weeks. This is the math that works.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
