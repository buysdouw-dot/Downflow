/**
 * AutonomousAI — Self-Improving SaaS System
 * Observe → Analyze → Adjust → Deploy → Repeat
 * 4 agents: Coach · Analyst · Growth · Pricing
 */
import { useState, useEffect, useRef } from 'react';
import {
  Brain, BarChart2, TrendingUp, DollarSign, Cpu,
  Play, RefreshCw, Zap, CheckCircle2, ArrowRight,
  Activity, Target, Flame, Eye, Settings, Clock,
  ChevronRight,
} from 'lucide-react';

// ── Agent definitions ─────────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'coach',
    name: 'Coach Agent',
    role: 'Personalizes feedback per user',
    icon: Brain,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    observe: (data) => ({ metric: 'avg_engagement', value: data.engagement }),
    analyze: (data) => `${data.engagement}% team engagement — ${data.engagement >= 70 ? 'coaching is landing' : data.engagement >= 40 ? 'tone adjustment needed' : 'full coaching reset triggered'}`,
    adapt:   (data) => data.engagement < 40
      ? 'Switched low-engagement users to Motivator personality'
      : data.engagement < 70
      ? 'Adjusted feedback frequency from daily to twice-daily'
      : 'Coaching model stable — no change needed',
  },
  {
    id: 'analyst',
    name: 'Analyst Agent',
    role: 'Finds patterns and predicts churn',
    icon: BarChart2,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/8',
    border: 'border-cyan-500/20',
    observe: (data) => ({ metric: 'churn_signal', value: data.churn }),
    analyze: (data) => `${data.churn}% churn — ${data.churn <= 5 ? 'healthy retention' : data.churn <= 15 ? 'early warning signals detected' : 'CHURN RISK: intervention required'}`,
    adapt:   (data) => data.churn > 15
      ? 'Triggered re-engagement sequence for 12 at-risk users'
      : data.churn > 5
      ? 'Flagged 4 users with 3+ RED days for manager review'
      : 'No churn interventions needed this cycle',
  },
  {
    id: 'growth',
    name: 'Growth Agent',
    role: 'Optimizes onboarding and acquisition',
    icon: TrendingUp,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/8',
    border: 'border-emerald-500/20',
    observe: (data) => ({ metric: 'trial_conversion', value: data.conversion }),
    analyze: (data) => `${data.conversion}% trial → paid — ${data.conversion >= 50 ? 'above benchmark (industry: 20%)' : data.conversion >= 25 ? 'at benchmark' : 'below benchmark — onboarding friction detected'}`,
    adapt:   (data) => data.conversion < 25
      ? 'Shortened onboarding from 6 steps to 3 — removed friction points'
      : data.conversion < 50
      ? 'Added upgrade prompt at Day 5 streak milestone'
      : 'Onboarding funnel optimized — testing expanded referral loop',
  },
  {
    id: 'pricing',
    name: 'Pricing Agent',
    role: 'Adjusts pricing based on value signals',
    icon: DollarSign,
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/8',
    border: 'border-yellow-500/20',
    observe: (data) => ({ metric: 'value_delivered', value: data.engagement }),
    analyze: (data) => `Value signal: ${data.engagement}% engagement, ${data.churn}% churn — ${data.engagement > 70 && data.churn < 5 ? 'high value delivery detected' : data.churn > 15 ? 'value gap — users not reaching outcomes' : 'value delivery normal'}`,
    adapt:   (data) => data.engagement > 70 && data.churn < 5
      ? 'Recommendation: raise Pro plan price by $3/user — users are seeing ROI'
      : data.churn > 15
      ? 'Recommendation: add AI memory to Starter plan to increase perceived value'
      : 'Pricing model stable — no adjustments this cycle',
  },
];

// ── Orchestrator ──────────────────────────────────────────────────────────────
function runOrchestrator(data, agentOutputs) {
  const insights  = agentOutputs.map(o => o.analysis);
  const adaptations = agentOutputs.map(o => o.adaptation);

  const priority = data.churn > 15 ? 'CHURN RISK — analyst + coach agents prioritized'
    : data.engagement < 40         ? 'ENGAGEMENT CRISIS — coaching reset deployed'
    : data.conversion < 25         ? 'CONVERSION GAP — onboarding agent activated'
    : 'System healthy — optimization mode active';

  const health = Math.round(
    (Math.min(100, data.engagement) * 0.4)
    + (Math.max(0, 100 - data.churn * 5) * 0.35)
    + (Math.min(100, data.conversion * 1.5) * 0.25)
  );

  return { priority, health, insights, adaptations, cycleTs: new Date().toLocaleTimeString() };
}

// ── Storage ───────────────────────────────────────────────────────────────────
function loadState()  { try { return JSON.parse(localStorage.getItem('be_autonomous_ai')) ?? { cycles: 0, log: [] }; } catch { return { cycles: 0, log: [] }; } }
function saveState(s) { try { localStorage.setItem('be_autonomous_ai', JSON.stringify(s)); } catch {} }

// ── Steps ─────────────────────────────────────────────────────────────────────
const LOOP_STEPS = [
  { id: 'observe',  label: 'Observe',  desc: 'Collect live signals from all users',    icon: Eye,      color: 'text-indigo-400'  },
  { id: 'analyze',  label: 'Analyze',  desc: '4 agents run pattern analysis in parallel', icon: BarChart2,color: 'text-cyan-400'    },
  { id: 'adjust',   label: 'Adjust',   desc: 'Orchestrator synthesizes + decides',     icon: Settings, color: 'text-purple-400'  },
  { id: 'deploy',   label: 'Deploy',   desc: 'Adaptations pushed to live system',      icon: Zap,      color: 'text-emerald-400' },
  { id: 'repeat',   label: 'Repeat',   desc: 'Next session begins new cycle',          icon: RefreshCw,color: 'text-white/40'    },
];

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AutonomousAI() {
  const [engagement,  setEngagement]  = useState(62);
  const [churn,       setChurn]       = useState(9);
  const [conversion,  setConversion]  = useState(38);
  const [running,     setRunning]     = useState(false);
  const [step,        setStep]        = useState(-1);
  const [result,      setResult]      = useState(null);
  const [agentResults,setAgentResults]= useState([]);
  const [state,       setState_]      = useState(loadState);
  const timerRef = useRef(null);

  const runCycle = () => {
    if (running) return;
    setRunning(true);
    setStep(0);
    setResult(null);
    setAgentResults([]);

    const data = { engagement, churn, conversion };

    // Step through the loop with delays
    let s = 0;
    timerRef.current = setInterval(() => {
      s++;
      setStep(s);
      if (s >= LOOP_STEPS.length) {
        clearInterval(timerRef.current);

        const outputs = AGENTS.map(agent => ({
          id:         agent.id,
          name:       agent.name,
          observed:   agent.observe(data),
          analysis:   agent.analyze(data),
          adaptation: agent.adapt(data),
        }));

        const orch = runOrchestrator(data, outputs);
        setAgentResults(outputs);
        setResult(orch);

        const newState = {
          cycles: state.cycles + 1,
          log: [
            { cycle: state.cycles + 1, time: orch.cycleTs, priority: orch.priority, health: orch.health },
            ...state.log.slice(0, 9),
          ],
        };
        setState_(newState);
        saveState(newState);
        setRunning(false);
      }
    }, 600);
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={14} className="text-purple-400" />
              <p className="text-purple-400 text-xs font-bold uppercase tracking-widest">Autonomous AI</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Self-Improving SaaS</h1>
            <p className="text-white/35 text-sm">
              System that improves itself without you. {state.cycles} cycles run.
            </p>
          </div>
          <button onClick={runCycle} disabled={running}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
              running
                ? 'bg-purple-500/10 border border-purple-500/20 text-purple-400'
                : 'bg-purple-500 hover:bg-purple-400 text-white shadow-lg shadow-purple-500/25'
            }`}>
            {running ? <><RefreshCw size={13} className="animate-spin" /> Running…</> : <><Play size={13} /> Run Cycle</>}
          </button>
        </div>

        {/* Live input signals */}
        <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
          <p className="text-white/30 text-[9px] uppercase tracking-widest mb-4">Live System Signals</p>
          <div className="grid lg:grid-cols-3 gap-4">
            {[
              { label: 'Team Engagement',    value: engagement,  set: setEngagement,  color: engagement >= 70 ? 'text-emerald-400' : engagement >= 40 ? 'text-yellow-400' : 'text-red-400',    unit: '%' },
              { label: 'Monthly Churn',      value: churn,       set: setChurn,       color: churn <= 5 ? 'text-emerald-400' : churn <= 15 ? 'text-yellow-400' : 'text-red-400',                unit: '%' },
              { label: 'Trial Conversion',   value: conversion,  set: setConversion,  color: conversion >= 50 ? 'text-emerald-400' : conversion >= 25 ? 'text-yellow-400' : 'text-red-400',    unit: '%' },
            ].map(({ label, value, set, color, unit }) => (
              <div key={label}>
                <div className="flex justify-between mb-1.5">
                  <span className="text-white/35 text-xs">{label}</span>
                  <span className={`font-black text-base ${color}`}>{value}{unit}</span>
                </div>
                <input type="range" min={0} max={100} value={value}
                  onChange={e => set(Number(e.target.value))}
                  className="w-full accent-purple-500 cursor-pointer" />
              </div>
            ))}
          </div>
        </div>

        {/* Observe → Deploy loop */}
        <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-5">
          <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Autonomous Loop</p>
          <div className="flex items-center gap-1 flex-wrap">
            {LOOP_STEPS.map((s, i) => {
              const Icon = s.icon;
              const active = running && step === i;
              const done   = step > i || (!running && result && step >= LOOP_STEPS.length);
              return (
                <div key={s.id} className="flex items-center gap-1">
                  <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold transition-all duration-300 ${
                    active ? `${['bg-indigo-500/15 border-indigo-500/30 text-indigo-300','bg-cyan-500/15 border-cyan-500/30 text-cyan-300','bg-purple-500/15 border-purple-500/30 text-purple-300','bg-emerald-500/15 border-emerald-500/30 text-emerald-300','bg-white/8 border-white/15 text-white/50'][i]} scale-105 shadow-lg`
                    : done ? 'bg-emerald-500/8 border-emerald-500/20 text-emerald-400'
                    : 'bg-white/3 border-white/6 text-white/25'
                  }`}>
                    {done && !active ? <CheckCircle2 size={11} /> : <Icon size={11} className={active ? '' : ''} />}
                    <span>{s.label}</span>
                    {active && <div className="w-1 h-1 rounded-full bg-current animate-pulse" />}
                  </div>
                  {i < LOOP_STEPS.length - 1 && (
                    <ArrowRight size={10} className={done ? 'text-emerald-400/60' : 'text-white/10'} />
                  )}
                </div>
              );
            })}
          </div>
          {result && (
            <div className="mt-4 pt-4 border-t border-white/8 flex items-center justify-between">
              <p className={`text-xs font-semibold ${result.health >= 70 ? 'text-emerald-400' : result.health >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
                {result.priority}
              </p>
              <div className="flex items-center gap-2">
                <span className="text-white/20 text-[9px]">System health</span>
                <span className={`text-sm font-black ${result.health >= 70 ? 'text-emerald-400' : result.health >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
                  {result.health}%
                </span>
              </div>
            </div>
          )}
        </div>

        {/* 4-agent outputs */}
        {agentResults.length > 0 && (
          <div className="grid lg:grid-cols-2 gap-4">
            {agentResults.map(ar => {
              const agent = AGENTS.find(a => a.id === ar.id) ?? AGENTS[0];
              const Icon = agent.icon;
              return (
                <div key={ar.id} className={`p-4 rounded-2xl border ${agent.border} ${agent.bg}`}>
                  <div className="flex items-center gap-2.5 mb-3">
                    <div className={`w-8 h-8 rounded-xl ${agent.bg} border ${agent.border} flex items-center justify-center`}>
                      <Icon size={14} className={agent.color} />
                    </div>
                    <div>
                      <p className={`text-xs font-bold ${agent.color}`}>{agent.name}</p>
                      <p className="text-white/20 text-[9px]">{agent.role}</p>
                    </div>
                  </div>
                  <div className="space-y-2.5">
                    <div>
                      <p className="text-white/20 text-[8px] uppercase tracking-widest mb-1">Observed</p>
                      <p className="text-white/50 text-xs">{ar.observed.metric}: <span className={`font-bold ${agent.color}`}>{ar.observed.value}%</span></p>
                    </div>
                    <div>
                      <p className="text-white/20 text-[8px] uppercase tracking-widest mb-1">Analysis</p>
                      <p className="text-white/55 text-xs leading-snug">{ar.analysis}</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-black/30 border border-white/6">
                      <p className="text-white/20 text-[8px] uppercase tracking-widest mb-1">Adaptation Applied</p>
                      <p className={`text-xs leading-snug font-semibold ${agent.color}`}>{ar.adaptation}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Cycle log */}
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <p className="text-white/25 text-[9px] uppercase tracking-widest">Cycle History</p>
            {state.log.length === 0 ? (
              <div className="p-6 rounded-2xl border border-white/6 text-center">
                <Cpu size={20} className="mx-auto text-white/10 mb-2" />
                <p className="text-white/20 text-sm">No cycles yet</p>
                <p className="text-white/10 text-xs">Click "Run Cycle" to start</p>
              </div>
            ) : (
              <div className="space-y-2">
                {state.log.map((entry, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border transition-all ${
                    i === 0 ? 'border-purple-500/20 bg-purple-500/5' : 'border-white/5 bg-white/1'
                  }`}>
                    <span className="text-white/20 text-[9px] font-mono mt-0.5 w-5 shrink-0">#{entry.cycle}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-white/55 text-[10px] font-semibold leading-snug truncate">{entry.priority}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-white/20 text-[9px]">{entry.time}</span>
                        <span className={`text-[9px] font-bold ${entry.health >= 70 ? 'text-emerald-400' : entry.health >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
                          {entry.health}% health
                        </span>
                      </div>
                    </div>
                    {i === 0 && <span className="text-[8px] font-black text-purple-400 bg-purple-500/10 border border-purple-500/15 px-1.5 py-0.5 rounded-full shrink-0">LATEST</span>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Architecture */}
          <div className="space-y-3">
            <p className="text-white/25 text-[9px] uppercase tracking-widest">System Architecture</p>
            <div className="p-4 rounded-2xl bg-black/40 border border-white/8">
              <pre className="text-[9px] text-purple-400/70 leading-relaxed overflow-x-auto scrollbar-hide">{`// Autonomous SaaS loop
// Runs every session, improves over time

async function systemAI(liveData) {
  // Phase 1: Observe
  const signals = collectSignals(liveData)

  // Phase 2: Analyze (agents run in parallel)
  const [coach, analyst, growth, pricing] =
    await Promise.all([
      coachAgent.analyze(signals),
      analystAgent.analyze(signals),
      growthAgent.analyze(signals),
      pricingAgent.analyze(signals),
    ])

  // Phase 3: Adjust (orchestrator decides)
  const { priority, adaptations } =
    orchestrator.synthesize({ coach, analyst,
                              growth, pricing })

  // Phase 4: Deploy
  await applyAdaptations(adaptations)

  // Phase 5: Repeat (next session)
  return { priority, health: calcHealth(signals) }
}`}</pre>
            </div>
            <p className="text-white/25 text-xs leading-relaxed">
              <span className="text-white/50 font-semibold">The compound effect: </span>
              Each cycle the system learns more about your users. After 30 days, no two companies get the same system. After 90 days, it is more personalized than any human coach could be.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
