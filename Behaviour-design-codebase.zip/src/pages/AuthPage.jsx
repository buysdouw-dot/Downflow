import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Zap, Eye, EyeOff, ArrowRight, Shield, Users, BarChart2 } from 'lucide-react';
import { useAuth } from '../store/AuthContext';

const DEMO_ACCOUNTS = [
  { email: 'alex@sales.co',    label: 'Sales Admin',    icon: '💼', role: 'Admin'   },
  { email: 'jamie@fitness.io', label: 'Fitness User',   icon: '🏋️', role: 'User'    },
  { email: 'morgan@school.edu',label: 'School Student', icon: '🎓', role: 'User'    },
  { email: 'casey@sales.co',   label: 'Sales Manager',  icon: '💼', role: 'Manager' },
];

export default function AuthPage() {
  const { login, register, authError, setAuthError, tenants } = useAuth();
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({ name: '', email: '', password: '', tenant: 'sales' });
  const set = (k) => (e) => { setForm((p) => ({ ...p, [k]: e.target.value })); setAuthError(''); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 600)); // simulate network
    if (mode === 'login') {
      login(form.email, form.password);
    } else {
      if (!form.name.trim()) { setAuthError('Name is required.'); setLoading(false); return; }
      register(form.name, form.email, form.password, form.tenant);
    }
    setLoading(false);
  };

  const quickLogin = async (email) => {
    setLoading(true);
    setForm((p) => ({ ...p, email, password: 'demo123' }));
    await new Promise((r) => setTimeout(r, 400));
    login(email, 'demo123');
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#070b14] flex">
      {/* Left panel — branding */}
      <div className="hidden lg:flex flex-col w-[480px] bg-[#0b0f1a] border-r border-white/6 p-12 relative overflow-hidden">
        {/* Decorative grid */}
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.8) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />
        {/* Glow */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center">
              <Zap size={18} className="text-indigo-400" />
            </div>
            <span className="text-white font-bold text-lg">Behavior Engine</span>
          </div>

          <h1 className="text-4xl font-bold text-white leading-tight mb-4">
            Human potential.<br />
            <span className="text-indigo-400">Engineered.</span>
          </h1>
          <p className="text-white/40 text-base leading-relaxed mb-12">
            A performance operating system that converts intention into consistent daily execution. Track, score, and improve behavior across every team.
          </p>

          <div className="space-y-4">
            {[
              { icon: Shield, label: 'Secure multi-tenant auth', desc: 'JWT-based, role-controlled access' },
              { icon: BarChart2, label: 'Real-time performance scoring', desc: 'GREEN / YELLOW / RED status engine' },
              { icon: Users, label: 'Plugin system for every business', desc: 'Sales, fitness, school — one platform' },
            ].map(({ icon: Icon, label, desc }) => (
              <div key={label} className="flex items-start gap-3 p-4 rounded-xl glass">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/15 flex items-center justify-center shrink-0 mt-0.5">
                  <Icon size={14} className="text-indigo-400" />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">{label}</p>
                  <p className="text-white/35 text-xs mt-0.5">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tenant pills */}
        <div className="relative mt-auto pt-8 border-t border-white/6">
          <p className="text-white/25 text-xs uppercase tracking-widest mb-3">Powered tenants</p>
          <div className="flex gap-2 flex-wrap">
            {Object.values(tenants).map((t) => (
              <span key={t.name} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full glass text-xs text-white/50">
                {t.icon} {t.name}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-[420px]">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center">
              <Zap size={14} className="text-indigo-400" />
            </div>
            <span className="text-white font-bold">Behavior Engine</span>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white">
              {mode === 'login' ? 'Sign in to your account' : 'Create your account'}
            </h2>
            <p className="text-white/40 text-sm mt-1">
              {mode === 'login'
                ? 'Access your performance dashboard'
                : 'Start building consistent daily output'}
            </p>
          </div>

          {/* Mode toggle */}
          <div className="flex p-1 bg-white/5 rounded-xl mb-6">
            {['login', 'register'].map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setAuthError(''); }}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                  mode === m
                    ? 'bg-indigo-500 text-white shadow-lg'
                    : 'text-white/40 hover:text-white/70'
                }`}
              >
                {m === 'login' ? 'Sign In' : 'Register'}
              </button>
            ))}
          </div>

          {/* Error */}
          {authError && (
            <div className="mb-4 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/25 text-red-300 text-sm">
              {authError}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="text-white/50 text-xs mb-1.5 block">Full Name</label>
                <input
                  type="text"
                  placeholder="Your full name"
                  value={form.name}
                  onChange={set('name')}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/25 focus:outline-none focus:border-indigo-500/60 transition-colors"
                />
              </div>
            )}

            <div>
              <label className="text-white/50 text-xs mb-1.5 block">Email Address</label>
              <input
                type="email"
                placeholder="you@company.com"
                value={form.email}
                onChange={set('email')}
                required
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/25 focus:outline-none focus:border-indigo-500/60 transition-colors"
              />
            </div>

            <div>
              <label className="text-white/50 text-xs mb-1.5 block">Password</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  placeholder="Enter password"
                  value={form.password}
                  onChange={set('password')}
                  required
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pr-11 text-white text-sm placeholder-white/25 focus:outline-none focus:border-indigo-500/60 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="text-white/50 text-xs mb-1.5 block">Organization</label>
                <select
                  value={form.tenant}
                  onChange={set('tenant')}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500/60 transition-colors appearance-none"
                >
                  {Object.entries(tenants).map(([key, t]) => (
                    <option key={key} value={key} className="bg-[#0b0f1a]">
                      {t.icon} {t.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed mt-2"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  {mode === 'login' ? 'Sign In' : 'Create Account'}
                  <ArrowRight size={15} />
                </>
              )}
            </button>
          </form>

          {/* Demo accounts */}
          <div className="mt-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px flex-1 bg-white/8" />
              <p className="text-white/25 text-xs">Quick demo access</p>
              <div className="h-px flex-1 bg-white/8" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              {DEMO_ACCOUNTS.map((acct) => (
                <button
                  key={acct.email}
                  onClick={() => quickLogin(acct.email)}
                  disabled={loading}
                  className="p-3 glass rounded-xl text-left transition-all hover:bg-white/7 disabled:opacity-50"
                >
                  <span className="text-base">{acct.icon}</span>
                  <p className="text-white/70 text-xs font-medium mt-1">{acct.label}</p>
                  <p className="text-white/25 text-[10px]">{acct.role}</p>
                </button>
              ))}
            </div>
            <p className="text-white/20 text-xs text-center mt-3">All demo accounts use password: <code className="text-white/40">demo123</code></p>
          </div>

          {/* Onboarding link */}
          <div className="mt-6 pt-5 border-t border-white/6 text-center">
            <p className="text-white/25 text-xs mb-2">New to Behavior Engine?</p>
            <Link
              to="/onboarding"
              className="inline-flex items-center gap-1.5 text-indigo-400 text-sm font-semibold hover:text-indigo-300 transition-colors"
            >
              See how it works <ArrowRight size={13} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
