import { useState } from 'react';
import {
  Building2, Users, BarChart2, Shield, Copy, CheckCheck,
  ArrowRight, ChevronRight, Crown, Zap, Globe, Lock,
  TrendingUp, CheckCircle2, Code2, Database, Settings,
  AlertTriangle, Star,
} from 'lucide-react';

// ── Demo org data ──────────────────────────────────────────────────────────────
const DEMO_ORGS = [
  {
    id: 'org_acme',
    name: 'Acme Corp',
    plan: 'enterprise',
    seats: 42,
    avgScore: 74,
    topUser: 'Sarah K.',
    topScore: 96,
    atRisk: 6,
    trend: '+8',
    arr: '$99,800',
  },
  {
    id: 'org_apex',
    name: 'Apex Sales',
    plan: 'enterprise',
    seats: 18,
    avgScore: 81,
    topUser: 'Marcus T.',
    topScore: 100,
    atRisk: 2,
    trend: '+14',
    arr: '$39,960',
  },
  {
    id: 'org_nova',
    name: 'Nova Digital',
    plan: 'pro',
    seats: 5,
    avgScore: 62,
    topUser: 'Priya M.',
    topScore: 89,
    atRisk: 2,
    trend: '+3',
    arr: '$1,740',
  },
];

const DEMO_MEMBERS = [
  { name: 'Sarah K.',  role: 'admin',  score: 96, streak: 12, tasks: 8,  status: 'elite'    },
  { name: 'James R.',  role: 'member', score: 84, streak: 7,  tasks: 7,  status: 'active'   },
  { name: 'Priya M.',  role: 'member', score: 71, streak: 4,  tasks: 6,  status: 'active'   },
  { name: 'Tom H.',    role: 'member', score: 52, streak: 2,  tasks: 4,  status: 'building' },
  { name: 'Lisa C.',   role: 'member', score: 31, streak: 0,  tasks: 2,  status: 'at-risk'  },
  { name: 'Dan W.',    role: 'member', score: 18, streak: 0,  tasks: 1,  status: 'at-risk'  },
];

// ── Code snippets ─────────────────────────────────────────────────────────────
const CODE = {
  'supabase/tenant-schema.sql': `-- Organizations table
create table if not exists public.organizations (
  id           uuid primary key default gen_random_uuid(),
  name         text not null,
  slug         text unique not null,    -- for subdomain: slug.behaviorengine.app
  plan         text not null default 'free',
  seat_limit   int  not null default 5,
  owner_id     uuid references public.profiles(id),
  stripe_sub_id text,
  settings     jsonb default '{}',     -- custom branding, coach persona, etc.
  created_at   timestamptz default now()
);

-- Link users to orgs
alter table public.profiles
  add column if not exists org_id       uuid references public.organizations(id),
  add column if not exists org_role     text not null default 'member',   -- admin | manager | member
  add column if not exists invited_by   uuid references public.profiles(id);

-- Org invites
create table if not exists public.org_invites (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizations(id) on delete cascade,
  email       text not null,
  role        text not null default 'member',
  token       text unique not null default gen_random_uuid()::text,
  accepted    boolean default false,
  expires_at  timestamptz default now() + interval '7 days',
  created_at  timestamptz default now()
);

-- Org-scoped indexes
create index if not exists profiles_org on public.profiles(org_id);
create index if not exists tasks_org    on public.tasks(user_id);   -- tasks are user-scoped, org via join`,

  'supabase/tenant-rls.sql': `-- ╔══════════════════════════════════════════════════════╗
-- ║  Tenant RLS — complete isolation between orgs        ║
-- ╚══════════════════════════════════════════════════════╝

-- Orgs: members can read their own org
create policy "orgs: select own"
  on public.organizations for select
  using (
    id in (
      select org_id from public.profiles where id = auth.uid()
    )
  );

-- Orgs: only owner can update
create policy "orgs: update by owner"
  on public.organizations for update
  using (owner_id = auth.uid());

-- Profiles: see all teammates in same org
create policy "profiles: select teammates"
  on public.profiles for select
  using (
    org_id in (
      select org_id from public.profiles where id = auth.uid()
    )
    or id = auth.uid()
  );

-- Tasks: own tasks only (org visibility via API join)
-- (tasks already have user_id RLS from base schema)

-- Invites: org admins can manage
create policy "invites: admin manage"
  on public.org_invites for all
  using (
    org_id in (
      select org_id from public.profiles
      where id = auth.uid() and org_role in ('admin','manager')
    )
  );`,

  'middleware/tenant.js': `const db = require('../db/supabase');

/**
 * requireOrg — attaches org context to req.org
 * Must run AFTER requireAuth
 */
async function requireOrg(req, res, next) {
  const { data: profile } = await db
    .from('profiles')
    .select('org_id, org_role')
    .eq('id', req.user.sub)
    .single();

  if (!profile?.org_id)
    return res.status(403).json({ error: 'No organization associated with this account' });

  req.org = { id: profile.org_id, role: profile.org_role };
  next();
}

/**
 * requireAdmin — restricts to org admin or manager
 */
function requireAdmin(req, res, next) {
  if (!['admin','manager'].includes(req.org?.role))
    return res.status(403).json({ error: 'Admin access required' });
  next();
}

module.exports = { requireOrg, requireAdmin };`,

  'routes/org.js': `const router = require('express').Router();
const db     = require('../db/supabase');
const { requireAuth }  = require('../middleware/auth');
const { requireOrg, requireAdmin } = require('../middleware/tenant');

// GET /org — current org + members
router.get('/', requireAuth, requireOrg, async (req, res, next) => {
  try {
    const [{ data: org }, { data: members }, { data: scores }] = await Promise.all([
      db.from('organizations').select('*').eq('id', req.org.id).single(),
      db.from('profiles').select('id,email,name,org_role').eq('org_id', req.org.id),
      db.from('scores').select('user_id,score').in(
        'user_id',
        (await db.from('profiles').select('id').eq('org_id', req.org.id)).data?.map(p => p.id) || []
      ),
    ]);

    const scoreMap = Object.fromEntries((scores || []).map(s => [s.user_id, s.score]));
    const enriched = (members || []).map(m => ({ ...m, score: scoreMap[m.id] || 0 }));

    const avgScore = enriched.length
      ? Math.round(enriched.reduce((sum, m) => sum + m.score, 0) / enriched.length)
      : 0;

    res.json({ org, members: enriched, avgScore });
  } catch (err) { next(err); }
});

// POST /org/invite — invite member by email
router.post('/invite', requireAuth, requireOrg, requireAdmin, async (req, res, next) => {
  const { email, role = 'member' } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });

  try {
    const { data: org } = await db
      .from('organizations').select('seat_limit').eq('id', req.org.id).single();
    const { count } = await db
      .from('profiles').select('id', { count: 'exact' }).eq('org_id', req.org.id);

    if (count >= org.seat_limit)
      return res.status(402).json({ error: 'Seat limit reached. Upgrade plan.' });

    const { data: invite, error } = await db
      .from('org_invites')
      .insert({ org_id: req.org.id, email, role })
      .select().single();

    if (error) throw error;

    // TODO: send invite email with invite.token
    res.status(201).json({ invite });
  } catch (err) { next(err); }
});

// GET /org/analytics — org-level execution stats
router.get('/analytics', requireAuth, requireOrg, requireAdmin, async (req, res, next) => {
  try {
    const { data: memberIds } = await db
      .from('profiles').select('id').eq('org_id', req.org.id);
    const ids = (memberIds || []).map(m => m.id);

    const today = new Date().toISOString().split('T')[0];
    const { data: tasks } = await db
      .from('tasks').select('user_id,completed').in('user_id', ids).gte('created_at', today);

    const totalTasks     = tasks?.length || 0;
    const completedTasks = tasks?.filter(t => t.completed).length || 0;
    const completionRate = totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0;

    res.json({
      seats:          ids.length,
      totalTasks,
      completedTasks,
      completionRate,
      date:           today,
    });
  } catch (err) { next(err); }
});

module.exports = router;`,
};

// ── Status config ─────────────────────────────────────────────────────────────
const STATUS_CONFIG = {
  elite:    { color: 'text-green-400',  bg: 'bg-green-900/30',   label: 'ELITE'    },
  active:   { color: 'text-blue-400',   bg: 'bg-blue-900/30',    label: 'ACTIVE'   },
  building: { color: 'text-amber-400',  bg: 'bg-amber-900/30',   label: 'BUILDING' },
  'at-risk':{ color: 'text-red-400',    bg: 'bg-red-900/30',     label: 'AT RISK'  },
};

export default function EnterpriseMultiTenant() {
  const [tab,      setTab]      = useState('orgs');
  const [activeOrg, setActiveOrg] = useState(DEMO_ORGS[0]);
  const [codeFile, setCodeFile] = useState('supabase/tenant-schema.sql');
  const [copied,   setCopied]   = useState('');

  function copy(key) {
    navigator.clipboard.writeText(CODE[key] || '');
    setCopied(key);
    setTimeout(() => setCopied(''), 1800);
  }

  const TABS = [
    { id: 'orgs',      label: 'Org Dashboard'  },
    { id: 'members',   label: 'Team Analytics' },
    { id: 'arch',      label: 'Architecture'   },
    { id: 'code',      label: 'Backend Code'   },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white p-4 md:p-6">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="mb-6 flex items-start gap-4">
          <div className="p-2.5 bg-blue-900/40 rounded-xl border border-blue-700/50">
            <Building2 size={24} className="text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black">Enterprise Multi-Tenant</h1>
            <p className="text-gray-400 text-sm mt-0.5">
              Company-level analytics, team isolation, seat management, org admin
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-gray-900 p-1 rounded-xl w-fit border border-gray-800">
          {TABS.map(({ id, label }) => (
            <button key={id} onClick={() => setTab(id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition
                ${tab === id ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* ── ORG DASHBOARD ── */}
        {tab === 'orgs' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {DEMO_ORGS.map(org => (
                <button key={org.id} onClick={() => setActiveOrg(org)}
                  className={`text-left bg-gray-900 rounded-xl border-2 p-4 transition
                    ${activeOrg.id === org.id ? 'border-blue-600' : 'border-gray-800 hover:border-gray-700'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Building2 size={16} className="text-blue-400" />
                      <span className="font-semibold">{org.name}</span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-bold
                      ${org.plan === 'enterprise'
                        ? 'bg-violet-900/50 text-violet-300'
                        : 'bg-green-900/50 text-green-300'}`}>
                      {org.plan}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-center">
                    {[
                      { label: 'Seats',     val: org.seats     },
                      { label: 'Avg Score', val: org.avgScore  },
                      { label: 'ARR',       val: org.arr       },
                      { label: 'Trend',     val: org.trend     },
                    ].map(({ label, val }) => (
                      <div key={label} className="bg-gray-950 rounded-lg p-2">
                        <p className="text-base font-black text-white">{val}</p>
                        <p className="text-xs text-gray-500">{label}</p>
                      </div>
                    ))}
                  </div>
                </button>
              ))}
            </div>

            {activeOrg && (
              <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-lg">{activeOrg.name}</h3>
                  <div className="flex gap-2">
                    <span className="text-xs text-gray-400">{activeOrg.seats} seats</span>
                    <span className="text-xs text-gray-600">•</span>
                    <span className="text-xs text-gray-400">{activeOrg.arr} ARR</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { label: 'Avg Execution Score', val: activeOrg.avgScore, color: activeOrg.avgScore >= 70 ? 'text-green-400' : 'text-amber-400' },
                    { label: 'Top Performer',        val: activeOrg.topUser, color: 'text-white'  },
                    { label: 'Top Score',            val: activeOrg.topScore, color: 'text-green-400' },
                    { label: 'At-Risk Users',         val: activeOrg.atRisk,  color: 'text-red-400'   },
                  ].map(({ label, val, color }) => (
                    <div key={label} className="bg-gray-950 rounded-xl p-3 text-center">
                      <p className={`text-2xl font-black ${color}`}>{val}</p>
                      <p className="text-xs text-gray-500 mt-1">{label}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-gray-400 mb-1">
                    <span>Org Execution Score</span>
                    <span>{activeOrg.avgScore}/100</span>
                  </div>
                  <div className="w-full h-3 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className={`h-3 rounded-full transition-all duration-700
                        ${activeOrg.avgScore >= 80 ? 'bg-green-500' :
                          activeOrg.avgScore >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}
                      style={{ width: `${activeOrg.avgScore}%` }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── TEAM ANALYTICS ── */}
        {tab === 'members' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Total Members', val: DEMO_MEMBERS.length,                                           color: 'text-white'       },
                { label: 'Elite (80+)',   val: DEMO_MEMBERS.filter(m => m.score >= 80).length,                color: 'text-green-400'   },
                { label: 'At Risk (<40)', val: DEMO_MEMBERS.filter(m => m.score < 40).length,                 color: 'text-red-400'     },
                { label: 'Avg Score',     val: Math.round(DEMO_MEMBERS.reduce((s,m)=>s+m.score,0)/DEMO_MEMBERS.length), color: 'text-amber-400' },
              ].map(({ label, val, color }) => (
                <div key={label} className="bg-gray-900 rounded-xl border border-gray-800 p-4 text-center">
                  <p className={`text-3xl font-black ${color}`}>{val}</p>
                  <p className="text-xs text-gray-500 mt-1">{label}</p>
                </div>
              ))}
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
              <div className="grid grid-cols-6 text-xs text-gray-500 uppercase tracking-wider
                              px-4 py-2 border-b border-gray-800">
                <span className="col-span-2">Member</span>
                <span>Score</span>
                <span>Streak</span>
                <span>Tasks</span>
                <span>Status</span>
              </div>
              {DEMO_MEMBERS.map(m => {
                const sc = STATUS_CONFIG[m.status];
                return (
                  <div key={m.name}
                    className="grid grid-cols-6 items-center px-4 py-3 border-b border-gray-800/60
                               hover:bg-gray-800/40 transition">
                    <div className="col-span-2 flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-gray-700 flex items-center justify-center
                                      text-xs font-bold text-white">
                        {m.name[0]}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{m.name}</p>
                        <p className="text-xs text-gray-500">{m.role}</p>
                      </div>
                    </div>
                    <div>
                      <p className={`text-sm font-bold
                        ${m.score >= 80 ? 'text-green-400' : m.score >= 50 ? 'text-amber-400' : 'text-red-400'}`}>
                        {m.score}
                      </p>
                      <div className="w-12 h-1.5 bg-gray-800 rounded-full overflow-hidden mt-1">
                        <div className={`h-1.5 rounded-full
                          ${m.score >= 80 ? 'bg-green-500' : m.score >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}
                          style={{ width: `${m.score}%` }} />
                      </div>
                    </div>
                    <p className="text-sm text-gray-300">{m.streak}d</p>
                    <p className="text-sm text-gray-300">{m.tasks}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full w-fit font-bold ${sc.bg} ${sc.color}`}>
                      {sc.label}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="bg-amber-900/20 border border-amber-700/40 rounded-xl p-4 flex gap-3">
              <AlertTriangle size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-200">
                <strong>2 at-risk members</strong> detected.
                Agent will send automated coaching messages at 8am, 12pm, and 5pm today.
              </div>
            </div>
          </div>
        )}

        {/* ── ARCHITECTURE ── */}
        {tab === 'arch' && (
          <div className="space-y-4 max-w-3xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                {
                  title: 'Tenant Isolation',
                  icon: Shield,
                  color: 'text-blue-400',
                  items: [
                    'Every org has a UUID org_id',
                    'Profiles link to org via org_id FK',
                    'RLS policies filter all reads by org_id',
                    'Service-role API enforces org context in middleware',
                    'No cross-org data leakage possible at DB level',
                  ],
                },
                {
                  title: 'Seat Management',
                  icon: Users,
                  color: 'text-green-400',
                  items: [
                    'seat_limit stored on organization row',
                    'Invite API checks count before allowing',
                    'Returns 402 when limit reached',
                    'Upgrading plan → update seat_limit via Stripe webhook',
                    'Admin dashboard shows seats used vs available',
                  ],
                },
                {
                  title: 'Org Roles',
                  icon: Crown,
                  color: 'text-amber-400',
                  items: [
                    'owner — full access, billing management',
                    'admin — invite/remove members, view analytics',
                    'manager — view team analytics, no billing',
                    'member — own data only',
                    'Role stored in profiles.org_role',
                  ],
                },
                {
                  title: 'Custom Branding',
                  icon: Star,
                  color: 'text-violet-400',
                  items: [
                    'settings JSONB on organizations table',
                    'coach_persona: custom AI coach name/tone',
                    'primary_color: hex for white-label UI',
                    'logo_url: org logo in nav',
                    'subdomain: slug.behaviorengine.app (DNS)',
                  ],
                },
              ].map(({ title, icon: Icon, color, items }) => (
                <div key={title} className="bg-gray-900 rounded-xl border border-gray-800 p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Icon size={16} className={color} />
                    <span className="font-semibold">{title}</span>
                  </div>
                  <ul className="space-y-1.5">
                    {items.map(i => (
                      <li key={i} className="flex items-start gap-2 text-xs text-gray-300">
                        <ChevronRight size={11} className="text-gray-600 mt-0.5 flex-shrink-0" />
                        {i}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-3">Request Flow — Org Context</p>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                {[
                  'JWT token',
                  'requireAuth → req.user.sub',
                  'requireOrg → req.org.id + role',
                  'Route handler',
                  'DB query with org filter',
                  'RLS double-checks',
                  'Response',
                ].map((node, i, arr) => (
                  <div key={node} className="flex items-center gap-2">
                    <span className="px-2 py-1 bg-gray-800 rounded text-gray-300 whitespace-nowrap">{node}</span>
                    {i < arr.length - 1 && <ArrowRight size={11} className="text-gray-600" />}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-3">Enterprise Pricing Model</p>
              <div className="grid grid-cols-3 gap-3 text-center text-sm">
                {[
                  { tier: 'Starter',    seats: '1-5',   price: '$29/mo',   per: '$29/seat/mo' },
                  { tier: 'Team',       seats: '6-20',  price: '$99/mo',   per: '$5-17/seat/mo' },
                  { tier: 'Enterprise', seats: '20+',   price: '$199/mo+', per: 'custom'       },
                ].map(({ tier, seats, price, per }) => (
                  <div key={tier} className="bg-gray-950 rounded-xl p-3">
                    <p className="font-bold text-white">{tier}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{seats} seats</p>
                    <p className="text-lg font-black text-green-400 mt-2">{price}</p>
                    <p className="text-xs text-gray-600">{per}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── CODE ── */}
        {tab === 'code' && (
          <div className="flex gap-4 h-[70vh]">
            <div className="w-56 flex-shrink-0 bg-gray-900 rounded-xl border border-gray-800 overflow-y-auto">
              <p className="px-3 py-2 text-xs text-gray-500 uppercase tracking-wider border-b border-gray-800">Files</p>
              {Object.keys(CODE).map(k => (
                <button key={k} onClick={() => setCodeFile(k)}
                  className={`w-full text-left px-3 py-2 text-xs font-mono transition
                    ${codeFile === k
                      ? 'bg-blue-900/40 text-blue-300 border-r-2 border-blue-500'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}>
                  {k}
                </button>
              ))}
            </div>
            <div className="flex-1 bg-gray-900 rounded-xl border border-gray-800 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
                <span className="text-sm font-mono text-gray-300">{codeFile}</span>
                <button onClick={() => copy(codeFile)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-800
                             hover:bg-gray-700 text-xs transition">
                  {copied === codeFile ? <CheckCheck size={12} className="text-green-400"/> : <Copy size={12}/>}
                  {copied === codeFile ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="flex-1 overflow-auto p-4 text-xs text-gray-300 font-mono leading-relaxed">
                {CODE[codeFile]}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
