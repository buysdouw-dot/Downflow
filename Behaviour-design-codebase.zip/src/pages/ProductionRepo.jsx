/**
 * ProductionRepo — Real Full-Stack GitHub-Ready Codebase
 * Complete file-by-file production code for every layer of the stack.
 */
import { useState } from 'react';
import {
  GitMerge, Copy, Check, ChevronRight, ChevronDown,
  Folder, FileCode, FileText, Database, Terminal,
  Server, Smartphone, Zap, Package, Cloud,
  ExternalLink, Download,
} from 'lucide-react';

// ── Real production code for every file ──────────────────────────────────────
const REPO = [
  {
    id: 'backend',
    label: 'backend/',
    icon: Server,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    desc: 'Node.js + Express + Prisma + JWT',
    files: [
      {
        path: 'backend/package.json',
        desc: 'Backend dependencies',
        lang: 'json',
        code: `{
  "name": "behavior-engine-backend",
  "version": "1.0.0",
  "scripts": {
    "dev": "ts-node-dev src/server.ts",
    "build": "tsc",
    "start": "node dist/server.js",
    "db:push": "prisma db push",
    "db:studio": "prisma studio"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.0",
    "@prisma/client": "^5.7.0",
    "dotenv": "^16.3.1",
    "zod": "^3.22.4",
    "express-rate-limit": "^7.1.5"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/bcryptjs": "^2.4.6",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/cors": "^2.8.17",
    "@types/node": "^20.10.0",
    "ts-node-dev": "^2.0.0",
    "typescript": "^5.3.3",
    "prisma": "^5.7.0"
  }
}`,
      },
      {
        path: 'backend/src/server.ts',
        desc: 'Entry point — starts HTTP server',
        lang: 'typescript',
        code: `import app from './app';
import { PrismaClient } from '@prisma/client';

const PORT = process.env.PORT || 3000;
export const prisma = new PrismaClient();

async function main() {
  await prisma.$connect();
  app.listen(PORT, () => {
    console.log(\`\\n🚀 Behavior Engine running on port \${PORT}\`);
    console.log(\`   Environment: \${process.env.NODE_ENV ?? 'development'}\`);
  });
}

main().catch((e) => {
  console.error(e);
  prisma.$disconnect();
  process.exit(1);
});`,
      },
      {
        path: 'backend/src/app.ts',
        desc: 'Express app + middleware + routes',
        lang: 'typescript',
        code: `import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import authRoutes    from './routes/auth';
import engineRoutes  from './routes/engine';
import analyticsRoutes from './routes/analytics';
import crmRoutes     from './routes/crm';

const app = express();

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });

// Middleware
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use(express.json());
app.use(limiter);

// Health check
app.get('/health', (_, res) => res.json({ status: 'ok', ts: Date.now() }));

// Routes
app.use('/auth',      authRoutes);
app.use('/engine',    engineRoutes);
app.use('/analytics', analyticsRoutes);
app.use('/crm',       crmRoutes);

// 404
app.use((_, res) => res.status(404).json({ error: 'Not found' }));

export default app;`,
      },
      {
        path: 'backend/src/routes/auth.ts',
        desc: 'Auth routes: register, login, me',
        lang: 'typescript',
        code: `import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../server';
import { authMiddleware } from '../middleware/auth.middleware';
import { z } from 'zod';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET!;

const registerSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(8),
  name:     z.string().min(2),
  tenantId: z.string(),
  role:     z.enum(['admin', 'manager', 'rep']).default('rep'),
});

// POST /auth/register
router.post('/register', async (req, res) => {
  try {
    const data = registerSchema.parse(req.body);
    const hashed = await bcrypt.hash(data.password, 12);
    const user = await prisma.user.create({
      data: { ...data, password: hashed },
      select: { id: true, email: true, name: true, role: true, tenantId: true },
    });
    const token = jwt.sign({ userId: user.id, tenantId: user.tenantId }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ user, token });
  } catch (e: any) {
    res.status(400).json({ error: e.message });
  }
});

// POST /auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ userId: user.id, tenantId: user.tenantId }, JWT_SECRET, { expiresIn: '7d' });
    const { password: _, ...safeUser } = user;
    res.json({ user: safeUser, token });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// GET /auth/me
router.get('/me', authMiddleware, async (req: any, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.userId },
    select: { id: true, email: true, name: true, role: true, tenantId: true },
  });
  res.json(user);
});

export default router;`,
      },
      {
        path: 'backend/src/routes/engine.ts',
        desc: 'Engine: log actions, get score, leaderboard',
        lang: 'typescript',
        code: `import { Router } from 'express';
import { prisma } from '../server';
import { authMiddleware } from '../middleware/auth.middleware';
import { calculateScore, getStatus } from '../services/engine.service';

const router = Router();
router.use(authMiddleware);

// POST /engine/action — Log a user action
router.post('/action', async (req: any, res) => {
  try {
    const { taskId, type, points } = req.body;
    const action = await prisma.action.create({
      data: {
        userId:   req.user.userId,
        tenantId: req.user.tenantId,
        taskId,
        type:     type ?? 'task_complete',
        points:   points ?? 10,
        date:     new Date().toISOString().slice(0, 10),
      },
    });
    const todayActions = await prisma.action.findMany({
      where: { userId: req.user.userId, date: action.date },
    });
    const score  = calculateScore(todayActions);
    const status = getStatus(score);
    res.json({ action, score, status });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// GET /engine/score — Today's score
router.get('/score', async (req: any, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const actions = await prisma.action.findMany({
    where: { userId: req.user.userId, date: today },
  });
  const score  = calculateScore(actions);
  const status = getStatus(score);
  res.json({ score, status, actions });
});

// GET /engine/leaderboard — Team ranking
router.get('/leaderboard', async (req: any, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const rows = await prisma.action.groupBy({
    by: ['userId'],
    where: { tenantId: req.user.tenantId, date: today },
    _sum: { points: true },
    orderBy: { _sum: { points: 'desc' } },
  });
  res.json(rows.map((r, i) => ({ rank: i + 1, userId: r.userId, score: r._sum.points ?? 0 })));
});

export default router;`,
      },
      {
        path: 'backend/src/services/engine.service.ts',
        desc: 'Core scoring + status engine',
        lang: 'typescript',
        code: `export function calculateScore(actions: { points: number }[]): number {
  return actions.reduce((sum, a) => sum + a.points, 0);
}

export function getStatus(score: number): 'GREEN' | 'YELLOW' | 'RED' {
  if (score >= 40) return 'GREEN';
  if (score >= 20) return 'YELLOW';
  return 'RED';
}

export function getConsistency(history: number[]): number {
  if (!history.length) return 0;
  const activeDays = history.filter(s => s > 0).length;
  return Math.round((activeDays / history.length) * 100);
}

export function getTrend(history: number[]): 'up' | 'down' | 'stable' {
  if (history.length < 3) return 'stable';
  const recent = history.slice(-3);
  const slope = recent[2] - recent[0];
  if (slope > 5) return 'up';
  if (slope < -5) return 'down';
  return 'stable';
}`,
      },
      {
        path: 'backend/src/services/ai.service.ts',
        desc: 'AI coaching engine — personality-aware responses',
        lang: 'typescript',
        code: `type Personality = 'discipline' | 'strategy' | 'motivation';
type Status = 'GREEN' | 'YELLOW' | 'RED';

interface UserContext {
  name: string;
  score: number;
  status: Status;
  streak: number;
  consistency: number;
  personality: Personality;
}

const RESPONSES: Record<Personality, Record<Status, string[]>> = {
  discipline: {
    GREEN:  ['Strong execution. Maintain the standard.', 'Results speak. Keep the output up.'],
    YELLOW: ['You are coasting. Unacceptable. Three actions. Now.', 'Mediocre effort produces mediocre results.'],
    RED:    ['You are off track. No excuses. One task. Complete it now.', 'This is not who you are. Reset. Execute.'],
  },
  strategy:   {
    GREEN:  ['Solid. Now document what\'s working so you can replicate it.'],
    YELLOW: ['Identify the bottleneck. What single change gives most leverage?'],
    RED:    ['Step back. What is the root cause? Fix the system, not the symptoms.'],
  },
  motivation: {
    GREEN:  ['You are on fire! Keep this energy going! 🔥', 'This is exactly who you are capable of being!'],
    YELLOW: ['You\'ve got more in you! One more action — you can do this!'],
    RED:    ['Every champion has down days. This is just the reset. Come back stronger!'],
  },
};

export function coach(ctx: UserContext): string {
  const opts = RESPONSES[ctx.personality][ctx.status];
  return opts[Math.floor(Math.random() * opts.length)];
}

export function buildCoachingPayload(ctx: UserContext) {
  return {
    message:    coach(ctx),
    priority:   ctx.status === 'RED' ? 'high' : ctx.status === 'YELLOW' ? 'medium' : 'low',
    streakNote: ctx.streak > 0 ? \`\${ctx.streak}-day streak. Protect it.\` : null,
    trend:      ctx.consistency >= 70 ? 'consistent' : ctx.consistency >= 40 ? 'building' : 'starting',
  };
}`,
      },
      {
        path: 'backend/src/middleware/auth.middleware.ts',
        desc: 'JWT auth middleware',
        lang: 'typescript',
        code: `import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET!;

export interface AuthRequest extends Request {
  user?: { userId: string; tenantId: string };
}

export function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer '))
    return res.status(401).json({ error: 'No token provided' });

  const token = header.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET) as { userId: string; tenantId: string };
    req.user = payload;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}`,
      },
      {
        path: 'backend/src/routes/crm.ts',
        desc: 'CRM: leads, pipeline, auto-advance',
        lang: 'typescript',
        code: `import { Router } from 'express';
import { prisma } from '../server';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();
router.use(authMiddleware);

const PIPELINE = ['new', 'contacted', 'pilot', 'paid', 'expansion'];

// GET /crm/leads
router.get('/leads', async (req: any, res) => {
  const leads = await prisma.lead.findMany({
    where: { tenantId: req.user.tenantId },
    orderBy: { createdAt: 'desc' },
  });
  res.json(leads);
});

// POST /crm/leads
router.post('/leads', async (req: any, res) => {
  const lead = await prisma.lead.create({
    data: { ...req.body, tenantId: req.user.tenantId, status: 'new' },
  });
  res.status(201).json(lead);
});

// PATCH /crm/leads/:id/advance — Move to next stage
router.patch('/leads/:id/advance', async (req: any, res) => {
  const lead = await prisma.lead.findUnique({ where: { id: req.params.id } });
  if (!lead) return res.status(404).json({ error: 'Not found' });
  const idx  = PIPELINE.indexOf(lead.status);
  if (idx >= PIPELINE.length - 1)
    return res.status(400).json({ error: 'Already at final stage' });
  const updated = await prisma.lead.update({
    where: { id: lead.id },
    data:  { status: PIPELINE[idx + 1] },
  });
  res.json(updated);
});

export default router;`,
      },
    ],
  },
  {
    id: 'prisma',
    label: 'prisma/',
    icon: Database,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/8',
    border: 'border-cyan-500/20',
    desc: 'Complete database schema',
    files: [
      {
        path: 'prisma/schema.prisma',
        desc: 'Full database schema',
        lang: 'prisma',
        code: `// This is your Prisma schema file.
// Learn more about it at https://pris.ly/d/prisma-schema

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model Tenant {
  id        String   @id @default(cuid())
  name      String
  slug      String   @unique
  plan      String   @default("starter")
  createdAt DateTime @default(now())
  users     User[]
  leads     Lead[]
  actions   Action[]
  tasks     Task[]
}

model User {
  id          String   @id @default(cuid())
  email       String   @unique
  password    String
  name        String
  role        String   @default("rep")  // admin | manager | rep
  tenantId    String
  personality String   @default("discipline")
  streak      Int      @default(0)
  createdAt   DateTime @default(now())
  tenant      Tenant   @relation(fields: [tenantId], references: [id])
  actions     Action[]
}

model Task {
  id          String   @id @default(cuid())
  tenantId    String
  title       String
  description String?
  points      Int      @default(10)
  category    String   @default("general")
  active      Boolean  @default(true)
  createdAt   DateTime @default(now())
  tenant      Tenant   @relation(fields: [tenantId], references: [id])
  actions     Action[]
}

model Action {
  id       String   @id @default(cuid())
  userId   String
  tenantId String
  taskId   String?
  type     String   @default("task_complete")
  points   Int
  date     String   // YYYY-MM-DD
  createdAt DateTime @default(now())
  user     User     @relation(fields: [userId], references: [id])
  tenant   Tenant   @relation(fields: [tenantId], references: [id])
  task     Task?    @relation(fields: [taskId], references: [id])
}

model Lead {
  id          String   @id @default(cuid())
  tenantId    String
  name        String
  company     String
  email       String?
  status      String   @default("new")   // new|contacted|pilot|paid|expansion
  source      String   @default("inbound")
  teamSize    Int      @default(5)
  value       Int      @default(0)
  lastAction  String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  tenant      Tenant   @relation(fields: [tenantId], references: [id])
}`,
      },
      {
        path: 'prisma/seed.ts',
        desc: 'Database seed for local dev',
        lang: 'typescript',
        code: `import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Create demo tenant
  const tenant = await prisma.tenant.upsert({
    where: { slug: 'acme-sales' },
    update: {},
    create: { name: 'Acme Sales Team', slug: 'acme-sales', plan: 'pro' },
  });

  // Create admin user
  await prisma.user.upsert({
    where: { email: 'admin@acme.com' },
    update: {},
    create: {
      email:    'admin@acme.com',
      password: await bcrypt.hash('password123', 12),
      name:     'Admin User',
      role:     'admin',
      tenantId: tenant.id,
    },
  });

  // Create default tasks
  const tasks = ['Morning check-in', 'Log sales call', 'Update CRM', 'Submit daily report'];
  for (const title of tasks) {
    await prisma.task.create({ data: { title, tenantId: tenant.id, points: 10 } });
  }

  console.log('✅ Database seeded successfully');
}

main().catch(console.error).finally(() => prisma.$disconnect());`,
      },
    ],
  },
  {
    id: 'frontend',
    label: 'frontend/',
    icon: FileCode,
    color: 'text-purple-400',
    bg: 'bg-purple-500/8',
    border: 'border-purple-500/20',
    desc: 'React + TypeScript + Tailwind',
    files: [
      {
        path: 'frontend/src/api/client.ts',
        desc: 'Axios API client with JWT interceptor',
        lang: 'typescript',
        code: `import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:3000',
  timeout: 10000,
});

// Attach JWT on every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('be_token');
  if (token) config.headers.Authorization = \`Bearer \${token}\`;
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('be_token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export const auth = {
  login:    (email: string, password: string) => api.post('/auth/login', { email, password }),
  register: (data: object)                    => api.post('/auth/register', data),
  me:       ()                                => api.get('/auth/me'),
};

export const engine = {
  logAction:   (taskId: string, points: number) => api.post('/engine/action', { taskId, points }),
  getScore:    ()                               => api.get('/engine/score'),
  leaderboard: ()                               => api.get('/engine/leaderboard'),
};

export const crm = {
  getLeads:     ()         => api.get('/crm/leads'),
  createLead:   (data: object) => api.post('/crm/leads', data),
  advanceLead:  (id: string)   => api.patch(\`/crm/leads/\${id}/advance\`),
};

export default api;`,
      },
      {
        path: 'frontend/src/store/AuthContext.tsx',
        desc: 'Auth context with JWT persistence',
        lang: 'typescript',
        code: `import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth as authApi } from '../api/client';

interface User {
  id: string; email: string; name: string; role: string; tenantId: string;
}
interface AuthCtx {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthCtx>({} as AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user,  setUser]  = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(
    () => localStorage.getItem('be_token')
  );

  useEffect(() => {
    if (token && !user) {
      authApi.me()
        .then(r => setUser(r.data))
        .catch(() => { setToken(null); localStorage.removeItem('be_token'); });
    }
  }, [token]);

  const login = async (email: string, password: string) => {
    const { data } = await authApi.login(email, password);
    setUser(data.user);
    setToken(data.token);
    localStorage.setItem('be_token', data.token);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('be_token');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);`,
      },
      {
        path: 'frontend/.env.example',
        desc: 'Frontend environment variables',
        lang: 'bash',
        code: `VITE_API_URL=http://localhost:3000
VITE_APP_NAME=Behavior Engine`,
      },
    ],
  },
  {
    id: 'mobile',
    label: 'mobile/',
    icon: Smartphone,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/8',
    border: 'border-emerald-500/20',
    desc: 'React Native — iOS + Android',
    files: [
      {
        path: 'mobile/src/screens/Dashboard.js',
        desc: 'Mobile dashboard with live score',
        lang: 'javascript',
        code: `import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { engine } from '../api/client';

const STATUS_COLORS = { GREEN: '#10b981', YELLOW: '#f59e0b', RED: '#ef4444' };

export default function Dashboard() {
  const [score,   setScore]   = useState(0);
  const [status,  setStatus]  = useState('RED');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    engine.getScore()
      .then(r => { setScore(r.data.score); setStatus(r.data.status); })
      .finally(() => setLoading(false));
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Today</Text>
      <View style={[styles.scoreCard, { borderColor: STATUS_COLORS[status] }]}>
        <Text style={[styles.score, { color: STATUS_COLORS[status] }]}>
          {loading ? '...' : score}
        </Text>
        <Text style={[styles.status, { color: STATUS_COLORS[status] }]}>{status}</Text>
      </View>
      <TouchableOpacity style={styles.actionBtn}
        onPress={() => engine.logAction('default', 10)
          .then(r => { setScore(r.data.score); setStatus(r.data.status); })}>
        <Text style={styles.actionBtnText}>+ Log Action</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: '#070b14', padding: 24 },
  title:        { color: 'rgba(255,255,255,0.4)', fontSize: 12, letterSpacing: 2, marginBottom: 16 },
  scoreCard:    { borderWidth: 1, borderRadius: 16, padding: 24, alignItems: 'center', marginBottom: 24 },
  score:        { fontSize: 72, fontWeight: '900', lineHeight: 80 },
  status:       { fontSize: 14, fontWeight: '700', marginTop: 4 },
  actionBtn:    { backgroundColor: '#6366f1', borderRadius: 14, padding: 16, alignItems: 'center' },
  actionBtnText:{ color: '#fff', fontWeight: '700', fontSize: 15 },
});`,
      },
      {
        path: 'mobile/src/screens/Tasks.js',
        desc: 'Mobile task list with completion',
        lang: 'javascript',
        code: `import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { engine } from '../api/client';

const DEFAULT_TASKS = [
  { id: '1', title: 'Morning check-in',    points: 10, done: false },
  { id: '2', title: 'Log sales call',      points: 15, done: false },
  { id: '3', title: 'Update CRM pipeline', points: 10, done: false },
  { id: '4', title: 'Submit daily report', points: 15, done: false },
];

export default function Tasks() {
  const [tasks, setTasks] = useState(DEFAULT_TASKS);

  const complete = async (task) => {
    if (task.done) return;
    await engine.logAction(task.id, task.points);
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, done: true } : t));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tasks</Text>
      <FlatList
        data={tasks}
        keyExtractor={t => t.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.task, item.done && styles.taskDone]}
            onPress={() => complete(item)}>
            <View style={[styles.check, item.done && styles.checkDone]}>
              {item.done && <Text style={styles.checkMark}>✓</Text>}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.taskTitle, item.done && styles.taskTitleDone]}>{item.title}</Text>
              <Text style={styles.pts}>+{item.points} pts</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: '#070b14', padding: 24 },
  title:        { color: 'rgba(255,255,255,0.4)', fontSize: 12, letterSpacing: 2, marginBottom: 16 },
  task:         { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 12, marginBottom: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  taskDone:     { borderColor: 'rgba(16,185,129,0.3)', backgroundColor: 'rgba(16,185,129,0.06)' },
  check:        { width: 22, height: 22, borderRadius: 6, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  checkDone:    { backgroundColor: '#10b981', borderColor: '#10b981' },
  checkMark:    { color: '#fff', fontSize: 11, fontWeight: '700' },
  taskTitle:    { color: 'rgba(255,255,255,0.7)', fontSize: 14, fontWeight: '600' },
  taskTitleDone:{ color: 'rgba(255,255,255,0.3)', textDecorationLine: 'line-through' },
  pts:          { color: 'rgba(255,255,255,0.3)', fontSize: 11, marginTop: 2 },
});`,
      },
    ],
  },
  {
    id: 'infra',
    label: 'infra/',
    icon: Cloud,
    color: 'text-orange-400',
    bg: 'bg-orange-500/8',
    border: 'border-orange-500/20',
    desc: 'Docker + deploy configs',
    files: [
      {
        path: 'docker-compose.yml',
        desc: 'Full stack with Postgres + Redis',
        lang: 'yaml',
        code: `version: "3.9"

services:
  postgres:
    image: postgres:15-alpine
    restart: unless-stopped
    environment:
      POSTGRES_USER:     \${POSTGRES_USER:-postgres}
      POSTGRES_PASSWORD: \${POSTGRES_PASSWORD:-postgres}
      POSTGRES_DB:       behavior_engine
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    restart: unless-stopped
    ports:
      - "6379:6379"

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    restart: unless-stopped
    environment:
      DATABASE_URL: postgresql://\${POSTGRES_USER:-postgres}:\${POSTGRES_PASSWORD:-postgres}@postgres:5432/behavior_engine
      JWT_SECRET:   \${JWT_SECRET:-change-me-in-production}
      NODE_ENV:     production
      PORT:         3000
    ports:
      - "3000:3000"
    depends_on:
      - postgres
      - redis

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    restart: unless-stopped
    environment:
      VITE_API_URL: http://localhost:3000
    ports:
      - "80:80"
    depends_on:
      - backend

volumes:
  pgdata:`,
      },
      {
        path: 'backend/Dockerfile',
        desc: 'Backend Docker build',
        lang: 'dockerfile',
        code: `FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine AS production
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/prisma ./prisma
COPY package*.json ./

ENV NODE_ENV=production
EXPOSE 3000

RUN npx prisma generate
CMD ["node", "dist/server.js"]`,
      },
      {
        path: '.env.example',
        desc: 'Root environment variables',
        lang: 'bash',
        code: `# Database
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/behavior_engine

# Auth
JWT_SECRET=your-super-secret-key-change-in-production

# App
NODE_ENV=development
PORT=3000
FRONTEND_URL=http://localhost:5173

# PostgreSQL (for Docker Compose)
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres

# Optional: Redis
REDIS_URL=redis://localhost:6379

# Optional: Email (for notifications)
SMTP_HOST=smtp.resend.com
SMTP_PORT=465
SMTP_USER=resend
SMTP_PASS=your-api-key
SMTP_FROM=noreply@yourdomain.com`,
      },
      {
        path: 'README.md',
        desc: 'Setup + deployment guide',
        lang: 'markdown',
        code: `# Behavior Engine SaaS

> Convert human potential into consistent daily output through structured behavior design.

## Quick Start

\`\`\`bash
# 1. Clone
git clone https://github.com/you/behavior-engine
cd behavior-engine

# 2. Environment
cp .env.example .env
# Edit .env with your values

# 3. Start with Docker
docker-compose up -d

# 4. Run migrations + seed
docker-compose exec backend npx prisma db push
docker-compose exec backend npx ts-node prisma/seed.ts

# 5. Open
open http://localhost:80
\`\`\`

## Manual Setup

\`\`\`bash
# Backend
cd backend && npm install
npx prisma db push && npx ts-node prisma/seed.ts
npm run dev    # → http://localhost:3000

# Frontend (new terminal)
cd frontend && npm install
npm run dev    # → http://localhost:5173
\`\`\`

## Deploy to Railway (Recommended)

\`\`\`bash
npm install -g @railway/cli
railway login
railway init
railway add postgresql
railway up
\`\`\`

## Stack

| Layer    | Tech                        |
|----------|-----------------------------|
| Frontend | React 18 + TypeScript + Vite + Tailwind CSS v4 |
| Backend  | Node.js + Express + TypeScript |
| Database | PostgreSQL + Prisma ORM     |
| Auth     | JWT (7-day tokens)          |
| Mobile   | React Native (Expo)         |
| Infra    | Docker + docker-compose     |
| Deploy   | Railway / Render / Fly.io   |

## License
MIT`,
      },
    ],
  },
];

// ── Copy button ───────────────────────────────────────────────────────────────
function CopyBtn({ text, small }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };
  return (
    <button onClick={copy}
      className={`flex items-center gap-1 rounded-lg transition-all ${
        small ? 'px-2 py-1 text-[9px]' : 'px-2.5 py-1.5 text-[10px]'
      } ${copied
        ? 'bg-emerald-500/15 border border-emerald-500/20 text-emerald-400'
        : 'bg-white/5 border border-white/8 text-white/35 hover:text-white/60 hover:bg-white/8'
      } font-semibold`}>
      {copied ? <><Check size={9} /> Copied</> : <><Copy size={9} /> Copy</>}
    </button>
  );
}

// ── File node ─────────────────────────────────────────────────────────────────
function FileNode({ file }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl border border-white/6 bg-white/1 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-2.5 cursor-pointer hover:bg-white/3 transition-all"
        onClick={() => setOpen(v => !v)}>
        <div className="flex items-center gap-2.5">
          {open ? <ChevronDown size={11} className="text-white/25 shrink-0" /> : <ChevronRight size={11} className="text-white/25 shrink-0" />}
          <FileCode size={11} className="text-white/25 shrink-0" />
          <code className="text-white/60 text-[10px] font-mono">{file.path}</code>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-white/20 text-[9px] hidden lg:inline">{file.desc}</span>
          <CopyBtn text={file.code} small />
        </div>
      </div>
      {open && (
        <div className="border-t border-white/6">
          <pre className="p-4 text-[10px] leading-relaxed text-emerald-400/80 font-mono overflow-x-auto scrollbar-hide max-h-96 bg-black/30">
            {file.code}
          </pre>
        </div>
      )}
    </div>
  );
}

// ── Section ───────────────────────────────────────────────────────────────────
function Section({ section }) {
  const [open, setOpen] = useState(true);
  const Icon = section.icon;
  const allCode = section.files.map(f => `// ── ${f.path} ──\n${f.code}`).join('\n\n');
  return (
    <div className={`rounded-2xl border ${section.border} overflow-hidden`}>
      <div className={`flex items-center justify-between px-5 py-4 cursor-pointer ${section.bg}`}
        onClick={() => setOpen(v => !v)}>
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-xl ${section.bg} border ${section.border} flex items-center justify-center shrink-0`}>
            <Icon size={15} className={section.color} />
          </div>
          <div>
            <p className={`text-sm font-bold ${section.color} font-mono`}>{section.label}</p>
            <p className="text-white/30 text-[10px]">{section.desc} · {section.files.length} files</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <CopyBtn text={allCode} />
          {open ? <ChevronDown size={14} className="text-white/25" /> : <ChevronRight size={14} className="text-white/25" />}
        </div>
      </div>
      {open && (
        <div className="px-4 pb-4 pt-2 space-y-2 border-t border-white/6">
          {section.files.map(f => <FileNode key={f.path} file={f} />)}
        </div>
      )}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function ProductionRepo() {
  const allCode = REPO.flatMap(s => s.files).map(f => `// ══ ${f.path} ══\n${f.code}`).join('\n\n');

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <GitMerge size={14} className="text-white/40" />
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Production Repo</p>
            </div>
            <h1 className="text-3xl font-black mb-1">behavior-engine-saas</h1>
            <p className="text-white/35 text-sm">Full-stack deployable codebase. Copy, paste, ship.</p>
          </div>
          <div className="flex flex-col gap-2 items-end">
            <CopyBtn text={allCode} />
            <div className="flex gap-2">
              {['MIT', 'PostgreSQL', 'Node 20', 'React 18'].map(t => (
                <span key={t} className="text-[8px] font-bold px-2 py-0.5 rounded-full bg-white/5 border border-white/8 text-white/30">{t}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Quick setup */}
        <div className="rounded-2xl border border-white/8 bg-black/30 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Terminal size={12} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold">Quick Setup (Docker)</p>
            </div>
            <CopyBtn text={`git clone https://github.com/you/behavior-engine\ncd behavior-engine\ncp .env.example .env\ndocker-compose up -d\ndocker-compose exec backend npx prisma db push\ndocker-compose exec backend npx ts-node prisma/seed.ts`} small />
          </div>
          <pre className="text-[10px] text-emerald-400/70 font-mono leading-relaxed">{`git clone https://github.com/you/behavior-engine
cd behavior-engine
cp .env.example .env           # fill in JWT_SECRET + DB creds
docker-compose up -d           # starts postgres + backend + frontend
docker-compose exec backend npx prisma db push
docker-compose exec backend npx ts-node prisma/seed.ts
open http://localhost          # done ✅`}</pre>
        </div>

        {/* Stack overview */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Backend',  value: 'Node + Express', icon: Server,     color: 'text-indigo-400' },
            { label: 'Database', value: 'PostgreSQL + Prisma', icon: Database, color: 'text-cyan-400' },
            { label: 'Frontend', value: 'React + Vite',   icon: FileCode,   color: 'text-purple-400' },
            { label: 'Deploy',   value: 'Docker / Railway', icon: Cloud,    color: 'text-orange-400' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="p-3 rounded-xl bg-white/2 border border-white/6 flex items-center gap-2.5">
              <Icon size={13} className={color} />
              <div>
                <p className={`text-[10px] font-bold ${color}`}>{label}</p>
                <p className="text-white/30 text-[9px]">{value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* File sections */}
        <div className="space-y-4">
          {REPO.map(section => <Section key={section.id} section={section} />)}
        </div>

        {/* Deploy options */}
        <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
          <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-4">One-Click Deploy Options</p>
          <div className="grid lg:grid-cols-3 gap-3">
            {[
              { name: 'Railway',    desc: 'Easiest. Auto-detects Node + Postgres.', time: '~5 min', color: 'text-purple-400', bg: 'bg-purple-500/8', border: 'border-purple-500/20', cmd: 'railway up' },
              { name: 'Render',     desc: 'Free tier. Good for MVPs + demos.',       time: '~8 min', color: 'text-blue-400',   bg: 'bg-blue-500/8',   border: 'border-blue-500/20',   cmd: 'render deploy' },
              { name: 'Fly.io',     desc: 'Best performance. Global edge.',          time: '~10 min',color: 'text-orange-400', bg: 'bg-orange-500/8', border: 'border-orange-500/20', cmd: 'fly deploy' },
            ].map(opt => (
              <div key={opt.name} className={`p-4 rounded-xl ${opt.bg} border ${opt.border}`}>
                <div className="flex items-center justify-between mb-1.5">
                  <p className={`text-sm font-bold ${opt.color}`}>{opt.name}</p>
                  <span className="text-white/20 text-[9px]">{opt.time}</span>
                </div>
                <p className="text-white/35 text-xs mb-2.5">{opt.desc}</p>
                <code className={`text-[9px] font-mono px-2 py-1 rounded-lg ${opt.bg} border ${opt.border} ${opt.color}`}>{opt.cmd}</code>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
