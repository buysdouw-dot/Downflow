/**
 * AutonomousV6 — Fully Autonomous SaaS v6
 * AI runs: product · onboarding · coaching · pricing · growth
 * Observe → Analyze → Decide → Deploy → Improve → Loop
 * No dashboards. No humans. Just execution.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Cpu, Play, RefreshCw, Eye, Brain, TrendingUp,
  DollarSign, Wrench, Settings, ArrowRight, Repeat,
  CheckCircle2, Zap, BarChart2, Code2, GitBranch,
  MessageCircle, Mail, Bell, Star, Layers,
} from 'lucide-react';

// ── v1 → v6 evolution ─────────────────────────────────────────────────────────
const EVOLUTION = [
  { v: 'v1', label: 'You build features manually',         color: '#a1a1aa', active: false },
  { v: 'v2', label: 'Product learns from usage data',      color: '#818cf8', active: false },
  { v: 'v3', label: 'Product improves itself (logic)',     color: '#22d3ee', active: false },
  { v: 'v4', label: 'Company runs itself (4 agents)',      color: '#a78bfa', active: false },
  { v: 'v5', label: 'Company evolves itself (5 agents)',   color: '#fbbf24', active: false },
  { v: 'v6', label: 'System replaces itself — indefinitely', color: '#f472b6', active: true  },
];

// ── 5 Agents ──────────────────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'behavior', name: 'Behavior Agent', Icon: Eye,
    color: '#22d3ee', bg: 'rgba(6,182,212,0.06)', border: 'rgba(6,182,212,0.15)',
    schedule: 'Hourly',
    runs: (c) => `Scanned ${c.users} users. ${c.high} high (${c.highPct}%). ${c.drops} drop patterns. Signals dispatched to all agents.`,
    ctx: { users: 312, high: 187, highPct: 60, drops: 23 },
    tasks: ['Read all user execution data in real time', 'Calculate score per user (0–100)', 'Detect 3-day drop patterns', 'Segment: HIGH / MEDIUM / LOW', 'Dispatch signals → all other agents'],
    kpi: 'Signal accuracy / false positive rate',
  },
  {
    id: 'coach', name: 'Coach Agent', Icon: Brain,
    color: '#a78bfa', bg: 'rgba(139,92,246,0.06)', border: 'rgba(139,92,246,0.15)',
    schedule: 'Daily 8am + on trigger',
    runs: (c) => `Sent ${c.sent} coaching messages. ${c.wa} WhatsApp, ${c.em} email. Avg open rate ${c.open}%. Corr with score lift: ${c.corr}.`,
    ctx: { sent: 189, wa: 94, em: 71, open: 74, corr: '+0.63' },
    tasks: ['Read behavior signals per user', 'Generate personalised message (LLM, not template)', 'Route: WhatsApp → email → push by preference', 'Adjust tone: supportive / direct / urgent', 'Track message → score lift correlation'],
    kpi: 'Score lift after coaching message',
  },
  {
    id: 'growth', name: 'Growth Agent', Icon: TrendingUp,
    color: '#f472b6', bg: 'rgba(236,72,153,0.06)', border: 'rgba(236,72,153,0.15)',
    schedule: 'Every 12 hours',
    runs: (c) => `Published ${c.posts} posts. ${c.viral} viral triggers fired. ${c.refs} referrals generated. A/B test "${c.test}" running.`,
    ctx: { posts: 4, viral: 31, refs: 7, test: '"Score" vs "Execution" headline' },
    tasks: ['Detect users with K > 0.8 (viral candidates)', 'Post execution insights to LinkedIn + Twitter', 'Send "share your score" to top performers', 'Monitor referral links + nurture warm leads', 'A/B test outreach copy (1 variant per week)'],
    kpi: 'Viral coefficient K',
  },
  {
    id: 'revenue', name: 'Revenue Agent', Icon: DollarSign,
    color: '#fbbf24', bg: 'rgba(245,158,11,0.06)', border: 'rgba(245,158,11,0.15)',
    schedule: 'Monday 9am',
    runs: (c) => `${c.ready} upgrade-ready accounts. ${c.proposals} proposals sent. ${c.conv} converted. $${c.mrr} MRR added. Win-backs: ${c.wb}.`,
    ctx: { ready: 9, proposals: 9, conv: 3, mrr: 540, wb: 4 },
    tasks: ['Detect teams ready for upgrade (5+ active seats)', 'Send upgrade prompt with their own usage stats', 'Propose annual plan (30% discount) to high-engagement', 'Trigger win-back for lapsed accounts (5-day inactive)', 'Adjust pricing for new signups on demand signals'],
    kpi: 'Net Revenue Retention (NRR)',
  },
  {
    id: 'system', name: 'System Agent', Icon: Wrench,
    color: '#34d399', bg: 'rgba(16,185,129,0.06)', border: 'rgba(16,185,129,0.15)',
    schedule: 'Sunday midnight',
    runs: (c) => `Analysed ${c.pts} data points. ${c.changes} improvements generated. ${c.applied} auto-applied (conf > 80%). ${c.flagged} flagged for review.`,
    ctx: { pts: 4800, changes: 7, applied: 5, flagged: 2 },
    tasks: ['Analyse which task types drive highest completion', 'Adjust scoring weights for underperforming users', 'Rewrite low-performing coaching templates', 'A/B test product logic (difficulty, frequency, tone)', 'Write weekly improvement log — flag uncertain changes'],
    kpi: 'Product iteration velocity',
  },
];

// ── Self-op loop ───────────────────────────────────────────────────────────────
const LOOP = [
  { id: 'observe',  label: 'Observe',   Icon: Eye,       color: '#22d3ee', desc: 'All agents read system state' },
  { id: 'analyze',  label: 'Analyze',   Icon: BarChart2, color: '#818cf8', desc: 'Patterns + anomalies detected' },
  { id: 'decide',   label: 'Decide',    Icon: Brain,     color: '#a78bfa', desc: 'LLM selects optimal action' },
  { id: 'deploy',   label: 'Deploy',    Icon: Zap,       color: '#fbbf24', desc: 'Action executed automatically' },
  { id: 'improve',  label: 'Improve',   Icon: TrendingUp,color: '#34d399', desc: 'System Agent learns from result' },
];

// ── Orchestrator code ──────────────────────────────────────────────────────────
const ORCHESTRATOR = `// ai/orchestrator.js — v6 Autonomous System

require('dotenv').config({ path: '../.env' });
const cron     = require('node-cron');
const behavior = require('./agents/behavior');
const coach    = require('./agents/coach');
const growth   = require('./agents/growth');
const revenue  = require('./agents/revenue');
const system   = require('./agents/system');   // ← NEW in v6
const memory   = require('./memory');

// ── Agent Schedule ────────────────────────────────────────────────────
cron.schedule('0 * * * *',    () => run('behavior', behavior.run));
cron.schedule('0 8 * * *',    async () => {
  const { signals } = await behavior.run();
  run('coach', () => coach.run(signals));
});
cron.schedule('0 6,18 * * *', () => run('growth', growth.run));
cron.schedule('0 9 * * 1',    () => run('revenue', revenue.run));
cron.schedule('0 0 * * 0',    () => run('system', system.run)); // Sunday midnight

// ── Runner ────────────────────────────────────────────────────────────
async function run(name, fn) {
  try {
    const result = await fn();
    memory.store(name, result);
    console.log(\`[\${name}]\`, result);
  } catch (e) {
    console.error(\`[\${name}] ERROR:\`, e.message);
    // In production: alert via Sentry
  }
}`;

const SYSTEM_AGENT = `// ai/agents/system.js — The Product Intelligence Agent (v6 only)

async function run() {
  // 1. Pull all signals from memory
  const behaviorData = memory.recall('behavior', 30);
  const coachData    = memory.recall('coach',    30);

  // 2. Identify what's working and what's not
  const patterns = await analyzePatterns(behaviorData, coachData);

  // 3. Generate improvement proposals
  const proposals = await openai.chat.completions.create({
    model:    'gpt-4o',
    messages: [{ role: 'user', content: \`
      You are a product intelligence agent.
      Data: \${JSON.stringify(patterns)}
      Generate 3–5 specific product improvement proposals.
      Each must include: change, reason, expected_impact, confidence (0–1).
      Return JSON array.\` }],
    response_format: { type: 'json_object' },
  });

  const improvements = JSON.parse(proposals.choices[0].message.content).changes;

  // 4. Auto-apply high-confidence changes
  const applied = [];
  const flagged  = [];

  for (const change of improvements) {
    if (change.confidence > 0.80) {
      await applyChange(change);   // modifies feature flags / scoring weights
      applied.push(change);
    } else {
      flagged.push(change);        // sent to weekly founder digest
    }
  }

  // 5. Send weekly digest to founder
  await sendDigest({ applied, flagged });

  return { analysed: behaviorData.length, changes: improvements.length,
           applied: applied.length, flagged: flagged.length };
}

// Your entire product meeting is now:
// "5 changes auto-applied. 2 need your input."
// That's it.

module.exports = { run };`;

function loadState()  { try { return JSON.parse(localStorage.getItem('be_v6')) ?? { cycles: 0, log: [] }; } catch { return { cycles: 0, log: [] }; } }
function saveState(s) { try { localStorage.setItem('be_v6', JSON.stringify(s)); } catch {} }

export default function AutonomousV6() {
  const [view,    setView]    = useState('agents');
  const [active,  setActive]  = useState(null);
  const [loop,    setLoop]    = useState(-1);
  const [running, setRunning] = useState(false);
  const [state,   setState_]  = useState(loadState);
  const [code,    setCode]    = useState('orchestrator');
  const timer = useRef(null);

  const setState = s => { setState_(s); saveState(s); };

  const runCycle = () => {
    if (running) return;
    setRunning(true); setLoop(0);
    let li = 0;
    timer.current = setInterval(() => {
      li++;
      if (li < LOOP.length) { setLoop(li); }
      else {
        clearInterval(timer.current);
        let ai = 0;
        const cycle = setInterval(() => {
          setActive(AGENTS[ai].id);
          ai++;
          if (ai >= AGENTS.length) {
            clearInterval(cycle);
            const next = {
              cycles: state.cycles + 1,
              log: [{
                n: state.cycles + 1,
                ts: new Date().toLocaleTimeString(),
                summary: `All 5 agents ran. 23 drop patterns caught. 7 referrals generated. $540 MRR added. 5 product changes applied.`,
              }, ...state.log.slice(0, 9)],
            };
            setState(next);
            setRunning(false); setLoop(LOOP.length - 1); setActive(null);
          }
        }, 400);
      }
    }, 380);
  };

  useEffect(() => () => clearInterval(timer.current), []);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={13} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">Autonomous SaaS v6</p>
            </div>
            <h1 className="text-3xl font-black mb-1">AI Runs Everything</h1>
            <p className="text-white/35 text-sm">
              Product. Onboarding. Coaching. Pricing. Growth.
              <span className="text-emerald-400 font-semibold"> You set direction — nothing else.</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-center p-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-xl font-black text-emerald-400">{state.cycles}</p>
              <p className="text-white/20 text-[9px]">cycles</p>
            </div>
            <button onClick={runCycle} disabled={running}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-lg ${
                running ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shadow-none' : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-emerald-500/20'
              }`}>
              {running ? <><RefreshCw size={13} className="animate-spin" />Running…</> : <><Play size={13} />Run Cycle</>}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['agents','Agent Stack'],['loop','Self-Op Loop'],['code','Orchestrator Code'],['evolution','v1 → v6']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-emerald-500 text-black font-bold' : 'text-white/35 hover:text-white/60'}`}>{l}</button>
          ))}
        </div>

        {/* ── AGENTS ── */}
        {view === 'agents' && (
          <div className="space-y-5">
            <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {AGENTS.map((a, i) => {
                const AIcon = a.Icon;
                const isRun = active === a.id;
                const isCyc = running && loop === i;
                return (
                  <div key={a.id} className="p-4 rounded-2xl border transition-all duration-300"
                    style={{ borderColor: isRun ? a.border.replace('0.15','0.45') : a.border, background: isRun ? a.bg.replace('0.06','0.12') : a.bg, transform: isRun ? 'scale(1.015)' : 'scale(1)' }}>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: a.bg, border: `1px solid ${a.border}` }}>
                        <AIcon size={13} style={{ color: a.color }} />
                      </div>
                      <div className="flex-1">
                        <p className="text-xs font-bold" style={{ color: a.color }}>{a.name}</p>
                        <p className="text-white/20 text-[8px]">{a.schedule}</p>
                      </div>
                      {isRun && <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: a.color }} />}
                    </div>
                    <div className="space-y-1 mb-3">
                      {a.tasks.slice(0, 3).map(t => (
                        <div key={t} className="flex items-start gap-1.5">
                          <CheckCircle2 size={8} style={{ color: a.color, opacity: 0.5 }} className="shrink-0 mt-0.5" />
                          <span className="text-white/25 text-[8px] leading-snug">{t}</span>
                        </div>
                      ))}
                    </div>
                    <div className="p-2 rounded-lg bg-black/25 border border-white/5">
                      <p className="text-[7px] uppercase tracking-widest mb-0.5" style={{ color: a.color, opacity: 0.6 }}>Last cycle</p>
                      <p className="text-white/40 text-[8px] leading-snug">{a.runs(a.ctx)}</p>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-white/15 text-[7px]">KPI: {a.kpi}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {state.log.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-white/20 text-[8px] uppercase tracking-widest">Cycle Log</p>
                {state.log.map((e, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border ${i===0 ? 'border-emerald-500/18 bg-emerald-500/4' : 'border-white/5 bg-white/1'}`}>
                    <span className="text-white/15 text-[8px] font-mono shrink-0">#{e.n}</span>
                    <p className="text-white/35 text-xs flex-1 leading-snug">{e.summary}</p>
                    <span className="text-white/15 text-[7px] font-mono shrink-0">{e.ts}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── LOOP ── */}
        {view === 'loop' && (
          <div className="space-y-5">
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-5">Self-Operating Loop</p>
              <div className="flex items-center gap-2 flex-wrap">
                {LOOP.map((s, i) => {
                  const SI = s.Icon;
                  const isAct  = running && loop === i;
                  const isDone = loop > i && loop >= 0;
                  return (
                    <div key={s.id} className="flex items-center gap-2">
                      <div className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border transition-all duration-300"
                        style={{ borderColor: isAct ? s.color : isDone ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.06)',
                                 background:   isAct ? s.color+'10' : isDone ? 'rgba(16,185,129,0.05)' : 'rgba(255,255,255,0.02)',
                                 transform:    isAct ? 'scale(1.06)' : 'scale(1)' }}>
                        <SI size={10} style={{ color: isAct ? s.color : isDone ? '#34d399' : 'rgba(255,255,255,0.18)' }} />
                        <span className="text-[9px] font-semibold" style={{ color: isAct ? s.color : isDone ? '#34d399' : 'rgba(255,255,255,0.25)' }}>{s.label}</span>
                        {isAct && <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: s.color }} />}
                      </div>
                      {i < LOOP.length - 1 && <ArrowRight size={8} className={isDone ? 'text-emerald-400/40' : 'text-white/10'} />}
                    </div>
                  );
                })}
                <ArrowRight size={8} className="text-white/10" />
                <div className="px-3 py-2.5 rounded-xl border border-white/8 flex items-center gap-1">
                  <Repeat size={9} className="text-white/20" />
                  <span className="text-[9px] text-white/20 font-bold">∞</span>
                </div>
              </div>
              {running && loop >= 0 && <p className="text-white/25 text-xs mt-3 italic">{LOOP[loop]?.desc}</p>}
            </div>

            <div className="space-y-2">
              {LOOP.map((s, i) => {
                const SI = s.Icon;
                return (
                  <div key={s.id} className="flex items-start gap-4 p-4 rounded-xl border border-white/6 bg-white/2">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0" style={{ background: s.color+'10', border: `1px solid ${s.color}20` }}>
                      <SI size={12} style={{ color: s.color }} />
                    </div>
                    <div>
                      <p className="text-white/65 text-xs font-bold mb-0.5">{i+1}. {s.label}</p>
                      <p className="text-white/25 text-[10px]">{s.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-sm mb-3">Your Week at v6</p>
              <div className="space-y-2">
                {[
                  { d: 'Monday',   t: 'Read weekly digest (3 min). Approve or reject 2 System Agent proposals.', dim: false },
                  { d: 'Tuesday',  t: 'Nothing. Agents ran outreach, coaching, 3 product changes overnight.',    dim: true  },
                  { d: 'Wednesday',t: 'Review 1 A/B test result from Growth Agent.',                             dim: false },
                  { d: 'Thursday', t: 'Nothing. Revenue Agent ran upsell cycle. System Agent adjusted scoring.', dim: true  },
                  { d: 'Friday',   t: 'Strategy: which market next? What does v7 look like?',                    dim: false },
                  { d: 'Weekend',  t: 'Nothing. The company is running, improving, and growing without you.',   dim: true  },
                ].map(({ d, t, dim }) => (
                  <div key={d} className="flex gap-4 p-3 rounded-xl border border-white/6 bg-white/2">
                    <span className="text-white/30 text-xs font-bold w-20 shrink-0">{d}</span>
                    <p className={`text-xs leading-snug ${dim ? 'text-white/20' : 'text-white/55'}`}>{t}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── CODE ── */}
        {view === 'code' && (
          <div className="space-y-4">
            <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6">
              {[['orchestrator','orchestrator.js'],['system','system agent']].map(([v,l]) => (
                <button key={v} onClick={() => setCode(v)} className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${code===v ? 'bg-white/10 text-white' : 'text-white/35 hover:text-white/55'}`}>{l}</button>
              ))}
            </div>
            <div className="rounded-2xl border border-white/8 bg-black/30 overflow-hidden">
              <pre className="p-4 text-[9.5px] text-white/55 font-mono leading-relaxed overflow-auto max-h-[500px]">
                {code === 'orchestrator' ? ORCHESTRATOR : SYSTEM_AGENT}
              </pre>
            </div>
          </div>
        )}

        {/* ── EVOLUTION ── */}
        {view === 'evolution' && (
          <div className="space-y-3">
            {EVOLUTION.map((e, i) => (
              <div key={e.v} className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${e.active ? 'border-pink-500/25 bg-pink-500/5' : 'border-white/5 bg-white/2 opacity-40'}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: e.color+'12', border: `1px solid ${e.color}20` }}>
                  <span className="text-[10px] font-black" style={{ color: e.color }}>{e.v}</span>
                </div>
                <p className={`flex-1 text-sm ${e.active ? 'text-white font-bold' : 'text-white/35'}`}>{e.label}</p>
                {e.active ? (
                  <span className="text-[8px] font-black px-2 py-1 rounded border border-pink-500/25 bg-pink-500/10 text-pink-400">YOU ARE HERE</span>
                ) : (
                  <CheckCircle2 size={12} style={{ color: e.color, opacity: 0.45 }} />
                )}
              </div>
            ))}

            <div className="p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5 mt-4">
              <p className="text-emerald-400 font-bold text-sm mb-2">The v6 Difference: The System Agent</p>
              <p className="text-white/45 text-xs leading-relaxed mb-3">
                v5 ran the company. v6 <span className="text-white font-bold">redesigns</span> the company.
                The System Agent reads all performance data, generates hypotheses,
                runs experiments at system level, and auto-applies changes with &gt;80% confidence.
                Every week the product gets smarter. Without a product meeting.
              </p>
              <div className="p-3 rounded-xl border border-white/8 bg-black/20">
                <p className="text-emerald-400 text-[9px] font-bold mb-1">Real example change from System Agent:</p>
                <p className="text-white/35 text-[9px] leading-snug">
                  "Users who complete tasks after 7pm score 18% lower on day 2. Proposal: reduce task count by 1 for users in negative evening completion pattern. Confidence: 0.84. Auto-applying."
                </p>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
