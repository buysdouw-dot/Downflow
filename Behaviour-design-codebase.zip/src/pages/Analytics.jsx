import { useMemo, useState } from 'react';
import {
  BarChart2, TrendingUp, Users, Activity, Target,
  ChevronDown, ArrowUp, ArrowDown, Minus,
} from 'lucide-react';
import { useAuth } from '../store/AuthContext';
import { useBehavior } from '../store/BehaviorContext';
import { getStatus, getStatusConfig } from '../engine/core';
import MobileHeader from '../components/MobileHeader';
import {
  AreaChart, Area, BarChart, Bar, ResponsiveContainer,
  Tooltip, XAxis, YAxis, ReferenceLine, CartesianGrid,
} from 'recharts';

export default function Analytics() {
  const { allUsersInTenant, tenantInfo } = useAuth();
  const { getTodayScore, getWeekScores, activePlugin, plugins } = useBehavior();
  const plug = plugins[activePlugin];
  const [selectedUser, setSelectedUser] = useState('all');

  // Per-user data
  const userData = useMemo(() => {
    return allUsersInTenant.map((u) => {
      const weekData = getWeekScores(u.id);
      const weekScores = weekData.map((d) => d.score);
      const avg = Math.round(weekScores.reduce((a, b) => a + b, 0) / weekScores.length);
      const todayScore = getTodayScore(u.id);
      const status = getStatus(todayScore);
      const greenDays = weekScores.filter(s => s >= (plug?.dailyTarget ?? 40)).length;
      const redDays = weekScores.filter(s => s < 25).length;
      const dropOffRate = Math.round((redDays / 7) * 100);
      const improvement = weekScores.length >= 2
        ? weekScores[weekScores.length - 1] - weekScores[0]
        : 0;
      return { ...u, weekData, weekScores, avg, todayScore, status, greenDays, redDays, dropOffRate, improvement };
    });
  }, [allUsersInTenant, getWeekScores, getTodayScore, plug]);

  // Team aggregate — 7-day average score per day
  const teamTrendData = useMemo(() => {
    if (!userData.length) return [];
    return userData[0].weekData.map((day, i) => ({
      label: day.label,
      date: day.date,
      avg: Math.round(userData.reduce((sum, u) => sum + (u.weekScores[i] ?? 0), 0) / userData.length),
      max: Math.max(...userData.map(u => u.weekScores[i] ?? 0)),
      min: Math.min(...userData.map(u => u.weekScores[i] ?? 0)),
    }));
  }, [userData]);

  // Per-user chart data (when a specific user is selected)
  const selectedUserData = useMemo(() => {
    if (selectedUser === 'all') return teamTrendData;
    const u = userData.find(u => String(u.id) === selectedUser);
    if (!u) return [];
    return u.weekData.map((day, i) => ({
      label: day.label,
      score: u.weekScores[i] ?? 0,
    }));
  }, [selectedUser, userData, teamTrendData]);

  // Aggregate KPIs
  const totalUsers = userData.length;
  const activeToday = userData.filter(u => u.todayScore > 0).length;
  const executionRate = totalUsers > 0 ? Math.round((activeToday / totalUsers) * 100) : 0;
  const avgImprovement = userData.length > 0
    ? Math.round(userData.reduce((s, u) => s + u.improvement, 0) / userData.length)
    : 0;
  const avgDropOff = userData.length > 0
    ? Math.round(userData.reduce((s, u) => s + u.dropOffRate, 0) / userData.length)
    : 0;
  const topPerformer = [...userData].sort((a, b) => b.todayScore - a.todayScore)[0];
  const avgTeamScore = totalUsers > 0
    ? Math.round(userData.reduce((s, u) => s + u.todayScore, 0) / totalUsers)
    : 0;

  // Status breakdown
  const statusDist = {
    GREEN: userData.filter(u => u.status === 'GREEN').length,
    YELLOW: userData.filter(u => u.status === 'YELLOW').length,
    RED: userData.filter(u => u.status === 'RED').length,
  };

  // Per-user bar data for comparison
  const userCompareData = userData.map(u => ({
    name: u.name.split(' ')[0],
    score: u.todayScore,
    avg: u.avg,
    fill: getStatusConfig(u.status).hex ?? '#6366f1',
  }));

  return (
    <div className="max-w-5xl mx-auto">
      <MobileHeader title="Analytics" />

      {/* Desktop header */}
      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BarChart2 size={16} className="text-indigo-400" />
            <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">Analytics Layer</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Execution Intelligence</h1>
          <p className="text-white/35 text-sm mt-0.5">{tenantInfo?.icon} {tenantInfo?.name} · {totalUsers} team members</p>
        </div>
        {/* User selector */}
        <div className="flex items-center gap-2 glass px-3 py-2 rounded-xl border border-white/8">
          <Users size={12} className="text-white/35" />
          <select
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            className="bg-transparent text-white/70 text-xs outline-none cursor-pointer pr-1"
          >
            <option value="all" className="bg-[#0b0f1a]">All members</option>
            {userData.map(u => (
              <option key={u.id} value={String(u.id)} className="bg-[#0b0f1a]">{u.name}</option>
            ))}
          </select>
          <ChevronDown size={11} className="text-white/35" />
        </div>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-5">
        {/* Core KPI metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            {
              label: 'Daily Active Execution Rate',
              value: `${executionRate}%`,
              sub: `${activeToday} of ${totalUsers} users active`,
              color: 'text-indigo-400',
              icon: Activity,
              trend: executionRate >= 70 ? 'up' : executionRate >= 50 ? 'flat' : 'down',
            },
            {
              label: 'Score Improvement',
              value: avgImprovement >= 0 ? `+${avgImprovement}` : `${avgImprovement}`,
              sub: 'vs 7 days ago (team avg)',
              color: avgImprovement >= 0 ? 'text-green-400' : 'text-red-400',
              icon: TrendingUp,
              trend: avgImprovement >= 0 ? 'up' : 'down',
            },
            {
              label: 'Drop-off Rate',
              value: `${avgDropOff}%`,
              sub: 'RED days / 7 day window',
              color: avgDropOff > 30 ? 'text-red-400' : 'text-yellow-400',
              icon: Target,
              trend: avgDropOff > 30 ? 'down' : 'flat',
            },
          ].map(({ label, value, sub, color, icon: Icon, trend }) => (
            <div key={label} className="glass rounded-xl p-4 border border-white/8">
              <div className="flex items-center justify-between mb-3">
                <Icon size={14} className={color} />
                <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-full ${
                  trend === 'up' ? 'text-green-400 bg-green-500/10' :
                  trend === 'down' ? 'text-red-400 bg-red-500/10' :
                  'text-white/30 bg-white/6'
                }`}>
                  {trend === 'up' ? '↑ UP' : trend === 'down' ? '↓ DOWN' : '→ FLAT'}
                </span>
              </div>
              <p className={`text-2xl font-bold ${color}`}>{value}</p>
              <p className="text-white/50 text-[10px] font-medium mt-0.5">{label}</p>
              <p className="text-white/25 text-[10px] mt-0.5">{sub}</p>
            </div>
          ))}
        </div>

        {/* Main trend chart */}
        <div className="glass rounded-xl p-5 border border-white/8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-white font-semibold text-sm">
                {selectedUser === 'all' ? 'Team Score Trend' : `${userData.find(u => String(u.id) === selectedUser)?.name?.split(' ')[0]} — 7-Day Trend`}
              </p>
              <p className="text-white/30 text-xs mt-0.5">
                {selectedUser === 'all' ? 'Average + range across all members' : 'Personal execution score by day'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1 text-[10px] text-indigo-400"><span className="w-3 h-0.5 bg-indigo-500 inline-block rounded" /> {selectedUser === 'all' ? 'Avg' : 'Score'}</span>
              {selectedUser === 'all' && (
                <span className="flex items-center gap-1 text-[10px] text-indigo-300/40"><span className="w-3 h-0.5 bg-indigo-400/20 inline-block rounded" /> Range</span>
              )}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={selectedUserData} margin={{ top: 4, right: 0, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="analyticsGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                {selectedUser === 'all' && (
                  <linearGradient id="rangeGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity={0.08} />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                )}
              </defs>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.2)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.2)' }} axisLine={false} tickLine={false} />
              <ReferenceLine y={plug?.dailyTarget ?? 40} stroke="rgba(99,102,241,0.3)" strokeDasharray="3 3" />
              <Tooltip
                contentStyle={{ background: '#0f1421', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                labelStyle={{ color: 'rgba(255,255,255,0.5)' }}
                itemStyle={{ color: '#a5b4fc' }}
              />
              {selectedUser === 'all' ? (
                <>
                  <Area type="monotone" dataKey="max" stroke="none" fill="url(#rangeGrad)" />
                  <Area type="monotone" dataKey="avg" stroke="#6366f1" strokeWidth={2} fill="url(#analyticsGrad)" dot={{ r: 3, fill: '#6366f1', strokeWidth: 0 }} />
                </>
              ) : (
                <Area type="monotone" dataKey="score" stroke="#6366f1" strokeWidth={2} fill="url(#analyticsGrad)" dot={{ r: 3, fill: '#6366f1', strokeWidth: 0 }} />
              )}
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* User comparison bar chart */}
        <div className="glass rounded-xl p-5 border border-white/8">
          <div className="mb-4">
            <p className="text-white font-semibold text-sm">User Performance Comparison</p>
            <p className="text-white/30 text-xs mt-0.5">Today's score vs 7-day average per member</p>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart data={userCompareData} margin={{ top: 0, right: 0, bottom: 0, left: -20 }} barGap={2}>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.3)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.2)' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: '#0f1421', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                labelStyle={{ color: 'rgba(255,255,255,0.5)' }}
              />
              <ReferenceLine y={plug?.dailyTarget ?? 40} stroke="rgba(99,102,241,0.25)" strokeDasharray="3 3" />
              <Bar dataKey="score" name="Today" fill="#6366f1" radius={[3, 3, 0, 0]} maxBarSize={28} />
              <Bar dataKey="avg" name="7d Avg" fill="rgba(99,102,241,0.25)" radius={[3, 3, 0, 0]} maxBarSize={28} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Status distribution + per-user detail table */}
        <div className="grid lg:grid-cols-3 gap-4">
          {/* Status dist */}
          <div className="glass rounded-xl p-5 border border-white/8">
            <p className="text-white font-semibold text-sm mb-4">Status Distribution</p>
            <div className="space-y-3">
              {[
                { status: 'GREEN', count: statusDist.GREEN, color: 'text-green-400', bg: 'bg-green-500', bar: 'bg-green-500' },
                { status: 'YELLOW', count: statusDist.YELLOW, color: 'text-yellow-400', bg: 'bg-yellow-500', bar: 'bg-yellow-500' },
                { status: 'RED', count: statusDist.RED, color: 'text-red-400', bg: 'bg-red-500', bar: 'bg-red-500' },
              ].map(({ status, count, color, bar }) => (
                <div key={status}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-xs font-semibold ${color}`}>{status}</span>
                    <span className="text-white/50 text-xs">{count} / {totalUsers}</span>
                  </div>
                  <div className="h-1.5 bg-white/6 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${bar} transition-all duration-700`}
                      style={{ width: totalUsers > 0 ? `${(count / totalUsers) * 100}%` : '0%' }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-white/6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-white/35 text-xs">Execution Rate</span>
                <span className="text-indigo-400 text-xs font-bold">{executionRate}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/35 text-xs">Avg Score</span>
                <span className={`text-xs font-bold ${getStatusConfig(getStatus(avgTeamScore)).color}`}>{avgTeamScore} pts</span>
              </div>
              {topPerformer && (
                <div className="flex items-center justify-between">
                  <span className="text-white/35 text-xs">Top Performer</span>
                  <span className="text-yellow-400 text-xs font-bold">{topPerformer.name.split(' ')[0]}</span>
                </div>
              )}
            </div>
          </div>

          {/* Per-user breakdown */}
          <div className="lg:col-span-2 glass rounded-xl overflow-hidden border border-white/8">
            <div className="grid grid-cols-[1fr_auto_auto_auto_auto] px-4 py-2.5 border-b border-white/6 text-[10px] text-white/25 uppercase tracking-widest">
              <span>Member</span>
              <span className="pr-4 text-right">Today</span>
              <span className="pr-4 text-right">7d Avg</span>
              <span className="pr-4 text-right">Drop-off</span>
              <span className="text-right">Trend</span>
            </div>
            {userData.map((u, i) => (
              <div
                key={u.id}
                className={`grid grid-cols-[1fr_auto_auto_auto_auto] px-4 py-3 items-center ${i < userData.length - 1 ? 'border-b border-white/4' : ''}`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="min-w-0">
                    <p className="text-white/80 text-sm font-medium truncate">{u.name}</p>
                    <p className="text-white/25 text-[10px]">{u.title}</p>
                  </div>
                </div>
                <span className={`text-sm font-bold pr-4 ${getStatusConfig(u.status).color}`}>{u.todayScore}</span>
                <span className="text-white/50 text-xs pr-4">{u.avg}</span>
                <span className={`text-xs pr-4 ${u.dropOffRate > 40 ? 'text-red-400' : 'text-white/40'}`}>{u.dropOffRate}%</span>
                <span className={u.improvement > 0 ? 'text-green-400' : u.improvement < 0 ? 'text-red-400' : 'text-white/30'}>
                  {u.improvement > 0 ? <ArrowUp size={13} /> : u.improvement < 0 ? <ArrowDown size={13} /> : <Minus size={13} />}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
