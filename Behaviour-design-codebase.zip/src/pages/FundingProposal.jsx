/**
 * FundingProposal — Investor-Grade Funding Proposal
 * Beautiful, scroll-based design. Designed to convert investors.
 */
import { useState } from 'react';
import {
  DollarSign, TrendingUp, Users, Zap, Brain, Target,
  CheckCircle2, ArrowRight, Star, Shield, Rocket,
  BarChart2, Globe, Activity, Award, Clock, Layers,
  ChevronRight, Mail, Calendar, Building2, PieChart,
  Sparkles, HandshakeIcon, Download, FileText, Printer,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  Tooltip, ResponsiveContainer, CartesianGrid,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
} from 'recharts';

const C = {
  indigo: '#6366f1', cyan: '#22d3ee', violet: '#a78bfa',
  pink: '#f472b6', amber: '#fbbf24', emerald: '#34d399',
  orange: '#fb923c',
};

const MRR_DATA = [
  { m: 'M0', mrr: 0   }, { m: 'M1', mrr: 1   }, { m: 'M2', mrr: 4.2 },
  { m: 'M3', mrr: 10  }, { m: 'M4', mrr: 18.5 }, { m: 'M5', mrr: 30  },
  { m: 'M6', mrr: 41.6}, { m: 'M9', mrr: 75   }, { m: 'M12',mrr: 120 },
  { m: 'M18',mrr: 210 }, { m: 'M24',mrr: 380  }, { m: 'M30',mrr: 650 },
];

const RADAR_DATA = [
  { subject: 'Product',      BE: 95, Industry: 60 },
  { subject: 'AI Depth',     BE: 98, Industry: 35 },
  { subject: 'Growth',       BE: 88, Industry: 55 },
  { subject: 'Retention',    BE: 85, Industry: 62 },
  { subject: 'Unit Econ.',   BE: 92, Industry: 58 },
  { subject: 'Market Size',  BE: 90, Industry: 70 },
];

const USE_OF_FUNDS = [
  { category: 'Engineering (2 Sr. Engineers, 18 mo.)', pct: 45, amount: 540, color: C.indigo },
  { category: 'Sales & Growth (First GTM hire)',        pct: 28, amount: 336, color: C.pink    },
  { category: 'Infrastructure & AI Scale',              pct: 15, amount: 180, color: C.amber   },
  { category: 'Legal, Ops & Runway Buffer',             pct: 12, amount: 144, color: C.violet  },
];

const MILESTONES_18M = [
  { t: 'M3',  milestone: '$100K MRR',         sub: 'Team plan rollout complete. 500+ users.',  color: C.cyan   },
  { t: 'M6',  milestone: '$200K MRR',         sub: 'Enterprise tier live. Slack integration.', color: C.indigo },
  { t: 'M9',  milestone: '$300K MRR',         sub: 'WhatsApp coaching channel. 3K+ users.',    color: C.violet },
  { t: 'M12', milestone: '$400K MRR',         sub: '2nd vertical expansion. Mobile app.', color: C.amber  },
  { t: 'M18', milestone: '$500K MRR',         sub: 'Series A ready. 10K+ users.',             color: C.emerald},
];

const WHY_NOW = [
  { stat: '78%', text: 'of HR leaders plan to increase AI investment in 2025', color: C.cyan },
  { stat: '$1.2T', text: 'lost to low performance in US enterprises annually', color: C.pink },
  { stat: '0', text: 'companies with our exact product — AI coaching + autonomous ops', color: C.emerald },
  { stat: '23%', text: 'MoM growth with zero paid marketing. The loop already works.', color: C.amber },
];

const TRACTION = [
  { metric: '$41.6K', label: 'MRR',       sub: 'Month 8',         color: C.emerald },
  { metric: '312',    label: 'Active Users', sub: '3 verticals',  color: C.indigo  },
  { metric: '88%',    label: 'Retention',  sub: 'vs 78% avg',     color: C.cyan    },
  { metric: '$0',     label: 'CAC',        sub: '100% organic',   color: C.amber   },
  { metric: '0.74',   label: 'Viral K',   sub: 'growing',         color: C.pink    },
  { metric: '67',     label: 'NPS',        sub: 'World class',    color: C.violet  },
];

const COMPARABLES = [
  { company: 'BetterUp',  raised: '$300M', multiple: '20×', stage: 'Series D' },
  { company: 'Lattice',   raised: '$175M', multiple: '18×', stage: 'Series E' },
  { company: 'Leapsome', raised: '$60M',  multiple: '15×', stage: 'Series B' },
  { company: 'Behavior Engine', raised: '$1.2M (Seed)', multiple: '6× entry', stage: 'Seed ← You', highlight: true },
];

const COMPETITIVE_MOAT = [
  { moat: 'Proprietary Behavioral Data', desc: 'Every user-day generates unique training signal. Model improves continuously. Impossible to copy without time.', icon: Brain, color: C.violet },
  { moat: 'Network Effect', desc: 'Team leaderboards create social stickiness. Teams that leave lose their competitive context.', icon: Users, color: C.cyan },
  { moat: '6-Agent Autonomous OS', desc: 'v7 strategy layer: no competitor has autonomous cross-agent business intelligence. 18-month engineering lead.', icon: Zap, color: C.amber },
  { moat: 'Viral Loop Flywheel', desc: 'Users share score cards → referral → new users → more data → better AI → better retention. Self-reinforcing.', icon: TrendingUp, color: C.pink },
];

const TEAM_SIGNALS = [
  'Alex Chen (CEO): Led 0→$10M ARR at prior startup. Stripe product background.',
  'Jordan Park (CTO): Ex-OpenAI. Architected the 6-agent autonomous system solo.',
  'Sam Rivera (Growth): Ex-HubSpot. Responsible for all 312 users — zero ad spend.',
  'Sequoia Partner (Advisor): Provides strategic guidance and warm LP intros.',
];

const TABS = [
  { id: 'overview',    label: '1. Overview'      },
  { id: 'opportunity', label: '2. Opportunity'   },
  { id: 'traction',    label: '3. Traction'      },
  { id: 'ask',         label: '4. The Ask'       },
  { id: 'terms',       label: '5. Deal Terms'    },
  { id: 'team',        label: '6. Team & Moat'   },
  { id: 'close',       label: '7. Next Steps'    },
];

function SectionTitle({ label, title, sub, color = C.indigo }) {
  return (
    <div className="mb-8 text-center">
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border mb-3"
        style={{ color, borderColor: color + '30', background: color + '10' }}>
        {label}
      </span>
      <h2 className="text-3xl lg:text-4xl font-black mb-2">{title}</h2>
      {sub && <p className="text-white/40 text-sm max-w-xl mx-auto">{sub}</p>}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#0c1018] border border-white/10 rounded-xl p-3 text-[10px] shadow-xl">
      <p className="text-white/40 mb-1 font-bold">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }}>{p.name}: <span className="font-bold">{p.value}</span></p>
      ))}
    </div>
  );
};

function DownloadBar({ title, filename }) {
  const handlePrint = () => {
    const original = document.title;
    document.title = filename;
    window.print();
    document.title = original;
  };

  const handleDownloadText = () => {
    const el = document.getElementById('fp-printable');
    if (!el) return;
    const text = el.innerText || el.textContent || '';
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename + '.txt'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="no-print fixed bottom-0 left-0 right-0 z-[999] border-t border-indigo-500/25 bg-[#080c16]/98 backdrop-blur-xl shadow-[0_-8px_32px_rgba(0,0,0,0.6)]">
      <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <FileText size={16} className="text-indigo-400" />
          </div>
          <div>
            <p className="text-white/80 text-sm font-bold">{title}</p>
            <p className="text-white/30 text-[10px]">Confidential · Click Download PDF → Save as PDF in print dialog</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleDownloadText}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-white/15 bg-white/5 text-white/55 hover:text-white/90 hover:bg-white/10 text-xs font-semibold transition-all">
            <Download size={13} />
            Export .TXT
          </button>
          <button onClick={handlePrint}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 active:scale-95 text-white text-sm font-bold transition-all shadow-lg shadow-indigo-500/30">
            <Printer size={15} />
            Download PDF
          </button>
        </div>
      </div>
    </div>
  );
}

export default function FundingProposal() {
  const [tab, setTab] = useState('overview');

  return (
    <div className="min-h-screen bg-[#070b14] text-white pb-20">
      <div id="fp-printable">

      {/* Hero banner */}
      <div className="relative overflow-hidden border-b border-white/8 bg-[#080c16]">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 via-transparent to-purple-500/5" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-32 bg-indigo-500/8 blur-3xl rounded-full" />
        <div className="relative max-w-5xl mx-auto px-6 py-10 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-indigo-500/25 bg-indigo-500/8 text-indigo-300 text-xs font-bold mb-6">
            <Sparkles size={11} />
            CONFIDENTIAL INVESTMENT MEMO · SEED ROUND 2026
          </div>
          <h1 className="text-4xl lg:text-6xl font-black mb-4 leading-tight">
            Behavior Engine
          </h1>
          <p className="text-white/50 text-lg mb-2 max-w-xl mx-auto leading-relaxed">
            The AI-powered Human Performance OS. We replace manual performance management
            with a self-improving, autonomous multi-agent system.
          </p>
          <p className="text-indigo-400 font-bold text-sm mb-8">
            $41.6K MRR · 312 Users · 88% Retention · $0 CAC · Growing 23% MoM
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <div className="px-6 py-3 rounded-2xl border border-indigo-500/25 bg-indigo-500/8 text-center">
              <p className="text-2xl font-black text-indigo-400">$1.2M</p>
              <p className="text-white/25 text-[9px]">Seed Round</p>
            </div>
            <div className="text-white/20 text-sm">at</div>
            <div className="px-6 py-3 rounded-2xl border border-emerald-500/25 bg-emerald-500/8 text-center">
              <p className="text-2xl font-black text-emerald-400">$6M</p>
              <p className="text-white/25 text-[9px]">Pre-Money Val.</p>
            </div>
            <div className="text-white/20 text-sm">for</div>
            <div className="px-6 py-3 rounded-2xl border border-amber-500/25 bg-amber-500/8 text-center">
              <p className="text-2xl font-black text-amber-400">16.7%</p>
              <p className="text-white/25 text-[9px]">Equity</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab navigation */}
      <div className="sticky top-0 z-10 border-b border-white/8 bg-[#070b14]/95 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex gap-0.5 overflow-x-auto scrollbar-hide py-2">
            {TABS.map(({ id, label }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${tab === id ? 'bg-indigo-500 text-white' : 'text-white/30 hover:text-white/60'}`}>
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-10">

        {/* ── OVERVIEW ── */}
        {tab === 'overview' && (
          <div className="space-y-10">
            <SectionTitle label="Company Overview" title="The problem is $1.2 trillion." sub="Every high-performance team in the world manages execution manually. We automate it." color={C.indigo} />

            {/* Problem/Solution */}
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="p-6 rounded-2xl border border-rose-500/20 bg-rose-500/4">
                <p className="text-rose-400 font-bold text-xs uppercase tracking-widest mb-4">The Problem</p>
                <div className="space-y-3">
                  {[
                    'Performance tools track activity. None of them coach execution in real time.',
                    '68% of employees miss weekly targets — with zero behavior feedback.',
                    'Managers spend 5× their productive time on status updates, not strategy.',
                    'The best performance coaching costs $500K+/year. Only Fortune 500 can afford it.',
                  ].map((p, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <div className="w-1 h-1 rounded-full bg-rose-400 shrink-0 mt-1.5" />
                      <p className="text-white/50 text-xs leading-snug">{p}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="p-6 rounded-2xl border border-emerald-500/20 bg-emerald-500/4">
                <p className="text-emerald-400 font-bold text-xs uppercase tracking-widest mb-4">Our Solution</p>
                <div className="space-y-3">
                  {[
                    'Behavior Engine: AI coaching for every user, every day, at $20/month.',
                    '6 autonomous agents run product, growth, sales, and coaching — 24/7.',
                    'Self-improving system: gets smarter every week from behavioral data.',
                    'Multi-tenant SaaS: works for Sales, Fitness, Education — any performance team.',
                  ].map((p, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <CheckCircle2 size={11} className="text-emerald-400 shrink-0 mt-0.5" />
                      <p className="text-white/60 text-xs leading-snug">{p}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Core snapshot */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { v: '$47B', l: 'Total Addressable Market', color: C.indigo },
                { v: '$499K', l: 'Current ARR Run Rate', color: C.emerald },
                { v: '5 yrs', l: 'Path to $25M ARR', color: C.cyan },
                { v: '88%', l: 'Monthly Retention', color: C.amber },
                { v: '11×', l: 'LTV:CAC Ratio (Y2)', color: C.violet },
                { v: '84%', l: 'Gross Margin', color: C.pink },
              ].map(({ v, l, color }) => (
                <div key={l} className="p-4 rounded-2xl border border-white/8 bg-white/2 text-center">
                  <p className="text-2xl font-black mb-0.5" style={{ color }}>{v}</p>
                  <p className="text-white/35 text-[9px]">{l}</p>
                </div>
              ))}
            </div>

            {/* MRR chart */}
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">MRR Trajectory — Historical + 30-Month Projection ($K)</p>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={MRR_DATA} margin={{ top: 5, right: 10, bottom: 0, left: 0 }}>
                    <defs>
                      <linearGradient id="fpGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={C.indigo} stopOpacity={0.3} />
                        <stop offset="100%" stopColor={C.indigo} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="m" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}K`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="mrr" name="MRR ($K)" stroke={C.indigo} strokeWidth={2.5} fill="url(#fpGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center gap-4 mt-4 pt-4 border-t border-white/5">
                <div className="w-3 h-0.5 bg-indigo-400" /><p className="text-white/25 text-[9px]">M0–M6: Historical (actual)</p>
                <div className="w-3 h-0.5 bg-indigo-400 opacity-50 border-dashed" /><p className="text-white/25 text-[9px]">M9–M30: Projection (conservative 23% MoM)</p>
              </div>
            </div>
          </div>
        )}

        {/* ── OPPORTUNITY ── */}
        {tab === 'opportunity' && (
          <div className="space-y-10">
            <SectionTitle label="Market Opportunity" title="A $47B market with no dominant AI player." sub="Performance management is being disrupted by AI. We're first." color={C.cyan} />

            {/* Why now */}
            <div className="grid lg:grid-cols-2 gap-4">
              {WHY_NOW.map(({ stat, text, color }) => (
                <div key={stat} className="flex items-start gap-4 p-5 rounded-2xl border border-white/8 bg-white/2">
                  <p className="text-3xl font-black shrink-0" style={{ color }}>{stat}</p>
                  <p className="text-white/55 text-sm leading-snug">{text}</p>
                </div>
              ))}
            </div>

            {/* Radar — vs industry */}
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Behavior Engine vs. Industry Average</p>
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={RADAR_DATA} cx="50%" cy="50%" outerRadius={70}>
                      <PolarGrid stroke="rgba(255,255,255,0.07)" />
                      <PolarAngleAxis dataKey="subject" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 9 }} />
                      <PolarRadiusAxis tick={false} axisLine={false} />
                      <Radar name="Behavior Engine" dataKey="BE"       stroke={C.indigo} fill={C.indigo} fillOpacity={0.2} />
                      <Radar name="Industry Avg"    dataKey="Industry" stroke="rgba(148,163,184,0.4)" fill="rgba(148,163,184,0.05)" fillOpacity={0.05} />
                      <Tooltip contentStyle={{ background: '#0c1018', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 9 }} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-white/25 text-[9px] uppercase tracking-widest">Comparable Companies</p>
                <div className="space-y-2">
                  {COMPARABLES.map(({ company, raised, multiple, stage, highlight }) => (
                    <div key={company} className={`flex items-center justify-between p-3.5 rounded-xl border transition-all ${highlight ? 'border-indigo-500/30 bg-indigo-500/8' : 'border-white/6 bg-white/2'}`}>
                      <div>
                        <p className={`text-xs font-bold ${highlight ? 'text-indigo-300' : 'text-white/50'}`}>{company}</p>
                        <p className="text-white/20 text-[8px]">{stage}</p>
                      </div>
                      <div className="text-right">
                        <p className={`text-xs font-bold ${highlight ? 'text-emerald-400' : 'text-white/40'}`}>{raised}</p>
                        <p className={`text-[9px] ${highlight ? 'text-amber-400 font-bold' : 'text-white/20'}`}>{multiple}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3.5 rounded-xl border border-amber-500/20 bg-amber-500/5">
                  <p className="text-amber-400 font-bold text-xs mb-1">Investor Take</p>
                  <p className="text-white/40 text-[9px] leading-relaxed">
                    BetterUp raised $300M for human coaching. We deliver AI coaching at 100× lower cost with autonomous ops.
                    Entry at 6× revenue vs. 15–20× for comparable companies at Series B.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── TRACTION ── */}
        {tab === 'traction' && (
          <div className="space-y-10">
            <SectionTitle label="Traction & Proof" title="$41.6K MRR. Zero paid ads. 8 months." sub="Every number below was achieved with 3 people and no marketing budget." color={C.emerald} />

            {/* Core traction metrics */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
              {TRACTION.map(({ metric, label, sub, color }) => (
                <div key={label} className="p-5 rounded-2xl border border-white/8 bg-white/2 text-center">
                  <p className="text-3xl font-black mb-1" style={{ color }}>{metric}</p>
                  <p className="text-white/60 text-xs font-bold">{label}</p>
                  <p className="text-white/25 text-[8px] mt-0.5">{sub}</p>
                </div>
              ))}
            </div>

            {/* MRR growth bar */}
            <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">MRR Growth by Month ($K) — 8 months, zero paid ads</p>
              <div className="h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={MRR_DATA.slice(0, 7)} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="m" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}K`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="mrr" name="MRR ($K)" radius={[4, 4, 0, 0]}>
                      {MRR_DATA.slice(0, 7).map((_, i) => (
                        <rect key={i} fill={`rgba(99,102,241,${0.3 + i * 0.12})`} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Social proof */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">What Users Say</p>
              <div className="grid lg:grid-cols-3 gap-3">
                {[
                  { quote: 'Our sales team improved weekly execution by 31% in 6 weeks. The AI coaching is actually better than our manager check-ins.', name: 'James T.', role: 'VP Sales, NovaSales Inc.' },
                  { quote: 'I never thought a $20/mo app would replace $400/hr executive coaching for my team. The behavior tracking is addictive.', name: 'Maria C.', role: 'Studio Owner, PeakFit' },
                  { quote: 'The leaderboard created competition our teachers had never seen before. Students are studying more just to rank higher.', name: 'David L.', role: 'Director, Apex Academy' },
                ].map(({ quote, name, role }) => (
                  <div key={name} className="p-4 rounded-2xl border border-white/8 bg-white/2 flex flex-col">
                    <div className="flex gap-0.5 mb-3">
                      {[...Array(5)].map((_, i) => <Star key={i} size={10} className="text-yellow-400 fill-yellow-400" />)}
                    </div>
                    <p className="text-white/50 text-[10px] leading-relaxed flex-1 italic">"{quote}"</p>
                    <div className="mt-3 pt-3 border-t border-white/5">
                      <p className="text-white/65 text-[10px] font-bold">{name}</p>
                      <p className="text-white/25 text-[8px]">{role}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Product-market fit signals */}
            <div className="p-5 rounded-2xl border border-indigo-500/20 bg-indigo-500/5">
              <p className="text-indigo-400 font-bold text-sm mb-4">Product-Market Fit Signals</p>
              <div className="grid lg:grid-cols-2 gap-3">
                {[
                  { signal: 'NPS of 67', detail: 'World-class. Industry avg is 31 for B2B SaaS.' },
                  { signal: '88% 30-day retention', detail: 'Top decile. Benchmark is 75–80% for SaaS.' },
                  { signal: 'Viral K = 0.74', detail: 'Every user brings in 0.74 new users organically.' },
                  { signal: '74% email open rate', detail: 'Industry avg is 21%. People want the coaching.' },
                  { signal: '$0 CAC for 312 users', detail: 'Organic only. This is rare. It scales with content.' },
                  { signal: '108% NRR', detail: 'Expansion revenue >100% means growth without new users.' },
                ].map(({ signal, detail }) => (
                  <div key={signal} className="flex items-start gap-2">
                    <CheckCircle2 size={11} className="text-indigo-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-white/70 text-[10px] font-bold">{signal}</p>
                      <p className="text-white/30 text-[9px]">{detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── THE ASK ── */}
        {tab === 'ask' && (
          <div className="space-y-10">
            <SectionTitle label="The Ask" title="$1.2M Seed to $500K ARR in 18 months." sub="Specific capital. Clear milestones. Measurable ROI." color={C.amber} />

            {/* Round details */}
            <div className="grid lg:grid-cols-3 gap-4">
              <div className="p-6 rounded-2xl border border-indigo-500/30 bg-indigo-500/8 text-center">
                <p className="text-white/30 text-[9px] uppercase tracking-widest mb-1">Raise</p>
                <p className="text-4xl font-black text-indigo-400 mb-1">$1.2M</p>
                <p className="text-white/30 text-[10px]">Seed Round · SAFE</p>
              </div>
              <div className="p-6 rounded-2xl border border-emerald-500/30 bg-emerald-500/8 text-center">
                <p className="text-white/30 text-[9px] uppercase tracking-widest mb-1">Pre-Money</p>
                <p className="text-4xl font-black text-emerald-400 mb-1">$6M</p>
                <p className="text-white/30 text-[10px]">12× ARR multiple</p>
              </div>
              <div className="p-6 rounded-2xl border border-amber-500/30 bg-amber-500/8 text-center">
                <p className="text-white/30 text-[9px] uppercase tracking-widest mb-1">Dilution</p>
                <p className="text-4xl font-black text-amber-400 mb-1">16.7%</p>
                <p className="text-white/30 text-[10px]">Pro-rata rights included</p>
              </div>
            </div>

            {/* Use of funds */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Use of Funds — $1.2M Breakdown</p>
              <div className="space-y-3">
                {USE_OF_FUNDS.map(({ category, pct, amount, color }) => (
                  <div key={category}>
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-white/60 text-xs">{category}</p>
                      <div className="flex items-center gap-3">
                        <p className="font-black text-sm" style={{ color }}>{pct}%</p>
                        <p className="text-white/30 text-xs">${amount}K</p>
                      </div>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 18-month milestones */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">What This Capital Achieves — 18-Month Milestones</p>
              <div className="relative">
                <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-white/5" />
                <div className="space-y-3">
                  {MILESTONES_18M.map(({ t, milestone, sub, color }) => (
                    <div key={t} className="flex items-start gap-4 pl-4">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-[8px] font-black z-10 border"
                        style={{ background: color + '15', borderColor: color + '40', color }}>{t}</div>
                      <div className="flex-1 p-3 rounded-xl border border-white/6 bg-white/2">
                        <p className="font-black text-sm" style={{ color }}>{milestone}</p>
                        <p className="text-white/35 text-[9px] mt-0.5">{sub}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Post-money path */}
            <div className="p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-sm mb-2">Series A Path</p>
              <p className="text-white/45 text-[10px] leading-relaxed mb-3">
                At $500K MRR (M18), we will raise a $6–8M Series A at a projected $30–40M valuation.
                Seed investors at $6M entry → Series A exit at $30M = <span className="text-emerald-400 font-bold">5× return in 18 months</span> at the pre-Series A round.
                Exit potential (5Y): acquisition by Salesforce, Workday, or strategic at $150–250M (20–30× ARR).
              </p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: 'Seed entry', val: '$6M', color: C.indigo },
                  { label: 'Series A (M18)', val: '$30–40M', color: C.cyan },
                  { label: 'Exit (Y5)', val: '$150–250M', color: C.emerald },
                ].map(({ label, val, color }) => (
                  <div key={label} className="text-center p-2.5 rounded-xl border border-white/6 bg-black/20">
                    <p className="font-black text-sm" style={{ color }}>{val}</p>
                    <p className="text-white/25 text-[8px]">{label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── DEAL TERMS ── */}
        {tab === 'terms' && (
          <div className="space-y-8">
            <SectionTitle label="Deal Terms" title="Clean, founder-friendly structure." sub="Designed to move fast and be fair to all parties." color={C.violet} />

            <div className="grid lg:grid-cols-2 gap-4">
              {[
                { term: 'Instrument', detail: 'SAFE (Simple Agreement for Future Equity)' },
                { term: 'Round Size', detail: '$1.2M total' },
                { term: 'Pre-Money Valuation', detail: '$6,000,000 (12× ARR run rate)' },
                { term: 'Investor Equity', detail: '16.7% post-money at full raise' },
                { term: 'Minimum Check', detail: '$25,000' },
                { term: 'Lead Investor', detail: 'Seeking $500K lead (with board observer)' },
                { term: 'Discount Rate', detail: '20% discount on Series A (for SAFE holders)' },
                { term: 'Valuation Cap', detail: '$6M cap (locks in price even if Series A >$30M)' },
                { term: 'Pro-Rata Rights', detail: 'Pro-rata participation rights in future rounds' },
                { term: 'MFN Clause', detail: 'Most-Favored Nation across all SAFE holders' },
                { term: 'Use of Proceeds', detail: 'Engineering (45%), Sales (28%), Infra (15%), Ops (12%)' },
                { term: 'Closing Date', detail: 'Rolling close — first close targeted May 2026' },
              ].map(({ term, detail }) => (
                <div key={term} className="flex items-start gap-4 p-3.5 rounded-xl border border-white/8 bg-white/2">
                  <p className="text-white/30 text-[10px] w-32 shrink-0 font-semibold">{term}</p>
                  <p className="text-white/65 text-[10px] font-bold">{detail}</p>
                </div>
              ))}
            </div>

            {/* Return scenarios */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Return Scenarios for $100K Investment</p>
              <div className="overflow-x-auto rounded-2xl border border-white/8 bg-[#0c1018]">
                <table className="w-full text-[10px]">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left p-4 text-white/30">Scenario</th>
                      <th className="p-4 text-white/30 text-right">Exit Val.</th>
                      <th className="p-4 text-white/30 text-right">ARR Multiple</th>
                      <th className="p-4 text-white/30 text-right">Return on $100K</th>
                      <th className="p-4 text-white/30 text-right">Cash Back</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { scenario: 'Base (conservative)', exit: '$60M', multiple: '10×', ret: '16.7×', cash: '$1.67M', color: C.cyan },
                      { scenario: 'Mid (probable)', exit: '$150M', multiple: '15×', ret: '41.7×', cash: '$4.17M', color: C.indigo },
                      { scenario: 'Bull (achievable)', exit: '$300M', multiple: '18×', ret: '83.3×', cash: '$8.33M', color: C.violet },
                      { scenario: 'Grand Slam (IPO)', exit: '$500M+', multiple: '20×+', ret: '138×+', cash: '$13.8M+', color: C.emerald },
                    ].map(({ scenario, exit, multiple, ret, cash, color }) => (
                      <tr key={scenario} className="border-b border-white/4 hover:bg-white/2 transition-all">
                        <td className="p-4 text-white/50 font-semibold">{scenario}</td>
                        <td className="p-4 text-right font-bold" style={{ color }}>{exit}</td>
                        <td className="p-4 text-right text-white/40">{multiple} ARR</td>
                        <td className="p-4 text-right font-black" style={{ color }}>{ret}</td>
                        <td className="p-4 text-right font-bold text-emerald-400">{cash}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-white/15 text-[8px] mt-2 text-center">*Projections are illustrative. Past performance not indicative of future results. All investments carry risk.</p>
            </div>
          </div>
        )}

        {/* ── TEAM & MOAT ── */}
        {tab === 'team' && (
          <div className="space-y-10">
            <SectionTitle label="Team & Competitive Moat" title="The right team at the right time." sub="Domain expertise + AI depth + proven growth — in 3 people." color={C.pink} />

            {/* Team */}
            <div className="grid lg:grid-cols-3 gap-4">
              {[
                { name: 'Alex Chen', title: 'CEO & Co-Founder', bio: 'Led 0→$10M ARR at SaaS startup. Ex-Stripe product lead. 6 years building B2B software. MBA, Stanford.', img: '🧠', color: C.indigo },
                { name: 'Jordan Park', title: 'CTO & Co-Founder', bio: 'Ex-OpenAI researcher. Architected the full 6-agent autonomous system. Prior: Google SWE, 3 SaaS products shipped.', img: '⚡', color: C.cyan },
                { name: 'Sam Rivera', title: 'Head of Growth', bio: 'Ex-HubSpot. Grew content-led acquisition to 50K users at prior role. 100% responsible for all 312 users — zero ad spend.', img: '📈', color: C.pink },
              ].map(({ name, title, bio, img, color }) => (
                <div key={name} className="p-5 rounded-2xl border border-white/8 bg-white/2">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/8 flex items-center justify-center text-3xl mb-4">{img}</div>
                  <p className="text-white/80 font-black text-sm mb-0.5">{name}</p>
                  <p className="text-xs font-bold mb-3" style={{ color }}>{title}</p>
                  <p className="text-white/40 text-[9px] leading-relaxed">{bio}</p>
                </div>
              ))}
            </div>

            {/* Team signals */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/30 text-[9px] uppercase tracking-widest mb-3">Why This Team Wins</p>
              <div className="space-y-2">
                {TEAM_SIGNALS.map(s => (
                  <div key={s} className="flex items-start gap-2">
                    <Star size={10} className="text-yellow-400 shrink-0 mt-0.5" />
                    <p className="text-white/50 text-[10px] leading-snug">{s}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Moat */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Competitive Moat — 4 Layers</p>
              <div className="grid lg:grid-cols-2 gap-3">
                {COMPETITIVE_MOAT.map(({ moat, desc, icon: Icon, color }) => (
                  <div key={moat} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0" style={{ background: color + '12', border: `1px solid ${color}20` }}>
                        <Icon size={13} style={{ color }} />
                      </div>
                      <p className="text-white/70 text-xs font-bold">{moat}</p>
                    </div>
                    <p className="text-white/35 text-[9px] leading-snug">{desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── NEXT STEPS ── */}
        {tab === 'close' && (
          <div className="space-y-10">
            <SectionTitle label="Next Steps" title="Let's move fast." sub="We're targeting a first close in 30 days. Here's what happens next." color={C.emerald} />

            {/* Process */}
            <div className="max-w-lg mx-auto space-y-3">
              {[
                { step: '1', title: 'Schedule a 45-minute call', desc: 'Live product demo + Q&A with founders. See the AI agents run in real time.', color: C.indigo },
                { step: '2', title: 'Data Room Access', desc: 'Full financials, cap table, legal docs, user cohort analysis, and investor deck.', color: C.cyan },
                { step: '3', title: 'Term Sheet / SAFE Sent', desc: '48-hour turnaround. We move at startup speed. No 2-month partner track.', color: C.violet },
                { step: '4', title: 'Wire & Close', desc: 'Rolling close. First tranche deployed to engineering within 2 weeks of close.', color: C.emerald },
              ].map(({ step, title, desc, color }) => (
                <div key={step} className="flex items-start gap-4 p-4 rounded-2xl border border-white/8 bg-white/2">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-black text-sm"
                    style={{ background: color + '12', border: `1px solid ${color}25`, color }}>{step}</div>
                  <div>
                    <p className="text-white/70 font-bold text-sm mb-0.5">{title}</p>
                    <p className="text-white/35 text-[10px] leading-snug">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Contact */}
            <div className="p-8 rounded-2xl border border-indigo-500/25 bg-indigo-500/5 text-center max-w-lg mx-auto">
              <div className="w-16 h-16 rounded-2xl bg-indigo-500/15 border border-indigo-500/25 flex items-center justify-center mx-auto mb-4 text-2xl">🧠</div>
              <p className="text-white/80 font-black text-xl mb-1">Alex Chen</p>
              <p className="text-indigo-400 text-sm font-bold mb-4">CEO & Co-Founder, Behavior Engine</p>
              <div className="flex items-center justify-center gap-4 text-sm">
                <div className="flex items-center gap-1.5 text-white/40">
                  <Mail size={12} />
                  <span>alex@behaviorengine.ai</span>
                </div>
                <div className="flex items-center gap-1.5 text-white/40">
                  <Calendar size={12} />
                  <span>calendly.com/alexchen-be</span>
                </div>
              </div>
            </div>

            {/* Final statement */}
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018] text-center max-w-2xl mx-auto">
              <p className="text-white/60 text-sm leading-relaxed mb-4">
                "We built in 8 months what took our competitors $10M to build.
                We did it with 3 people, no marketing spend, and an AI system that gets smarter every week.
                The market is ready. The product is live. The numbers prove it.
                We're raising to accelerate — not to survive."
              </p>
              <p className="text-indigo-400 font-bold text-sm">— Alex Chen, CEO</p>
              <div className="flex items-center justify-center gap-4 mt-4 pt-4 border-t border-white/5 flex-wrap">
                {['$41.6K MRR', '312 Users', '88% Retention', '$0 CAC', '23% MoM Growth'].map(t => (
                  <span key={t} className="text-[9px] font-bold px-2.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300">{t}</span>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
      </div>{/* /fp-printable */}

      <DownloadBar
        title="Behavior Engine — Confidential Funding Proposal · Seed 2026"
        filename="BehaviorEngine_FundingProposal_Seed2026"
      />
    </div>
  );
}
