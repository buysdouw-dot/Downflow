/**
 * AgentCodebase — Full Autonomous Agent Architecture
 * Real code. Real workflows. AI runs the company.
 * 4 agents + orchestrator + cron schedule + delivery stack
 */
import { useState, useEffect, useRef } from 'react';
import {
  Cpu, Play, RefreshCw, Copy, Check,
  ChevronRight, Eye, Brain, TrendingUp, DollarSign,
  Layers, GitBranch, Clock, Zap, Terminal,
  ArrowRight, FileCode2, Settings, Repeat,
} from 'lucide-react';

// ── Agent definitions with full implementation code ──────────────────────────
const AGENTS = [
  {
    id: 'behavior',
    name: 'Behavior Agent',
    schedule: 'Every 1 hour',
    color: '#22d3ee',
    bg: 'rgba(6,182,212,0.06)',
    border: 'rgba(6,182,212,0.16)',
    Icon: Eye,
    file: 'ai/agents/behavior.js',
    description: 'Scans all users. Calculates execution scores. Detects drop patterns. Dispatches signals.',
    code: `// ai/agents/behavior.js
require('dotenv').config({ path: '../../.env' });
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function run() {
  const today = new Date().toISOString().slice(0, 10);

  // Load all users + last 7 scores each
  const users = await prisma.user.findMany({
    include: {
      scores: { orderBy: { date: 'desc' }, take: 7 },
      tasks:  { where: { createdAt: { gte: new Date(today) } } },
    },
  });

  const signals = users.map(user => {
    const vals  = user.scores.map(s => s.score);
    const avg   = vals.length
      ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;

    // Detect 3-day consecutive drop
    const dropping = vals.length >= 3
      && vals[0] < vals[1] && vals[1] < vals[2];

    return {
      userId:     user.id,
      name:       user.name,
      todayScore: vals[0] ?? 0,
      avg:        Math.round(avg),
      trend:      vals,
      dropping,
      status:     vals[0] >= 30 ? 'high'
                : vals[0] >= 15 ? 'medium' : 'low',
    };
  });

  // Upsert daily scores
  for (const sig of signals) {
    await prisma.dailyScore.upsert({
      where:  { userId_date: { userId: sig.userId, date: today } },
      update: { score: sig.todayScore },
      create: { userId: sig.userId, date: today, score: sig.todayScore },
    });
  }

  // Return signals for orchestrator to dispatch
  return {
    processed:  users.length,
    high:       signals.filter(s => s.status === 'high').length,
    low:        signals.filter(s => s.status === 'low').length,
    dropping:   signals.filter(s => s.dropping).length,
    signals,    // ← passed to Coach Agent
  };
}

module.exports = { run };`,
  },
  {
    id: 'coach',
    name: 'Coach Agent',
    schedule: 'Daily 8am + on drop trigger',
    color: '#a78bfa',
    bg: 'rgba(139,92,246,0.06)',
    border: 'rgba(139,92,246,0.16)',
    Icon: Brain,
    file: 'ai/agents/coach.js',
    description: 'Generates personalised coaching. Routes to WhatsApp or email. No templates used.',
    code: `// ai/agents/coach.js
require('dotenv').config({ path: '../../.env' });
const { PrismaClient } = require('@prisma/client');
const OpenAI  = require('openai');
const twilio  = require('twilio')(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);
const prisma  = new PrismaClient();
const openai  = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function run(signals) {
  // signals come from Behavior Agent.
  // If called directly (cron), load signals now.
  if (!signals) {
    const { run: behavior } = require('./behavior');
    const result = await behavior();
    signals = result.signals;
  }

  let sent = 0;

  for (const sig of signals) {
    try {
      const message = await generateMessage(sig);

      // Route: WhatsApp → push → log
      const user = await prisma.user.findUnique({
        where: { id: sig.userId },
        select: { phone: true, email: true },
      });

      if (user.phone) {
        await twilio.messages.create({
          from: process.env.TWILIO_WHATSAPP_FROM,
          to:   \`whatsapp:\${user.phone}\`,
          body: message,
        });
      } else {
        // Fallback: log / email via SendGrid
        console.log(\`[CoachAgent] \${sig.name}: \${message}\`);
      }
      sent++;
    } catch (err) {
      console.error(\`[CoachAgent] \${sig.name}:\`, err.message);
    }
  }

  return { sent, total: signals.length };
}

async function generateMessage({ todayScore, avg, trend, dropping, name }) {
  const prompt = \`
You are a performance coach. Be direct. Max 2 sentences. No fluff.

Rep: \${name}
Score today: \${todayScore} | 7-day avg: \${avg}
Trend: \${trend.join(', ')} | Dropping: \${dropping}

Write 1 coaching message.\`;

  const res = await openai.chat.completions.create({
    model:       'gpt-4o-mini',
    messages:    [{ role: 'user', content: prompt }],
    max_tokens:  80,
    temperature: 0.7,
  });
  return res.choices[0].message.content.trim();
}

module.exports = { run };`,
  },
  {
    id: 'growth',
    name: 'Growth Agent',
    schedule: 'Every 12 hours',
    color: '#f472b6',
    bg: 'rgba(236,72,153,0.06)',
    border: 'rgba(236,72,153,0.16)',
    Icon: TrendingUp,
    file: 'ai/agents/growth.js',
    description: 'Detects viral triggers. Generates and posts content. A/B tests outreach copy.',
    code: `// ai/agents/growth.js
require('dotenv').config({ path: '../../.env' });
const { PrismaClient } = require('@prisma/client');
const OpenAI  = require('openai');
const prisma  = new PrismaClient();
const openai  = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// In production: connect to Buffer / Typefully for posting
async function postContent(text) {
  console.log('[GrowthAgent] Post:', text.slice(0, 60) + '...');
  // await buffer.createPost({ text, profiles: ['linkedin', 'twitter'] });
}

async function run() {
  const users = await prisma.user.findMany({
    include: { scores: { orderBy: { date: 'desc' }, take: 14 } },
  });

  // Find top performers (viral candidates)
  const top = users.filter(u => {
    const avg = u.scores.length
      ? u.scores.reduce((s, x) => s + x.score, 0) / u.scores.length : 0;
    return avg >= 30;
  });

  // Generate insight post from top performer data
  if (top.length >= 3) {
    const prompt = \`
Write a 1-tweet insight about team execution.
Data: \${top.length} reps averaging 30+ execution points per day.
Angle: execution consistency drives revenue.
No hashtags. No emojis. Direct. Under 280 chars.\`;

    const res = await openai.chat.completions.create({
      model:    'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 80,
    });
    const tweet = res.choices[0].message.content.trim();
    await postContent(tweet);
  }

  // A/B test: pick variant for this cycle
  const variants = [
    '"Execution score" headline',
    '"Team performance" headline',
  ];
  const variant = variants[Math.floor(Date.now() / 86400000) % variants.length];

  return {
    viralCandidates: top.length,
    postsPublished:  top.length >= 3 ? 1 : 0,
    activeVariant:   variant,
  };
}

module.exports = { run };`,
  },
  {
    id: 'revenue',
    name: 'Revenue Agent',
    schedule: 'Monday 9am',
    color: '#fbbf24',
    bg: 'rgba(245,158,11,0.06)',
    border: 'rgba(245,158,11,0.16)',
    Icon: DollarSign,
    file: 'ai/agents/revenue.js',
    description: 'Detects upgrade-ready accounts. Sends proposals. Runs win-back campaigns.',
    code: `// ai/agents/revenue.js
require('dotenv').config({ path: '../../.env' });
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// SendGrid email stub — replace with real client
async function sendEmail(to, subject, body) {
  console.log(\`[RevenueAgent] Email → \${to}: \${subject}\`);
  // const sgMail = require('@sendgrid/mail');
  // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  // await sgMail.send({ to, from: process.env.FROM_EMAIL, subject, text: body });
}

async function run() {
  // ── 1. Detect upgrade-ready free tenants ──────────
  const tenants = await prisma.tenant.findMany({
    where:   { plan: 'free' },
    include: {
      users: {
        include: { scores: { orderBy: { date: 'desc' }, take: 7 } }
      }
    },
  });

  let proposals = 0;
  for (const t of tenants) {
    const active = t.users.filter(u => {
      const avg = u.scores.length
        ? u.scores.reduce((s, x) => s + x.score, 0) / u.scores.length : 0;
      return avg > 10;
    });

    if (active.length >= 5) {
      const admin = t.users.find(u => u.role === 'admin');
      if (admin) {
        await sendEmail(
          admin.email,
          \`\${t.name}: upgrade to unlock team analytics\`,
          \`Hi,\\n\\nYour team has \${active.length} active users.\\n\\n\` +
          \`Upgrade to Growth ($200/mo) to unlock:\\n\` +
          \`- Team manager dashboard\\n- AI coaching per rep\\n- Weekly performance reports\\n\\n\` +
          \`Reply to upgrade or book a 10-min call.\\n\\nBehavior Engine\`
        );
        proposals++;
      }
    }
  }

  // ── 2. Win-back: no activity in 5 days ───────────
  const cutoff = new Date(Date.now() - 5 * 86400000);
  const lapsed = await prisma.user.findMany({
    where: {
      tasks: { none: { createdAt: { gte: cutoff } } },
    },
    take: 100,
  });

  for (const u of lapsed) {
    await sendEmail(
      u.email,
      'We noticed you stepped away',
      \`Hi \${u.name},\\n\\nYour team is still executing without you.\\n\` +
      \`Log back in and see your score: https://app.behaviorengine.io\\n\\nBehavior Engine\`
    );
  }

  return { proposals, winback: lapsed.length };
}

module.exports = { run };`,
  },
];

// ── Orchestrator code ─────────────────────────────────────────────────────────
const ORCHESTRATOR_CODE = `// ai/orchestrator.js — Master scheduler
require('dotenv').config({ path: '../.env' });
const cron = require('node-cron');

const behaviorAgent = require('./agents/behavior');
const coachAgent    = require('./agents/coach');
const growthAgent   = require('./agents/growth');
const revenueAgent  = require('./agents/revenue');

console.log('Behavior Engine Orchestrator v2 starting...');

// ── Schedules ─────────────────────────────────────────────
// Behavior Agent: every hour, on the hour
cron.schedule('0 * * * *', () => run('Behavior', behaviorAgent.run));

// Coach Agent: daily 8am — receives signals from Behavior Agent
cron.schedule('0 8 * * *', async () => {
  const { signals } = await behaviorAgent.run();
  run('Coach', () => coachAgent.run(signals));
});

// Growth Agent: 6am and 6pm
cron.schedule('0 6,18 * * *', () => run('Growth', growthAgent.run));

// Revenue Agent: Monday 9am
cron.schedule('0 9 * * 1', () => run('Revenue', revenueAgent.run));

// ── Runner ────────────────────────────────────────────────
async function run(name, fn) {
  const t = Date.now();
  try {
    console.log(\`[\${name}] starting\`);
    const result = await fn();
    console.log(\`[\${name}] done \${Date.now() - t}ms\`, JSON.stringify(result));
  } catch (err) {
    console.error(\`[\${name}] ERROR:\`, err.message);
    // In production: alert via Sentry / PagerDuty
  }
}

// ── Dev server: manual trigger ────────────────────────────
if (process.env.NODE_ENV !== 'production') {
  const http    = require('http');
  const runners = { behavior: behaviorAgent, coach: coachAgent,
                    growth:   growthAgent,   revenue: revenueAgent };

  http.createServer(async (req, res) => {
    const name = req.url.slice(1);
    if (runners[name]) {
      await run(name, runners[name].run);
      res.end(\`Ran \${name}\`);
    } else {
      res.end('Agents: ' + Object.keys(runners).join(', '));
    }
  }).listen(3001);

  console.log('Dev trigger: http://localhost:3001/<agent-name>');
}`;

// ── Copy button ───────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1600); }}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border shrink-0 transition-all ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'
      }`}>
      {c ? <><Check size={8} />Copied</> : <><Copy size={8} />Copy</>}
    </button>
  );
}

// ── Animated run simulation ───────────────────────────────────────────────────
export default function AgentCodebase() {
  const [view,        setView]        = useState('agents');   // 'agents' | 'orchestrator' | 'flow'
  const [activeAgent, setActiveAgent] = useState(AGENTS[0].id);
  const [running,     setRunning]     = useState(false);
  const [activeStep,  setActiveStep]  = useState(-1);
  const [cycleCount,  setCycleCount]  = useState(() => {
    try { return Number(localStorage.getItem('be_agcb_cycles') ?? 0); } catch { return 0; }
  });
  const timer = useRef(null);

  const agent = AGENTS.find(a => a.id === activeAgent) ?? AGENTS[0];

  const runCycle = () => {
    if (running) return;
    setRunning(true);
    setActiveStep(0);
    const STEPS = AGENTS.length + 1;
    let s = 0;
    timer.current = setInterval(() => {
      s++;
      if (s < STEPS) setActiveStep(s);
      else {
        clearInterval(timer.current);
        setRunning(false);
        setActiveStep(-1);
        const next = cycleCount + 1;
        setCycleCount(next);
        try { localStorage.setItem('be_agcb_cycles', next); } catch {}
      }
    }, 600);
  };

  useEffect(() => () => clearInterval(timer.current), []);

  const FLOW_STEPS = [
    { label: 'Observe',      Icon: Eye,       color: '#22d3ee', desc: 'Behavior Agent reads all user activity' },
    { label: 'Analyze',      Icon: Cpu,       color: '#a78bfa', desc: 'Score engine + pattern detection' },
    { label: 'Adjust',       Icon: Settings,  color: '#f472b6', desc: 'Coach Agent generates messages' },
    { label: 'Deliver',      Icon: Zap,       color: '#fbbf24', desc: 'WhatsApp / Email / Push' },
    { label: 'Learn',        Icon: TrendingUp,color: '#34d399', desc: 'Signals feed next cycle' },
    { label: 'Loop',         Icon: Repeat,    color: '#818cf8', desc: 'Orchestrator triggers next run' },
  ];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={13} className="text-violet-400" />
              <p className="text-violet-400 text-xs font-bold uppercase tracking-widest">Autonomous Agent Codebase</p>
            </div>
            <h1 className="text-3xl font-black mb-1">AI Runs the Workflows</h1>
            <p className="text-white/35 text-sm">Real code. Copy it. Run it. The company operates without you.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-center p-3 rounded-xl border border-violet-500/20 bg-violet-500/5">
              <p className="text-xl font-black text-violet-400">{cycleCount}</p>
              <p className="text-white/20 text-[9px]">cycles run</p>
            </div>
            <button onClick={runCycle} disabled={running}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${
                running
                  ? 'bg-violet-500/10 border border-violet-500/20 text-violet-400'
                  : 'bg-violet-500 hover:bg-violet-400 text-white shadow-lg shadow-violet-500/20'
              }`}>
              {running ? <><RefreshCw size={13} className="animate-spin" /> Running…</> : <><Play size={13} /> Simulate Cycle</>}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['agents','Agent Code'],['orchestrator','Orchestrator'],['flow','Self-Improvement Loop']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-violet-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── AGENTS ── */}
        {view === 'agents' && (
          <div className="grid lg:grid-cols-[200px_1fr] gap-5">
            {/* Agent picker */}
            <div className="space-y-1">
              {AGENTS.map((a, i) => {
                const AIcon = a.Icon;
                const isActive = activeAgent === a.id;
                const isRunning = running && activeStep === i;
                return (
                  <button key={a.id} onClick={() => setActiveAgent(a.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-200 ${
                      isActive ? 'border-white/12 bg-white/5' : 'border-white/5 hover:bg-white/3'
                    }`}>
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-all"
                      style={{ background: isRunning ? a.color + '25' : a.bg, border: `1px solid ${a.border}` }}>
                      <AIcon size={11} style={{ color: isActive || isRunning ? a.color : 'rgba(255,255,255,0.2)' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[9px] font-bold truncate" style={{ color: isActive ? a.color : 'rgba(255,255,255,0.3)' }}>{a.name}</p>
                      <p className="text-white/15 text-[8px]">{a.schedule}</p>
                    </div>
                    {isRunning && <div className="w-2 h-2 rounded-full animate-pulse shrink-0" style={{ background: a.color }} />}
                  </button>
                );
              })}
            </div>

            {/* Code panel */}
            <div className="rounded-2xl border border-white/8 bg-black/30 overflow-hidden flex flex-col" style={{ minHeight: 400, maxHeight: 560 }}>
              <div className="flex items-center justify-between px-4 py-2 border-b border-white/6 bg-white/2 shrink-0">
                <div className="flex items-center gap-2">
                  <FileCode2 size={11} className="text-white/25" />
                  <span className="text-white/50 text-xs font-mono">{agent.file}</span>
                  <span className="text-white/15 text-[8px] px-1.5 py-0.5 rounded border border-white/8">{agent.schedule}</span>
                </div>
                <CopyBtn text={agent.code} />
              </div>
              <div className="p-3 border-b border-white/5 shrink-0">
                <p className="text-white/35 text-[9px]">{agent.description}</p>
              </div>
              <pre className="flex-1 p-4 text-[9.5px] text-white/55 font-mono leading-relaxed overflow-auto">{agent.code}</pre>
            </div>
          </div>
        )}

        {/* ── ORCHESTRATOR ── */}
        {view === 'orchestrator' && (
          <div className="space-y-4">
            {/* Schedule summary */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {AGENTS.map(a => {
                const AIcon = a.Icon;
                return (
                  <div key={a.id} className="p-3 rounded-xl border" style={{ borderColor: a.border, background: a.bg }}>
                    <div className="flex items-center gap-1.5 mb-1">
                      <AIcon size={10} style={{ color: a.color }} />
                      <p className="text-[9px] font-bold" style={{ color: a.color }}>{a.name}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={8} style={{ color: a.color, opacity: 0.5 }} />
                      <p className="text-white/30 text-[8px]">{a.schedule}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Orchestrator code */}
            <div className="rounded-2xl border border-white/8 bg-black/30 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2 border-b border-white/6 bg-white/2">
                <div className="flex items-center gap-2">
                  <Terminal size={11} className="text-white/25" />
                  <span className="text-white/50 text-xs font-mono">ai/orchestrator.js</span>
                </div>
                <CopyBtn text={ORCHESTRATOR_CODE} />
              </div>
              <pre className="p-4 text-[9.5px] text-white/55 font-mono leading-relaxed overflow-auto max-h-[500px]">{ORCHESTRATOR_CODE}</pre>
            </div>

            {/* Deploy command */}
            <div className="p-4 rounded-xl border border-white/8 bg-black/20">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Start the Orchestrator</p>
              <div className="flex items-center gap-2">
                <pre className="flex-1 text-[10px] text-emerald-400/80 font-mono">cd ai && npm install && NODE_ENV=production node orchestrator.js</pre>
                <CopyBtn text="cd ai && npm install && NODE_ENV=production node orchestrator.js" />
              </div>
              <p className="text-white/20 text-[9px] mt-2">On Railway: set start command to the above. All 4 agents run on schedule indefinitely.</p>
            </div>
          </div>
        )}

        {/* ── FLOW ── */}
        {view === 'flow' && (
          <div className="space-y-5">
            {/* Loop visual */}
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-5">Self-Improvement Loop — runs every 24 hours</p>
              <div className="flex items-center gap-2 flex-wrap">
                {FLOW_STEPS.map((step, i) => {
                  const SIcon = step.Icon;
                  const isActive = running && activeStep % FLOW_STEPS.length === i;
                  return (
                    <div key={step.label} className="flex items-center gap-2">
                      <div className="flex flex-col items-center gap-1.5 px-3 py-2.5 rounded-xl border transition-all duration-300"
                        style={{
                          borderColor: isActive ? step.color : 'rgba(255,255,255,0.06)',
                          background:  isActive ? step.color + '10' : 'rgba(255,255,255,0.02)',
                          transform:   isActive ? 'scale(1.06)' : 'scale(1)',
                        }}>
                        <SIcon size={12} style={{ color: isActive ? step.color : 'rgba(255,255,255,0.2)' }} />
                        <span className="text-[9px] font-bold whitespace-nowrap" style={{ color: isActive ? step.color : 'rgba(255,255,255,0.25)' }}>
                          {step.label}
                        </span>
                      </div>
                      {i < FLOW_STEPS.length - 1 && <ArrowRight size={8} className="text-white/10 shrink-0" />}
                    </div>
                  );
                })}
                <ArrowRight size={8} className="text-white/10" />
                <div className="px-3 py-2.5 rounded-xl border border-white/8 flex items-center gap-1">
                  <Repeat size={9} className="text-white/20" />
                  <span className="text-[9px] text-white/20 font-bold">∞</span>
                </div>
              </div>
            </div>

            {/* What happens in each step */}
            <div className="space-y-2">
              {FLOW_STEPS.map((step, i) => {
                const SIcon = step.Icon;
                return (
                  <div key={step.label} className="flex items-start gap-4 p-4 rounded-xl border border-white/6 bg-white/2">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                      style={{ background: step.color + '10', border: `1px solid ${step.color}20` }}>
                      <SIcon size={12} style={{ color: step.color }} />
                    </div>
                    <div className="flex-1">
                      <p className="text-white/70 text-xs font-bold mb-0.5">{i + 1}. {step.label}</p>
                      <p className="text-white/30 text-[10px]">{step.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Result: what you get */}
            <div className="p-5 rounded-2xl border border-violet-500/20 bg-violet-500/5">
              <p className="text-violet-400 font-bold text-sm mb-3">What This Means</p>
              <div className="grid lg:grid-cols-2 gap-3">
                {[
                  { t: 'Before this codebase', d: 'You check dashboards. You write messages. You manually follow up. You forget people. Revenue leaks.' },
                  { t: 'After this codebase',  d: 'Orchestrator runs. Agents observe, decide, act. Coaching delivered. Revenue proposals sent. You sleep.' },
                ].map(({ t, d }) => (
                  <div key={t} className="p-3 rounded-xl border border-white/8 bg-black/20">
                    <p className="text-violet-300 text-xs font-bold mb-1">{t}</p>
                    <p className="text-white/35 text-[10px] leading-snug">{d}</p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
