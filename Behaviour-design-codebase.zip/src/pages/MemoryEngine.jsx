/**
 * MemoryEngine — AI Memory Engine Dashboard
 * Shows the user's behavioral profile, performance history, pattern detection,
 * and how the AI adapts coaching based on accumulated behavioral data.
 */
import { useState, useEffect, useMemo } from 'react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus, getStatusConfig } from '../engine/core';
import { detectDropPattern, calcStreak } from '../engine/coach';
import { coachWithPersonality, COACH_PERSONALITIES } from '../engine/personality';
import { loadMemory, saveMemory, updateMemory, getMemoryInsight, generateExecutionCard } from '../engine/memory';
import {
  Brain, Activity, TrendingUp, Flame, Target, Clock, Shield,
  BarChart2, Bot, Users, ChevronRight, Zap, RefreshCw, Star,
  Eye, Database, Cpu, CheckCircle2,
} from 'lucide-react';

// ── Stat Badge ────────────────────────────────────────────────────────────────
function StatBadge({ value, label, color = 'text-white', icon: Icon, bg = 'bg-white/3', border = 'border-white/6' }) {
  return (
    <div className={`p-4 rounded-xl ${bg} border ${border}`}>
      {Icon && <Icon size={13} className={`${color} mb-2`} />}
      <p className={`text-2xl font-black leading-none ${color}`}>{value}</p>
      <p className="text-white/25 text-[10px] mt-1 leading-tight">{label}</p>
    </div>
  );
}

// ── Profile Trait ─────────────────────────────────────────────────────────────
function ProfileTrait({ label, value, color, desc }) {
  if (!value || value === 'unknown') return null;
  const map = {
    consistency:        { high: '🟢 Highly Consistent', medium: '🟡 Building Consistency', low: '🔴 Low Consistency' },
    dropPattern:        {
      monday: '📅 Monday Drops', 'end-of-week': '📉 Week Fader',
      midweek: '📊 Midweek Dip', weekend: '🛌 Weekend Dropout', unknown: null
    },
    paceType:           { 'fast-starter': '🚀 Fast Starter', 'slow-starter': '🐢 Slow Starter', steady: '⚖️ Steady Pace', inconsistent: '🌪️ Inconsistent' },
    responseToPressure: { positive: '💪 Responds to Pressure', negative: '🤝 Benefits from Support', neutral: '😐 Neutral to Pressure' },
  };
  const display = map[label]?.[value];
  if (!display) return null;
  return (
    <div className={`flex items-center gap-3 p-3 rounded-xl ${color.replace('text-', 'bg-').replace('-400', '-500/8')} border ${color.replace('text-', 'border-').replace('-400', '-500/20')}`}>
      <p className="text-sm">{display.split(' ').slice(0, 1).join(' ')}</p>
      <div>
        <p className={`text-xs font-semibold ${color}`}>{display.split(' ').slice(1).join(' ')}</p>
        <p className="text-white/25 text-[9px]">{desc}</p>
      </div>
    </div>
  );
}

// ── 30-day mini chart ─────────────────────────────────────────────────────────
function MiniHistoryChart({ history }) {
  if (!history || history.length === 0) {
    return (
      <div className="h-16 flex items-center justify-center text-white/20 text-xs">
        Not enough data yet — keep logging actions
      </div>
    );
  }
  const recent = history.slice(-14);
  return (
    <div className="flex items-end gap-1 h-16">
      {recent.map((h, i) => {
        const cfg = getStatusConfig(h.status);
        return (
          <div key={i} className="flex-1 flex flex-col items-center gap-0.5 group relative">
            <div
              className={`w-full rounded-t ${cfg.bar} transition-all cursor-default`}
              style={{ height: `${Math.max(8, (h.score / 100) * 100)}%`, opacity: 0.7 }}
            />
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 hidden group-hover:flex bg-black/80 border border-white/10 rounded-lg px-2 py-1 text-[9px] text-white whitespace-nowrap z-10">
              {h.date}: {h.score}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Adaptive Coach Preview ────────────────────────────────────────────────────
function AdaptiveCoachPreview({ insight, personalityId, score }) {
  const personality = COACH_PERSONALITIES[personalityId];
  const status = getStatus(score);
  const cfg = getStatusConfig(status);

  const scenarios = [
    { label: 'If you hit target today',    score: 85, context: 'celebrating' },
    { label: 'If you\'re 10 pts behind',  score: 52, context: 'coaching' },
    { label: 'After a RED day',            score: 18, context: 'recovery' },
  ];

  const pColors = {
    discipline: { border: 'border-red-500/25',    bg: 'bg-red-500/10',    color: 'text-red-400',    bar: 'bg-red-500'    },
    strategy:   { border: 'border-indigo-500/25', bg: 'bg-indigo-500/10', color: 'text-indigo-400', bar: 'bg-indigo-500' },
    motivation: { border: 'border-emerald-500/25',bg: 'bg-emerald-500/10',color: 'text-emerald-400',bar: 'bg-emerald-500'},
  };
  const pc = pColors[personalityId] ?? pColors.discipline;

  return (
    <div className="space-y-3">
      {scenarios.map(({ label, score: s }) => {
        const st = getStatus(s);
        const fake = {
          score: s, weekScores: [40, 45, s, 55, 50, s, s],
          streak: s > 60 ? 3 : 0, role: 'sales', target: 70, userId: 'preview',
        };
        let msg;
        try { msg = coachWithPersonality(fake, personalityId); } catch { msg = null; }
        return (
          <div key={label} className={`p-3 rounded-xl ${pc.bg} border ${pc.border}`}>
            <p className="text-white/25 text-[9px] uppercase tracking-wider mb-2">{label}</p>
            <div className="flex items-start gap-2">
              <span className="text-base shrink-0">{personality?.emoji ?? '🤖'}</span>
              <div>
                <p className="text-white/65 text-xs leading-snug">{msg?.insight ?? '...'}</p>
                {msg?.action && (
                  <p className={`text-xs font-semibold ${pc.color} mt-1`}>→ {msg.action}</p>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export default function MemoryEngine() {
  const { getTodayScore, getWeekScores, activeUserId, personalityId } = useBehavior();
  const { user, tenantInfo } = useAuth();
  const [memory, setMemory] = useState(null);
  const [memInsight, setMemInsight] = useState(null);
  const [showRaw, setShowRaw] = useState(false);

  const score       = getTodayScore(activeUserId);
  const status      = getStatus(score);
  const cfg         = getStatusConfig(status);
  const weekScores  = getWeekScores(activeUserId);
  const streak      = calcStreak(weekScores);
  const dropPattern = detectDropPattern(weekScores);

  // Load and update memory on mount
  useEffect(() => {
    const userId   = user?.id ?? activeUserId ?? 1;
    const tenantId = tenantInfo?.id ?? 'default';
    let mem = loadMemory(userId, tenantId);

    // Sync today's data into memory
    mem = updateMemory(mem, {
      score,
      status,
      tasksCompleted: weekScores.filter(s => s > 0).length,
      actionTimestamps: [new Date().toISOString()],
      streak,
    });
    saveMemory(mem);

    const insight = getMemoryInsight(mem);
    setMemory(mem);
    setMemInsight(insight);
  }, [score, status, streak]);

  const personality = COACH_PERSONALITIES[personalityId];

  const resetMemory = () => {
    const userId   = user?.id ?? activeUserId ?? 1;
    const tenantId = tenantInfo?.id ?? 'default';
    const fresh = { userId, tenantId, joinedAt: new Date().toISOString() };
    saveMemory(fresh);
    setMemory(fresh);
    setMemInsight(getMemoryInsight(fresh));
  };

  if (!memory) {
    return (
      <div className="min-h-screen bg-[#070b14] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <RefreshCw size={20} className="text-indigo-400 animate-spin" />
          <p className="text-white/35 text-sm">Loading memory…</p>
        </div>
      </div>
    );
  }

  const bp = memory.behaviorProfile ?? {};
  const history = memory.performanceHistory ?? [];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-8">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Brain size={15} className="text-purple-400" />
              <p className="text-purple-400 text-xs font-bold uppercase tracking-widest">AI Memory Engine</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Your Behavioral Profile</h1>
            <p className="text-white/35 text-sm">
              {memInsight?.isNewUser
                ? 'Building your profile — keep logging actions to unlock deeper insights.'
                : memInsight?.summary ?? 'Adaptive AI coaching based on your patterns.'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowRaw(p => !p)}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/4 border border-white/8 text-white/35 hover:text-white/55 text-xs transition-all">
              <Database size={11} /> {showRaw ? 'Hide' : 'View'} Raw
            </button>
            <button onClick={resetMemory}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/8 border border-red-500/15 text-red-400/60 hover:text-red-400 text-xs transition-all">
              <RefreshCw size={11} /> Reset
            </button>
          </div>
        </div>

        {/* Core KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatBadge icon={Activity}   value={score}                   label="Today's Score"   color={cfg.color} bg={cfg.bg} border={cfg.border} />
          <StatBadge icon={Flame}      value={`${streak}d`}            label="Current Streak"  color="text-orange-400" bg="bg-orange-500/10" border="border-orange-500/20" />
          <StatBadge icon={BarChart2}  value={memory.totalSessions ?? 0}  label="Total Sessions"  color="text-indigo-400" />
          <StatBadge icon={Star}       value={`${memory.streakRecord ?? 0}d`} label="Best Streak"  color="text-yellow-400" />
        </div>

        {/* Two columns */}
        <div className="grid lg:grid-cols-2 gap-6">

          {/* LEFT — Behavioral Profile */}
          <div className="space-y-4">
            <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Detected Behavioral Profile</p>

            {(bp.consistency === 'unknown' && !memInsight?.hasLongHistory) ? (
              <div className="p-5 rounded-2xl bg-white/2 border border-white/6 text-center space-y-2">
                <Eye size={24} className="mx-auto text-white/15" />
                <p className="text-white/40 text-sm font-semibold">Building your profile</p>
                <p className="text-white/20 text-xs">Log actions for at least 3 days to unlock behavioral pattern detection.</p>
                <div className="flex gap-1.5 justify-center mt-3">
                  {[0, 1, 2].map(i => (
                    <div key={i} className={`h-1.5 flex-1 rounded-full ${i < (history.length) ? 'bg-indigo-500' : 'bg-white/10'}`} />
                  ))}
                </div>
                <p className="text-white/15 text-[10px]">{history.length} / 3 days completed</p>
              </div>
            ) : (
              <div className="space-y-2">
                {[
                  { label: 'consistency',        value: bp.consistency,        color: 'text-emerald-400', desc: 'Based on your GREEN/YELLOW/RED ratio over time' },
                  { label: 'dropPattern',         value: bp.dropPattern,        color: 'text-orange-400',  desc: 'Day of week where performance typically drops' },
                  { label: 'paceType',            value: bp.paceType,           color: 'text-indigo-400',  desc: 'Your typical weekly performance arc' },
                  { label: 'responseToPressure',  value: bp.responseToPressure, color: 'text-purple-400',  desc: 'How your scores move after a RED day' },
                ].map(t => <ProfileTrait key={t.label} {...t} />)}
              </div>
            )}

            {/* Coaching Style */}
            <div className={`p-4 rounded-2xl border bg-${personalityId === 'discipline' ? 'red' : personalityId === 'strategy' ? 'indigo' : 'emerald'}-500/8 border-${personalityId === 'discipline' ? 'red' : personalityId === 'strategy' ? 'indigo' : 'emerald'}-500/20`}>
              <p className="text-white/30 text-[9px] uppercase tracking-widest mb-2">Active Coaching Style</p>
              <div className="flex items-center gap-3">
                <span className="text-2xl">{personality?.emoji ?? '🤖'}</span>
                <div>
                  <p className="text-white font-bold text-sm">{personality?.name ?? 'Disciplinarian'}</p>
                  <p className="text-white/35 text-xs">{personality?.tagline ?? ''}</p>
                </div>
                <a href="/coach" className="ml-auto text-indigo-400 text-xs hover:text-indigo-300 transition-colors">
                  Change →
                </a>
              </div>
            </div>

            {/* Memory model display */}
            {showRaw && (
              <div className="p-4 rounded-xl bg-black/30 border border-white/6">
                <p className="text-white/30 text-[9px] uppercase tracking-widest mb-2">Memory Object (JSON)</p>
                <pre className="text-[9px] text-green-400/70 overflow-x-auto scrollbar-hide leading-relaxed">
                  {JSON.stringify({
                    userId: memory.userId,
                    tenantId: memory.tenantId,
                    behaviorProfile: memory.behaviorProfile,
                    coachingStyle: memory.coachingStyle,
                    streakRecord: memory.streakRecord,
                    totalSessions: memory.totalSessions,
                    performanceHistoryCount: history.length,
                    lastSeenAt: memory.lastSeenAt,
                  }, null, 2)}
                </pre>
              </div>
            )}
          </div>

          {/* RIGHT — History + Adaptive Coach */}
          <div className="space-y-4">
            <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Performance History (last 14 days)</p>
            <div className="p-4 rounded-2xl bg-white/2 border border-white/6">
              <MiniHistoryChart history={history} />
              {history.length > 0 && (
                <div className="flex justify-between text-white/15 text-[9px] mt-2">
                  <span>14 days ago</span>
                  <span>Today</span>
                </div>
              )}
            </div>

            {/* Trend */}
            {memInsight && (
              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 rounded-xl bg-white/2 border border-white/6">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">7-Day Avg Score</p>
                  <p className={`text-xl font-black ${memInsight.avgScore >= 60 ? 'text-green-400' : memInsight.avgScore >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
                    {memInsight.avgScore}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-white/2 border border-white/6">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">Trend</p>
                  <p className={`text-xl font-black ${memInsight.trend === 'improving' ? 'text-green-400' : memInsight.trend === 'declining' ? 'text-red-400' : 'text-yellow-400'}`}>
                    {memInsight.trend === 'improving' ? '↑' : memInsight.trend === 'declining' ? '↓' : '→'} {memInsight.trend}
                  </p>
                </div>
              </div>
            )}

            <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Adaptive Coaching Previews</p>
            <AdaptiveCoachPreview
              insight={memInsight}
              personalityId={personalityId}
              score={score}
            />
          </div>
        </div>

        {/* How the memory engine works */}
        <div className="rounded-2xl border border-purple-500/20 bg-purple-500/4 p-5 lg:p-6">
          <div className="flex items-center gap-2 mb-4">
            <Cpu size={15} className="text-purple-400" />
            <p className="text-purple-400 font-bold text-sm">How the Memory Engine Works</p>
          </div>
          <div className="grid lg:grid-cols-3 gap-4">
            {[
              {
                step: '01',
                title: 'Observe Behavior',
                color: 'text-indigo-400',
                bg: 'bg-indigo-500/8',
                border: 'border-indigo-500/15',
                items: ['Completed vs missed tasks', 'Action timestamps & frequency', 'Response to RED days', 'Day-of-week patterns'],
              },
              {
                step: '02',
                title: 'Build Profile',
                color: 'text-purple-400',
                bg: 'bg-purple-500/8',
                border: 'border-purple-500/15',
                items: ['Consistency score (low/med/high)', 'Drop pattern (day of week)', 'Pace type (fast/slow/steady)', 'Pressure response (positive/neg)'],
              },
              {
                step: '03',
                title: 'Adapt Response',
                color: 'text-emerald-400',
                bg: 'bg-emerald-500/8',
                border: 'border-emerald-500/15',
                items: ['Coaching style auto-suggests', 'Messages reference specific patterns', 'Insights improve over 7+ days', 'Moat: no competitor has this'],
              },
            ].map(({ step, title, color, bg, border, items }) => (
              <div key={step} className={`p-4 rounded-xl ${bg} border ${border}`}>
                <div className="flex items-center gap-2 mb-3">
                  <span className={`text-xs font-black font-mono ${color}`}>{step}</span>
                  <p className={`text-sm font-bold ${color}`}>{title}</p>
                </div>
                <div className="space-y-1">
                  {items.map(item => (
                    <div key={item} className="flex items-start gap-2">
                      <CheckCircle2 size={10} className={`${color} mt-0.5 shrink-0`} />
                      <p className="text-white/40 text-xs">{item}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 rounded-xl bg-white/3 border border-white/6">
            <p className="text-white/25 text-xs">
              <span className="text-white/55 font-semibold">The moat: </span>
              Most SaaS gives everyone the same feedback. Behavior Engine builds a persistent behavioral model per user — every message references actual history. After 14 days, the AI knows this person better than their manager does.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
