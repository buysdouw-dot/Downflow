/**
 * RevenueTracker — MRR / ARR Revenue Dashboard
 * Full SaaS revenue analytics: MRR, ARR, churn, LTV, cohort breakdown.
 */
import { useState } from 'react';
import {
  DollarSign, TrendingUp, TrendingDown, Users, Zap,
  CreditCard, ArrowUpRight, ArrowDownRight, BarChart2,
  Activity, Target, RefreshCw, ChevronUp, Minus,
} from 'lucide-react';

// ── Seed data ─────────────────────────────────────────────────────────────────
const MONTHS = ['Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr'];

const MRR_HISTORY = [
  { month: 'Nov', mrr: 1200, newMRR: 1200, churnMRR: 0,  expansionMRR: 0,   customers: 2,  churnCount: 0 },
  { month: 'Dec', mrr: 2600, newMRR: 1600, churnMRR: 200, expansionMRR: 0,  customers: 4,  churnCount: 1 },
  { month: 'Jan', mrr: 4100, newMRR: 1800, churnMRR: 300, expansionMRR: 0,  customers: 6,  churnCount: 1 },
  { month: 'Feb', mrr: 6200, newMRR: 2400, churnMRR: 300, expansionMRR: 0,  customers: 9,  churnCount: 1 },
  { month: 'Mar', mrr: 8900, newMRR: 3000, churnMRR: 300, expansionMRR: 0,  customers: 13, churnCount: 1 },
  { month: 'Apr', mrr: 11800,newMRR: 3200, churnMRR: 300, expansionMRR: 0,  customers: 17, churnCount: 1 },
];

const PLANS = [
  { name: 'Starter',    price: 99,  customers: 6,  color: 'text-white/50',   bg: 'bg-white/5',       border: 'border-white/10',     bar: 'bg-white/25' },
  { name: 'Pro',        price: 299, customers: 8,  color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20', bar: 'bg-indigo-400' },
  { name: 'Enterprise', price: 799, customers: 3,  color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', bar: 'bg-yellow-400' },
];

const COHORTS = [
  { month: 'Nov', size: 2, m1: 100, m2: 100, m3: 100, m4: 100, m5: 50 },
  { month: 'Dec', size: 4, m1: 100, m2: 75,  m3: 75,  m4: 75,  m5: null },
  { month: 'Jan', size: 6, m1: 100, m2: 83,  m3: 83,  m4: null,m5: null },
  { month: 'Feb', size: 9, m1: 100, m2: 89,  m3: null,m4: null,m5: null },
  { month: 'Mar', size: 13,m1: 100, m2: null,m3: null,m4: null,m5: null },
];

const CUSTOMERS = [
  { name: 'NovaSales',    plan: 'Enterprise', mrr: 799, status: 'healthy', months: 6, ltv: 4794  },
  { name: 'Peak Ops',     plan: 'Pro',        mrr: 299, status: 'healthy', months: 5, ltv: 1495  },
  { name: 'FlexForce',    plan: 'Pro',        mrr: 299, status: 'healthy', months: 4, ltv: 1196  },
  { name: 'Momentum Co',  plan: 'Starter',    mrr: 99,  status: 'at-risk', months: 3, ltv: 297   },
  { name: 'ExecOps',      plan: 'Pro',        mrr: 299, status: 'healthy', months: 3, ltv: 897   },
  { name: 'Velocity Team',plan: 'Enterprise', mrr: 799, status: 'healthy', months: 2, ltv: 1598  },
  { name: 'ScaleHQ',      plan: 'Starter',    mrr: 99,  status: 'at-risk', months: 2, ltv: 198   },
  { name: 'SalesForge',   plan: 'Enterprise', mrr: 799, status: 'healthy', months: 1, ltv: 799   },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt  = (n) => n >= 1000 ? `$${(n / 1000).toFixed(1)}k` : `$${n}`;
const fmtK = (n) => n >= 1000 ? `$${(n / 1000).toFixed(0)}k` : `$${n}`;

// ── Sub-components ────────────────────────────────────────────────────────────
function KPICard({ icon: Icon, label, value, sub, change, color, bg, border }) {
  const up = change > 0;
  return (
    <div className={`p-4 rounded-2xl border ${border} ${bg}`}>
      <div className="flex items-start justify-between mb-3">
        <Icon size={14} className={color} />
        {change !== undefined && (
          <div className={`flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full ${up ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
            {up ? <ChevronUp size={8} /> : <ArrowDownRight size={8} />}
            {Math.abs(change)}%
          </div>
        )}
      </div>
      <p className={`text-2xl font-black ${color}`}>{value}</p>
      <p className="text-white/35 text-xs mt-0.5">{label}</p>
      {sub && <p className="text-white/20 text-[9px] mt-0.5">{sub}</p>}
    </div>
  );
}

function MiniBarChart({ data, valueKey, maxVal, barColor }) {
  const max = maxVal ?? Math.max(...data.map(d => d[valueKey]));
  return (
    <div className="flex items-end gap-1 h-16">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <div className="w-full relative rounded-t-sm overflow-hidden bg-white/5" style={{ height: '48px' }}>
            <div
              className={`absolute bottom-0 left-0 right-0 rounded-t-sm ${barColor} transition-all duration-700`}
              style={{ height: `${Math.min(100, (d[valueKey] / max) * 100)}%` }}
            />
          </div>
          <span className="text-white/20 text-[8px]">{d.month}</span>
        </div>
      ))}
    </div>
  );
}

function WaterfallBar({ newMRR, churnMRR, mrr, maxMRR }) {
  const newH  = (newMRR  / maxMRR) * 100;
  const churnH= (churnMRR/ maxMRR) * 100;
  const netH  = ((newMRR - churnMRR) / maxMRR) * 100;
  return (
    <div className="flex items-center gap-1">
      <div className="w-3 rounded-sm bg-emerald-400/70" style={{ height: `${newH}px` }} title={`+$${newMRR}`} />
      {churnMRR > 0 && <div className="w-3 rounded-sm bg-red-400/70" style={{ height: `${churnH}px` }} title={`-$${churnMRR}`} />}
    </div>
  );
}

function CohortCell({ value }) {
  if (value === null) return <div className="w-8 h-7 rounded bg-white/2 border border-white/4" />;
  const color = value === 100 ? 'bg-indigo-400/20 text-indigo-300'
    : value >= 80 ? 'bg-emerald-400/20 text-emerald-300'
    : value >= 60 ? 'bg-yellow-400/20 text-yellow-300'
    : 'bg-red-400/15 text-red-300';
  return (
    <div className={`w-8 h-7 rounded flex items-center justify-center text-[8px] font-bold ${color}`}>
      {value}%
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function RevenueTracker() {
  const [view, setView] = useState('overview'); // 'overview' | 'cohorts' | 'customers'

  const latest  = MRR_HISTORY[MRR_HISTORY.length - 1];
  const prev    = MRR_HISTORY[MRR_HISTORY.length - 2];
  const mrrGrowth = Math.round(((latest.mrr - prev.mrr) / prev.mrr) * 100);
  const arr     = latest.mrr * 12;
  const churnRate = Math.round((latest.churnCount / prev.customers) * 100);
  const avgRevPerCustomer = Math.round(latest.mrr / latest.customers);
  const ltv     = Math.round(avgRevPerCustomer / (churnRate / 100 || 0.05));

  const totalRevenue = MRR_HISTORY.reduce((s, m) => s + m.mrr, 0);
  const maxMRR = Math.max(...MRR_HISTORY.map(m => m.mrr));

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <DollarSign size={14} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">Revenue Dashboard</p>
            </div>
            <h1 className="text-3xl font-black mb-1">MRR · ARR · LTV</h1>
            <p className="text-white/35 text-sm">SaaS revenue analytics from first dollar to scale.</p>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/8 border border-emerald-500/20">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-400 text-xs font-bold">Live Data</span>
          </div>
        </div>

        {/* View toggle */}
        <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
          {[['overview','Overview'],['cohorts','Cohort Analysis'],['customers','Customers']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-emerald-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── OVERVIEW ──────────────────────────────────────────────── */}
        {view === 'overview' && (
          <div className="space-y-6">
            {/* KPI row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <KPICard icon={DollarSign} label="Current MRR"   value={fmt(latest.mrr)} sub={`+$${latest.newMRR - latest.churnMRR} net new`} change={mrrGrowth} color="text-emerald-400" bg="bg-emerald-500/8" border="border-emerald-500/20" />
              <KPICard icon={TrendingUp} label="ARR"           value={fmtK(arr)}        sub="annualized"          color="text-indigo-400"  bg="bg-indigo-500/8"  border="border-indigo-500/20" />
              <KPICard icon={Users}      label="Customers"     value={latest.customers} sub={`${churnRate}% churn`} color="text-cyan-400"  bg="bg-cyan-500/8"    border="border-cyan-500/20" />
              <KPICard icon={Star}       label="Avg LTV"       value={fmtK(ltv)}        sub={`$${avgRevPerCustomer}/mo avg`} color="text-yellow-400" bg="bg-yellow-500/10" border="border-yellow-500/20" />
            </div>

            {/* MRR chart + breakdown */}
            <div className="grid lg:grid-cols-[1fr_280px] gap-5">
              {/* MRR over time */}
              <div className="p-5 rounded-2xl bg-white/2 border border-white/6 space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-white/40 text-xs font-bold uppercase tracking-widest">MRR Growth</p>
                  <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
                    <TrendingUp size={11} /> +{mrrGrowth}% MoM
                  </div>
                </div>
                {/* Chart */}
                <div className="flex items-end gap-3 h-32">
                  {MRR_HISTORY.map((m, i) => (
                    <div key={m.month} className="flex-1 flex flex-col items-center gap-1.5">
                      <div className="w-full relative rounded-t-lg overflow-hidden bg-white/4" style={{ height: '96px' }}>
                        <div
                          className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-emerald-500 to-emerald-400/50 rounded-t-lg transition-all duration-1000"
                          style={{ height: `${(m.mrr / maxMRR) * 100}%` }}
                        />
                        <div className="absolute top-1 left-0 right-0 text-center">
                          <span className="text-white/60 text-[8px] font-bold">{fmt(m.mrr)}</span>
                        </div>
                      </div>
                      <span className="text-white/25 text-[9px]">{m.month}</span>
                    </div>
                  ))}
                </div>
                {/* New vs churn vs net */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/6">
                  {[
                    ['New MRR', `+$${latest.newMRR.toLocaleString()}`, 'text-emerald-400'],
                    ['Churn MRR', `-$${latest.churnMRR.toLocaleString()}`, 'text-red-400'],
                    ['Net New', `+$${(latest.newMRR - latest.churnMRR).toLocaleString()}`, 'text-indigo-400'],
                  ].map(([l, v, c]) => (
                    <div key={l} className="text-center">
                      <p className={`text-base font-black ${c}`}>{v}</p>
                      <p className="text-white/25 text-[9px]">{l}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Plan breakdown */}
              <div className="space-y-3">
                <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Revenue by Plan</p>
                {PLANS.map(plan => {
                  const planMRR = plan.price * plan.customers;
                  const pct = Math.round((planMRR / latest.mrr) * 100);
                  return (
                    <div key={plan.name} className={`p-4 rounded-2xl border ${plan.border} ${plan.bg}`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-xs font-bold ${plan.color}`}>{plan.name}</span>
                        <span className={`text-base font-black ${plan.color}`}>{fmt(planMRR)}</span>
                      </div>
                      <div className="flex items-center justify-between text-[9px] text-white/30 mb-1.5">
                        <span>{plan.customers} customers × ${plan.price}/mo</span>
                        <span>{pct}%</span>
                      </div>
                      <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                        <div className={`h-full ${plan.bar} rounded-full transition-all duration-700`} style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}

                {/* Key metrics */}
                <div className="p-4 rounded-2xl bg-white/2 border border-white/6 space-y-2">
                  {[
                    ['Net Revenue Retention', `${100 + Math.round((latest.expansionMRR - latest.churnMRR) / prev.mrr * 100)}%`, 'text-white/60'],
                    ['Gross Margin',          '92%',    'text-emerald-400'],
                    ['CAC Payback',           '1.8 mo', 'text-indigo-400'],
                    ['MoM Growth Rate',       `${mrrGrowth}%`, 'text-yellow-400'],
                  ].map(([l, v, c]) => (
                    <div key={l} className="flex items-center justify-between">
                      <span className="text-white/30 text-xs">{l}</span>
                      <span className={`text-xs font-bold ${c}`}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Path to milestones */}
            <div className="p-5 rounded-2xl bg-white/2 border border-white/6">
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-4">Revenue Milestones</p>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: '$1K MRR',   target: 1000,  color: 'text-white/50',   bar: 'bg-white/30'   },
                  { label: '$10K MRR',  target: 10000, color: 'text-indigo-400', bar: 'bg-indigo-400' },
                  { label: '$50K MRR',  target: 50000, color: 'text-purple-400', bar: 'bg-purple-400' },
                  { label: '$100K MRR', target: 100000,color: 'text-yellow-400', bar: 'bg-yellow-400' },
                ].map(({ label, target, color, bar }) => {
                  const pct = Math.min(100, Math.round((latest.mrr / target) * 100));
                  const done = latest.mrr >= target;
                  return (
                    <div key={label}>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className={`text-xs font-bold ${done ? 'text-emerald-400' : color}`}>
                          {done ? '✅ ' : ''}{label}
                        </span>
                        <span className="text-white/30 text-[9px]">{pct}%</span>
                      </div>
                      <div className="h-2 bg-white/6 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${done ? 'bg-emerald-400' : bar} transition-all duration-700`}
                          style={{ width: `${pct}%` }} />
                      </div>
                      {!done && <p className="text-white/20 text-[8px] mt-1">${(target - latest.mrr).toLocaleString()} to go</p>}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ── COHORTS ───────────────────────────────────────────────── */}
        {view === 'cohorts' && (
          <div className="space-y-4">
            <p className="text-white/40 text-sm">Retention by signup cohort. Numbers show % of customers still active each month.</p>
            <div className="rounded-2xl border border-white/8 bg-white/2 p-5 overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="text-left text-[9px] font-bold text-white/25 uppercase tracking-widest pb-3 pr-4 whitespace-nowrap">Cohort</th>
                    <th className="text-center text-[9px] font-bold text-white/25 uppercase tracking-widest pb-3 px-1">Size</th>
                    {['M0','M1','M2','M3','M4'].map(m => (
                      <th key={m} className="text-center text-[9px] font-bold text-white/25 uppercase tracking-widest pb-3 px-1">{m}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="space-y-1">
                  {COHORTS.map(c => (
                    <tr key={c.month}>
                      <td className="pr-4 py-1.5 text-white/60 text-xs font-semibold">{c.month}</td>
                      <td className="text-center py-1.5 px-1">
                        <span className="text-white/30 text-xs">{c.size}</span>
                      </td>
                      {[c.m1, c.m2, c.m3, c.m4, c.m5].map((val, i) => (
                        <td key={i} className="px-1 py-1.5 text-center">
                          <CohortCell value={val} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="grid grid-cols-3 gap-4">
              {[['M1 Retention', '92%', 'text-emerald-400'], ['M3 Retention', '81%', 'text-indigo-400'], ['M5 Retention', '50%', 'text-yellow-400']].map(([l, v, c]) => (
                <div key={l} className="p-4 rounded-2xl bg-white/2 border border-white/6 text-center">
                  <p className={`text-2xl font-black ${c}`}>{v}</p>
                  <p className="text-white/30 text-xs mt-1">{l}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── CUSTOMERS ─────────────────────────────────────────────── */}
        {view === 'customers' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest">{CUSTOMERS.length} Active Accounts</p>
              <p className="text-emerald-400 text-xs font-bold">{fmt(CUSTOMERS.reduce((s, c) => s + c.mrr, 0))} total MRR</p>
            </div>
            <div className="space-y-2">
              {CUSTOMERS.sort((a, b) => b.mrr - a.mrr).map((c, i) => {
                const plan = PLANS.find(p => p.name === c.plan) ?? PLANS[0];
                return (
                  <div key={c.name} className={`flex items-center gap-4 p-4 rounded-2xl border ${
                    c.status === 'at-risk' ? 'border-yellow-500/20 bg-yellow-500/4' : 'border-white/6 bg-white/2'
                  } hover:border-white/10 transition-all`}>
                    <span className="text-white/15 text-[9px] font-mono w-4 shrink-0">#{i+1}</span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-white text-sm font-semibold">{c.name}</p>
                        {c.status === 'at-risk' && (
                          <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-yellow-500/15 border border-yellow-500/20 text-yellow-400">AT RISK</span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className={`text-[9px] font-bold ${plan.color}`}>{c.plan}</span>
                        <span className="text-white/20 text-[9px]">{c.months} months</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-emerald-400 font-bold text-sm">{fmt(c.mrr)}<span className="text-white/20 text-[9px]">/mo</span></p>
                      <p className="text-white/25 text-[9px]">LTV {fmtK(c.ltv)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
