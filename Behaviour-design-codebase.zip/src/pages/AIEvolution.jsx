/**
 * AIEvolution — Self-Improving AI Behavior Engine Dashboard
 * Visual: Observe → Analyze → Adapt → Re-test → Improve cycle
 * Shows the evolution state for the current user with live adaptation log.
 */
import { useState, useEffect } from 'react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus } from '../engine/core';
import {
  loadEvolution, saveEvolution, observeSession, analyzeProfile,
  evolveAI, getAdaptationMessage, getEvolutionSummary,
} from '../engine/evolution';
import {
  Cpu, Eye, Brain, Zap, RefreshCw, TrendingUp, Activity,
  CheckCircle2, Clock, Target, BarChart2, Flame, Shield,
  ArrowRight, ChevronRight, Database, Play,
} from 'lucide-react';

// ── Cycle step card ───────────────────────────────────────────────────────────
function CycleStep({ step, label, desc, color, bg, border, active }) {
  return (
    <div className={`p-3 rounded-xl border transition-all ${active ? `${bg} ${border}` : 'bg-white/2 border-white/5 opacity-50'}`}>
      <p className={`text-[9px] font-black uppercase tracking-widest mb-1 ${active ? color : 'text-white/20'}`}>{step}</p>
      <p className={`text-xs font-bold ${active ? 'text-white' : 'text-white/25'}`}>{label}</p>
      <p className={`text-[9px] mt-0.5 leading-snug ${active ? 'text-white/40' : 'text-white/15'}`}>{desc}</p>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AIEvolution() {
  const { getTodayScore, getWeekScores, activeUserId, plugins, activePlugin } = useBehavior();
  const { user, tenantInfo } = useAuth();
  const [evoState, setEvoState] = useState(null);
  const [summary,  setSummary]  = useState(null);
  const [adaptMsgs, setAdaptMsgs] = useState([]);
  const [evolLog,  setEvolLog]  = useState([]);
  const [cycleStep, setCycleStep] = useState(0); // 0=observe 1=analyze 2=adapt 3=retest 4=improve
  const [running, setRunning]   = useState(false);
  const [showRaw, setShowRaw]   = useState(false);

  const score      = getTodayScore(activeUserId);
  const status     = getStatus(score);
  const weekScores = getWeekScores(activeUserId);
  const plug       = plugins[activePlugin];

  useEffect(() => {
    const uid = user?.id ?? activeUserId ?? 1;
    const tid = tenantInfo?.id ?? 'default';
    let state = loadEvolution(uid, tid);

    // Feed today's data into observations
    const now = new Date();
    const timestamps = weekScores
      .map((s, i) => {
        if (s === 0) return null;
        const d = new Date();
        d.setDate(d.getDate() - (6 - i));
        d.setHours(9 + Math.floor(Math.random() * 8));
        return d.toISOString();
      })
      .filter(Boolean);

    const taskResults = (plug?.tasks ?? []).map(t => ({
      taskId: t.id, category: t.label, completed: score > 20,
    }));

    state = observeSession(state, {
      actionsLogged: weekScores.filter(s => s > 0).length,
      missedToday: score === 0,
      actionTimestamps: timestamps,
      taskResults,
    });
    state = analyzeProfile(state);
    saveEvolution(state);

    const summ = getEvolutionSummary(state);
    const msgs = getAdaptationMessage(state);

    setEvoState(state);
    setSummary(summ);
    setAdaptMsgs(msgs);
    setEvolLog(state.evolutionLog ?? []);
    setCycleStep(summ.totalSessions >= 3 ? 4 : summ.totalSessions >= 2 ? 3 : summ.totalSessions >= 1 ? 2 : 1);
  }, [score, status]);

  const runEvolution = () => {
    if (!evoState || running) return;
    setRunning(true);
    let step = 0;
    const interval = setInterval(() => {
      setCycleStep(step);
      step++;
      if (step > 4) {
        clearInterval(interval);
        // Actually run the evolution
        const { state: newState, evolutionLog } = evolveAI(evoState);
        saveEvolution(newState);
        const newSumm = getEvolutionSummary(newState);
        const newMsgs = getAdaptationMessage(newState);
        setEvoState(newState);
        setSummary(newSumm);
        setAdaptMsgs(newMsgs);
        setEvolLog(newState.evolutionLog ?? []);
        setRunning(false);
      }
    }, 600);
  };

  const resetEvolution = () => {
    const uid = user?.id ?? activeUserId ?? 1;
    const tid = tenantInfo?.id ?? 'default';
    const fresh = { userId: uid, tenantId: tid };
    saveEvolution(fresh);
    setEvoState(fresh);
    setSummary(null);
    setAdaptMsgs([]);
    setEvolLog([]);
    setCycleStep(0);
  };

  const CYCLE_STEPS = [
    { step: '01', label: 'Observe',  desc: 'Collect sessions, actions, timing, task results',      color: 'text-indigo-400',  bg: 'bg-indigo-500/10',  border: 'border-indigo-500/20'  },
    { step: '02', label: 'Analyze',  desc: 'Derive patterns, consistency score, drop profile',    color: 'text-cyan-400',    bg: 'bg-cyan-500/10',    border: 'border-cyan-500/20'    },
    { step: '03', label: 'Adapt',    desc: 'Adjust task size, timing, and coaching tone',         color: 'text-purple-400',  bg: 'bg-purple-500/10',  border: 'border-purple-500/20'  },
    { step: '04', label: 'Re-test',  desc: 'Apply changes and observe new behavioral response',    color: 'text-orange-400',  bg: 'bg-orange-500/10',  border: 'border-orange-500/20'  },
    { step: '05', label: 'Improve',  desc: 'Outcomes improve. Cycle restarts with new baseline',  color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  ];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-8">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={15} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">AI Evolution Engine</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Self-Improving Behavior AI</h1>
            <p className="text-white/35 text-sm">
              Observe → Analyze → Adapt → Re-test → Improve. Running for{' '}
              <span className="text-white/60 font-semibold">{summary?.totalSessions ?? 0} sessions</span>.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowRaw(p => !p)}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/4 border border-white/8 text-white/30 hover:text-white/55 text-xs">
              <Database size={11} /> {showRaw ? 'Hide' : 'Raw'}
            </button>
            <button onClick={resetEvolution}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/8 border border-red-500/15 text-red-400/60 hover:text-red-400 text-xs">
              <RefreshCw size={11} /> Reset
            </button>
          </div>
        </div>

        {/* Evolution Cycle Visualizer */}
        <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-white font-bold text-sm">Evolution Cycle</p>
            <button onClick={runEvolution} disabled={running}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                running
                  ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-white shadow-lg shadow-emerald-500/20'
              }`}>
              {running
                ? <><RefreshCw size={12} className="animate-spin" /> Running…</>
                : <><Play size={12} /> Run Cycle</>}
            </button>
          </div>

          {/* Cycle steps */}
          <div className="grid grid-cols-5 gap-2">
            {CYCLE_STEPS.map((s, i) => (
              <CycleStep key={s.step} {...s} active={cycleStep >= i} />
            ))}
          </div>

          {/* Progress bar */}
          <div className="h-1 bg-white/8 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 rounded-full transition-all duration-700"
              style={{ width: `${(cycleStep / 4) * 100}%` }} />
          </div>
        </div>

        {/* KPI row */}
        {summary && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { label: 'Consistency Score', value: `${summary.consistencyScore}%`,   color: summary.consistencyScore >= 70 ? 'text-green-400' : summary.consistencyScore >= 40 ? 'text-yellow-400' : 'text-red-400', icon: Activity },
              { label: 'Sessions Observed', value: summary.totalSessions,            color: 'text-indigo-400',  icon: Eye       },
              { label: 'Actions Logged',    value: summary.totalActionsLogged,       color: 'text-purple-400', icon: CheckCircle2 },
              { label: 'Adaptations Made',  value: summary.adaptationsApplied,      color: 'text-emerald-400',icon: Zap       },
            ].map(({ label, value, color, icon: Icon }) => (
              <div key={label} className="p-4 rounded-xl bg-white/2 border border-white/6">
                <Icon size={13} className={`${color} mb-2`} />
                <p className={`text-2xl font-black ${color}`}>{value}</p>
                <p className="text-white/25 text-[10px] mt-0.5">{label}</p>
              </div>
            ))}
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-6">

          {/* LEFT — Observed Profile */}
          <div className="space-y-4">
            <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Observed Behavioral Data</p>

            {summary ? (
              <div className="space-y-2">
                {[
                  { label: 'Consistency',       value: summary.consistencyScore >= 70 ? 'High' : summary.consistencyScore >= 40 ? 'Medium' : 'Low', icon: BarChart2 },
                  { label: 'Drop Pattern',      value: summary.dropPattern ?? 'Analyzing…',   icon: TrendingUp },
                  { label: 'Best Time',         value: summary.bestTime ?? 'Analyzing…',      icon: Clock      },
                  { label: 'Weak Area',         value: summary.weakArea ?? 'Analyzing…',      icon: Target     },
                  { label: 'Feedback Style',    value: summary.feedbackStyle ?? 'Analyzing…', icon: Brain      },
                  { label: 'Pace Profile',      value: summary.paceProfile ?? 'Analyzing…',   icon: Flame      },
                  { label: 'Task Difficulty',   value: summary.taskDifficulty,                 icon: Shield     },
                ].map(({ label, value, icon: Icon }) => (
                  <div key={label} className="flex items-center justify-between py-2.5 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      <Icon size={12} className="text-white/20" />
                      <span className="text-white/40 text-xs">{label}</span>
                    </div>
                    <span className={`text-xs font-semibold capitalize ${
                      value.includes('high') || value === 'responsive' || value === 'elevated'   ? 'text-emerald-400' :
                      value.includes('low')  || value === 'resistant' || value === 'slow-starter'? 'text-red-400' :
                      value === 'Analyzing…'                                                     ? 'text-white/15' :
                      'text-white/65'
                    }`}>{value}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 rounded-xl bg-white/2 border border-white/6 text-center">
                <Eye size={24} className="mx-auto text-white/15 mb-2" />
                <p className="text-white/25 text-sm">Observing behavior…</p>
                <p className="text-white/15 text-xs mt-1">Log actions across 3 sessions to build your profile</p>
              </div>
            )}

            {/* Raw state viewer */}
            {showRaw && evoState && (
              <div className="p-3 rounded-xl bg-black/30 border border-white/6">
                <p className="text-white/20 text-[9px] uppercase tracking-widest mb-2">Evolution State (JSON)</p>
                <pre className="text-[8px] text-emerald-400/60 overflow-x-auto scrollbar-hide leading-relaxed max-h-48">
                  {JSON.stringify({
                    profile: evoState.profile,
                    adaptations: evoState.adaptations,
                    observations: {
                      totalSessions: evoState.observations?.totalSessions,
                      totalActionsLogged: evoState.observations?.totalActionsLogged,
                      avgResponseTime: evoState.observations?.avgResponseTime,
                    },
                  }, null, 2)}
                </pre>
              </div>
            )}
          </div>

          {/* RIGHT — Adaptations + Evolution Log */}
          <div className="space-y-4">
            <p className="text-white/40 text-xs font-bold uppercase tracking-widest">AI Adaptations Applied</p>

            {adaptMsgs.length === 0 ? (
              <div className="p-5 rounded-xl bg-white/2 border border-white/5 text-center space-y-2">
                <Cpu size={20} className="mx-auto text-white/15" />
                <p className="text-white/25 text-sm">No adaptations yet</p>
                <p className="text-white/15 text-xs">Run 3+ sessions for the AI to begin adapting your system</p>
                <button onClick={runEvolution} disabled={running}
                  className="mt-2 flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mx-auto">
                  <Play size={11} /> Trigger Evolution Cycle
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {adaptMsgs.map((msg, i) => (
                  <div key={i} className={`p-4 rounded-xl ${msg.bg} border ${msg.border}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-base">{msg.icon}</span>
                      <p className={`text-xs font-bold ${msg.color}`}>{msg.title}</p>
                      <span className={`ml-auto text-[8px] font-black px-1.5 py-0.5 rounded-full ${msg.bg} ${msg.color} border ${msg.border}`}>
                        ACTIVE
                      </span>
                    </div>
                    <p className="text-white/50 text-xs leading-snug">{msg.body}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Evolution Log */}
            {evolLog.length > 0 && (
              <div className="space-y-2">
                <p className="text-white/25 text-[9px] uppercase tracking-widest">Evolution Log</p>
                {evolLog.slice(-5).reverse().map((entry, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-white/2 border border-white/5">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <div>
                      <p className="text-white/55 text-xs font-semibold">{entry.change}</p>
                      <p className="text-white/20 text-[9px] mt-0.5">Reason: {entry.reason}</p>
                      <p className="text-white/15 text-[8px]">{new Date(entry.date).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* The Evolve AI function — code concept */}
        <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/4 p-5 lg:p-6">
          <div className="flex items-center gap-2 mb-4">
            <Cpu size={14} className="text-emerald-400" />
            <p className="text-emerald-400 font-bold text-sm">The evolveAI() Function</p>
          </div>
          <div className="rounded-xl bg-black/40 border border-white/8 p-4 mb-4">
            <pre className="text-[10px] text-emerald-400/80 leading-relaxed overflow-x-auto scrollbar-hide">
{`function evolveAI(memory) {
  // Rule 1: Low consistency → reduce task load
  if (memory.consistencyScore < 30) {
    adapt({ taskSize: 'reduce' });
    log("Reduced to 1 task. Build habit first.");
  }

  // Rule 2: Morning drop pattern → shift timing
  if (memory.dropPattern === 'morning') {
    adapt({ timing: 'afternoon' });
    log("Moved tasks to afternoon. Better performance.");
  }

  // Rule 3: High consistency → increase challenge
  if (memory.consistencyScore >= 80) {
    adapt({ taskSize: 'increase' });
    log("Elevated difficulty. High performer detected.");
  }

  // Rule 4: Resistant to feedback → change tone
  if (memory.responseToFeedback === 'resistant') {
    adapt({ coachTone: 'motivation' });
    log("Switched to supportive coaching. Resistance detected.");
  }

  return adaptedSystem;
}`}
            </pre>
          </div>
          <p className="text-white/35 text-sm">
            <span className="text-white/70 font-semibold">Why this is the moat: </span>
            Every competitor gives the same coaching to everyone. This system builds a unique behavioral model per user, adapts its own logic, and improves coaching quality session by session. After 30 days, no two users have the same experience.
          </p>
        </div>

      </div>
    </div>
  );
}
