import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Zap, TrendingUp, CheckCircle2, ArrowRight, ChevronRight,
  Users, BarChart2, Bot, Shield, Star, X, Check,
} from 'lucide-react';
import { useAuth } from '../store/AuthContext';

// ── Step IDs ─────────────────────────────────────────────────────────────────
const STEPS = { LANDING: 'landing', PITCH: 'pitch', PRICING: 'pricing', SIGNUP: 'signup', WELCOME: 'welcome' };

// ── Pricing plans ─────────────────────────────────────────────────────────────
const PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: '$5',
    priceZAR: 'R100',
    period: '/ month',
    highlight: false,
    tag: '',
    desc: 'For solo operators who want to install daily discipline.',
    features: [
      'Sales Execution Engine',
      'Daily task loop (4 action types)',
      'Score tracking (GREEN / YELLOW / RED)',
      'Script library (4 scripts)',
      'AI feedback on every action',
    ],
    missing: ['Team leaderboard', 'Manager dashboard', 'Custom scripts'],
    cta: 'Start Free Trial',
  },
  {
    id: 'pro',
    name: 'Pro',
    price: '$10',
    priceZAR: 'R200',
    period: '/ month',
    highlight: true,
    tag: 'Most Popular',
    desc: 'For reps who want accountability and performance data.',
    features: [
      'Everything in Starter',
      'Team leaderboard',
      '7-day performance analysis',
      'Recovery protocol alerts',
      'Customizable daily targets',
      'Priority AI feedback',
    ],
    missing: ['Manager dashboard', 'Multi-team support'],
    cta: 'Get Pro Access',
  },
  {
    id: 'team',
    name: 'Team',
    price: '$49',
    priceZAR: 'R999',
    period: '/ month',
    highlight: false,
    tag: 'Best Value',
    desc: 'For sales managers who need team-wide execution visibility.',
    features: [
      'Everything in Pro',
      'Up to 10 team members',
      'Manager dashboard',
      'Automated daily notifications',
      'Plugin system (Sales, Fitness, School)',
      'Custom branding',
    ],
    missing: [],
    cta: 'Start Team Trial',
  },
];

const TESTIMONIALS = [
  { name: 'Alex R.', role: 'SDR, NovaSales',    score: 47, quote: 'I went from 12 outreach/day to 28 in 2 weeks. The system doesn\'t let you hide.' },
  { name: 'Sam O.',  role: 'Account Exec',       score: 52, quote: 'Hit target 6 days in a row. Never done that before. The RED status scared me into action.' },
  { name: 'Casey N.',role: 'Sales Manager',      score: 61, quote: 'My team\'s average score went from 22 to 38 in the first month. The leaderboard does the coaching.' },
];

// ── Sub-screens ───────────────────────────────────────────────────────────────

function Landing({ onNext }) {
  return (
    <div className="min-h-screen bg-[#070b14] flex flex-col">
      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center text-center px-6 py-16 max-w-2xl mx-auto">
        <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center mb-6">
          <Zap size={26} className="text-indigo-400" />
        </div>

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          Now live · Sales Execution Engine
        </div>

        <h1 className="text-4xl md:text-5xl font-black text-white leading-tight mb-4">
          Stop knowing what to do.<br />
          <span className="text-indigo-400">Start doing it.</span>
        </h1>

        <p className="text-white/50 text-lg leading-relaxed mb-8 max-w-lg">
          Behavior Engine is a daily execution system for salespeople. It tells you exactly what to do, tracks whether you did it, and holds you accountable with your score.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 w-full max-w-sm">
          <button
            onClick={() => onNext(STEPS.PITCH)}
            className="flex-1 py-3.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/25"
          >
            See How It Works <ArrowRight size={15} />
          </button>
          <button
            onClick={() => onNext(STEPS.PRICING)}
            className="flex-1 py-3.5 rounded-xl glass text-white/60 hover:text-white/90 font-medium text-sm transition-all"
          >
            View Pricing
          </button>
        </div>

        {/* Social proof strip */}
        <div className="flex items-center gap-2 mt-8 text-white/25 text-xs">
          <div className="flex -space-x-1.5">
            {['AR','JC','SO','TK','CN'].map((a) => (
              <div key={a} className="w-6 h-6 rounded-full bg-indigo-500/40 border border-white/10 flex items-center justify-center text-[9px] font-bold text-indigo-300">{a}</div>
            ))}
          </div>
          <span>47 reps active this week · avg score 38 pts</span>
        </div>
      </div>

      {/* Features strip */}
      <div className="border-t border-white/6 bg-[#0b0f1a]/50">
        <div className="max-w-3xl mx-auto px-6 py-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: TrendingUp, label: 'Real-time scoring', color: 'text-indigo-400' },
            { icon: Bot,        label: 'AI feedback loop',  color: 'text-emerald-400' },
            { icon: Users,      label: 'Team leaderboard',  color: 'text-amber-400'   },
            { icon: Shield,     label: 'Rule enforcement',  color: 'text-purple-400'  },
          ].map(({ icon: Icon, label, color }) => (
            <div key={label} className="flex flex-col items-center gap-2 text-center">
              <Icon size={20} className={color} />
              <p className="text-white/40 text-xs">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Pitch({ onNext }) {
  const steps = [
    { icon: '📱', title: 'App shows your task', body: 'Four daily actions: Outreach, Conversation, Follow-Up, Close. The app tells you exactly what to do and gives you the script.' },
    { icon: '⚡', title: 'You execute it', body: 'Use the provided script. Tap Done. One action at a time. No thinking required — just execution.' },
    { icon: '📊', title: 'Score updates live', body: 'Hit 40 points = GREEN. Below 25 = RED. Your score is visible to your team. Social pressure drives behavior.' },
    { icon: '🤖', title: 'AI gives feedback', body: 'After every action, the AI engine gives you specific feedback: volume alerts, conversion coaching, closing prompts.' },
    { icon: '🔁', title: 'Recovery mode activates', body: 'Fall below target? The system switches to frictionless mode — one small action, one script, no overwhelm.' },
    { icon: '📈', title: 'Consistency compounds', body: 'Week 1: discipline. Week 2: habit. Month 1: results. The system doesn\'t change — your behavior does.' },
  ];

  return (
    <div className="min-h-screen bg-[#070b14] px-6 py-10 max-w-2xl mx-auto">
      <button onClick={() => onNext(STEPS.LANDING)} className="text-white/30 text-sm flex items-center gap-1 mb-8 hover:text-white/60">
        ← Back
      </button>

      <h2 className="text-3xl font-black text-white mb-2">The Execution Loop</h2>
      <p className="text-white/40 text-base mb-10">This is why it works. Not motivation. Not training. An enforced daily loop.</p>

      <div className="space-y-4 mb-10">
        {steps.map((s, i) => (
          <div key={i} className="glass rounded-2xl p-5 flex gap-4">
            <div className="text-2xl shrink-0 mt-0.5">{s.icon}</div>
            <div>
              <p className="text-white font-bold text-sm mb-1">Step {i+1}: {s.title}</p>
              <p className="text-white/45 text-sm leading-relaxed">{s.body}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Testimonials */}
      <h3 className="text-white/50 text-xs uppercase tracking-widest mb-4">What users say</h3>
      <div className="space-y-3 mb-10">
        {TESTIMONIALS.map((t) => (
          <div key={t.name} className="glass rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex gap-0.5">{[1,2,3,4,5].map((s) => <Star key={s} size={10} className="text-yellow-400 fill-yellow-400" />)}</div>
              <span className="text-white/40 text-xs">{t.name} · {t.role}</span>
              <span className="ml-auto text-green-400 text-xs font-bold">{t.score} pts/day</span>
            </div>
            <p className="text-white/65 text-sm italic">"{t.quote}"</p>
          </div>
        ))}
      </div>

      <button
        onClick={() => onNext(STEPS.PRICING)}
        className="w-full py-4 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold transition-all flex items-center justify-center gap-2"
      >
        See Pricing <ArrowRight size={15} />
      </button>
    </div>
  );
}

function Pricing({ onNext }) {
  const [selected, setSelected] = useState('pro');
  const [currency, setCurrency] = useState('usd');

  return (
    <div className="min-h-screen bg-[#070b14] px-6 py-10 max-w-3xl mx-auto">
      <button onClick={() => onNext(STEPS.PITCH)} className="text-white/30 text-sm flex items-center gap-1 mb-8 hover:text-white/60">
        ← Back
      </button>

      <div className="text-center mb-10">
        <h2 className="text-3xl font-black text-white mb-2">Pick your plan</h2>
        <p className="text-white/40 text-base mb-5">7-day free trial on all plans. No card needed.</p>
        {/* Currency toggle */}
        <div className="inline-flex p-1 bg-white/5 rounded-xl">
          {[['usd','USD ($)'],['zar','ZAR (R)']].map(([k,l]) => (
            <button key={k} onClick={() => setCurrency(k)}
              className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${currency===k ? 'bg-indigo-500 text-white' : 'text-white/40 hover:text-white/70'}`}>
              {l}
            </button>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4 mb-8">
        {PLANS.map((plan) => (
          <button
            key={plan.id}
            onClick={() => setSelected(plan.id)}
            className={`text-left rounded-2xl p-5 border transition-all relative ${
              selected === plan.id
                ? 'border-indigo-500/50 bg-indigo-500/8'
                : 'glass border-white/8 hover:border-white/15'
            }`}
          >
            {plan.tag && (
              <span className="absolute -top-2.5 left-4 px-2.5 py-0.5 rounded-full bg-indigo-500 text-white text-[10px] font-bold">
                {plan.tag}
              </span>
            )}
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-white font-bold text-sm">{plan.name}</p>
                <div className="flex items-end gap-1 mt-0.5">
                  <span className="text-2xl font-black text-white">{currency === 'usd' ? plan.price : plan.priceZAR}</span>
                  <span className="text-white/30 text-xs pb-1">{plan.period}</span>
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${selected === plan.id ? 'border-indigo-400 bg-indigo-500' : 'border-white/20'}`}>
                {selected === plan.id && <Check size={10} className="text-white" />}
              </div>
            </div>
            <p className="text-white/40 text-xs mb-4">{plan.desc}</p>
            <div className="space-y-1.5">
              {plan.features.map((f) => (
                <div key={f} className="flex items-start gap-2">
                  <CheckCircle2 size={11} className="text-green-400 mt-0.5 shrink-0" />
                  <span className="text-white/60 text-xs">{f}</span>
                </div>
              ))}
              {plan.missing.map((f) => (
                <div key={f} className="flex items-start gap-2 opacity-40">
                  <X size={11} className="text-white/30 mt-0.5 shrink-0" />
                  <span className="text-white/30 text-xs">{f}</span>
                </div>
              ))}
            </div>
          </button>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => onNext(STEPS.SIGNUP, selected)}
          className="flex-1 py-4 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/20"
        >
          Start Free Trial · {PLANS.find(p=>p.id===selected)?.name} <ArrowRight size={15} />
        </button>
      </div>
      <p className="text-white/20 text-xs text-center mt-3">No credit card needed · Cancel anytime</p>
    </div>
  );
}

function Signup({ plan, onNext }) {
  const { register, authError, setAuthError, tenants } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '', tenant: 'sales' });
  const [loading, setLoading] = useState(false);
  const set = (k) => (e) => { setForm((p) => ({ ...p, [k]: e.target.value })); setAuthError(''); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) { setAuthError('Enter your name.'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 700));
    const ok = register(form.name, form.email, form.password, form.tenant);
    setLoading(false);
    if (ok) onNext(STEPS.WELCOME);
  };

  const selectedPlan = PLANS.find(p => p.id === plan) ?? PLANS[1];

  return (
    <div className="min-h-screen bg-[#070b14] flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md">
        <button onClick={() => onNext(STEPS.PRICING)} className="text-white/30 text-sm flex items-center gap-1 mb-6 hover:text-white/60">
          ← Back
        </button>

        {/* Plan badge */}
        <div className="flex items-center gap-3 p-3 rounded-xl glass border border-indigo-500/20 mb-6">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center">
            <Zap size={14} className="text-indigo-400" />
          </div>
          <div className="flex-1">
            <p className="text-white text-xs font-semibold">{selectedPlan.name} Plan · 7-Day Free Trial</p>
            <p className="text-white/30 text-[10px]">Then {selectedPlan.price}/month · Cancel anytime</p>
          </div>
          <CheckCircle2 size={14} className="text-green-400" />
        </div>

        <h2 className="text-2xl font-black text-white mb-1">Create your account</h2>
        <p className="text-white/40 text-sm mb-6">Start your 7-day free trial. No card required.</p>

        {authError && (
          <div className="mb-4 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/25 text-red-300 text-sm">{authError}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {[
            { key: 'name',     label: 'Full Name',       type: 'text',     ph: 'Your full name'     },
            { key: 'email',    label: 'Work Email',       type: 'email',    ph: 'you@company.com'    },
            { key: 'password', label: 'Password',         type: 'password', ph: 'Create a password'  },
          ].map(({ key, label, type, ph }) => (
            <div key={key}>
              <label className="text-white/40 text-xs mb-1.5 block">{label}</label>
              <input
                type={type}
                placeholder={ph}
                value={form[key]}
                onChange={set(key)}
                required
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/20 focus:outline-none focus:border-indigo-500/50 transition-colors"
              />
            </div>
          ))}
          <div>
            <label className="text-white/40 text-xs mb-1.5 block">Organisation Type</label>
            <select value={form.tenant} onChange={set('tenant')} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-500/50 appearance-none">
              {Object.entries(tenants).map(([k, t]) => (
                <option key={k} value={k} className="bg-[#0b0f1a]">{t.icon} {t.name}</option>
              ))}
            </select>
          </div>
          <button type="submit" disabled={loading}
            className="w-full py-3.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-60 mt-2">
            {loading
              ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              : <><CheckCircle2 size={15} /> Activate Free Trial</>}
          </button>
        </form>

        <p className="text-white/20 text-xs text-center mt-4">By signing up you agree to our terms. No spam. Ever.</p>
      </div>
    </div>
  );
}

function Welcome({ onDone }) {
  const { user } = useAuth();
  const steps = [
    { icon: '💼', text: 'Open the Sales Engine from the sidebar' },
    { icon: '📋', text: 'Send your first outreach message using the script' },
    { icon: '✅', text: 'Tap "Log" — watch your score update live' },
    { icon: '📊', text: 'Hit 40 points today to go GREEN' },
  ];
  return (
    <div className="min-h-screen bg-[#070b14] flex items-center justify-center px-6">
      <div className="max-w-md w-full text-center">
        <div className="w-16 h-16 rounded-2xl bg-green-500/20 border border-green-500/30 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={30} className="text-green-400" />
        </div>
        <h2 className="text-3xl font-black text-white mb-2">You're in, {user?.name?.split(' ')[0]}.</h2>
        <p className="text-white/40 text-base mb-8">Your 7-day trial starts now. Here's your first mission:</p>
        <div className="space-y-3 mb-8 text-left">
          {steps.map((s, i) => (
            <div key={i} className="glass rounded-xl px-4 py-3 flex items-center gap-3">
              <span className="text-xl">{s.icon}</span>
              <p className="text-white/70 text-sm">Step {i+1}: {s.text}</p>
            </div>
          ))}
        </div>
        <button onClick={onDone}
          className="w-full py-4 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/25">
          Enter the System <ArrowRight size={15} />
        </button>
      </div>
    </div>
  );
}

// ── Main Onboarding container ─────────────────────────────────────────────────
export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(STEPS.LANDING);
  const [plan, setPlan] = useState('pro');

  const goTo = (next, selectedPlan) => {
    if (selectedPlan) setPlan(selectedPlan);
    setStep(next);
  };

  if (step === STEPS.LANDING)  return <Landing  onNext={goTo} />;
  if (step === STEPS.PITCH)    return <Pitch    onNext={goTo} />;
  if (step === STEPS.PRICING)  return <Pricing  onNext={goTo} />;
  if (step === STEPS.SIGNUP)   return <Signup   plan={plan} onNext={goTo} />;
  if (step === STEPS.WELCOME)  return <Welcome  onDone={() => navigate('/sales')} />;
  return null;
}
