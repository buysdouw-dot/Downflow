import { useState } from 'react';
import {
  CreditCard, CheckCircle2, Zap, Shield, Users, BarChart2,
  Puzzle, Bot, ChevronRight, AlertCircle, Crown,
} from 'lucide-react';
import { useAuth } from '../store/AuthContext';
import MobileHeader from '../components/MobileHeader';

const PLANS = [
  {
    key: 'starter',
    name: 'Starter',
    emoji: '🟢',
    priceMonthly: 5,
    priceYearly: 4,
    perUser: true,
    userLimit: 10,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    borderActive: 'border-emerald-500',
    features: [
      'Up to 10 users',
      'Core behavior engine',
      'Daily task tracking',
      'Score & status system',
      'Basic leaderboard',
      'Email support',
    ],
    missing: ['AI feedback engine', 'Plugin marketplace', 'Analytics API', 'Custom plugins'],
  },
  {
    key: 'pro',
    name: 'Pro',
    emoji: '🔵',
    priceMonthly: 15,
    priceYearly: 12,
    perUser: true,
    userLimit: 50,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    borderActive: 'border-indigo-500',
    popular: true,
    features: [
      'Up to 50 users',
      'Everything in Starter',
      'AI feedback engine',
      'Advanced leaderboards',
      'Performance analytics',
      'Plugin access (3 plugins)',
      'Priority support',
    ],
    missing: ['Custom plugins', 'Analytics API', 'White-label'],
  },
  {
    key: 'enterprise',
    name: 'Enterprise',
    emoji: '🔴',
    priceMonthly: 50,
    priceYearly: 40,
    perUser: true,
    userLimit: null,
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    borderActive: 'border-purple-500',
    features: [
      'Unlimited users',
      'Everything in Pro',
      'Plugin marketplace access',
      'Custom plugin creation',
      'Full analytics + API access',
      'Dedicated account manager',
      'White-label option',
      'SLA guarantee',
    ],
    missing: [],
  },
];

const ADD_ONS = [
  {
    name: 'AI Coaching',
    description: 'OpenAI-powered personalized coaching and feedback for every user.',
    price: 99,
    icon: Bot,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
  },
  {
    name: 'Custom Plugins',
    description: 'Build and deploy custom behavior modules for your specific workflow.',
    price: 199,
    icon: Puzzle,
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
  },
  {
    name: 'Analytics Pack',
    description: 'Advanced reporting, CSV exports, and REST API access to all metrics.',
    price: 149,
    icon: BarChart2,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
  },
];

export default function Billing() {
  const { user, tenantInfo } = useAuth();
  const [billing, setBilling] = useState('monthly');
  const [currentPlan] = useState('pro'); // simulated current plan
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [activeAddOns, setActiveAddOns] = useState(['AI Coaching']);

  const teamSize = 7; // simulated
  const monthlyTotal = PLANS.find(p => p.key === currentPlan)?.priceMonthly * teamSize ?? 0;

  return (
    <div className="max-w-4xl mx-auto">
      <MobileHeader title="Billing" />

      {/* Desktop header */}
      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <CreditCard size={16} className="text-indigo-400" />
            <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">Billing & Subscriptions</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Plans & Billing</h1>
          <p className="text-white/35 text-sm mt-0.5">{tenantInfo?.icon} {tenantInfo?.name} · Stripe-secured</p>
        </div>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-6">
        {/* Current plan summary */}
        <div className="glass rounded-xl p-5 border border-indigo-500/25">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center">
                <Zap size={14} className="text-indigo-400" />
              </div>
              <div>
                <p className="text-white font-semibold text-sm">Current Plan</p>
                <p className="text-white/35 text-xs">Renews automatically · Stripe billing</p>
              </div>
            </div>
            <span className="text-[10px] font-bold text-green-400 bg-green-500/10 px-2.5 py-1 rounded-full border border-green-500/20">
              ACTIVE
            </span>
          </div>
          <div className="grid grid-cols-3 gap-4 py-3 border-t border-b border-white/6">
            <div>
              <p className="text-white/30 text-xs mb-0.5">Plan</p>
              <p className="text-indigo-400 font-bold text-sm">Pro</p>
            </div>
            <div>
              <p className="text-white/30 text-xs mb-0.5">Team Size</p>
              <p className="text-white font-bold text-sm">{teamSize} users</p>
            </div>
            <div>
              <p className="text-white/30 text-xs mb-0.5">Monthly Total</p>
              <p className="text-white font-bold text-sm">${monthlyTotal}/mo</p>
            </div>
          </div>
          <div className="flex items-center justify-between mt-3">
            <div className="flex items-center gap-2">
              <AlertCircle size={12} className="text-white/25" />
              <p className="text-white/30 text-xs">Next billing date: May 23, 2026</p>
            </div>
            <button className="text-indigo-400 text-xs hover:text-indigo-300 flex items-center gap-1">
              View invoices <ChevronRight size={10} />
            </button>
          </div>
        </div>

        {/* Billing toggle */}
        <div className="flex items-center gap-3">
          <div className="flex p-1 bg-white/5 rounded-xl">
            {[['monthly', 'Monthly'], ['yearly', 'Yearly']].map(([k, l]) => (
              <button
                key={k}
                onClick={() => setBilling(k)}
                className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${billing === k ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}
              >
                {l}
              </button>
            ))}
          </div>
          {billing === 'yearly' && (
            <span className="text-xs font-semibold text-green-400 bg-green-500/10 px-2 py-1 rounded-full border border-green-500/20">
              Save 20%
            </span>
          )}
        </div>

        {/* Plans grid */}
        <div className="grid lg:grid-cols-3 gap-4">
          {PLANS.map((plan) => {
            const price = billing === 'yearly' ? plan.priceYearly : plan.priceMonthly;
            const isActive = plan.key === currentPlan;
            const isSelected = selectedPlan === plan.key;

            return (
              <div
                key={plan.key}
                className={`relative glass rounded-xl p-5 border transition-all cursor-pointer ${
                  isSelected ? plan.borderActive + ' ring-1 ring-indigo-500/20' :
                  isActive ? 'border-indigo-500/40' : plan.border
                }`}
                onClick={() => setSelectedPlan(isSelected ? null : plan.key)}
              >
                {plan.popular && (
                  <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                    <span className="text-[10px] font-bold bg-indigo-500 text-white px-3 py-0.5 rounded-full">
                      MOST POPULAR
                    </span>
                  </div>
                )}
                {isActive && (
                  <div className="absolute top-3 right-3">
                    <span className="text-[9px] font-bold text-indigo-400 bg-indigo-500/15 px-2 py-0.5 rounded-full border border-indigo-500/20">
                      CURRENT
                    </span>
                  </div>
                )}

                <div className="mb-4">
                  <span className="text-lg">{plan.emoji}</span>
                  <p className="text-white font-bold text-base mt-1">{plan.name}</p>
                  <p className="text-white/30 text-xs">
                    {plan.userLimit ? `Up to ${plan.userLimit} users` : 'Unlimited users'}
                  </p>
                </div>

                <div className="mb-4">
                  <span className={`text-3xl font-black ${plan.color}`}>${price}</span>
                  <span className="text-white/35 text-sm">/user/mo</span>
                  {billing === 'yearly' && (
                    <p className="text-white/25 text-[10px] mt-0.5">Billed annually</p>
                  )}
                </div>

                <div className="space-y-2 mb-4">
                  {plan.features.map((f) => (
                    <div key={f} className="flex items-center gap-2">
                      <CheckCircle2 size={11} className="text-green-400 shrink-0" />
                      <span className="text-white/65 text-xs">{f}</span>
                    </div>
                  ))}
                  {plan.missing.map((f) => (
                    <div key={f} className="flex items-center gap-2 opacity-40">
                      <div className="w-2.5 h-2.5 rounded-full border border-white/20 shrink-0" />
                      <span className="text-white/40 text-xs">{f}</span>
                    </div>
                  ))}
                </div>

                <button
                  className={`w-full py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-white/6 text-white/40 cursor-default'
                      : plan.key === 'enterprise'
                      ? `${plan.bg} ${plan.color} border ${plan.border} hover:bg-purple-500/20`
                      : 'bg-indigo-500 text-white hover:bg-indigo-400'
                  }`}
                  disabled={isActive}
                >
                  {isActive ? 'Current Plan' : plan.key === 'enterprise' ? 'Contact Sales' : `Upgrade to ${plan.name}`}
                </button>
              </div>
            );
          })}
        </div>

        {/* Add-ons */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3">Add-ons</p>
          <div className="space-y-3">
            {ADD_ONS.map(({ name, description, price, icon: Icon, color, bg, border }) => {
              const enabled = activeAddOns.includes(name);
              return (
                <div
                  key={name}
                  className={`glass rounded-xl p-4 border transition-all ${enabled ? border : 'border-white/8'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${enabled ? bg : 'bg-white/6'} flex items-center justify-center shrink-0`}>
                      <Icon size={16} className={enabled ? color : 'text-white/30'} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className={`text-sm font-semibold ${enabled ? 'text-white' : 'text-white/50'}`}>{name}</p>
                        {enabled && <span className="text-[9px] font-bold text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded-full">ACTIVE</span>}
                      </div>
                      <p className="text-white/30 text-xs mt-0.5">{description}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className={`text-sm font-bold ${enabled ? color : 'text-white/40'}`}>+${price}</p>
                      <p className="text-white/20 text-[10px]">/mo</p>
                    </div>
                    <button
                      onClick={() => setActiveAddOns(prev =>
                        enabled ? prev.filter(n => n !== name) : [...prev, name]
                      )}
                      className={`ml-2 relative w-10 shrink-0 rounded-full transition-all ${enabled ? 'bg-indigo-500' : 'bg-white/10'}`}
                      style={{ height: '22px' }}
                    >
                      <span
                        className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${enabled ? 'left-5' : 'left-0.5'}`}
                        style={{ width: '18px', height: '18px' }}
                      />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Summary */}
        <div className="glass rounded-xl p-5 border border-white/8">
          <p className="text-white/25 text-[10px] uppercase tracking-widest mb-3">Monthly Summary</p>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-white/60 text-sm">Pro Plan ({teamSize} users × $15)</span>
              <span className="text-white text-sm font-semibold">${teamSize * 15}/mo</span>
            </div>
            {activeAddOns.map(name => {
              const addon = ADD_ONS.find(a => a.name === name);
              return (
                <div key={name} className="flex items-center justify-between">
                  <span className="text-white/40 text-sm">{name}</span>
                  <span className="text-white/60 text-sm">+${addon?.price}/mo</span>
                </div>
              );
            })}
            <div className="flex items-center justify-between pt-3 border-t border-white/8">
              <span className="text-white font-bold text-sm">Total</span>
              <span className="text-indigo-400 font-bold text-lg">
                ${teamSize * 15 + activeAddOns.reduce((s, n) => s + (ADD_ONS.find(a => a.name === n)?.price ?? 0), 0)}/mo
              </span>
            </div>
          </div>
          <button className="w-full mt-4 py-3 rounded-xl bg-indigo-500 text-white text-sm font-semibold hover:bg-indigo-400 transition-all flex items-center justify-center gap-2">
            <CreditCard size={14} /> Update Billing · Powered by Stripe
          </button>
          <p className="text-white/20 text-xs text-center mt-2">256-bit SSL · Cancel anytime · Instant activation</p>
        </div>
      </div>
    </div>
  );
}
