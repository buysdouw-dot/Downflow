/**
 * AutonomousV7 — Multi-Agent Company OS
 * The company manages itself AND recommends strategic business decisions.
 * v6 ran the company. v7 RUNS the company + THINKS like a co-founder.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Cpu, Play, RefreshCw, Brain, TrendingUp, DollarSign,
  Wrench, Eye, Zap, ArrowRight, CheckCircle2, BarChart2,
  Lightbulb, Target, GitBranch, Layers, Users, Globe,
  AlertTriangle, Star, ChevronRight, Activity, Repeat,
  MessageSquare, Rocket, Shield, PieChart,
} from 'lucide-react';

// ── Agent definitions ──────────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'behavior', name: 'Behavior Agent', Icon: Eye,
    color: '#22d3ee', bg: 'rgba(6,182,212,0.06)', border: 'rgba(6,182,212,0.18)',
    schedule: 'Hourly',
    description: 'Reads all user execution data in real time. Calculates scores, detects drop patterns, dispatches signals.',
    kpi: 'Signal accuracy',
    stats: [{ label: 'Users Scanned', value: '312' }, { label: 'Drop Patterns', value: '23' }, { label: 'Signals Sent', value: '5' }],
    lastRun: 'Scanned 312 users. 23 drop patterns detected. HIGH/MED/LOW segments updated. Signals dispatched.',
  },
  {
    id: 'coach', name: 'Coach Agent', Icon: Brain,
    color: '#a78bfa', bg: 'rgba(139,92,246,0.06)', border: 'rgba(139,92,246,0.18)',
    schedule: 'Daily 8am + triggers',
    description: 'Generates personalized coaching per user using LLM. Routes via WhatsApp/email/push. Tracks message → score lift.',
    kpi: 'Score lift after message',
    stats: [{ label: 'Messages Sent', value: '189' }, { label: 'Avg Open Rate', value: '74%' }, { label: 'Score Lift', value: '+0.63' }],
    lastRun: 'Sent 189 coaching messages. 74% open rate. Correlation with score lift: +0.63.',
  },
  {
    id: 'growth', name: 'Growth Agent', Icon: TrendingUp,
    color: '#f472b6', bg: 'rgba(236,72,153,0.06)', border: 'rgba(236,72,153,0.18)',
    schedule: 'Every 12 hours',
    description: 'Detects viral candidates, posts insights to social, sends share prompts, monitors referrals, A/B tests copy.',
    kpi: 'Viral coefficient K',
    stats: [{ label: 'Posts Published', value: '4' }, { label: 'Viral Triggers', value: '31' }, { label: 'Referrals', value: '7' }],
    lastRun: 'Published 4 posts. 31 viral triggers fired. 7 referrals generated. A/B test running.',
  },
  {
    id: 'revenue', name: 'Revenue Agent', Icon: DollarSign,
    color: '#fbbf24', bg: 'rgba(245,158,11,0.06)', border: 'rgba(245,158,11,0.18)',
    schedule: 'Monday 9am',
    description: 'Detects upgrade-ready accounts, sends proposals with real usage data, triggers win-backs, adjusts pricing.',
    kpi: 'Net Revenue Retention',
    stats: [{ label: 'Proposals Sent', value: '9' }, { label: 'Conversions', value: '3' }, { label: 'MRR Added', value: '$540' }],
    lastRun: '9 upgrade-ready accounts found. 3 converted. $540 MRR added. 4 win-backs triggered.',
  },
  {
    id: 'system', name: 'System Agent', Icon: Wrench,
    color: '#34d399', bg: 'rgba(16,185,129,0.06)', border: 'rgba(16,185,129,0.18)',
    schedule: 'Sunday midnight',
    description: 'Analyzes 30 days of data, generates product improvement proposals, auto-applies high-confidence changes.',
    kpi: 'Product iteration velocity',
    stats: [{ label: 'Data Points', value: '4,800' }, { label: 'Auto-Applied', value: '5' }, { label: 'Flagged', value: '2' }],
    lastRun: 'Analyzed 4,800 data points. 7 improvements proposed. 5 auto-applied (conf > 80%). 2 flagged.',
  },
  {
    id: 'strategy', name: 'Strategy Agent', Icon: Lightbulb,
    color: '#fb923c', bg: 'rgba(251,146,60,0.06)', border: 'rgba(251,146,60,0.18)',
    schedule: 'Friday 6am (weekly)',
    description: 'Reads all agent data, market signals, competitive intel. Recommends next business moves like a co-founder.',
    kpi: 'Decision quality score',
    stats: [{ label: 'Recs Generated', value: '4' }, { label: 'Accepted', value: '3' }, { label: 'Revenue Impact', value: '+$2.4K' }],
    lastRun: '4 strategic recommendations. "Focus on team plans" accepted. Projected +$2.4K MRR this quarter.',
    isNew: true,
  },
];

// ── Strategy recommendations (v7 core feature) ───────────────────────────────
const STRATEGY_RECS = [
  {
    priority: 'HIGH',
    tag: 'Revenue',
    color: '#fbbf24',
    title: 'Launch Team Plans (5-seat bundles)',
    reasoning: 'Revenue Agent found 9 accounts with 4+ active users paying individual plans. Combined upgrade value: $1,800/mo.',
    action: 'Create a $99/mo Team plan (5 seats). Email those 9 accounts with their own engagement data.',
    impact: '+$1,800 MRR this month',
    confidence: 94,
  },
  {
    priority: 'HIGH',
    tag: 'Growth',
    color: '#f472b6',
    title: 'Double down on LinkedIn: fitness content',
    reasoning: 'Growth Agent data: fitness plugin posts generate 3.2× more referrals than sales posts this month.',
    action: 'Post 3 fitness performance content pieces per week for 4 weeks. Track referral delta.',
    impact: '+12 new signups/week',
    confidence: 81,
  },
  {
    priority: 'MED',
    tag: 'Product',
    color: '#22d3ee',
    title: 'Add WhatsApp coaching channel',
    reasoning: 'Coach Agent: email open rate 74%. WhatsApp messages in test cohort: 91% open, 2.1× score lift.',
    action: 'Integrate Twilio WhatsApp API. Route HIGH-risk users to WhatsApp coaching first.',
    impact: '+0.4 avg score per user',
    confidence: 87,
  },
  {
    priority: 'MED',
    tag: 'Retention',
    color: '#a78bfa',
    title: 'Launch "Streak Protection" feature',
    reasoning: 'System Agent: users who lose 3-day streak churn at 38% within 30 days. No current recovery mechanism.',
    action: 'Build streak protection: one missed day pauses (not breaks) streak. Launch as premium feature.',
    impact: '-12% churn rate',
    confidence: 76,
  },
];

// ── Self-op loop ───────────────────────────────────────────────────────────────
const LOOP = [
  { id: 'observe', label: 'Observe', Icon: Eye, color: '#22d3ee', desc: 'All 6 agents read full system state' },
  { id: 'analyze', label: 'Analyze', Icon: BarChart2, color: '#818cf8', desc: 'Patterns, anomalies, market signals detected' },
  { id: 'decide', label: 'Decide', Icon: Brain, color: '#a78bfa', desc: 'Strategy Agent synthesizes cross-agent intelligence' },
  { id: 'recommend', label: 'Recommend', Icon: Lightbulb, color: '#fb923c', desc: 'Business decisions surfaced to founder' },
  { id: 'deploy', label: 'Deploy', Icon: Zap, color: '#fbbf24', desc: 'Approved actions execute automatically' },
  { id: 'improve', label: 'Improve', Icon: TrendingUp, color: '#34d399', desc: 'System learns from outcomes — loop tightens' },
];

// ── v6 → v7 diff ──────────────────────────────────────────────────────────────
const EVOLUTION = [
  { v: 'v1', label: 'You build features manually', color: '#a1a1aa' },
  { v: 'v2', label: 'Product learns from usage data', color: '#818cf8' },
  { v: 'v3', label: 'Product improves itself (logic)', color: '#22d3ee' },
  { v: 'v4', label: 'Company runs itself (4 agents)', color: '#a78bfa' },
  { v: 'v5', label: 'Company evolves itself (5 agents)', color: '#fbbf24' },
  { v: 'v6', label: 'System replaces itself — indefinitely', color: '#f472b6' },
  { v: 'v7', label: 'System recommends next business moves', color: '#fb923c', active: true },
];

// ── Orchestrator code ──────────────────────────────────────────────────────────
const ORCHESTRATOR_CODE = `// ai/orchestrator.js — v7 Multi-Agent OS
require('dotenv').config({ path: '../.env' });
const cron     = require('node-cron');
const behavior = require('./agents/behavior');
const coach    = require('./agents/coach');
const growth   = require('./agents/growth');
const revenue  = require('./agents/revenue');
const system   = require('./agents/system');
const strategy = require('./agents/strategy'); // ← NEW in v7
const memory   = require('./memory');

// ── Agent schedule ─────────────────────────────────────────────────────────────
cron.schedule('0 * * * *',    () => run('behavior', behavior.run));
cron.schedule('0 8 * * *',    async () => {
  const { signals } = await behavior.run();
  run('coach', () => coach.run(signals));
});
cron.schedule('0 6,18 * * *', () => run('growth',  growth.run));
cron.schedule('0 9 * * 1',    () => run('revenue', revenue.run));
cron.schedule('0 0 * * 0',    () => run('system',  system.run));
cron.schedule('0 6 * * 5',    async () => {       // Friday 6am — v7 core
  const allData = memory.recallAll(7);             // last 7 days, all agents
  run('strategy', () => strategy.run(allData));
});

// ── Runner ─────────────────────────────────────────────────────────────────────
async function run(name, fn) {
  try {
    const result = await fn();
    memory.store(name, result);
    console.log(\`[\${name}]\`, result);
  } catch (e) {
    console.error(\`[\${name}] ERROR:\`, e.message);
  }
}`;

const STRATEGY_CODE = `// ai/agents/strategy.js — Business Intelligence Agent (v7 only)

async function run(allAgentData) {
  // 1. Synthesize cross-agent patterns
  const synthesis = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [{
      role: 'system',
      content: 'You are a co-founder-level strategist with deep SaaS expertise.',
    }, {
      role: 'user',
      content: \`
        You have access to 7 days of operational data from 5 AI agents:
        Behavior, Coach, Growth, Revenue, System.

        Data: \${JSON.stringify(allAgentData)}

        Generate 3–5 strategic business recommendations.
        Each must include:
          - title (short)
          - reasoning (what in the data suggests this)
          - action (specific, executable)
          - expected_impact (quantified)
          - priority: HIGH | MED | LOW
          - confidence: 0–1

        Focus on: revenue acceleration, retention, market expansion.
        Return JSON array.\`
    }],
    response_format: { type: 'json_object' },
  });

  const recs = JSON.parse(synthesis.choices[0].message.content).recommendations;

  // 2. Send weekly strategy brief to founder
  await sendFounderBrief({
    subject: \`Your company brief — \${recs.length} moves this week\`,
    recommendations: recs,
    topSignal: recs.find(r => r.priority === 'HIGH'),
  });

  // 3. Store for dashboard
  memory.store('strategy', { recommendations: recs, generatedAt: new Date() });

  return { generated: recs.length, highPriority: recs.filter(r => r.priority === 'HIGH').length };
}

module.exports = { run };`;

function loadState() {
  try { return JSON.parse(localStorage.getItem('be_v7')) ?? { cycles: 0, log: [], accepted: [] }; }
  catch { return { cycles: 0, log: [], accepted: [] }; }
}
function saveState(s) { try { localStorage.setItem('be_v7', JSON.stringify(s)); } catch {} }

export default function AutonomousV7() {
  const [view, setView] = useState('strategy');
  const [active, setActive] = useState(null);
  const [loop, setLoop] = useState(-1);
  const [running, setRunning] = useState(false);
  const [state, setState_] = useState(loadState);
  const [code, setCode] = useState('orchestrator');
  const [accepted, setAccepted] = useState(new Set(state.accepted || []));
  const timer = useRef(null);

  const setState = s => { setState_(s); saveState(s); };

  const acceptRec = (idx) => {
    const next = new Set(accepted);
    if (next.has(idx)) next.delete(idx);
    else next.add(idx);
    setAccepted(next);
    setState({ ...state, accepted: [...next] });
  };

  const runCycle = () => {
    if (running) return;
    setRunning(true); setLoop(0);
    let li = 0;
    timer.current = setInterval(() => {
      li++;
      if (li < LOOP.length) { setLoop(li); }
      else {
        clearInterval(timer.current);
        let ai = 0;
        const cycle = setInterval(() => {
          setActive(AGENTS[ai].id);
          ai++;
          if (ai >= AGENTS.length) {
            clearInterval(cycle);
            const next = {
              ...state,
              cycles: state.cycles + 1,
              log: [{
                n: state.cycles + 1,
                ts: new Date().toLocaleTimeString(),
                summary: 'All 6 agents ran. Strategy Agent generated 4 recommendations. 2 HIGH priority. Revenue Agent: $540 MRR added. System Agent: 5 product changes applied.',
              }, ...(state.log || []).slice(0, 9)],
            };
            setState(next);
            setRunning(false); setLoop(LOOP.length - 1); setActive(null);
          }
        }, 400);
      }
    }, 340);
  };

  useEffect(() => () => clearInterval(timer.current), []);

  const tabs = [
    ['strategy', 'Strategy Engine'],
    ['agents', 'Agent Stack'],
    ['loop', 'Self-Op Loop'],
    ['code', 'Code'],
    ['evolution', 'v1 → v7'],
  ];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={13} className="text-orange-400" />
              <p className="text-orange-400 text-xs font-bold uppercase tracking-widest">Autonomous SaaS v7</p>
              <span className="px-2 py-0.5 rounded bg-orange-500/15 border border-orange-500/25 text-orange-400 text-[8px] font-black">NEW</span>
            </div>
            <h1 className="text-3xl font-black mb-1">The Company That Thinks</h1>
            <p className="text-white/35 text-sm">
              v6 ran the company.{' '}
              <span className="text-orange-400 font-semibold">v7 runs it + recommends your next business move.</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-center p-3 rounded-xl border border-orange-500/20 bg-orange-500/5">
              <p className="text-xl font-black text-orange-400">{state.cycles}</p>
              <p className="text-white/20 text-[9px]">cycles</p>
            </div>
            <button onClick={runCycle} disabled={running}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-lg ${
                running ? 'bg-orange-500/10 border border-orange-500/20 text-orange-400' : 'bg-orange-500 hover:bg-orange-400 text-black shadow-orange-500/20'
              }`}>
              {running ? <><RefreshCw size={13} className="animate-spin" />Running…</> : <><Play size={13} />Run Cycle</>}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {tabs.map(([v, l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-orange-500 text-black font-bold' : 'text-white/35 hover:text-white/60'}`}>{l}
            </button>
          ))}
        </div>

        {/* ── STRATEGY ENGINE ── */}
        {view === 'strategy' && (
          <div className="space-y-4">
            {/* What is the Strategy Agent */}
            <div className="p-5 rounded-2xl border border-orange-500/20 bg-orange-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Lightbulb size={14} className="text-orange-400" />
                <p className="text-orange-400 font-bold text-sm">Strategy Agent — v7's Core Innovation</p>
              </div>
              <p className="text-white/50 text-xs leading-relaxed">
                Every Friday at 6am, the Strategy Agent reads 7 days of data from all 5 operational agents,
                synthesizes cross-agent patterns, and generates ranked business recommendations —
                the same analysis a $500/hour strategist would run, automatically, every week.
              </p>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[
                  { icon: Brain, label: 'Cross-Agent Intelligence', desc: 'Reads all 5 agent outputs simultaneously' },
                  { icon: Target, label: 'Ranked Priorities', desc: 'HIGH / MED / LOW with confidence scores' },
                  { icon: Rocket, label: 'Actionable Moves', desc: 'Specific, executable, revenue-focused' },
                ].map(({ icon: Icon, label, desc }) => (
                  <div key={label} className="p-3 rounded-xl border border-white/8 bg-white/2 text-center">
                    <Icon size={16} className="text-orange-400 mx-auto mb-2" />
                    <p className="text-white/70 text-[9px] font-bold mb-1">{label}</p>
                    <p className="text-white/25 text-[8px]">{desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* This week's recommendations */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-white/30 text-[9px] uppercase tracking-widest">This Week's Recommendations</p>
                <span className="text-white/20 text-[9px]">Generated by Strategy Agent · Friday 6:00am</span>
              </div>
              <div className="space-y-3">
                {STRATEGY_RECS.map((rec, idx) => {
                  const isAccepted = accepted.has(idx);
                  return (
                    <div key={idx} className={`p-4 rounded-2xl border transition-all duration-300 ${isAccepted ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-white/8 bg-white/2'}`}>
                      <div className="flex items-start gap-3">
                        <div className="flex flex-col items-center gap-1.5 shrink-0">
                          <span className={`text-[7px] font-black px-1.5 py-0.5 rounded border ${
                            rec.priority === 'HIGH' ? 'border-red-500/30 bg-red-500/10 text-red-400' :
                            rec.priority === 'MED' ? 'border-yellow-500/30 bg-yellow-500/10 text-yellow-400' :
                            'border-white/15 bg-white/5 text-white/30'
                          }`}>{rec.priority}</span>
                          <span className="text-[7px] px-1.5 py-0.5 rounded border border-white/10 bg-white/5 text-white/30"
                            style={{ borderColor: rec.color + '30', background: rec.color + '10', color: rec.color }}>
                            {rec.tag}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-white/80 text-xs font-bold mb-1">{rec.title}</p>
                          <p className="text-white/35 text-[9px] leading-snug mb-2">
                            <span className="text-white/20">Why: </span>{rec.reasoning}
                          </p>
                          <div className="p-2 rounded-lg border border-white/6 bg-black/20 mb-2">
                            <p className="text-white/20 text-[7px] uppercase tracking-widest mb-0.5">Action</p>
                            <p className="text-white/55 text-[9px] leading-snug">{rec.action}</p>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <span className="text-emerald-400 text-[9px] font-bold">{rec.impact}</span>
                              <span className="text-white/20 text-[8px]">{rec.confidence}% confidence</span>
                            </div>
                            <button onClick={() => acceptRec(idx)}
                              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[9px] font-bold transition-all ${
                                isAccepted ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-400' : 'bg-white/5 border border-white/10 text-white/30 hover:text-white/60'
                              }`}>
                              <CheckCircle2 size={9} />
                              {isAccepted ? 'Accepted' : 'Accept'}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Founder weekly schedule */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/50 font-bold text-xs mb-3">Your week at v7 (what you actually do)</p>
              <div className="space-y-2">
                {[
                  { d: 'Monday', t: 'Read weekly digest (5 min). Approve or reject Strategy Agent recs.', dim: false },
                  { d: 'Tuesday–Thu', t: 'Nothing. All 6 agents operate autonomously.', dim: true },
                  { d: 'Friday', t: 'New strategy brief arrives at 6am. Takes 5 min to review.', dim: false },
                  { d: 'Weekend', t: 'The company runs, grows, improves, and thinks — without you.', dim: true },
                ].map(({ d, t, dim }) => (
                  <div key={d} className="flex gap-4 p-3 rounded-xl border border-white/6 bg-white/2">
                    <span className="text-white/30 text-xs font-bold w-24 shrink-0">{d}</span>
                    <p className={`text-xs leading-snug ${dim ? 'text-white/20' : 'text-white/55'}`}>{t}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── AGENT STACK ── */}
        {view === 'agents' && (
          <div className="space-y-4">
            <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {AGENTS.map((a) => {
                const AIcon = a.Icon;
                const isRun = active === a.id;
                return (
                  <div key={a.id} className="p-4 rounded-2xl border transition-all duration-300"
                    style={{
                      borderColor: isRun ? a.border.replace('0.18', '0.5') : a.border,
                      background: isRun ? a.bg.replace('0.06', '0.12') : a.bg,
                      transform: isRun ? 'scale(1.015)' : 'scale(1)',
                    }}>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: a.bg, border: `1px solid ${a.border}` }}>
                        <AIcon size={13} style={{ color: a.color }} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-bold" style={{ color: a.color }}>{a.name}</p>
                          {a.isNew && <span className="text-[7px] px-1 py-0.5 rounded bg-orange-500/15 border border-orange-500/25 text-orange-400 font-black">v7</span>}
                        </div>
                        <p className="text-white/20 text-[8px]">{a.schedule}</p>
                      </div>
                      {isRun && <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: a.color }} />}
                    </div>
                    <p className="text-white/30 text-[9px] leading-snug mb-3">{a.description}</p>
                    <div className="grid grid-cols-3 gap-1.5 mb-3">
                      {a.stats.map(s => (
                        <div key={s.label} className="text-center p-1.5 rounded-lg bg-black/20 border border-white/5">
                          <p className="text-white/80 text-[10px] font-bold" style={{ color: a.color }}>{s.value}</p>
                          <p className="text-white/20 text-[7px]">{s.label}</p>
                        </div>
                      ))}
                    </div>
                    <div className="p-2 rounded-lg bg-black/25 border border-white/5">
                      <p className="text-[7px] uppercase tracking-widest mb-0.5" style={{ color: a.color, opacity: 0.6 }}>Last cycle</p>
                      <p className="text-white/35 text-[8px] leading-snug">{a.lastRun}</p>
                    </div>
                    <p className="text-white/15 text-[7px] mt-2">KPI: {a.kpi}</p>
                  </div>
                );
              })}
            </div>

            {state.log?.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-white/20 text-[8px] uppercase tracking-widest">Cycle Log</p>
                {state.log.map((e, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border ${i === 0 ? 'border-orange-500/18 bg-orange-500/4' : 'border-white/5 bg-white/1'}`}>
                    <span className="text-white/15 text-[8px] font-mono shrink-0">#{e.n}</span>
                    <p className="text-white/35 text-xs flex-1 leading-snug">{e.summary}</p>
                    <span className="text-white/15 text-[7px] font-mono shrink-0">{e.ts}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── SELF-OP LOOP ── */}
        {view === 'loop' && (
          <div className="space-y-5">
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-5">Self-Operating + Self-Thinking Loop</p>
              <div className="flex items-center gap-2 flex-wrap">
                {LOOP.map((s, i) => {
                  const SI = s.Icon;
                  const isAct = running && loop === i;
                  const isDone = loop > i && loop >= 0;
                  return (
                    <div key={s.id} className="flex items-center gap-2">
                      <div className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border transition-all duration-300"
                        style={{
                          borderColor: isAct ? s.color : isDone ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.06)',
                          background: isAct ? s.color + '10' : isDone ? 'rgba(16,185,129,0.05)' : 'rgba(255,255,255,0.02)',
                          transform: isAct ? 'scale(1.06)' : 'scale(1)',
                        }}>
                        <SI size={10} style={{ color: isAct ? s.color : isDone ? '#34d399' : 'rgba(255,255,255,0.18)' }} />
                        <span className="text-[9px] font-semibold"
                          style={{ color: isAct ? s.color : isDone ? '#34d399' : 'rgba(255,255,255,0.25)' }}>{s.label}</span>
                        {isAct && <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: s.color }} />}
                      </div>
                      {i < LOOP.length - 1 && <ArrowRight size={8} className={isDone ? 'text-emerald-400/40' : 'text-white/10'} />}
                    </div>
                  );
                })}
                <ArrowRight size={8} className="text-white/10" />
                <div className="px-3 py-2.5 rounded-xl border border-white/8 flex items-center gap-1">
                  <Repeat size={9} className="text-white/20" />
                  <span className="text-[9px] text-white/20 font-bold">∞</span>
                </div>
              </div>
              {running && loop >= 0 && (
                <p className="text-white/25 text-xs mt-3 italic">{LOOP[loop]?.desc}</p>
              )}
            </div>
            <div className="space-y-2">
              {LOOP.map((s, i) => {
                const SI = s.Icon;
                return (
                  <div key={s.id} className="flex items-start gap-4 p-4 rounded-xl border border-white/6 bg-white/2">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0" style={{ background: s.color + '10', border: `1px solid ${s.color}20` }}>
                      <SI size={12} style={{ color: s.color }} />
                    </div>
                    <div>
                      <p className="text-white/65 text-xs font-bold mb-0.5">{i + 1}. {s.label}</p>
                      <p className="text-white/25 text-[10px]">{s.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── CODE ── */}
        {view === 'code' && (
          <div className="space-y-4">
            <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6">
              {[['orchestrator', 'orchestrator.js'], ['strategy', 'strategy agent (v7)']].map(([v, l]) => (
                <button key={v} onClick={() => setCode(v)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${code === v ? 'bg-white/10 text-white' : 'text-white/35 hover:text-white/55'}`}>{l}
                </button>
              ))}
            </div>
            <div className="rounded-2xl border border-white/8 bg-black/30 overflow-hidden">
              <pre className="p-4 text-[9.5px] text-white/55 font-mono leading-relaxed overflow-auto max-h-[500px]">
                {code === 'orchestrator' ? ORCHESTRATOR_CODE : STRATEGY_CODE}
              </pre>
            </div>
          </div>
        )}

        {/* ── EVOLUTION ── */}
        {view === 'evolution' && (
          <div className="space-y-3">
            {EVOLUTION.map((e) => (
              <div key={e.v} className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${e.active ? 'border-orange-500/30 bg-orange-500/5' : 'border-white/5 bg-white/2 opacity-40'}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: e.color + '12', border: `1px solid ${e.color}20` }}>
                  <span className="text-[10px] font-black" style={{ color: e.color }}>{e.v}</span>
                </div>
                <p className={`flex-1 text-sm ${e.active ? 'text-white font-bold' : 'text-white/35'}`}>{e.label}</p>
                {e.active ? (
                  <span className="text-[8px] font-black px-2 py-1 rounded border border-orange-500/25 bg-orange-500/10 text-orange-400">YOU ARE HERE</span>
                ) : (
                  <CheckCircle2 size={12} style={{ color: e.color, opacity: 0.45 }} />
                )}
              </div>
            ))}

            <div className="p-5 rounded-2xl border border-orange-500/20 bg-orange-500/5 mt-4">
              <p className="text-orange-400 font-bold text-sm mb-2">v6 → v7: The Strategy Agent</p>
              <p className="text-white/45 text-xs leading-relaxed mb-3">
                v6 operated the company. v7 <span className="text-white font-bold">thinks</span> about the company.
                The Strategy Agent synthesizes all cross-agent intelligence weekly and surfaces
                the highest-leverage business moves — ranked, reasoned, ready to execute.
                It's like having a fractional CMO + CFO + CPO, running 24/7, for $0.
              </p>
              <div className="p-3 rounded-xl border border-white/8 bg-black/20">
                <p className="text-orange-400 text-[9px] font-bold mb-1">Real example output from Strategy Agent:</p>
                <p className="text-white/35 text-[9px] leading-snug">
                  "Revenue Agent identified 9 teams paying individual plans. Growth Agent's fitness content
                  is generating 3.2× referrals vs. sales content. Coach Agent WhatsApp cohort has 2.1× score lift.
                  Recommendation: Launch a $99 Team plan + pivot content to fitness + add WhatsApp coaching.
                  Combined impact estimate: +$2.4K MRR this quarter. Confidence: 88%."
                </p>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
