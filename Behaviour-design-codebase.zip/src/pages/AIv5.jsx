/**
 * AIv5 — Fully Autonomous SaaS (No Dashboards. No Humans. AI Runs the Company.)
 * 5 agents. Self-operating loop. Output via WhatsApp / Email / Notifications.
 * Observe → Decide → Act → Update System → Improve
 * The System Agent is new: it modifies product logic autonomously.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Cpu, Play, RefreshCw, ArrowRight, CheckCircle2,
  DollarSign, Users, TrendingUp, Brain, Mail,
  Zap, Shield, Layers, GitBranch, BarChart2,
  Clock, Eye, AlertTriangle, Sparkles, Repeat,
  Settings, MessageCircle, Bell, Wrench, Terminal,
  ChevronRight,
} from 'lucide-react';

// ── 5 Company-Level Agents ────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'behavior',
    name: 'Behavior Agent',
    job: 'Tracks every user. Detects patterns.',
    color: '#22d3ee',
    bg: 'rgba(6,182,212,0.07)',
    border: 'rgba(6,182,212,0.18)',
    Icon: Eye,
    schedule: 'Every 1 hour',
    tasks: [
      'Reads all user task completion data in real time',
      'Calculates execution score per user (0–100)',
      'Detects 3-day drop patterns and consistency breaks',
      'Segments users: HIGH / MEDIUM / LOW performance',
      'Feeds signals to all other agents automatically',
    ],
    output: (d) => `Scanned ${d.users} users. ${d.high} HIGH (${d.highPct}%), ${d.low} LOW (${d.lowPct}%). ${d.drops} drop patterns detected. Signals dispatched.`,
    liveData: { users: 312, high: 187, highPct: 60, low: 44, lowPct: 14, drops: 23 },
    kpi: 'Signal accuracy rate',
  },
  {
    id: 'coach',
    name: 'Coach Agent',
    job: 'Sends personalised coaching. No templates.',
    color: '#a78bfa',
    bg: 'rgba(139,92,246,0.07)',
    border: 'rgba(139,92,246,0.18)',
    Icon: Brain,
    schedule: 'Daily at 8am + on trigger',
    tasks: [
      'Reads each user\'s performance trajectory from Behavior Agent',
      'Generates personalised message (LLM — not template)',
      'Routes message to WhatsApp, email, or push (by preference)',
      'Adapts tone: supportive / challenging / urgent based on signal',
      'Tracks message-open vs score-change correlation for learning',
    ],
    output: (d) => `Sent ${d.messages} personalised messages. ${d.whatsapp} WhatsApp, ${d.email} email, ${d.push} push. Avg open rate: ${d.openRate}%.`,
    liveData: { messages: 189, whatsapp: 94, email: 71, push: 24, openRate: 74 },
    kpi: 'Score lift after message',
  },
  {
    id: 'growth',
    name: 'Growth Agent',
    job: 'Amplifies distribution. Generates referrals.',
    color: '#f472b6',
    bg: 'rgba(236,72,153,0.07)',
    border: 'rgba(236,72,153,0.18)',
    Icon: TrendingUp,
    schedule: 'Every 12 hours',
    tasks: [
      'Identifies users with K > 0.8 (viral triggers)',
      'Posts execution insights to LinkedIn + Twitter (scheduled)',
      'Sends "share your score" to top performers automatically',
      'Monitors referral links and nurtures warm referrals',
      'A/B tests outreach copy — 1 variant per week autonomously',
    ],
    output: (d) => `${d.posts} content pieces published. ${d.viral} users triggered. ${d.referrals} new referrals this cycle. A/B test: "${d.variant}" running.`,
    liveData: { posts: 4, viral: 31, referrals: 7, variant: '"Execution score" headline' },
    kpi: 'Viral coefficient K',
  },
  {
    id: 'revenue',
    name: 'Revenue Agent',
    job: 'Maximises MRR. No human involvement.',
    color: '#fbbf24',
    bg: 'rgba(245,158,11,0.07)',
    border: 'rgba(245,158,11,0.18)',
    Icon: DollarSign,
    schedule: 'Weekly on Monday',
    tasks: [
      'Detects teams ready to upgrade (5+ active seats)',
      'Sends upgrade prompt with their own usage stats',
      'Proposes annual plan to high-engagement users (30% discount)',
      'Triggers win-back sequence for lapsed accounts',
      'Adjusts pricing for new signups based on demand signals',
    ],
    output: (d) => `${d.ready} upgrade-ready accounts. ${d.proposals} proposals sent. ${d.converted} converted. $${d.mrr} MRR added. Churn prevented: ${d.saved}.`,
    liveData: { ready: 9, proposals: 9, converted: 3, mrr: 540, saved: 4 },
    kpi: 'Net Revenue Retention',
  },
  {
    id: 'system',
    name: 'System Agent',
    job: 'Modifies product logic. Self-improves.',
    color: '#34d399',
    bg: 'rgba(16,185,129,0.07)',
    border: 'rgba(16,185,129,0.18)',
    Icon: Wrench,
    schedule: 'Weekly — Sunday midnight',
    tasks: [
      'Analyses which task types have highest completion rates',
      'Adjusts task difficulty algorithm for underperforming users',
      'Rewrites low-performing coaching message templates',
      'Tests new scoring formula variants (A/B at system level)',
      'Writes change log — surfaces proposals > 80% confidence to founder',
    ],
    output: (d) => `Analysed ${d.analysed} data points. ${d.changes} product changes proposed. ${d.applied} auto-applied (confidence > 80%). ${d.flagged} flagged for review.`,
    liveData: { analysed: 4800, changes: 7, applied: 5, flagged: 2 },
    kpi: 'Product improvement rate',
  },
];

// ── Autonomous loop ────────────────────────────────────────────────────────────
const LOOP = [
  { id: 'observe',  label: 'Observe',        desc: 'Agent reads all system signals', color: '#22d3ee', Icon: Eye       },
  { id: 'decide',   label: 'Decide',         desc: 'LLM calculates best action',     color: '#a78bfa', Icon: Brain     },
  { id: 'act',      label: 'Act',            desc: 'Action executed automatically',  color: '#34d399', Icon: Zap       },
  { id: 'update',   label: 'Update System',  desc: 'Product logic adjusted',         color: '#fbbf24', Icon: Settings  },
  { id: 'improve',  label: 'Improve',        desc: 'Agent learns from result',       color: '#f472b6', Icon: TrendingUp },
];

// ── Output channels ────────────────────────────────────────────────────────────
const CHANNELS = [
  { id: 'whatsapp', label: 'WhatsApp',      Icon: MessageCircle, color: '#34d399', desc: 'Direct coaching + team nudges. 74% open rate.' },
  { id: 'email',    label: 'Email',         Icon: Mail,          color: '#818cf8', desc: 'Weekly reports, upgrade offers, case studies.'  },
  { id: 'push',     label: 'Notifications', Icon: Bell,          color: '#fbbf24', desc: 'Instant execution alerts and score milestones.' },
];

// ── v1 → v5 evolution ──────────────────────────────────────────────────────────
const EVOLUTION = [
  { v: 'v1', label: 'You build features',             color: '#a1a1aa', active: false },
  { v: 'v2', label: 'Product learns from users',      color: '#818cf8', active: false },
  { v: 'v3', label: 'Product improves itself',        color: '#34d399', active: false },
  { v: 'v4', label: 'Company runs itself',            color: '#fbbf24', active: false },
  { v: 'v5', label: 'Company evolves itself',         color: '#f472b6', active: true  },
];

// ── Persistence ────────────────────────────────────────────────────────────────
function loadState()  { try { return JSON.parse(localStorage.getItem('be_aiv5')) ?? { runs: 0, log: [] }; } catch { return { runs: 0, log: [] }; } }
function saveState(s) { try { localStorage.setItem('be_aiv5', JSON.stringify(s)); } catch {} }

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AIv5() {
  const [activeAgent, setActiveAgent] = useState(null);
  const [loopStep,    setLoopStep]    = useState(-1);
  const [running,     setRunning]     = useState(false);
  const [sysState,    setSysState_]   = useState(loadState);
  const [view,        setView]        = useState('agents'); // 'agents' | 'loop' | 'channels' | 'evolution'
  const timerRef = useRef(null);

  const setSysState = s => { setSysState_(s); saveState(s); };

  const runAllAgents = () => {
    if (running) return;
    setRunning(true);
    setLoopStep(0);
    setActiveAgent(null);

    let step = 0;
    timerRef.current = setInterval(() => {
      step++;
      if (step < LOOP.length) {
        setLoopStep(step);
      } else {
        clearInterval(timerRef.current);
        let ai = 0;
        const cycleAgents = setInterval(() => {
          setActiveAgent(AGENTS[ai].id);
          ai++;
          if (ai >= AGENTS.length) {
            clearInterval(cycleAgents);
            const d = AGENTS.map(a => a.liveData);
            const newState = {
              runs: sysState.runs + 1,
              log: [
                {
                  run: sysState.runs + 1,
                  ts: new Date().toLocaleTimeString(),
                  summary: `All 5 agents ran. ${AGENTS[0].liveData.drops} patterns detected. ${AGENTS[2].liveData.referrals} referrals generated. $${AGENTS[3].liveData.mrr} MRR added. ${AGENTS[4].liveData.applied} product changes applied.`,
                },
                ...sysState.log.slice(0, 9),
              ],
            };
            setSysState(newState);
            setRunning(false);
            setLoopStep(LOOP.length - 1);
          }
        }, 350);
      }
    }, 360);
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={13} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">Autonomous AI v5</p>
            </div>
            <h1 className="text-3xl font-black mb-1">AI Runs the Company</h1>
            <p className="text-white/35 text-sm">
              No dashboards. No manual tasks. 5 agents. System modifies itself.
              <span className="text-emerald-400 font-semibold"> You set direction — nothing else.</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right p-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-lg font-black text-emerald-400">{sysState.runs}</p>
              <p className="text-white/20 text-[9px]">full cycles</p>
            </div>
            <button onClick={runAllAgents} disabled={running}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${
                running
                  ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-500/20'
              }`}>
              {running
                ? <><RefreshCw size={13} className="animate-spin" /> Running…</>
                : <><Play size={13} /> Run All Agents</>}
            </button>
          </div>
        </div>

        {/* View tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['agents','Agent Dashboard'],['loop','Self-Operating Loop'],['channels','Output Channels'],['evolution','v1 → v5']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-emerald-500 text-black' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── AGENTS ── */}
        {view === 'agents' && (
          <div className="space-y-5">
            {/* Agent grid */}
            <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {AGENTS.map(agent => {
                const AIcon = agent.Icon;
                const isActive = activeAgent === agent.id;
                const output = agent.output(agent.liveData);
                return (
                  <div key={agent.id}
                    className="p-4 rounded-2xl border transition-all duration-300"
                    style={{
                      borderColor: isActive ? agent.border.replace('0.18', '0.45') : agent.border,
                      background: isActive ? agent.bg.replace('0.07', '0.14') : agent.bg,
                      transform: isActive ? 'scale(1.015)' : 'scale(1)',
                    }}>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                        style={{ background: agent.bg, border: `1px solid ${agent.border}` }}>
                        <AIcon size={13} style={{ color: agent.color }} />
                      </div>
                      <div className="flex-1">
                        <p className="text-xs font-bold" style={{ color: agent.color }}>{agent.name}</p>
                        <p className="text-white/25 text-[9px]">{agent.job}</p>
                      </div>
                      {isActive && <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: agent.color }} />}
                    </div>

                    <div className="space-y-1 mb-3">
                      {agent.tasks.slice(0, 3).map(t => (
                        <div key={t} className="flex items-start gap-1.5">
                          <CheckCircle2 size={8} style={{ color: agent.color, opacity: 0.55 }} className="shrink-0 mt-0.5" />
                          <span className="text-white/30 text-[9px] leading-snug">{t}</span>
                        </div>
                      ))}
                    </div>

                    <div className="p-2.5 rounded-lg bg-black/25 border border-white/5">
                      <p className="text-[8px] uppercase tracking-widest mb-1" style={{ color: agent.color, opacity: 0.6 }}>Last cycle</p>
                      <p className="text-white/50 text-[9px] leading-snug">{output}</p>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-white/20 text-[8px]">KPI: {agent.kpi}</span>
                      <span className="text-[8px] px-1.5 py-0.5 rounded border" style={{ color: agent.color, borderColor: agent.border }}>
                        {agent.schedule}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Run log */}
            {sysState.log.length > 0 && (
              <div className="space-y-2">
                <p className="text-white/25 text-[9px] uppercase tracking-widest">Cycle Log</p>
                {sysState.log.map((entry, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border ${i === 0 ? 'border-emerald-500/20 bg-emerald-500/4' : 'border-white/5 bg-white/1'}`}>
                    <span className="text-white/15 text-[9px] font-mono w-5 shrink-0">#{entry.run}</span>
                    <p className="text-white/40 text-xs flex-1 leading-snug">{entry.summary}</p>
                    <span className="text-white/15 text-[8px] font-mono shrink-0">{entry.ts}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── LOOP ── */}
        {view === 'loop' && (
          <div className="space-y-5">
            {/* Visual loop */}
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-5">Self-Operating Agent Loop</p>
              <div className="flex items-center gap-2 flex-wrap">
                {LOOP.map((step, i) => {
                  const StepIcon = step.Icon;
                  const isActive = running && loopStep === i;
                  const isDone = loopStep > i && loopStep >= 0;
                  return (
                    <div key={step.id} className="flex items-center gap-2">
                      <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl border transition-all duration-300"
                        style={{
                          borderColor: isActive ? step.color : isDone ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.06)',
                          background: isActive ? step.color + '12' : isDone ? 'rgba(16,185,129,0.05)' : 'rgba(255,255,255,0.02)',
                          transform: isActive ? 'scale(1.06)' : 'scale(1)',
                        }}>
                        <StepIcon size={10} style={{ color: isActive ? step.color : isDone ? '#34d399' : 'rgba(255,255,255,0.2)' }} />
                        <span className="text-[10px] font-semibold"
                          style={{ color: isActive ? step.color : isDone ? '#34d399' : 'rgba(255,255,255,0.3)' }}>
                          {step.label}
                        </span>
                        {isActive && <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: step.color }} />}
                      </div>
                      {i < LOOP.length - 1 && <ArrowRight size={9} className={isDone ? 'text-emerald-400/40' : 'text-white/10'} />}
                    </div>
                  );
                })}
                <ArrowRight size={9} className="text-white/10" />
                <div className="px-3 py-2.5 rounded-xl border border-white/8 bg-white/2 flex items-center gap-1.5">
                  <Repeat size={9} className="text-white/20" />
                  <span className="text-[9px] text-white/20 font-bold">Loop ∞</span>
                </div>
              </div>
              {running && loopStep >= 0 && (
                <p className="text-white/25 text-xs mt-3 italic">{LOOP[loopStep]?.desc}</p>
              )}
            </div>

            {/* Architecture */}
            <div className="p-5 rounded-2xl bg-black/40 border border-white/8">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-3">v5 Architecture — System Agent (New in v5)</p>
              <pre className="text-[9px] text-emerald-400/75 font-mono leading-relaxed">{`// All v4 agents + the System Agent

class SystemAgent extends Agent {
  async run(context) {
    // 1. Analyse what's working
    const patterns = await this.observe(context)

    // 2. Generate product improvements
    const proposals = await this.decide(patterns)
    // e.g. "Reduce task difficulty for users at <30% execution"
    // e.g. "Change coaching tone from supportive to direct at day 14"

    // 3. Apply high-confidence changes automatically
    for (const proposal of proposals) {
      if (proposal.confidence > 0.80) {
        await this.execute(proposal)   // modifies product logic live
        await this.memory.store(proposal)
      } else {
        await this.flagForFounder(proposal)  // weekly digest
      }
    }
  }
}

// You just review the weekly digest:
// "5 changes auto-applied. 2 need your approval."
// That's your entire product meeting.`}</pre>
            </div>

            {/* What the founder does */}
            <div className="p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-sm mb-3">Your Entire Week at v5</p>
              <div className="space-y-2">
                {[
                  { day: 'Monday',    task: 'Read weekly agent digest (3 min). Approve or reject 2 flagged System Agent proposals.',    dim: false },
                  { day: 'Tuesday',   task: 'Nothing. Agents ran outreach, onboarding, coaching, and 2 product changes overnight.',       dim: true  },
                  { day: 'Wednesday', task: 'Review 1 A/B test result from Growth Agent. Say yes or no.',                                dim: false },
                  { day: 'Thursday',  task: 'Nothing. Revenue Agent ran upsell cycle. System Agent adjusted task difficulty at 2am.',    dim: true  },
                  { day: 'Friday',    task: 'Strategy session: which market next? Which agent needs a new tool? What does v6 look like?', dim: false },
                  { day: 'Weekend',   task: 'Nothing. The company is running, improving, and growing without you.',                      dim: true  },
                ].map(({ day, task, dim }) => (
                  <div key={day} className="flex gap-4 p-3 rounded-xl border border-white/6 bg-white/2">
                    <span className="text-white/35 text-xs font-bold w-20 shrink-0">{day}</span>
                    <p className={`text-xs leading-snug ${dim ? 'text-white/25' : 'text-white/60'}`}>{task}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── CHANNELS ── */}
        {view === 'channels' && (
          <div className="space-y-5">
            <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">Core Principle</p>
              <p className="text-white/60 text-sm leading-relaxed">
                No dashboard dependency. Users never need to log in to get value.
                The system reaches them — wherever they are.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-4">
              {CHANNELS.map(ch => {
                const CIcon = ch.Icon;
                return (
                  <div key={ch.id} className="p-5 rounded-2xl border border-white/8 bg-white/2">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                      style={{ background: ch.color + '12', border: `1px solid ${ch.color}25` }}>
                      <CIcon size={16} style={{ color: ch.color }} />
                    </div>
                    <p className="text-white/70 text-sm font-bold mb-1">{ch.label}</p>
                    <p className="text-white/35 text-xs leading-snug mb-3">{ch.desc}</p>
                  </div>
                );
              })}
            </div>

            {/* Message routing logic */}
            <div className="p-5 rounded-2xl bg-black/40 border border-white/8">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-3">Channel Routing Logic</p>
              <pre className="text-[9px] text-emerald-400/75 font-mono leading-relaxed">{`function routeMessage(user, message) {
  // Coach Agent decides channel per user preference
  if (user.preferredChannel === 'whatsapp' && user.phoneVerified) {
    return sendWhatsApp(user.phone, message)
  }
  if (user.openRate.push > 0.5) {
    return sendPush(user.deviceToken, message)
  }
  // Email as fallback — always available
  return sendEmail(user.email, message)
}

// No login required. No dashboard visit needed.
// User gets coached wherever they are.
// Execution improves without any effort from the user.`}</pre>
            </div>

            {/* Channel stats */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'WhatsApp open rate', v: '74%', sub: 'avg across all users', color: '#34d399' },
                { label: 'Email open rate',    v: '38%', sub: 'above industry avg',   color: '#818cf8' },
                { label: 'Push click rate',    v: '22%', sub: 'high-engagement tier', color: '#fbbf24' },
              ].map(m => (
                <div key={m.label} className="p-4 rounded-xl border border-white/8 bg-white/2 text-center">
                  <p className="text-xl font-black" style={{ color: m.color }}>{m.v}</p>
                  <p className="text-white/35 text-[9px] mt-0.5">{m.label}</p>
                  <p className="text-white/15 text-[8px]">{m.sub}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── EVOLUTION ── */}
        {view === 'evolution' && (
          <div className="space-y-5">
            {/* v1 → v5 ladder */}
            <div className="space-y-2">
              {EVOLUTION.map((e, i) => (
                <div key={e.v} className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${
                  e.active
                    ? 'border-pink-500/25 bg-pink-500/6'
                    : 'border-white/6 bg-white/2 opacity-50'
                }`}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: e.color + '12', border: `1px solid ${e.color}25` }}>
                    <span className="text-[10px] font-black" style={{ color: e.color }}>{e.v}</span>
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-bold ${e.active ? 'text-white' : 'text-white/40'}`}>{e.label}</p>
                  </div>
                  {e.active && (
                    <span className="text-[8px] font-black px-2 py-1 rounded border border-pink-500/25 bg-pink-500/10 text-pink-400">
                      YOU ARE HERE
                    </span>
                  )}
                  {!e.active && i < EVOLUTION.length - 1 && (
                    <CheckCircle2 size={12} style={{ color: e.color, opacity: 0.5 }} />
                  )}
                </div>
              ))}
            </div>

            {/* The System Agent shift */}
            <div className="p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-sm mb-2">What Changed in v5: The System Agent</p>
              <p className="text-white/50 text-xs leading-relaxed mb-4">
                v4 ran the company. v5 <span className="text-white font-semibold">improves</span> the company.
                The System Agent doesn&apos;t just execute — it reads performance data, generates hypotheses,
                tests changes, and applies improvements at product level. Every week the product gets slightly better.
                Without you writing a line of code.
              </p>
              <div className="grid lg:grid-cols-2 gap-3">
                {[
                  { t: 'Before: Product roadmap', d: 'You write tickets. Prioritise. Build. Ship in 2 weeks. Hope users respond.' },
                  { t: 'After: System Agent', d: 'Agent identifies what\'s not working. Proposes fix. Auto-applies if confidence > 80%. Ships in minutes.' },
                ].map(({ t, d }) => (
                  <div key={t} className="p-3 rounded-xl border border-white/8 bg-black/20">
                    <p className="text-emerald-400 text-xs font-bold mb-1">{t}</p>
                    <p className="text-white/40 text-[10px] leading-snug">{d}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Reality check */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Is This Real?</p>
              <div className="space-y-2">
                {[
                  { q: 'Can agents really send WhatsApp?',   a: 'Yes. Twilio, WhatsApp Business API. Fully available today.' },
                  { q: 'Can agents modify product logic?',   a: 'Yes. Feature flags, prompt templates, scoring weights — all API-driven.' },
                  { q: 'Can an LLM generate these messages?', a: 'Yes. GPT-4o, Claude 3.5. Cost is ~$0.002 per message.' },
                  { q: 'What\'s the actual bottleneck?',     a: 'Not the AI. Not the tools. It\'s connecting them and running the first cycle.' },
                ].map(({ q, a }) => (
                  <div key={q} className="flex gap-3 p-3 rounded-xl border border-white/6 bg-black/15">
                    <ChevronRight size={10} className="text-emerald-400/50 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-white/55 text-[10px] font-semibold">{q}</p>
                      <p className="text-white/30 text-[9px] leading-snug mt-0.5">{a}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
