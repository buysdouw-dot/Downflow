import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, Zap, ChevronRight, Flame, Bot, BarChart2 } from 'lucide-react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { COACH_PERSONALITIES, suggestPersonality, coachWithPersonality } from '../engine/personality';
import { detectDropPattern, calcStreak } from '../engine/coach';
import MobileHeader from '../components/MobileHeader';

const DEMO_SCENARIOS = [
  { label: 'Hit target today', score: 48, streak: 3, dropPattern: 'building_momentum' },
  { label: 'Slightly behind', score: 22, streak: 1, dropPattern: 'slow_starter' },
  { label: 'RED day', score: 8, streak: 0, dropPattern: 'chronic_underperformance' },
];

export default function CoachPersonality() {
  const { personalityId, changePersonality, getTodayScore, getWeekScores, activeUserId } = useBehavior();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [previewScenario, setPreviewScenario] = useState(0);
  const [saved, setSaved] = useState(false);

  const weekScores = getWeekScores(activeUserId).map(d => d.score);
  const suggested = suggestPersonality(weekScores, user?.role);

  const scenario = DEMO_SCENARIOS[previewScenario];

  const handleSelect = (id) => {
    changePersonality(id);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <MobileHeader title="AI Coach" />

      <div className="hidden lg:block px-6 pt-6 pb-4">
        <div className="flex items-center gap-2 mb-1">
          <Bot size={16} className="text-indigo-400" />
          <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">AI Coach Personality</span>
        </div>
        <h1 className="text-2xl font-bold text-white">Choose Your Coach</h1>
        <p className="text-white/35 text-sm mt-0.5">Three personalities. One that matches how you grow best.</p>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-5">
        {/* What is this */}
        <div className="glass rounded-xl p-4 border border-indigo-500/20">
          <div className="flex items-start gap-3">
            <Zap size={14} className="text-indigo-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-white/70 text-sm leading-relaxed">
                Your AI coach adapts its entire communication style to the personality you choose. Same data, completely different delivery. This is your behavioral moat — no other productivity tool coaches like this.
              </p>
            </div>
          </div>
        </div>

        {/* Smart suggestion */}
        {suggested !== personalityId && (
          <div className="glass rounded-xl p-4 border border-yellow-500/20 flex items-center gap-3">
            <span className="text-xl">{COACH_PERSONALITIES[suggested].emoji}</span>
            <div className="flex-1">
              <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest mb-0.5">Recommended For You</p>
              <p className="text-white/60 text-sm">Based on your 7-day pattern, <span className="text-white font-semibold">{COACH_PERSONALITIES[suggested].name}</span> is your optimal coaching style right now.</p>
            </div>
            <button onClick={() => handleSelect(suggested)} className="text-yellow-400 text-xs font-bold px-3 py-1.5 bg-yellow-500/10 border border-yellow-500/20 rounded-lg hover:bg-yellow-500/20 transition-all whitespace-nowrap">
              Apply
            </button>
          </div>
        )}

        {/* Personality cards */}
        <div className="grid lg:grid-cols-3 gap-4">
          {Object.values(COACH_PERSONALITIES).map((p) => {
            const isActive = personalityId === p.id;
            return (
              <button
                key={p.id}
                onClick={() => handleSelect(p.id)}
                className={`relative text-left rounded-2xl p-5 border transition-all group ${
                  isActive
                    ? `${p.bg} ${p.border} ring-2 ${p.border}`
                    : 'glass border-white/8 hover:border-white/20 hover:bg-white/3'
                }`}
              >
                {isActive && (
                  <div className="absolute top-3 right-3">
                    <CheckCircle2 size={16} className={p.color} />
                  </div>
                )}
                {suggested === p.id && !isActive && (
                  <div className="absolute top-3 right-3">
                    <span className="text-[8px] font-bold text-yellow-400 bg-yellow-500/15 border border-yellow-500/20 px-1.5 py-0.5 rounded-full">BEST FIT</span>
                  </div>
                )}

                <div className="text-4xl mb-3">{p.emoji}</div>
                <p className={`font-black text-base ${isActive ? p.color : 'text-white'} mb-1`}>{p.name}</p>
                <p className={`text-xs font-semibold mb-3 ${isActive ? p.color : 'text-white/30'} opacity-80`}>"{p.tagline}"</p>
                <p className="text-white/45 text-xs leading-relaxed">{p.description}</p>

                {isActive && (
                  <div className={`mt-3 pt-3 border-t ${p.border} flex items-center gap-1.5`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${p.bg.replace('/10', '')} animate-pulse`} style={{ backgroundColor: p.accent }} />
                    <span className={`text-[10px] font-bold ${p.color}`}>ACTIVE COACH</span>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Save confirmation */}
        {saved && (
          <div className="glass rounded-xl p-3 border border-green-500/25 flex items-center gap-2.5">
            <CheckCircle2 size={14} className="text-green-400" />
            <p className="text-green-300 text-sm font-medium">Coach updated · All future feedback will use this style.</p>
          </div>
        )}

        {/* Preview section */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3">Live Preview</p>
          <div className="glass rounded-xl overflow-hidden border border-white/8">
            {/* Scenario tabs */}
            <div className="flex border-b border-white/6">
              {DEMO_SCENARIOS.map((s, i) => (
                <button
                  key={s.label}
                  onClick={() => setPreviewScenario(i)}
                  className={`flex-1 py-2.5 text-xs font-semibold transition-all ${
                    previewScenario === i
                      ? 'text-white bg-white/5 border-b-2 border-indigo-500'
                      : 'text-white/25 hover:text-white/50'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Preview for each personality */}
            <div className="p-5 space-y-3">
              {Object.values(COACH_PERSONALITIES).map((p) => {
                const preview = coachWithPersonality({
                  role: user?.role ?? 'user',
                  score: scenario.score,
                  dailyTarget: 40,
                  weekScores: [20, 30, scenario.score, 25, 15, scenario.score, scenario.score],
                  streak: scenario.streak,
                  dropPattern: scenario.dropPattern,
                }, p.id);
                const isActive = personalityId === p.id;

                return (
                  <div
                    key={p.id}
                    className={`rounded-xl p-4 border transition-all ${
                      isActive ? `${p.bg} ${p.border}` : 'bg-white/2 border-white/6'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-base">{p.emoji}</span>
                      <p className={`text-xs font-bold ${isActive ? p.color : 'text-white/30'}`}>{p.name}</p>
                      <span className={`ml-auto text-[9px] font-bold px-1.5 py-0.5 rounded-full ${isActive ? `${p.bg} ${p.color} border ${p.border}` : 'text-white/20 bg-white/5'}`}>
                        {preview.tag}
                      </span>
                    </div>
                    <p className={`text-sm leading-snug ${isActive ? 'text-white/90' : 'text-white/35'}`}>
                      "{preview.insight}"
                    </p>
                    <p className={`text-xs mt-1.5 flex items-center gap-1 ${isActive ? p.color : 'text-white/20'}`}>
                      <Zap size={9} /> {preview.action}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Personality memory note */}
        <div className="glass rounded-xl p-4 border border-white/6">
          <p className="text-white/25 text-[10px] uppercase tracking-widest mb-2 flex items-center gap-1.5">
            <Flame size={10} /> Behavioral Memory
          </p>
          <p className="text-white/45 text-sm leading-relaxed">
            Your coach learns your patterns over time. The feedback you receive is shaped by your role, 7-day score trend, streak, drop pattern, and the personality you've selected. No two users receive the same coaching.
          </p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 mt-3">
            {['Role-aware', 'Streak-sensitive', 'Pattern-detecting', 'Style-adaptive'].map(tag => (
              <div key={tag} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/4 border border-white/6">
                <CheckCircle2 size={9} className="text-green-400 shrink-0" />
                <span className="text-white/45 text-[10px] font-semibold">{tag}</span>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={() => navigate('/tasks')}
          className="w-full py-3.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white text-sm font-bold transition-all flex items-center justify-center gap-2"
        >
          Start Executing with {COACH_PERSONALITIES[personalityId].emoji} {COACH_PERSONALITIES[personalityId].name}
          <ChevronRight size={14} />
        </button>
      </div>
    </div>
  );
}
