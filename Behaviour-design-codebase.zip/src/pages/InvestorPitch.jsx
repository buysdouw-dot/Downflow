/**
 * InvestorPitch — Real Investor Demo App (Clickable + "Hosted")
 * Full simulation: Acme Sales Team live dashboard, leaderboard, AI insight panel.
 * Looks like a live product. Investors click through it themselves.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Play, Pause, ChevronRight, ChevronLeft, Zap,
  Users, Trophy, Brain, BarChart2, TrendingUp,
  CheckCircle2, ArrowRight, Maximize2, X,
  DollarSign, Target, Flame, Activity, Star,
} from 'lucide-react';

// ── Simulated company data ────────────────────────────────────────────────────
const COMPANY = { name: 'Acme Sales', industry: 'SaaS', teamSize: 18, plan: 'Pro', mrr: 2988 };

const TEAM = [
  { id: 1, name: 'Marcus Chen',    avatar: 'MC', title: 'Sr. AE',     score: 87, status: 'GREEN',  streak: 12, trend: 'up',   tasks: 4 },
  { id: 2, name: 'Leila Nkosi',    avatar: 'LN', title: 'AE',         score: 82, status: 'GREEN',  streak: 8,  trend: 'up',   tasks: 4 },
  { id: 3, name: 'Sarah Kim',      avatar: 'SK', title: 'Team Lead',  score: 76, status: 'GREEN',  streak: 6,  trend: 'up',   tasks: 3 },
  { id: 4, name: 'Carlos Ruiz',    avatar: 'CR', title: 'AE',         score: 71, status: 'GREEN',  streak: 5,  trend: 'flat', tasks: 3 },
  { id: 5, name: 'Nina Okafor',    avatar: 'NO', title: 'SDR',        score: 64, status: 'GREEN',  streak: 3,  trend: 'up',   tasks: 3 },
  { id: 6, name: 'Aisha Williams', avatar: 'AW', title: 'AE',         score: 58, status: 'YELLOW', streak: 2,  trend: 'flat', tasks: 2 },
  { id: 7, name: 'James Torres',   avatar: 'JT', title: 'SDR',        score: 43, status: 'YELLOW', streak: 1,  trend: 'down', tasks: 2 },
  { id: 8, name: 'Daniel Park',    avatar: 'DP', title: 'AE',         score: 31, status: 'YELLOW', streak: 0,  trend: 'down', tasks: 1 },
  { id: 9, name: 'Tom Bennett',    avatar: 'TB', title: 'Jr. AE',     score: 22, status: 'RED',    streak: 0,  trend: 'down', tasks: 1 },
  { id: 10,name: 'Priya Sharma',   avatar: 'PS', title: 'SDR',        score: 14, status: 'RED',    streak: 0,  trend: 'down', tasks: 0 },
];

const AI_INSIGHTS = [
  {
    user: 'Marcus Chen',
    insight: 'Marcus executes best before 9AM. His Monday scores are 40% higher than Thursday. Recommend: lock Mondays as deep work.',
    priority: 'high',
    type: 'pattern',
  },
  {
    user: 'James Torres',
    insight: 'James has missed 3 consecutive days after strong weeks. Classic burnout pattern. Coach is switching to Motivator mode.',
    priority: 'urgent',
    type: 'risk',
  },
  {
    user: 'Team',
    insight: 'Team execution rate: 72% → 78% this week. Top performers are pulling up the middle. Recommend: peer coaching pairs.',
    priority: 'medium',
    type: 'trend',
  },
  {
    user: 'Leila Nkosi',
    insight: 'Leila has the fastest response to feedback. She improves 2x faster when tasks are challenging. Increase her daily target.',
    priority: 'low',
    type: 'optimization',
  },
];

const SCREENS = [
  { id: 'login',       label: 'Login',       icon: Zap },
  { id: 'dashboard',   label: 'Dashboard',   icon: BarChart2 },
  { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { id: 'ai_coach',    label: 'AI Coach',    icon: Brain },
  { id: 'metrics',     label: 'Metrics',     icon: TrendingUp },
];

const STATUS = {
  GREEN:  { color: '#10b981', bg: 'rgba(16,185,129,0.12)', border: 'rgba(16,185,129,0.3)', label: 'GREEN'  },
  YELLOW: { color: '#f59e0b', bg: 'rgba(245,158,11,0.12)', border: 'rgba(245,158,11,0.3)', label: 'YELLOW' },
  RED:    { color: '#ef4444', bg: 'rgba(239,68,68,0.12)',  border: 'rgba(239,68,68,0.3)',  label: 'RED'    },
};

const AVATAR_COLORS = [
  '#6366f1','#10b981','#f59e0b','#ec4899','#06b6d4','#8b5cf6','#f43f5e','#0ea5e9','#f97316','#14b8a6'
];

// ── Phone frame ───────────────────────────────────────────────────────────────
function Phone({ screen, onNext, onPrev, autoPlay, setAutoPlay, screenIdx }) {
  return (
    <div className="flex flex-col items-center">
      {/* Phone */}
      <div className="relative" style={{ width: 320, height: 640 }}>
        {/* Frame */}
        <div className="absolute inset-0 rounded-[40px] border-[3px] border-white/15 bg-[#0b0f1a] shadow-2xl shadow-black/60 overflow-hidden">
          {/* Notch */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-6 bg-[#070b14] rounded-b-2xl z-20 flex items-center justify-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-white/20" />
            <div className="w-8 h-1 rounded-full bg-white/10" />
          </div>

          {/* Screen content */}
          <div className="absolute inset-0 overflow-hidden pt-6">
            {screen}
          </div>

          {/* Bottom bar */}
          <div className="absolute bottom-0 left-0 right-0 h-5 bg-[#0b0f1a] flex items-center justify-center">
            <div className="w-24 h-1 rounded-full bg-white/20" />
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="mt-5 flex items-center gap-3">
        <button onClick={onPrev} className="w-9 h-9 rounded-full bg-white/6 border border-white/10 flex items-center justify-center text-white/40 hover:text-white/70 hover:bg-white/10 transition-all">
          <ChevronLeft size={15} />
        </button>

        {/* Dot nav */}
        <div className="flex gap-1.5">
          {SCREENS.map((s, i) => (
            <div key={s.id} className={`rounded-full transition-all duration-300 ${i === screenIdx ? 'w-4 h-2 bg-indigo-400' : 'w-2 h-2 bg-white/20'}`} />
          ))}
        </div>

        <button onClick={onNext} className="w-9 h-9 rounded-full bg-white/6 border border-white/10 flex items-center justify-center text-white/40 hover:text-white/70 hover:bg-white/10 transition-all">
          <ChevronRight size={15} />
        </button>

        <button onClick={() => setAutoPlay(v => !v)}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
            autoPlay ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25' : 'bg-white/6 border border-white/10 text-white/40 hover:text-white/70'
          }`}>
          {autoPlay ? <Pause size={12} /> : <Play size={12} />}
        </button>
      </div>
    </div>
  );
}

// ── Screen: Login ─────────────────────────────────────────────────────────────
function LoginScreen() {
  return (
    <div style={{ background: '#070b14', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 28px', gap: 20 }}>
      <div style={{ width: 52, height: 52, borderRadius: 16, background: 'rgba(99,102,241,0.2)', border: '1px solid rgba(99,102,241,0.35)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ fontSize: 22 }}>⚡</span>
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ color: '#fff', fontWeight: 900, fontSize: 20 }}>Behavior Engine</div>
        <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 4 }}>Human Performance OS</div>
      </div>
      <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, padding: '12px 16px' }}>
          <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: 10, marginBottom: 4 }}>EMAIL</div>
          <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13 }}>marcus@acme.com</div>
        </div>
        <div style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, padding: '12px 16px' }}>
          <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: 10, marginBottom: 4 }}>PASSWORD</div>
          <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: 13 }}>••••••••</div>
        </div>
        <div style={{ background: '#6366f1', borderRadius: 12, padding: '14px 16px', textAlign: 'center', color: '#fff', fontWeight: 700, fontSize: 14 }}>
          Sign In →
        </div>
      </div>
      <div style={{ color: 'rgba(255,255,255,0.2)', fontSize: 10, textAlign: 'center' }}>
        Acme Sales Team · 18 active members
      </div>
    </div>
  );
}

// ── Screen: Dashboard ─────────────────────────────────────────────────────────
function DashboardScreen() {
  const user = TEAM[0];
  const cfg  = STATUS[user.status];
  const pct  = Math.round((user.score / 40) * 100);
  return (
    <div style={{ background: '#070b14', height: '100%', overflowY: 'auto', padding: '48px 16px 20px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: 2 }}>TODAY</div>
          <div style={{ color: '#fff', fontWeight: 800, fontSize: 16, marginTop: 2 }}>Hey, Marcus 👋</div>
        </div>
        <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 11 }}>
          MC
        </div>
      </div>

      {/* Score card */}
      <div style={{ background: cfg.bg, border: '1px solid ' + cfg.border, borderRadius: 16, padding: '18px 20px', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 10 }}>
          <div>
            <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: 10, marginBottom: 4 }}>TODAY'S SCORE</div>
            <div style={{ color: cfg.color, fontSize: 48, fontWeight: 900, lineHeight: 1 }}>{user.score}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ color: cfg.color, fontWeight: 800, fontSize: 13, marginBottom: 4 }}>{user.status}</div>
            <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 10 }}>🔥 {user.streak}-day streak</div>
          </div>
        </div>
        <div style={{ height: 6, background: 'rgba(255,255,255,0.08)', borderRadius: 99, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: Math.min(100, pct) + '%', background: cfg.color, borderRadius: 99 }} />
        </div>
        <div style={{ color: 'rgba(255,255,255,0.25)', fontSize: 10, marginTop: 6 }}>{user.tasks} tasks completed · #{TEAM.indexOf(user) + 1} on team</div>
      </div>

      {/* Task list */}
      {[
        { title: 'Morning check-in',    pts: 10, done: true  },
        { title: 'Log 3 sales calls',   pts: 15, done: true  },
        { title: 'Update CRM pipeline', pts: 10, done: true  },
        { title: 'Submit daily report', pts: 10, done: false },
      ].map((t, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, background: t.done ? 'rgba(16,185,129,0.06)' : 'rgba(255,255,255,0.04)', border: '1px solid ' + (t.done ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.07)'), marginBottom: 7 }}>
          <div style={{ width: 18, height: 18, borderRadius: 5, background: t.done ? '#10b981' : 'transparent', border: '1.5px solid ' + (t.done ? '#10b981' : 'rgba(255,255,255,0.2)'), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            {t.done && <span style={{ color: '#fff', fontSize: 9 }}>✓</span>}
          </div>
          <span style={{ flex: 1, color: t.done ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.7)', fontSize: 12, textDecoration: t.done ? 'line-through' : 'none' }}>{t.title}</span>
          <span style={{ color: t.done ? '#10b981' : 'rgba(255,255,255,0.2)', fontSize: 10, fontWeight: 600 }}>+{t.pts}</span>
        </div>
      ))}
    </div>
  );
}

// ── Screen: Leaderboard ───────────────────────────────────────────────────────
function LeaderboardScreen() {
  const greenCount  = TEAM.filter(u => u.status === 'GREEN').length;
  const teamAvg     = Math.round(TEAM.reduce((s, u) => s + u.score, 0) / TEAM.length);
  return (
    <div style={{ background: '#070b14', height: '100%', overflowY: 'auto', padding: '48px 16px 20px' }}>
      <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: 2, marginBottom: 4 }}>TODAY</div>
      <div style={{ color: '#fff', fontWeight: 900, fontSize: 18, marginBottom: 16 }}>Team Rankings</div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {[['Avg', teamAvg, '#6366f1'], [greenCount + ' Green', '', '#10b981'], [TEAM.length + ' total', '', 'rgba(255,255,255,0.3)']].map(([l, v, c]) => (
          <div key={l} style={{ flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, padding: '8px 10px' }}>
            <div style={{ color: c, fontWeight: 800, fontSize: 15 }}>{v}</div>
            <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 9 }}>{l}</div>
          </div>
        ))}
      </div>

      {TEAM.slice(0, 8).map((user, i) => {
        const cfg = STATUS[user.status];
        return (
          <div key={user.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', borderRadius: 10, background: cfg.bg, border: '1px solid ' + cfg.border, marginBottom: 5 }}>
            <span style={{ color: 'rgba(255,255,255,0.2)', fontSize: 9, fontFamily: 'monospace', width: 14 }}>#{i + 1}</span>
            <div style={{ width: 26, height: 26, borderRadius: '50%', background: AVATAR_COLORS[i], display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 9, flexShrink: 0 }}>
              {user.avatar}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: '#fff', fontSize: 11, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.name}</div>
              <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 9 }}>{user.streak > 0 ? '🔥' + user.streak + 'd streak' : 'No streak'}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ color: cfg.color, fontWeight: 900, fontSize: 15 }}>{user.score}</div>
              <div style={{ color: cfg.color, fontSize: 8, fontWeight: 700 }}>{user.status}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Screen: AI Coach ──────────────────────────────────────────────────────────
function AICoachScreen() {
  const [msg, setMsg] = useState('');
  const insight = AI_INSIGHTS[1]; // James risk alert
  return (
    <div style={{ background: '#070b14', height: '100%', display: 'flex', flexDirection: 'column', padding: '48px 0 0' }}>
      <div style={{ padding: '0 16px 12px', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: 2, marginBottom: 2 }}>AI COACH</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(99,102,241,0.2)', border: '1px solid rgba(99,102,241,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>⚡</div>
          <div>
            <div style={{ color: '#fff', fontWeight: 700, fontSize: 13 }}>The Disciplinarian</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981' }} />
              <span style={{ color: '#10b981', fontSize: 9, fontWeight: 600 }}>LIVE</span>
            </div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {/* Coach messages */}
        {[
          { from: 'coach', text: 'Marcus. Score: 87. You are executing. Now protect this weekend — maintain the 12-day streak.' },
          { from: 'user',  text: 'What about James? He seems off.' },
          { from: 'coach', text: 'James has missed 3 consecutive days after strong weeks — classic burnout pattern. I\'ve already switched his coaching mode to Motivator and scheduled a re-engagement message for 7AM.' },
        ].map((m, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: m.from === 'user' ? 'row-reverse' : 'row', gap: 8 }}>
            {m.from === 'coach' && (
              <div style={{ width: 26, height: 26, borderRadius: 8, background: 'rgba(99,102,241,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, flexShrink: 0 }}>⚡</div>
            )}
            <div style={{ maxWidth: '78%', background: m.from === 'user' ? '#6366f1' : 'rgba(255,255,255,0.06)', border: m.from === 'coach' ? '1px solid rgba(255,255,255,0.08)' : 'none', borderRadius: m.from === 'user' ? '14px 14px 2px 14px' : '14px 14px 14px 2px', padding: '10px 12px' }}>
              <div style={{ color: m.from === 'user' ? '#fff' : 'rgba(255,255,255,0.75)', fontSize: 11, lineHeight: 1.5 }}>{m.text}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ padding: '10px 16px 16px' }}>
        <div style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ color: 'rgba(255,255,255,0.2)', fontSize: 12, flex: 1 }}>Ask your coach…</span>
          <div style={{ width: 26, height: 26, borderRadius: 8, background: '#6366f1', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ color: '#fff', fontSize: 11 }}>→</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Screen: Metrics ───────────────────────────────────────────────────────────
function MetricsScreen() {
  const weeks = [42, 55, 61, 68, 72, 78];
  const maxV  = Math.max(...weeks);
  return (
    <div style={{ background: '#070b14', height: '100%', overflowY: 'auto', padding: '48px 16px 20px' }}>
      <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: 2, marginBottom: 4 }}>ANALYTICS</div>
      <div style={{ color: '#fff', fontWeight: 900, fontSize: 18, marginBottom: 4 }}>Team Execution</div>
      <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: 11, marginBottom: 20 }}>6-week trend · Acme Sales</div>

      {/* Chart */}
      <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 14, padding: '16px 16px 12px', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 80 }}>
          {weeks.map((w, i) => {
            const h = Math.round((w / maxV) * 80);
            const isLast = i === weeks.length - 1;
            return (
              <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                <div style={{ width: '100%', height: h, background: isLast ? '#6366f1' : 'rgba(99,102,241,0.35)', borderRadius: '3px 3px 0 0', position: 'relative' }}>
                  {isLast && <div style={{ position: 'absolute', top: -18, left: '50%', transform: 'translateX(-50%)', color: '#6366f1', fontSize: 9, fontWeight: 700, whiteSpace: 'nowrap' }}>{w}%</div>}
                </div>
                <div style={{ color: 'rgba(255,255,255,0.2)', fontSize: 8 }}>W{i + 1}</div>
              </div>
            );
          })}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10 }}>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10 }}>6 weeks ago: 42%</div>
          <div style={{ color: '#10b981', fontWeight: 700, fontSize: 10 }}>↑ +36% execution rate</div>
        </div>
      </div>

      {/* KPIs */}
      {[
        ['Consistency', '81%', '#10b981'],
        ['Active Users', '16 / 18', '#6366f1'],
        ['Avg Streak', '4.2 days', '#f59e0b'],
        ['RED Days Eliminated', '−67%', '#10b981'],
      ].map(([label, val, color]) => (
        <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 12px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 10, marginBottom: 6 }}>
          <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11 }}>{label}</span>
          <span style={{ color: color, fontWeight: 800, fontSize: 13 }}>{val}</span>
        </div>
      ))}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function InvestorPitch() {
  const [screenIdx, setScreenIdx] = useState(0);
  const [autoPlay,  setAutoPlay]  = useState(false);
  const [fullscreen,setFullscreen]= useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    if (autoPlay) {
      timerRef.current = setInterval(() => {
        setScreenIdx(i => (i + 1) % SCREENS.length);
      }, 4000);
    }
    return () => clearInterval(timerRef.current);
  }, [autoPlay]);

  const next = () => setScreenIdx(i => (i + 1) % SCREENS.length);
  const prev = () => setScreenIdx(i => (i - 1 + SCREENS.length) % SCREENS.length);

  const SCREEN_COMPONENTS = [
    <LoginScreen />,
    <DashboardScreen />,
    <LeaderboardScreen />,
    <AICoachScreen />,
    <MetricsScreen />,
  ];

  const currentScreen = SCREEN_COMPONENTS[screenIdx];
  const currentMeta   = SCREENS[screenIdx];
  const Icon          = currentMeta.icon;

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">Live Demo · {COMPANY.name}</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Investor Demo</h1>
            <p className="text-white/35 text-sm">
              Clickable product simulation — show this to investors, clients, and pilots.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setAutoPlay(v => !v)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                autoPlay ? 'bg-indigo-500 border-indigo-400 text-white' : 'bg-white/5 border-white/10 text-white/40 hover:text-white/60'
              }`}>
              {autoPlay ? <><Pause size={11} /> Pause Demo</> : <><Play size={11} /> Auto Demo</>}
            </button>
          </div>
        </div>

        {/* Company info bar */}
        <div className="flex items-center gap-4 p-3 rounded-xl bg-white/3 border border-white/8 flex-wrap">
          {[
            ['Company', COMPANY.name, 'text-white/60'],
            ['Plan', COMPANY.plan, 'text-indigo-400'],
            ['Team', COMPANY.teamSize + ' users', 'text-white/60'],
            ['MRR', '$' + COMPANY.mrr + '/mo', 'text-emerald-400'],
          ].map(([l, v, c]) => (
            <div key={l} className="flex items-center gap-2">
              <span className="text-white/25 text-[9px] uppercase">{l}:</span>
              <span className={`text-xs font-bold ${c}`}>{v}</span>
            </div>
          ))}
          <div className="ml-auto flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-400 text-[9px] font-bold">SIMULATED LIVE</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-[auto_1fr] gap-8 items-start">
          {/* Phone */}
          <Phone
            screen={currentScreen}
            onNext={next}
            onPrev={prev}
            autoPlay={autoPlay}
            setAutoPlay={setAutoPlay}
            screenIdx={screenIdx}
          />

          {/* Right panel */}
          <div className="space-y-4">
            {/* Screen selector */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Screens</p>
              <div className="space-y-1.5">
                {SCREENS.map((s, i) => {
                  const Icon = s.icon;
                  const active = i === screenIdx;
                  return (
                    <button key={s.id} onClick={() => setScreenIdx(i)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border text-sm font-semibold transition-all ${
                        active ? 'bg-indigo-500/15 border-indigo-500/25 text-indigo-300' : 'bg-white/2 border-white/6 text-white/40 hover:text-white/60 hover:bg-white/5'
                      }`}>
                      <Icon size={14} className={active ? 'text-indigo-400' : 'text-white/25'} />
                      <span>{s.label}</span>
                      {active && <ChevronRight size={12} className="ml-auto text-indigo-400" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* AI insights */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Live AI Insights</p>
              <div className="space-y-2">
                {AI_INSIGHTS.slice(0, 3).map((ins, i) => (
                  <div key={i} className={`p-3 rounded-xl border text-xs ${
                    ins.priority === 'urgent' ? 'bg-red-500/6 border-red-500/20' :
                    ins.priority === 'high'   ? 'bg-indigo-500/6 border-indigo-500/20' :
                    'bg-white/3 border-white/8'
                  }`}>
                    <div className="flex items-center gap-2 mb-1">
                      <div className={`w-1.5 h-1.5 rounded-full ${ins.priority === 'urgent' ? 'bg-red-400' : ins.priority === 'high' ? 'bg-indigo-400' : 'bg-white/30'}`} />
                      <span className="text-white/40 font-bold text-[9px] uppercase">{ins.user}</span>
                    </div>
                    <p className="text-white/55 leading-snug">{ins.insight}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Talking points */}
            <div className="p-4 rounded-xl bg-white/2 border border-white/8">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Investor Talking Points</p>
              <div className="space-y-1.5">
                {[
                  'Team execution went from 42% → 78% in 6 weeks',
                  'AI detects burnout patterns before managers notice',
                  '0 manual work — fully automated coaching + alerts',
                  '$166/user/year vs $50k+ in performance consulting',
                ].map((p, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <CheckCircle2 size={11} className="text-emerald-400 shrink-0 mt-0.5" />
                    <p className="text-white/50 text-xs">{p}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
