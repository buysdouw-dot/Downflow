/**
 * AIv4 — Fully Agent-Run Company (No Dashboards, No Humans)
 * The final form. Agents run every business function autonomously.
 * Sales Agent · Onboarding Agent · Retention Agent · Revenue Agent · Growth Agent
 * Each agent has a job. They run on schedule. They report to each other.
 * You are the board, not the operator.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Cpu, Play, RefreshCw, ArrowRight, CheckCircle2,
  DollarSign, Users, TrendingUp, Brain, Mail,
  Zap, Shield, Layers, GitBranch, BarChart2,
  Clock, Repeat, Eye, AlertTriangle, Sparkles,
} from 'lucide-react';

// ── 5 Company-Level Agents ────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'sales',
    name: 'Sales Agent',
    job: 'Runs outbound entirely',
    color: '#818cf8',
    bg: 'rgba(99,102,241,0.07)',
    border: 'rgba(99,102,241,0.18)',
    Icon: Mail,
    schedule: 'Every 6 hours',
    tasks: [
      'Scrapes new leads from LinkedIn / Hunter.io',
      'Scores each lead (company size, role, fit)',
      'Sends personalised cold outreach sequence',
      'Books demo call if reply detected',
      'Logs CRM automatically (no human entry)',
    ],
    output: (d) => `Found ${d.leadsFound} new leads. Sent ${d.outreach} messages. ${d.replied} replied. ${d.demos} demos booked.`,
    kpi: 'Demos booked / week',
  },
  {
    id: 'onboarding',
    name: 'Onboarding Agent',
    job: 'Activates every new user',
    color: '#34d399',
    bg: 'rgba(16,185,129,0.07)',
    border: 'rgba(16,185,129,0.18)',
    Icon: Users,
    schedule: 'On signup + Day 1, 3, 7',
    tasks: [
      'Sends personalised welcome sequence (not templates)',
      'Detects if user completed Step 1 (score visible)',
      'Intervenes if Day 1 task not done by 8pm',
      'Invites 3 teammates automatically if team size > 1',
      'Marks user as "activated" if score > 0 in 48h',
    ],
    output: (d) => `${d.newUsers} new signups. ${d.activated} activated (${d.activationRate}% rate). ${d.stalled} stalled → rescue triggered.`,
    kpi: 'Day-1 activation rate',
  },
  {
    id: 'retention',
    name: 'Retention Agent',
    job: 'Prevents every churn',
    color: '#22d3ee',
    bg: 'rgba(6,182,212,0.07)',
    border: 'rgba(6,182,212,0.18)',
    Icon: Shield,
    schedule: 'Daily at 7am',
    tasks: [
      'Scans every user for churn signal (3 missed days)',
      'Sends targeted "we noticed you\'ve been busy" message',
      'Triggers AI coach personality switch if normal tone failing',
      'Escalates to human if risk score > 85% (rare)',
      'Offers pause (not cancel) 5 days before renewal',
    ],
    output: (d) => `Scanned ${d.scanned} users. ${d.atRisk} at risk. ${d.saved} saved. ${d.escalated} escalated. Projected churn: ${d.projectedChurn}%.`,
    kpi: 'Monthly churn rate',
  },
  {
    id: 'revenue',
    name: 'Revenue Agent',
    job: 'Maximises MRR automatically',
    color: '#fbbf24',
    bg: 'rgba(245,158,11,0.07)',
    border: 'rgba(245,158,11,0.18)',
    Icon: DollarSign,
    schedule: 'Weekly on Monday',
    tasks: [
      'Identifies teams ready for upgrade (5+ seats active)',
      'Sends upgrade prompt with their own usage data',
      'Proposes annual plan to high-engagement users',
      'Detects value delivery gap → triggers win-back',
      'Adjusts price for new signups based on demand signal',
    ],
    output: (d) => `Detected ${d.upgradeReady} upgrade-ready accounts. Sent ${d.proposals} proposals. ${d.conversions} converted ($${d.mrrAdded} MRR added).`,
    kpi: 'Net Revenue Retention',
  },
  {
    id: 'growth',
    name: 'Growth Agent',
    job: 'Amplifies distribution',
    color: '#f472b6',
    bg: 'rgba(236,72,153,0.07)',
    border: 'rgba(236,72,153,0.18)',
    Icon: TrendingUp,
    schedule: 'Every 12 hours',
    tasks: [
      'Posts execution insights to LinkedIn / Twitter (auto)',
      'Identifies users with viral potential (score > 80%)',
      'Sends "share your score" prompt to top performers',
      'Monitors referral link clicks → nurtures referrals',
      'A/B tests outreach copy automatically (1 variant/week)',
    ],
    output: (d) => `Posted ${d.posts} pieces of content. ${d.viralUsers} users triggered to share. ${d.referrals} new referrals. ${d.ab} A/B test running.`,
    kpi: 'Viral coefficient K',
  },
];

// ── Company functions each agent handles ──────────────────────────────────────
const FUNCTIONS = [
  { fn: 'Lead Generation',    agent: 'sales',      human: 'Was: 8h/week manually sourcing leads' },
  { fn: 'Cold Outreach',      agent: 'sales',      human: 'Was: 2h/day writing DMs' },
  { fn: 'User Onboarding',    agent: 'onboarding', human: 'Was: Zoom call per new user' },
  { fn: 'Churn Prevention',   agent: 'retention',  human: 'Was: Manual check-in emails' },
  { fn: 'Upsell / Expansion', agent: 'revenue',    human: 'Was: Monthly account reviews' },
  { fn: 'Content / Social',   agent: 'growth',     human: 'Was: 1h/day writing posts' },
  { fn: 'CRM Updates',        agent: 'sales',      human: 'Was: Logging calls manually' },
  { fn: 'Pricing Decisions',  agent: 'revenue',    human: 'Was: Quarterly pricing meeting' },
];

// ── Simulated live data per agent ─────────────────────────────────────────────
const LIVE_DATA = {
  sales:      { leadsFound: 47, outreach: 38, replied: 6, demos: 2 },
  onboarding: { newUsers: 14, activated: 11, activationRate: 79, stalled: 3 },
  retention:  { scanned: 203, atRisk: 18, saved: 14, escalated: 1, projectedChurn: 3.2 },
  revenue:    { upgradeReady: 7, proposals: 7, conversions: 2, mrrAdded: 400 },
  growth:     { posts: 3, viralUsers: 22, referrals: 4, ab: '\'Execution score\' headline' },
};

// ── Loop steps ─────────────────────────────────────────────────────────────────
const LOOP = [
  { id: 'trigger',  label: 'Trigger',    desc: 'Schedule / event fires agent', color: '#818cf8', Icon: Clock     },
  { id: 'read',     label: 'Read',       desc: 'Agent reads live system state', color: '#22d3ee', Icon: Eye       },
  { id: 'decide',   label: 'Decide',     desc: 'Agent calculates best action',  color: '#a78bfa', Icon: Brain     },
  { id: 'execute',  label: 'Execute',    desc: 'Action deployed automatically', color: '#34d399', Icon: Zap       },
  { id: 'log',      label: 'Log',        desc: 'Result stored in memory',       color: '#fbbf24', Icon: Layers    },
  { id: 'report',   label: 'Report',     desc: 'Weekly summary to founder',     color: '#f472b6', Icon: BarChart2 },
];

// ── Persistence ────────────────────────────────────────────────────────────────
function loadState()  { try { return JSON.parse(localStorage.getItem('be_aiv4')) ?? { runs: 0, log: [] }; } catch { return { runs: 0, log: [] }; } }
function saveState(s) { try { localStorage.setItem('be_aiv4', JSON.stringify(s)); } catch {} }

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AIv4() {
  const [activeAgent, setActiveAgent] = useState(null);
  const [loopStep,    setLoopStep]    = useState(-1);
  const [running,     setRunning]     = useState(false);
  const [sysState,    setSysState_]   = useState(loadState);
  const [view,        setView]        = useState('company'); // 'company' | 'loop' | 'future'
  const timerRef = useRef(null);

  const setSysState = s => { setSysState_(s); saveState(s); };

  const runAllAgents = () => {
    if (running) return;
    setRunning(true);
    setLoopStep(0);
    setActiveAgent(null);

    let step = 0;
    timerRef.current = setInterval(() => {
      step++;
      if (step < LOOP.length) {
        setLoopStep(step);
      } else {
        clearInterval(timerRef.current);
        // Cycle through agents one by one
        let ai = 0;
        const cycleAgents = setInterval(() => {
          setActiveAgent(AGENTS[ai].id);
          ai++;
          if (ai >= AGENTS.length) {
            clearInterval(cycleAgents);
            const newState = {
              runs: sysState.runs + 1,
              log: [
                {
                  run: sysState.runs + 1,
                  ts: new Date().toLocaleTimeString(),
                  summary: `All 5 agents ran. ${LIVE_DATA.sales.demos} demos booked, ${LIVE_DATA.onboarding.activated} users activated, $${LIVE_DATA.revenue.mrrAdded} MRR added.`,
                },
                ...sysState.log.slice(0, 9),
              ],
            };
            setSysState(newState);
            setRunning(false);
            setLoopStep(5);
          }
        }, 400);
      }
    }, 380);
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  const agentColor = (id) => AGENTS.find(a => a.id === id)?.color ?? '#fff';

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={13} className="text-pink-400" />
              <p className="text-pink-400 text-xs font-bold uppercase tracking-widest">Autonomous AI v4</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Agent-Run Company</h1>
            <p className="text-white/35 text-sm">
              No dashboards. No manual tasks. 5 agents run every business function.
              You review the weekly report — nothing else.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right p-3 rounded-xl border border-pink-500/20 bg-pink-500/5">
              <p className="text-lg font-black text-pink-400">{sysState.runs}</p>
              <p className="text-white/20 text-[9px]">agent runs</p>
            </div>
            <button onClick={runAllAgents} disabled={running}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${
                running ? 'bg-pink-500/10 border border-pink-500/20 text-pink-400' : 'bg-pink-500 hover:bg-pink-400 text-white shadow-lg shadow-pink-500/20'
              }`}>
              {running ? <><RefreshCw size={13} className="animate-spin" /> Running…</> : <><Play size={13} /> Run All Agents</>}
            </button>
          </div>
        </div>

        {/* View tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6">
          {[['company','Agent Dashboard'],['loop','How It Works'],['future','The Future State']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-pink-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── COMPANY VIEW ─────────────────────────────────────── */}
        {view === 'company' && (
          <div className="space-y-5">
            {/* Agent grid */}
            <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {AGENTS.map(agent => {
                const AIcon = agent.Icon;
                const isActive = activeAgent === agent.id;
                const output = agent.output(LIVE_DATA[agent.id]);
                return (
                  <div key={agent.id}
                    className="p-4 rounded-2xl border transition-all duration-300"
                    style={{
                      borderColor: isActive ? agent.border.replace('0.18','0.4') : agent.border,
                      background:  isActive ? agent.bg.replace('0.07','0.12') : agent.bg,
                      transform:   isActive ? 'scale(1.01)' : 'scale(1)',
                    }}>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                        style={{ background: agent.bg, border: `1px solid ${agent.border}` }}>
                        <AIcon size={13} style={{ color: agent.color }} />
                      </div>
                      <div className="flex-1">
                        <p className="text-xs font-bold" style={{ color: agent.color }}>{agent.name}</p>
                        <p className="text-white/25 text-[9px]">{agent.job}</p>
                      </div>
                      {isActive && <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: agent.color }} />}
                    </div>

                    <div className="space-y-1 mb-3">
                      {agent.tasks.slice(0, 3).map(t => (
                        <div key={t} className="flex items-start gap-1.5">
                          <CheckCircle2 size={8} style={{ color: agent.color, opacity: 0.6 }} className="shrink-0 mt-0.5" />
                          <span className="text-white/30 text-[9px] leading-snug">{t}</span>
                        </div>
                      ))}
                    </div>

                    <div className="p-2.5 rounded-lg bg-black/25 border border-white/5">
                      <p className="text-[8px] uppercase tracking-widest mb-1" style={{ color: agent.color, opacity: 0.6 }}>Last run output</p>
                      <p className="text-white/50 text-[9px] leading-snug">{output}</p>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-white/20 text-[8px]">KPI: {agent.kpi}</span>
                      <span className="text-[8px] px-1.5 py-0.5 rounded border" style={{ color: agent.color, borderColor: agent.border }}>
                        {agent.schedule}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Functions replaced */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Business Functions Replaced</p>
              <div className="grid lg:grid-cols-2 gap-2">
                {FUNCTIONS.map(({ fn, agent: agentId, human }) => {
                  const a = AGENTS.find(ag => ag.id === agentId);
                  return (
                    <div key={fn} className="flex items-center gap-3 p-2.5 rounded-xl border border-white/6 bg-white/1">
                      <CheckCircle2 size={10} style={{ color: a?.color }} className="shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-white/60 text-[10px] font-semibold">{fn}</p>
                        <p className="text-white/20 text-[8px] truncate">{human}</p>
                      </div>
                      <span className="text-[8px] font-bold shrink-0" style={{ color: a?.color }}>{a?.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Run log */}
            {sysState.log.length > 0 && (
              <div className="space-y-2">
                <p className="text-white/25 text-[9px] uppercase tracking-widest">Run Log</p>
                {sysState.log.map((entry, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border ${i === 0 ? 'border-pink-500/20 bg-pink-500/4' : 'border-white/5 bg-white/1'}`}>
                    <span className="text-white/15 text-[9px] font-mono w-5 shrink-0">#{entry.run}</span>
                    <p className="text-white/40 text-xs flex-1 leading-snug">{entry.summary}</p>
                    <span className="text-white/15 text-[8px] font-mono shrink-0">{entry.ts}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── HOW IT WORKS ─────────────────────────────────────── */}
        {view === 'loop' && (
          <div className="space-y-5">
            {/* Agent loop */}
            <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-4">Agent Execution Loop</p>
              <div className="flex items-center gap-2 flex-wrap">
                {LOOP.map((step, i) => {
                  const StepIcon = step.Icon;
                  const isActive = running && loopStep === i;
                  const isDone   = loopStep > i && loopStep >= 0;
                  return (
                    <div key={step.id} className="flex items-center gap-2">
                      <div className="flex items-center gap-2 px-3 py-2 rounded-xl border transition-all duration-300"
                        style={{
                          borderColor: isActive ? step.color : isDone ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.06)',
                          background:  isActive ? step.color + '12' : isDone ? 'rgba(16,185,129,0.05)' : 'rgba(255,255,255,0.02)',
                          transform: isActive ? 'scale(1.05)' : 'scale(1)',
                        }}>
                        <StepIcon size={10} style={{ color: isActive ? step.color : isDone ? '#34d399' : 'rgba(255,255,255,0.2)' }} />
                        <span className="text-[10px] font-semibold"
                          style={{ color: isActive ? step.color : isDone ? '#34d399' : 'rgba(255,255,255,0.3)' }}>
                          {step.label}
                        </span>
                        {isActive && <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: step.color }} />}
                      </div>
                      {i < LOOP.length - 1 && <ArrowRight size={9} className={isDone ? 'text-emerald-400/40' : 'text-white/10'} />}
                    </div>
                  );
                })}
              </div>
              {running && loopStep >= 0 && (
                <p className="text-white/25 text-xs mt-3 italic">{LOOP[loopStep]?.desc}</p>
              )}
            </div>

            {/* Architecture */}
            <div className="p-5 rounded-2xl bg-black/40 border border-white/8">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-3">v4 Architecture (conceptual)</p>
              <pre className="text-[9px] text-pink-400/75 font-mono leading-relaxed">{`// Every agent follows this interface

class Agent {
  constructor(name, schedule, tools) {
    this.name     = name
    this.schedule = schedule  // cron expression
    this.tools    = tools     // what the agent can call
    this.memory   = new Memory(name)
  }

  async run(context) {
    const state   = await this.observe(context)     // read signals
    const plan    = await this.decide(state)         // LLM reasoning
    const results = await this.execute(plan)         // call tools
    await this.memory.store({ state, plan, results }) // log
    return results
  }
}

// Orchestrator coordinates all 5 agents
const company = new AgentCompany([
  new SalesAgent(),
  new OnboardingAgent(),
  new RetentionAgent(),
  new RevenueAgent(),
  new GrowthAgent(),
])

// You just call:
company.runAll()
// That's it. The company operates itself.`}</pre>
            </div>

            {/* Tools each agent uses */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-3">Tools Each Agent Has Access To</p>
              <div className="grid lg:grid-cols-2 gap-3">
                {[
                  { name: 'Sales Agent tools',      tools: ['LinkedIn API', 'Hunter.io (email find)', 'SendGrid (email)', 'Calendly API', 'CRM write'] },
                  { name: 'Onboarding Agent tools', tools: ['Twilio (SMS)', 'SendGrid (email)', 'User DB read/write', 'Product analytics', 'Slack webhook'] },
                  { name: 'Retention Agent tools',  tools: ['Usage DB (read)', 'SendGrid (email)', 'Stripe (pause sub)', 'CRM flag', 'Slack escalation'] },
                  { name: 'Revenue Agent tools',    tools: ['Stripe (invoices)', 'CRM read/write', 'Usage analytics', 'Pricing DB write', 'Email send'] },
                ].map(({ name, tools }) => (
                  <div key={name} className="p-3 rounded-xl border border-white/8 bg-black/15">
                    <p className="text-white/40 text-[9px] font-bold uppercase tracking-widest mb-2">{name}</p>
                    {tools.map(t => (
                      <div key={t} className="flex items-center gap-1.5 mb-1">
                        <div className="w-1 h-1 rounded-full bg-white/20 shrink-0" />
                        <span className="text-white/35 text-[9px]">{t}</span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── FUTURE STATE ─────────────────────────────────────── */}
        {view === 'future' && (
          <div className="space-y-5">
            <div className="p-5 rounded-2xl border border-pink-500/20 bg-pink-500/5">
              <p className="text-pink-400 font-bold text-sm mb-3">What your week looks like at v4</p>
              <div className="space-y-3">
                {[
                  { day: 'Monday',   task: 'Read weekly agent report (5 min). Approve or reject 1–2 decisions flagged for human review.',           color: 'text-white/60' },
                  { day: 'Tuesday',  task: 'No tasks. Agents are running outreach, onboarding new users, and sending retention messages.',            color: 'text-white/30' },
                  { day: 'Wednesday',task: 'Review 1 A/B test result from Growth Agent. Approve next experiment.',                                   color: 'text-white/60' },
                  { day: 'Thursday', task: 'No tasks. Revenue Agent ran upsell campaign. Retention Agent intervened on 3 at-risk accounts.',         color: 'text-white/30' },
                  { day: 'Friday',   task: 'Strategy session: which market to expand into next? Agents handle the current one.',                      color: 'text-white/60' },
                  { day: 'Weekend',  task: 'Nothing. The company is running. Check Stripe if you want to feel good about it.',                        color: 'text-white/30' },
                ].map(({ day, task, color }) => (
                  <div key={day} className="flex gap-4 p-3 rounded-xl border border-white/6 bg-white/2">
                    <span className="text-white/35 text-xs font-bold w-20 shrink-0">{day}</span>
                    <p className={`text-xs leading-snug ${color}`}>{task}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* The shift */}
            <div className="grid lg:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
                <p className="text-white/35 text-xs font-bold uppercase tracking-widest mb-3">Before v4 (you as operator)</p>
                {[
                  '2h/day on outreach and follow-ups',
                  'Manual onboarding calls for every signup',
                  'Checking CRM and moving leads by hand',
                  'Writing posts and content yourself',
                  'Chasing renewals before they churn',
                  'Pricing experiments = hours in spreadsheets',
                ].map(t => (
                  <div key={t} className="flex items-start gap-2 mb-2">
                    <AlertTriangle size={9} className="text-red-400/60 shrink-0 mt-0.5" />
                    <span className="text-white/30 text-xs">{t}</span>
                  </div>
                ))}
              </div>
              <div className="p-5 rounded-2xl border border-pink-500/20 bg-pink-500/5">
                <p className="text-pink-400 text-xs font-bold uppercase tracking-widest mb-3">After v4 (you as board)</p>
                {[
                  'Sales Agent runs outreach on schedule',
                  'Onboarding Agent activates every signup',
                  'CRM updates itself in real time',
                  'Growth Agent posts content daily',
                  'Retention Agent catches churn before you see it',
                  'Revenue Agent A/B tests prices automatically',
                ].map(t => (
                  <div key={t} className="flex items-start gap-2 mb-2">
                    <CheckCircle2 size={9} className="text-pink-400 shrink-0 mt-0.5" />
                    <span className="text-white/55 text-xs">{t}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-pink-500/25 bg-pink-500/5">
              <p className="text-pink-400 font-bold text-sm mb-2">The Endgame Truth</p>
              <p className="text-white/50 text-sm leading-relaxed">
                v1: You build features.<br />
                v2: The product learns from users.<br />
                v3: The product improves itself.<br />
                <span className="text-pink-400 font-semibold">v4: The company runs itself. You set direction.</span>
              </p>
              <p className="text-white/30 text-xs mt-3 leading-relaxed">
                This is not science fiction. Every tool used by these agents (LinkedIn scraper, SendGrid, Stripe, Calendly)
                exists today and has an API. The only thing that changed is that an LLM can now orchestrate them
                with judgment — not just rules.
              </p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
