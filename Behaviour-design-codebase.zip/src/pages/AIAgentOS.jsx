import { useState, useEffect, useRef } from 'react';
import {
  Brain, MessageSquare, Zap, Eye, RefreshCw, Send,
  ArrowRight, CheckCircle2, AlertCircle, Activity,
  Mail, Phone, Bell, Code2, Copy, CheckCheck,
  BarChart2, ChevronRight, Bot, Cpu,
} from 'lucide-react';

// ── Agent actions log (simulated) ─────────────────────────────────────────────
const SEED_LOG = [
  { t: '08:02', agent: 'Observe',  msg: 'User opened app. Score: 0. No tasks logged.',         type: 'observe'  },
  { t: '08:03', agent: 'Decide',   msg: 'Score < 20 threshold. Trigger: push morning nudge.',   type: 'decide'   },
  { t: '08:03', agent: 'Act',      msg: 'WhatsApp: "Morning. Add your first task now."',         type: 'act'      },
  { t: '09:15', agent: 'Observe',  msg: 'Task added: "Send 20 outreach messages" (2 pts).',     type: 'observe'  },
  { t: '09:16', agent: 'Decide',   msg: 'Task added. No action needed yet.',                    type: 'decide'   },
  { t: '10:40', agent: 'Observe',  msg: 'Task completed. Score now: 20.',                       type: 'observe'  },
  { t: '10:41', agent: 'Decide',   msg: 'Score hit 20. Trigger: encouragement + next task.',   type: 'decide'   },
  { t: '10:41', agent: 'Act',      msg: 'Push: "20 pts. Add 1 more task to stay on track."',   type: 'act'      },
  { t: '12:00', agent: 'Observe',  msg: 'Midday check. Score: 20. Below 60 target.',            type: 'observe'  },
  { t: '12:00', agent: 'Decide',   msg: 'Below daily target. Trigger: midday push.',            type: 'decide'   },
  { t: '12:01', agent: 'Act',      msg: 'Email: "You\'re behind. 3 more tasks = 50pts today."',type: 'act'      },
  { t: '17:30', agent: 'Observe',  msg: 'End-of-day. Score: 70. Streak: 4 days.',              type: 'observe'  },
  { t: '17:31', agent: 'Decide',   msg: 'Score >= 60. Trigger: praise + share nudge.',         type: 'decide'   },
  { t: '17:31', agent: 'Act',      msg: 'WhatsApp: "70/100 today. 4-day streak. Share it."',   type: 'act'      },
  { t: '17:32', agent: 'Adjust',   msg: 'Tomorrow task set auto-raised to 8 (was 6).',         type: 'adjust'   },
];

// ── Agent modules ─────────────────────────────────────────────────────────────
const MODULES = [
  {
    id: 'observe',
    name: 'Observe',
    icon: Eye,
    color: 'text-blue-400',
    bg: 'bg-blue-900/20 border-blue-700/40',
    role: 'Watches every user event in real-time',
    triggers: [
      'Task added / completed / deleted',
      'Login / logout / inactivity (2h+)',
      'Score change',
      'Daily milestone crossed',
      'Subscription status change',
    ],
  },
  {
    id: 'decide',
    name: 'Decide',
    icon: Brain,
    color: 'text-violet-400',
    bg: 'bg-violet-900/20 border-violet-700/40',
    role: 'Applies rule tree + optional GPT-4o-mini reasoning',
    triggers: [
      'Score < 20 AND no message in 3h → nudge',
      'Score >= 80 → praise + share trigger',
      'Inactivity 2h during work hours → check-in',
      'Streak milestone → celebrate + viral share',
      'Daily completion rate < 50% by 4pm → urgent push',
    ],
  },
  {
    id: 'act',
    name: 'Act',
    icon: Send,
    color: 'text-green-400',
    bg: 'bg-green-900/20 border-green-700/40',
    role: 'Sends message via best available channel',
    triggers: [
      'WhatsApp (Twilio) — highest open rate',
      'Push notification (web/mobile)',
      'Email (Resend/Sendgrid) — fallback',
      'In-app banner (no channel needed)',
      'Slack DM (enterprise tier)',
    ],
  },
  {
    id: 'adjust',
    name: 'Adjust',
    icon: RefreshCw,
    color: 'text-amber-400',
    bg: 'bg-amber-900/20 border-amber-700/40',
    role: 'Modifies user task load based on performance',
    triggers: [
      'Score avg > 85 for 3 days → increase tasks',
      'Score avg < 40 for 3 days → reduce tasks',
      'Task skipped 3x → remove from queue',
      'New task suggested from completion patterns',
      'Weekly "calibration" on Sunday midnight',
    ],
  },
];

// ── Output channels ────────────────────────────────────────────────────────────
const CHANNELS = [
  { id: 'whatsapp', label: 'WhatsApp',   icon: Phone,        openRate: '98%', latency: '<10s',  tier: 'pro'        },
  { id: 'push',     label: 'Push',       icon: Bell,         openRate: '45%', latency: '<5s',   tier: 'pro'        },
  { id: 'email',    label: 'Email',      icon: Mail,         openRate: '28%', latency: '<60s',  tier: 'free'       },
  { id: 'inapp',    label: 'In-App',     icon: MessageSquare,openRate: '70%', latency: 'live',  tier: 'free'       },
  { id: 'slack',    label: 'Slack',      icon: Activity,     openRate: '85%', latency: '<15s',  tier: 'enterprise' },
];

// ── Agent code ────────────────────────────────────────────────────────────────
const CODE = {
  'agent-core.js': `const cron   = require('node-cron');
const db     = require('../db/supabase');
const OpenAI = require('openai');
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// ── Observe ──────────────────────────────────────────────────────────────────
async function observe(userId) {
  const today = new Date().toISOString().split('T')[0];

  const [{ data: tasks }, { data: profile }] = await Promise.all([
    db.from('tasks').select('*').eq('user_id', userId).gte('created_at', today),
    db.from('profiles').select('*').eq('id', userId).single(),
  ]);

  const score     = tasks.filter(t => t.completed).length * 10;
  const total     = tasks.length;
  const completed = tasks.filter(t => t.completed).length;

  return { userId, score, total, completed, profile, tasks };
}

// ── Decide ───────────────────────────────────────────────────────────────────
async function decide(state) {
  const { score, total, completed, profile } = state;

  // Rule tree (fast, no API call)
  if (score === 0 && total === 0)
    return { action: 'nudge_start',    priority: 'high',   channel: 'whatsapp' };
  if (score < 20)
    return { action: 'nudge_low',      priority: 'medium', channel: 'push'     };
  if (score >= 80)
    return { action: 'praise_share',   priority: 'low',    channel: 'inapp'    };
  if (completed === total && total > 0)
    return { action: 'perfect_day',    priority: 'high',   channel: 'whatsapp' };

  // Default: no action needed
  return null;
}

// ── Act ──────────────────────────────────────────────────────────────────────
const MESSAGES = {
  nudge_start:  s => 'No tasks logged yet. Add 1 task and start.',
  nudge_low:    s => \`Score: \${s.score}/100. Add tasks to catch up.\`,
  praise_share: s => \`\${s.score}/100 today. Share your score and earn referral credit.\`,
  perfect_day:  s => \`Perfect execution today. All \${s.completed} tasks done. Raise the bar tomorrow.\`,
};

async function act(state, decision) {
  if (!decision) return;

  // Optional: enrich message with GPT
  let message = MESSAGES[decision.action]?.(state) || 'Keep executing.';
  if (process.env.OPENAI_API_KEY && decision.priority === 'high') {
    const res = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 60,
      messages: [
        { role: 'system', content: 'You are a brutal execution coach. 1 sentence, no fluff.' },
        { role: 'user',   content: \`Situation: \${decision.action}. Score: \${state.score}. Write message.\` },
      ],
    });
    message = res.choices[0].message.content.trim();
  }

  // Route to channel
  await sendToChannel({ userId: state.userId, channel: decision.channel, message });

  // Log agent action
  await db.from('agent_events').insert({
    user_id: state.userId,
    action:  decision.action,
    channel: decision.channel,
    message,
    score:   state.score,
  });
}

// ── Adjust ───────────────────────────────────────────────────────────────────
async function adjust(state) {
  const { userId, score, total } = state;
  if (score > 85 && total < 10) {
    // Auto-add a stretch task
    await db.from('tasks').insert({
      user_id: userId,
      title:   'Stretch goal: 1 extra outreach call',
      points:  2,
      source:  'agent',
    });
  }
}

// ── Full cycle ───────────────────────────────────────────────────────────────
async function runAgentCycle(userId) {
  const state    = await observe(userId);
  const decision = await decide(state);
  await act(state, decision);
  await adjust(state);
}

// ── Schedule: run for all active users ───────────────────────────────────────
cron.schedule('0 8,12,17 * * *', async () => {
  const { data: users } = await db
    .from('profiles')
    .select('id')
    .neq('subscription_status', 'cancelled');

  for (const user of (users || [])) {
    await runAgentCycle(user.id).catch(console.error);
  }
});

module.exports = { runAgentCycle };`,

  'send-channel.js': `const twilio  = require('twilio');
const resend  = require('@resend/node');
const db      = require('../db/supabase');

const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

async function sendToChannel({ userId, channel, message }) {
  const { data: profile } = await db
    .from('profiles')
    .select('email, phone, push_token')
    .eq('id', userId)
    .single();

  switch (channel) {
    case 'whatsapp':
      if (!profile.phone) break;
      await twilioClient.messages.create({
        from: 'whatsapp:+14155238886',
        to:   \`whatsapp:\${profile.phone}\`,
        body: message,
      });
      break;

    case 'email':
      await resend.emails.send({
        from:    'coach@behaviorengine.app',
        to:      profile.email,
        subject: 'Your Execution Coach',
        text:    message,
      });
      break;

    case 'push':
      // Use web-push or Expo for mobile
      if (profile.push_token) {
        await sendWebPush(profile.push_token, message);
      }
      break;

    case 'inapp':
      // Store as notification — frontend polls or subscribes
      await db.from('notifications').insert({
        user_id: userId,
        body:    message,
        read:    false,
      });
      break;
  }
}

module.exports = { sendToChannel };`,

  'supabase/agent-schema.sql': `-- Agent event log
create table if not exists public.agent_events (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references public.profiles(id) on delete cascade,
  action     text not null,
  channel    text not null,
  message    text,
  score      int,
  created_at timestamptz default now()
);

-- Notifications (in-app channel)
create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references public.profiles(id) on delete cascade,
  body       text not null,
  read       boolean not null default false,
  created_at timestamptz default now()
);

-- User preferences (channel opt-in/out)
create table if not exists public.agent_prefs (
  user_id        uuid primary key references public.profiles(id),
  channel_order  text[] default array['whatsapp','push','email','inapp'],
  quiet_hours    int[]  default array[22,23,0,1,2,3,4,5,6],  -- UTC hours to suppress
  updated_at     timestamptz default now()
);`,
};

// ── Simulated log state ────────────────────────────────────────────────────────
function useAgentLog() {
  const [log, setLog]  = useState(SEED_LOG.slice(0, 4));
  const [idx, setIdx]  = useState(4);
  const timerRef = useRef(null);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setIdx(i => {
        if (i >= SEED_LOG.length) {
          clearInterval(timerRef.current);
          return i;
        }
        setLog(prev => [...prev, SEED_LOG[i]]);
        return i + 1;
      });
    }, 900);
    return () => clearInterval(timerRef.current);
  }, []);

  return log;
}

export default function AIAgentOS() {
  const [tab,      setTab]     = useState('live');
  const [codeFile, setCodeFile] = useState('agent-core.js');
  const [copied,   setCopied]  = useState('');
  const log = useAgentLog();
  const logRef = useRef(null);

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [log]);

  function copy(key) {
    navigator.clipboard.writeText(CODE[key] || '');
    setCopied(key);
    setTimeout(() => setCopied(''), 1800);
  }

  const typeColor = {
    observe: 'text-blue-400',
    decide:  'text-violet-400',
    act:     'text-green-400',
    adjust:  'text-amber-400',
  };
  const typeBg = {
    observe: 'bg-blue-900/20',
    decide:  'bg-violet-900/20',
    act:     'bg-green-900/20',
    adjust:  'bg-amber-900/20',
  };

  const TABS = [
    { id: 'live',     label: 'Live Agent Log'  },
    { id: 'modules',  label: 'Agent Modules'   },
    { id: 'channels', label: 'Output Channels' },
    { id: 'code',     label: 'Agent Code'      },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white p-4 md:p-6">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="mb-6 flex items-start gap-4">
          <div className="p-2.5 bg-violet-900/40 rounded-xl border border-violet-700/50">
            <Brain size={24} className="text-violet-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black">AI Agent OS</h1>
            <p className="text-gray-400 text-sm mt-0.5">
              Observe → Decide → Act → Adjust. No dashboards needed.
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs text-green-400 font-semibold">RUNNING</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-gray-900 p-1 rounded-xl w-fit border border-gray-800">
          {TABS.map(({ id, label }) => (
            <button key={id} onClick={() => setTab(id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition
                ${tab === id ? 'bg-violet-600 text-white' : 'text-gray-400 hover:text-white'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* ── LIVE LOG ── */}
        {tab === 'live' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {MODULES.map(({ id, name, icon: Icon, color }) => (
                <div key={id} className="bg-gray-900 border border-gray-800 rounded-xl p-3 text-center">
                  <Icon size={18} className={`${color} mx-auto mb-1`} />
                  <p className={`text-sm font-bold ${color}`}>{name}</p>
                </div>
              ))}
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
              <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-800">
                <Activity size={13} className="text-green-400 animate-pulse" />
                <span className="text-sm font-semibold">Agent Activity Stream</span>
                <span className="ml-auto text-xs text-gray-500">{log.length} events today</span>
              </div>
              <div ref={logRef}
                className="overflow-y-auto max-h-96 divide-y divide-gray-800/60">
                {log.map((entry, i) => (
                  <div key={i} className={`flex items-start gap-3 px-4 py-3 ${typeBg[entry.type]}`}>
                    <span className="text-xs text-gray-600 font-mono w-10 flex-shrink-0 mt-0.5">
                      {entry.t}
                    </span>
                    <span className={`text-xs font-bold w-16 flex-shrink-0 mt-0.5 ${typeColor[entry.type]}`}>
                      {entry.agent}
                    </span>
                    <span className="text-xs text-gray-300 leading-relaxed">{entry.msg}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-3">Why no dashboard?</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                {[
                  { x: 'Dashboard (passive)',       y: 'Agent (active)'                     },
                  { x: 'User checks metrics',       y: 'Agent checks user, sends action'    },
                  { x: 'User interprets data',      y: 'Agent interprets and decides'       },
                  { x: 'User decides what to do',   y: 'Agent tells user exactly what to do'},
                  { x: 'DAU depends on habit',      y: 'DAU driven by agent messages'       },
                ].map(({ x, y }) => (
                  <div key={x} className="flex items-center gap-3">
                    <span className="text-red-400 text-xs w-48">{x}</span>
                    <ArrowRight size={12} className="text-gray-600 flex-shrink-0" />
                    <span className="text-green-400 text-xs">{y}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── MODULES ── */}
        {tab === 'modules' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MODULES.map(({ id, name, icon: Icon, color, bg, role, triggers }) => (
              <div key={id} className={`rounded-xl border p-5 ${bg}`}>
                <div className="flex items-center gap-3 mb-3">
                  <Icon size={20} className={color} />
                  <div>
                    <p className="font-bold text-white">{name}</p>
                    <p className="text-xs text-gray-400">{role}</p>
                  </div>
                </div>
                <ul className="space-y-2">
                  {triggers.map(t => (
                    <li key={t} className="flex items-start gap-2 text-xs text-gray-300">
                      <ChevronRight size={11} className="flex-shrink-0 mt-0.5 text-gray-600" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}

        {/* ── CHANNELS ── */}
        {tab === 'channels' && (
          <div className="space-y-3 max-w-2xl">
            <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
              <div className="grid grid-cols-5 text-xs text-gray-500 uppercase tracking-wider
                              px-4 py-2 border-b border-gray-800">
                <span>Channel</span>
                <span>Open Rate</span>
                <span>Latency</span>
                <span>Tier</span>
                <span>Provider</span>
              </div>
              {CHANNELS.map(({ id, label, icon: Icon, openRate, latency, tier }) => (
                <div key={id} className="grid grid-cols-5 items-center px-4 py-3 border-b
                                         border-gray-800/60 hover:bg-gray-800/40 transition">
                  <div className="flex items-center gap-2">
                    <Icon size={14} className="text-gray-400" />
                    <span className="text-sm font-medium">{label}</span>
                  </div>
                  <span className={`text-sm font-bold ${
                    parseFloat(openRate) > 60 ? 'text-green-400' : 'text-amber-400'}`}>
                    {openRate}
                  </span>
                  <span className="text-sm text-gray-300">{latency}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full w-fit
                    ${tier === 'free'       ? 'bg-gray-800 text-gray-300' :
                      tier === 'pro'        ? 'bg-green-800/50 text-green-300' :
                      'bg-violet-800/50 text-violet-300'}`}>
                    {tier}
                  </span>
                  <span className="text-xs text-gray-500">
                    {id === 'whatsapp' ? 'Twilio' : id === 'email' ? 'Resend' : id === 'push' ? 'web-push' : id === 'slack' ? 'Slack API' : 'built-in'}
                  </span>
                </div>
              ))}
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-3">Channel Priority Logic</p>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                {['WhatsApp (if phone verified)', 'Push (if token exists)', 'Email (always fallback)', 'In-App (always stored)'].map((c, i) => (
                  <div key={c} className="flex items-center gap-2">
                    <span className="px-2 py-1 bg-gray-800 rounded text-gray-300">{c}</span>
                    {i < 3 && <ArrowRight size={11} className="text-gray-600" />}
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-3">
                Agent tries channels in priority order. Stops after first successful send.
                User can reorder in preferences.
              </p>
            </div>
          </div>
        )}

        {/* ── CODE ── */}
        {tab === 'code' && (
          <div className="flex gap-4 h-[70vh]">
            <div className="w-52 flex-shrink-0 bg-gray-900 rounded-xl border border-gray-800 overflow-y-auto">
              <p className="px-3 py-2 text-xs text-gray-500 uppercase tracking-wider border-b border-gray-800">Files</p>
              {Object.keys(CODE).map(k => (
                <button key={k} onClick={() => setCodeFile(k)}
                  className={`w-full text-left px-3 py-2 text-xs font-mono transition
                    ${codeFile === k
                      ? 'bg-violet-900/40 text-violet-300 border-r-2 border-violet-500'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}>
                  {k}
                </button>
              ))}
            </div>
            <div className="flex-1 bg-gray-900 rounded-xl border border-gray-800 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
                <span className="text-sm font-mono text-gray-300">{codeFile}</span>
                <button onClick={() => copy(codeFile)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-800
                             hover:bg-gray-700 text-xs transition">
                  {copied === codeFile ? <CheckCheck size={12} className="text-green-400"/> : <Copy size={12}/>}
                  {copied === codeFile ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="flex-1 overflow-auto p-4 text-xs text-gray-300 font-mono leading-relaxed">
                {CODE[codeFile]}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
