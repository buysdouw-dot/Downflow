import { useMemo } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  ReferenceLine, Cell,
} from 'recharts';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus, getStatusConfig, needsRecovery } from '../engine/core';
import StatusBadge from '../components/StatusBadge';
import MobileHeader from '../components/MobileHeader';

export default function Score() {
  const { activeUserId, getWeekScores, plugins, activePlugin } = useBehavior();
  const { user } = useAuth();
  const plug = plugins[activePlugin];
  const weekData = getWeekScores(activeUserId);

  const scores = weekData.map((d) => d.score);
  const avg = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  const best = Math.max(...scores);
  const worst = Math.min(...scores);
  const recovery = needsRecovery(scores);
  const trend = scores[scores.length - 1] - scores[0];

  const TrendIcon = trend > 0 ? TrendingUp : trend < 0 ? TrendingDown : Minus;
  const trendColor = trend > 0 ? 'text-green-400' : trend < 0 ? 'text-red-400' : 'text-white/40';

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload?.length) {
      const s = payload[0].value;
      const st = getStatus(s);
      const c = getStatusConfig(st);
      return (
        <div className="glass rounded-xl px-3 py-2 text-sm">
          <p className="text-white/50 text-xs mb-1">{label}</p>
          <p className={`font-bold ${c.color}`}>{s} pts</p>
          <StatusBadge status={st} size="xs" />
        </div>
      );
    }
    return null;
  };

  const breakdown = useMemo(() => {
    const total = scores.reduce((a, b) => a + b, 0);
    return {
      green: scores.filter((s) => s >= 40).length,
      yellow: scores.filter((s) => s >= 25 && s < 40).length,
      red: scores.filter((s) => s < 25).length,
      total,
    };
  }, [scores]);

  return (
    <div className="max-w-4xl">
      <MobileHeader title="Score Analysis" />
    <div className="p-4 lg:p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Score Analysis</h1>
        <p className="text-white/40 text-sm mt-1">7-day performance breakdown for {user.name}</p>
      </div>

      {/* Stat row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: '7-Day Avg', value: avg, color: 'text-indigo-400', suffix: 'pts' },
          { label: 'Best Day', value: best, color: 'text-green-400', suffix: 'pts' },
          { label: 'Worst Day', value: worst, color: 'text-red-400', suffix: 'pts' },
          { label: 'Weekly Total', value: breakdown.total, color: 'text-yellow-400', suffix: 'pts' },
        ].map(({ label, value, color, suffix }) => (
          <div key={label} className="glass rounded-xl p-4">
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
            <p className="text-white/25 text-[10px] mt-0.5">{suffix}</p>
            <p className="text-white/50 text-xs mt-2">{label}</p>
          </div>
        ))}
      </div>

      {/* Bar chart */}
      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-white font-semibold text-sm">Daily Score History</h2>
            <p className="text-white/30 text-xs mt-0.5">Dashed line = {plug.dailyTarget}pt target</p>
          </div>
          <div className={`flex items-center gap-1.5 ${trendColor} text-sm font-semibold`}>
            <TrendIcon size={16} />
            {trend > 0 ? '+' : ''}{trend} pts
          </div>
        </div>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={weekData} margin={{ top: 10, right: 0, bottom: 0, left: -20 }}>
            <XAxis dataKey="label" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 65]} />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
            <ReferenceLine y={plug.dailyTarget} stroke="rgba(255,255,255,0.15)" strokeDasharray="4 4" />
            <Bar dataKey="score" radius={[6, 6, 0, 0]}>
              {weekData.map((entry, i) => {
                const st = getStatus(entry.score);
                const c = getStatusConfig(st);
                return <Cell key={i} fill={c.hex} fillOpacity={0.8} />;
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Status distribution */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'GREEN Days', count: breakdown.green, status: 'GREEN', note: '≥40 pts' },
          { label: 'YELLOW Days', count: breakdown.yellow, status: 'YELLOW', note: '25–39 pts' },
          { label: 'RED Days', count: breakdown.red, status: 'RED', note: '<25 pts' },
        ].map(({ label, count, status, note }) => {
          const c = getStatusConfig(status);
          return (
            <div key={label} className={`glass rounded-xl p-5 border ${c.border}`}>
              <p className={`text-3xl font-bold ${c.color}`}>{count}</p>
              <p className="text-white/50 text-xs mt-1">{label}</p>
              <p className="text-white/25 text-[10px] mt-0.5">{note}</p>
            </div>
          );
        })}
      </div>

      {/* Recovery panel */}
      {recovery && (
        <div className="glass rounded-xl p-5 border border-red-500/25 bg-red-500/5">
          <p className="text-red-300 font-semibold text-sm mb-1">Recovery Protocol Active</p>
          <p className="text-red-400/60 text-xs">
            You've had {breakdown.red} RED days this week. Focus on high-value tasks to recover your score.
          </p>
        </div>
      )}

      {/* Daily breakdown table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/6">
          <p className="text-white/50 text-xs font-semibold uppercase tracking-widest">Daily Breakdown</p>
        </div>
        <div className="divide-y divide-white/5">
          {weekData.map((d) => {
            const st = getStatus(d.score);
            const c = getStatusConfig(st);
            return (
              <div key={d.date} className="px-5 py-3 flex items-center gap-4">
                <p className="text-white/30 text-xs w-8">{d.label}</p>
                <div className="flex-1 h-2 bg-white/6 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${c.bar}`}
                    style={{ width: `${Math.min(100, (d.score / 60) * 100)}%`, transition: 'width 0.6s ease' }}
                  />
                </div>
                <p className={`font-bold text-sm w-12 text-right ${c.color}`}>{d.score}</p>
                <StatusBadge status={st} size="xs" />
              </div>
            );
          })}
        </div>
      </div>
    </div>
    </div>
  );
}
