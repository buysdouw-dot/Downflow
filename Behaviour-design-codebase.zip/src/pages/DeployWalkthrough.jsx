/**
 * DeployWalkthrough — Live Deployment Guide
 * Railway · Vercel · Supabase · Docker VPS
 * Step-by-step interactive checklist. Copy commands. Live status tracker.
 */
import { useState } from 'react';
import {
  Server, Globe, Database, Cloud, Check, Copy,
  ChevronRight, ExternalLink, Play, Terminal,
  ArrowRight, Zap, Shield, Clock, CheckCircle2,
} from 'lucide-react';

// ── Platform configs ───────────────────────────────────────────────────────────
const PLATFORMS = [
  {
    id: 'railway',
    label: 'Railway',
    tagline: 'Easiest. Backend + DB in one click.',
    Icon: Server,
    color: '#818cf8',
    border: 'border-indigo-500/20',
    bg: 'bg-indigo-500/5',
    time: '~5 min',
    cost: '$5/mo',
    badge: 'RECOMMENDED',
    steps: [
      {
        title: 'Push to GitHub',
        cmd: 'git init && git add . && git commit -m "init"\ngit remote add origin https://github.com/you/behavior-engine\ngit push -u origin main',
        note: 'If you already have a repo, skip this.',
      },
      {
        title: 'Create Railway project',
        cmd: null,
        note: 'Go to railway.app → New Project → Deploy from GitHub repo → select your repo',
        link: 'https://railway.app/new',
      },
      {
        title: 'Set root directory to /backend',
        cmd: null,
        note: 'In Railway: Settings → Source → Root Directory → set to "backend"',
      },
      {
        title: 'Add environment variables',
        cmd: 'PORT=3001\nNODE_ENV=production\nJWT_SECRET=generate_a_long_random_string_here',
        note: 'Railway: Variables tab → add each one. Never commit .env to git.',
      },
      {
        title: '(Optional) Add Postgres',
        cmd: null,
        note: 'Railway: New Service → Database → PostgreSQL. Copy DATABASE_URL to your backend env vars.',
      },
      {
        title: 'Deploy frontend to Vercel',
        cmd: 'cd frontend\nnpx vercel --prod',
        note: 'Or connect Vercel to your GitHub repo and set root to "frontend". Add VITE_API_URL=https://your-railway-url.railway.app',
      },
      {
        title: 'Test the live API',
        cmd: 'curl https://your-app.railway.app/health\n# Expected: {"ok":true,"ts":"..."}',
        note: 'If this returns ok:true, your backend is live.',
      },
    ],
  },
  {
    id: 'vercel',
    label: 'Vercel + Render',
    tagline: 'Frontend on Vercel, backend on Render free tier.',
    Icon: Globe,
    color: '#34d399',
    border: 'border-emerald-500/20',
    bg: 'bg-emerald-500/5',
    time: '~10 min',
    cost: 'Free tier available',
    badge: 'FREE START',
    steps: [
      {
        title: 'Deploy backend to Render',
        cmd: null,
        note: 'render.com → New Web Service → Connect GitHub → Root: backend → Build: npm install → Start: node src/server.js',
        link: 'https://render.com/docs/node-express-app',
      },
      {
        title: 'Set Render env vars',
        cmd: 'PORT=3001\nJWT_SECRET=your_secret_here\nNODE_ENV=production',
        note: 'Render: Environment tab → add variables. Copy your service URL (e.g. https://be-api.onrender.com)',
      },
      {
        title: 'Deploy frontend to Vercel',
        cmd: 'npx vercel\n# Follow prompts: root=frontend, framework=vite',
        note: 'Or use vercel.com dashboard → Import Git → set Root Directory to "frontend"',
        link: 'https://vercel.com/new',
      },
      {
        title: 'Add VITE_API_URL to Vercel',
        cmd: 'VITE_API_URL=https://your-render-app.onrender.com',
        note: 'Vercel: Project Settings → Environment Variables. Redeploy after adding.',
      },
      {
        title: 'Test end-to-end',
        cmd: '# Register a user\ncurl -X POST https://your-render-url/api/auth/register \\\n  -H "Content-Type: application/json" \\\n  -d \'{"email":"test@test.com","password":"pass123","name":"Test User"}\'',
        note: 'You should get back a JWT token. That means it works.',
      },
    ],
  },
  {
    id: 'supabase',
    label: 'Supabase Backend',
    tagline: 'Postgres + Auth + Storage. Replace memoryStore.',
    Icon: Database,
    color: '#22d3ee',
    border: 'border-cyan-500/20',
    bg: 'bg-cyan-500/5',
    time: '~15 min',
    cost: 'Free tier (500MB DB)',
    badge: 'PRODUCTION DB',
    steps: [
      {
        title: 'Create Supabase project',
        cmd: null,
        note: 'supabase.com → New Project → pick a region close to your users',
        link: 'https://supabase.com/dashboard',
      },
      {
        title: 'Run SQL schema',
        cmd: `-- Paste in Supabase SQL Editor
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  role TEXT DEFAULT 'user',
  hash TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  title TEXT NOT NULL,
  points INT DEFAULT 10,
  category TEXT DEFAULT 'general',
  completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES users(id),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  company TEXT,
  source TEXT DEFAULT 'manual',
  status TEXT DEFAULT 'new',
  events JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);`,
        note: 'Project → SQL Editor → paste and run. This creates all 3 tables.',
      },
      {
        title: 'Get connection string',
        cmd: 'DATABASE_URL=postgresql://postgres:[password]@db.[project-ref].supabase.co:5432/postgres',
        note: 'Supabase: Settings → Database → Connection String → URI. Copy and add to your env vars.',
      },
      {
        title: 'Swap memoryStore for Postgres',
        cmd: `npm install pg --workspace=backend`,
        note: 'Then replace backend/src/db/memoryStore.js with a pg-based adapter (queries instead of Map operations).',
      },
      {
        title: 'Add DATABASE_URL to Railway/Render',
        cmd: 'DATABASE_URL=your_supabase_connection_string',
        note: 'Redeploy. Your data now persists across restarts.',
      },
    ],
  },
  {
    id: 'vps',
    label: 'Docker + VPS',
    tagline: 'Full control. DigitalOcean / Hetzner / Fly.io.',
    Icon: Cloud,
    color: '#fbbf24',
    border: 'border-yellow-500/20',
    bg: 'bg-yellow-500/5',
    time: '~20 min',
    cost: '$5–12/mo VPS',
    badge: 'FULL CONTROL',
    steps: [
      {
        title: 'Create $6/mo Droplet (DigitalOcean)',
        cmd: null,
        note: 'digitalocean.com → Droplets → Ubuntu 22.04 → Basic → $6/mo. Get the IP.',
        link: 'https://cloud.digitalocean.com/droplets/new',
      },
      {
        title: 'Install Docker on VPS',
        cmd: 'ssh root@YOUR_IP\ncurl -fsSL https://get.docker.com | sh\nsystemctl enable docker && systemctl start docker\napt install docker-compose-plugin -y',
        note: 'Run on the VPS over SSH.',
      },
      {
        title: 'Clone repo and configure',
        cmd: 'git clone https://github.com/you/behavior-engine-saas\ncd behavior-engine-saas\ncp .env.example .env\nnano .env   # set JWT_SECRET',
        note: 'Set a strong JWT_SECRET — minimum 32 characters.',
      },
      {
        title: 'Build and start containers',
        cmd: 'docker compose up --build -d\ndocker compose logs -f   # watch logs',
        note: 'Frontend on :80, backend on :3001. Both auto-restart on crash.',
      },
      {
        title: 'Point domain + add SSL (optional)',
        cmd: 'apt install certbot python3-certbot-nginx -y\ncertbot --nginx -d yourdomain.com',
        note: 'Add an A-record for your domain pointing to the VPS IP. Certbot handles SSL automatically.',
      },
      {
        title: 'Verify everything is live',
        cmd: 'curl http://YOUR_IP/health\ncurl http://YOUR_IP/api/auth/login   # expect 400 (missing body = working)',
        note: 'If you get JSON back, your stack is live.',
      },
    ],
  },
];

// ── Copy btn ──────────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1800); }}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border transition-all shrink-0 ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/60'
      }`}>
      {c ? <><Check size={8} /> Copied</> : <><Copy size={8} /> Copy</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function DeployWalkthrough() {
  const [platform, setPlatform]   = useState('railway');
  const [completed, setCompleted] = useState(() => {
    try { return JSON.parse(localStorage.getItem('be_deploy_done')) ?? {}; } catch { return {}; }
  });

  const toggle = (key) => {
    const n = { ...completed, [key]: !completed[key] };
    setCompleted(n);
    try { localStorage.setItem('be_deploy_done', JSON.stringify(n)); } catch {}
  };

  const plat = PLATFORMS.find(p => p.id === platform);
  const PIcon = plat.Icon;
  const doneCount = plat.steps.filter((_, i) => completed[`${platform}_${i}`]).length;

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Cloud size={14} className="text-cyan-400" />
            <p className="text-cyan-400 text-xs font-bold uppercase tracking-widest">Deployment Guide</p>
          </div>
          <h1 className="text-3xl font-black mb-1">Live Deployment Walkthrough</h1>
          <p className="text-white/35 text-sm">Step-by-step. Copy every command. Your app live in minutes.</p>
        </div>

        {/* Platform selector */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {PLATFORMS.map(p => {
            const PIc = p.Icon;
            const isActive = platform === p.id;
            const platDone = p.steps.filter((_, i) => completed[`${p.id}_${i}`]).length;
            return (
              <button key={p.id} onClick={() => setPlatform(p.id)}
                className={`p-4 rounded-2xl border text-left transition-all ${isActive ? `${p.border} ${p.bg}` : 'border-white/8 bg-white/2 hover:bg-white/4'}`}>
                <div className="flex items-start justify-between mb-2">
                  <PIc size={16} style={{ color: isActive ? p.color : 'rgba(255,255,255,0.2)' }} />
                  {p.badge && (
                    <span className="text-[7px] font-black px-1.5 py-0.5 rounded border"
                      style={{ color: p.color, borderColor: p.color + '40', background: p.color + '12' }}>
                      {p.badge}
                    </span>
                  )}
                </div>
                <p className={`text-xs font-bold mb-0.5 ${isActive ? '' : 'text-white/50'}`} style={{ color: isActive ? p.color : undefined }}>{p.label}</p>
                <p className="text-white/25 text-[9px] leading-snug">{p.tagline}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-white/20 text-[8px]"><Clock size={7} className="inline mr-0.5" />{p.time}</span>
                  <span className="text-white/20 text-[8px]">{p.cost}</span>
                </div>
                {platDone > 0 && (
                  <div className="mt-2 h-1 bg-white/8 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${(platDone / p.steps.length) * 100}%`, background: p.color }} />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Steps */}
        <div className={`p-5 rounded-2xl border ${plat.border} ${plat.bg}`}>
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <PIcon size={14} style={{ color: plat.color }} />
              <p style={{ color: plat.color }} className="text-sm font-bold">{plat.label} — {plat.tagline}</p>
            </div>
            <span className="text-white/30 text-xs">{doneCount}/{plat.steps.length} steps</span>
          </div>

          <div className="space-y-3">
            {plat.steps.map((step, i) => {
              const key = `${platform}_${i}`;
              const done = !!completed[key];
              return (
                <div key={i} className={`p-4 rounded-xl border transition-all ${
                  done ? 'border-emerald-500/20 bg-emerald-500/4' : 'border-white/8 bg-white/2'
                }`}>
                  <div className="flex items-start gap-3">
                    <button onClick={() => toggle(key)}
                      className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                        done ? 'bg-emerald-500 border-emerald-500' : 'border-white/20 hover:border-white/40'
                      }`}>
                      {done && <Check size={9} className="text-white" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <p className={`text-xs font-bold ${done ? 'text-white/35 line-through' : 'text-white/70'}`}>
                          Step {i + 1}: {step.title}
                        </p>
                        <div className="flex items-center gap-1.5">
                          {step.link && (
                            <a href={step.link} target="_blank" rel="noreferrer"
                              className="flex items-center gap-1 text-[9px] text-white/30 hover:text-white/60 border border-white/8 px-1.5 py-0.5 rounded transition-all">
                              <ExternalLink size={7} /> Open
                            </a>
                          )}
                        </div>
                      </div>
                      {step.note && <p className="text-white/35 text-[10px] leading-snug mb-2">{step.note}</p>}
                      {step.cmd && (
                        <div className="relative">
                          <div className="absolute top-2 right-2">
                            <CopyBtn text={step.cmd} />
                          </div>
                          <pre className="p-3 rounded-lg bg-black/40 border border-white/6 text-[9px] text-emerald-300/80 font-mono leading-relaxed overflow-x-auto pr-16 whitespace-pre-wrap">{step.cmd}</pre>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {doneCount === plat.steps.length && (
            <div className="mt-4 p-4 rounded-xl border border-emerald-500/25 bg-emerald-500/8 flex items-center gap-3">
              <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
              <div>
                <p className="text-emerald-400 text-sm font-bold">Deployment complete!</p>
                <p className="text-white/40 text-xs">Your Behavior Engine SaaS is live. Share the link and start onboarding users.</p>
              </div>
            </div>
          )}
        </div>

        {/* Architecture overview */}
        <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
          <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Production Architecture</p>
          <div className="flex items-center gap-2 flex-wrap">
            {[
              { label: 'User Browser',   color: '#818cf8', sub: 'React SPA'        },
              { label: 'CDN / Vercel',   color: '#34d399', sub: 'Static frontend'  },
              { label: 'API Server',     color: '#22d3ee', sub: 'Railway / Render' },
              { label: 'Database',       color: '#fbbf24', sub: 'Postgres / Supabase'},
            ].map((n, i, arr) => (
              <div key={n.label} className="flex items-center gap-2">
                <div className="px-3 py-2 rounded-xl border text-center" style={{ borderColor: n.color + '25', background: n.color + '08' }}>
                  <p className="text-[10px] font-bold" style={{ color: n.color }}>{n.label}</p>
                  <p className="text-white/25 text-[8px]">{n.sub}</p>
                </div>
                {i < arr.length - 1 && <ArrowRight size={10} className="text-white/15 shrink-0" />}
              </div>
            ))}
          </div>
        </div>

        {/* Env vars reference */}
        <div className="p-5 rounded-2xl border border-white/8 bg-black/30">
          <div className="flex items-center justify-between mb-3">
            <p className="text-white/25 text-[9px] uppercase tracking-widest">Required Environment Variables</p>
            <CopyBtn text={`PORT=3001\nNODE_ENV=production\nJWT_SECRET=your_32_char_min_secret\nFRONTEND_URL=https://your-frontend.vercel.app`} />
          </div>
          <pre className="text-[10px] text-cyan-300/80 font-mono leading-loose">{`PORT=3001
NODE_ENV=production
JWT_SECRET=your_32_char_min_secret_here
FRONTEND_URL=https://your-frontend.vercel.app

# Optional: Postgres (replaces in-memory store)
DATABASE_URL=postgresql://user:pass@host:5432/db

# Optional: Supabase
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_ANON_KEY=your_anon_key`}</pre>
        </div>

      </div>
    </div>
  );
}
