/**
 * InvestorDemo — Clickable Pitch Simulation App
 * A self-contained "Acme Sales Team" demo designed for investor meetings.
 * Simulates live metrics, leaderboard activity, and AI coaching in real-time.
 */
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Zap, TrendingUp, Users, Bot, BarChart2, Shield, Flame, Activity,
  CheckCircle2, ArrowRight, ChevronRight, Play, RefreshCw, Star,
  Target, Clock, AlertTriangle, LogIn,
} from 'lucide-react';

// ── Demo Data ─────────────────────────────────────────────────────────────────
const COMPANY = {
  name: 'Acme Sales Team',
  industry: 'SaaS Sales',
  users: 18,
  executionRate: 72,
  weekImprovement: 23,
  plugin: '💼 Sales Execution',
};

const DEMO_USERS = [
  { id: 1, name: 'John Mitchell',   score: 82, status: 'GREEN',  streak: 7,  avatar: 'JM', gradient: 'from-indigo-500 to-purple-600',  change: +5  },
  { id: 2, name: 'Sarah Chen',      score: 76, status: 'GREEN',  streak: 4,  avatar: 'SC', gradient: 'from-emerald-500 to-teal-600',   change: +12 },
  { id: 3, name: 'Alex Rodriguez',  score: 69, status: 'GREEN',  streak: 3,  avatar: 'AR', gradient: 'from-cyan-500 to-blue-600',      change: +3  },
  { id: 4, name: 'Maya Patel',      score: 54, status: 'YELLOW', streak: 1,  avatar: 'MP', gradient: 'from-amber-500 to-orange-600',   change: -4  },
  { id: 5, name: 'Chris Taylor',    score: 47, status: 'YELLOW', streak: 0,  avatar: 'CT', gradient: 'from-pink-500 to-rose-600',      change: -8  },
  { id: 6, name: 'Jordan Williams', score: 31, status: 'RED',    streak: 0,  avatar: 'JW', gradient: 'from-red-500 to-rose-600',       change: -15 },
];

const AI_MESSAGES = {
  82: {
    personality: '🧠 The Strategist',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    insight: 'Consistent top performer. 7-day streak shows strong morning habits.',
    action: 'Data suggests you close 30% faster on second contact. Prioritize follow-ups between 9–11am.',
    tag: 'Optimizing',
  },
  76: {
    personality: '⚡ The Motivator',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    insight: 'Strong week. +12 pts from yesterday — your best single-day jump this month.',
    action: 'Momentum is building. Push to hit 80+ today and you break your personal record.',
    tag: 'Building',
  },
  69: {
    personality: '🔥 The Disciplinarian',
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/20',
    insight: 'You are on the edge. 69 pts keeps you GREEN but barely.',
    action: '2 more outreach messages. That\'s the difference between GREEN and YELLOW. Execute.',
    tag: 'At Risk',
  },
  54: {
    personality: '⚡ The Motivator',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    insight: 'YELLOW status detected. You have the skill — the data shows it. Pattern broken Monday.',
    action: 'You had a strong Tuesday last week. Use that energy now. One action leads to another.',
    tag: 'Needs Push',
  },
  47: {
    personality: '🔥 The Disciplinarian',
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/20',
    insight: 'YELLOW status. Dropping from yesterday. Streak broken.',
    action: 'You have 4 hours left today. 3 logged calls gets you to 65. Stop planning. Execute now.',
    tag: 'Urgent',
  },
  31: {
    personality: '🔥 The Disciplinarian',
    color: 'text-orange-400',
    bg: 'bg-orange-500/10',
    border: 'border-orange-500/20',
    insight: 'RED status. Second consecutive RED day. Pattern: falls off after strong Friday.',
    action: 'You are underperforming in follow-ups. 1 call, 1 email, 1 LinkedIn message. Go. Now.',
    tag: 'Intervention',
  },
};

const DEMO_SCREENS = [
  { id: 'login',      label: 'Login',     icon: LogIn    },
  { id: 'dashboard',  label: 'Dashboard', icon: BarChart2 },
  { id: 'leaderboard',label: 'Leaderboard',icon: Star    },
  { id: 'ai_coach',   label: 'AI Coach',  icon: Bot      },
  { id: 'admin',      label: 'Admin',     icon: Shield   },
];

const STATUS_CFG = {
  GREEN:  { color: 'text-green-400',  bg: 'bg-green-500/10',  border: 'border-green-500/20',  bar: 'bg-green-500'  },
  YELLOW: { color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', bar: 'bg-yellow-400' },
  RED:    { color: 'text-red-400',    bg: 'bg-red-500/10',    border: 'border-red-500/20',    bar: 'bg-red-500'    },
};

// ── Sub-screens ───────────────────────────────────────────────────────────────

function LoginScreen({ onLogin }) {
  const [loading, setLoading] = useState(false);
  const simulate = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 1000);
  };
  return (
    <div className="flex flex-col items-center justify-center h-full p-8 space-y-6">
      <div className="w-14 h-14 rounded-2xl bg-indigo-500 flex items-center justify-center shadow-xl shadow-indigo-500/30">
        <Zap size={24} className="text-white" />
      </div>
      <div className="text-center">
        <h2 className="text-2xl font-black mb-1">Behavior Engine</h2>
        <p className="text-white/30 text-sm">{COMPANY.name}</p>
      </div>
      <div className="w-full max-w-xs space-y-3">
        <div className="px-4 py-3 rounded-xl bg-white/4 border border-white/10 text-sm text-indigo-300 font-medium">
          john.mitchell@acme.io
        </div>
        <div className="px-4 py-3 rounded-xl bg-white/4 border border-white/10 text-sm text-white/20">
          ••••••••••
        </div>
        <button onClick={simulate} disabled={loading}
          className="w-full py-3.5 bg-indigo-500 hover:bg-indigo-400 rounded-xl text-sm font-bold text-white transition-all flex items-center justify-center gap-2">
          {loading ? <RefreshCw size={14} className="animate-spin" /> : <><LogIn size={14} /> Sign In</>}
        </button>
      </div>
      <p className="text-white/15 text-xs">Demo account · {COMPANY.name}</p>
    </div>
  );
}

function DashboardScreen() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick(p => p + 1), 2500);
    return () => clearInterval(t);
  }, []);

  const metrics = [
    { label: 'Execution Rate',   value: `${COMPANY.executionRate}%`,   color: 'text-indigo-400',  icon: Activity    },
    { label: 'Active Users',     value: COMPANY.users,                  color: 'text-emerald-400', icon: Users       },
    { label: 'Week Improvement', value: `+${COMPANY.weekImprovement}%`, color: 'text-green-400',   icon: TrendingUp  },
    { label: 'GREEN Today',      value: `${DEMO_USERS.filter(u => u.status === 'GREEN').length}/${DEMO_USERS.length}`, color: 'text-yellow-400', icon: Target },
  ];

  const flashUser = DEMO_USERS[tick % DEMO_USERS.length];
  const msg = AI_MESSAGES[flashUser.score];

  return (
    <div className="p-4 space-y-4 h-full overflow-y-auto scrollbar-hide">
      {/* Company header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-white font-bold text-sm">{COMPANY.name}</p>
          <p className="text-white/25 text-[10px]">{COMPANY.plugin}</p>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          <span className="text-green-400/60 text-[9px] font-semibold">LIVE</span>
        </div>
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-2 gap-2">
        {metrics.map(({ label, value, color, icon: Icon }) => (
          <div key={label} className="p-3 rounded-xl bg-white/3 border border-white/6">
            <Icon size={13} className={`${color} mb-1.5`} />
            <p className={`text-xl font-black ${color}`}>{value}</p>
            <p className="text-white/25 text-[9px]">{label}</p>
          </div>
        ))}
      </div>

      {/* Week bar chart */}
      <div className="p-3 rounded-xl bg-white/3 border border-white/6">
        <p className="text-white/30 text-[9px] uppercase tracking-widest mb-2">7-Day Team Score Average</p>
        <div className="flex items-end gap-1 h-12">
          {[38, 45, 52, 41, 67, 74, 72].map((v, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
              <div className="w-full rounded-t bg-indigo-500/60 transition-all" style={{ height: `${(v / 80) * 100}%` }} />
              <span className="text-white/15 text-[7px]">
                {['M', 'T', 'W', 'T', 'F', 'S', 'S'][i]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Live AI toast */}
      <div className={`p-3 rounded-xl ${msg.bg} border ${msg.border}`} key={flashUser.id}>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs">{msg.personality.split(' ')[0]}</span>
          <p className={`text-[9px] font-bold uppercase tracking-wider ${msg.color}`}>{msg.personality.split(' ').slice(1).join(' ')}</p>
          <span className={`ml-auto text-[7px] font-black px-1.5 py-0.5 rounded-full ${msg.bg} ${msg.color} border ${msg.border}`}>{msg.tag}</span>
        </div>
        <p className="text-white/60 text-[10px] leading-snug">For {flashUser.name}: {msg.action}</p>
      </div>
    </div>
  );
}

function LeaderboardScreen() {
  return (
    <div className="p-4 space-y-3 h-full overflow-y-auto scrollbar-hide">
      <div className="flex items-center justify-between">
        <p className="text-white font-bold text-sm">Team Leaderboard</p>
        <span className="text-white/20 text-[9px]">Today · {COMPANY.name}</span>
      </div>

      {DEMO_USERS.map((u, i) => {
        const cfg = STATUS_CFG[u.status];
        return (
          <div key={u.id} className={`flex items-center gap-3 p-3 rounded-xl border ${cfg.border} ${cfg.bg}`}>
            {/* Rank */}
            <div className={`w-6 text-center font-black text-xs ${i < 3 ? cfg.color : 'text-white/20'}`}>
              {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}
            </div>
            {/* Avatar */}
            <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${u.gradient} flex items-center justify-center text-[9px] font-bold text-white shrink-0`}>
              {u.avatar}
            </div>
            {/* Info */}
            <div className="flex-1 min-w-0">
              <p className="text-white text-xs font-semibold truncate">{u.name}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                {u.streak > 0 && <span className="text-orange-400 text-[9px]">🔥 {u.streak}d</span>}
                <div className="h-1 flex-1 bg-white/8 rounded-full overflow-hidden">
                  <div className={`h-full ${cfg.bar} rounded-full`} style={{ width: `${u.score}%` }} />
                </div>
              </div>
            </div>
            {/* Score + change */}
            <div className="text-right">
              <p className={`text-base font-black ${cfg.color}`}>{u.score}</p>
              <p className={`text-[9px] font-semibold ${u.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                {u.change > 0 ? '+' : ''}{u.change}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function AICoachScreen() {
  const [selected, setSelected] = useState(DEMO_USERS[0]);
  const msg = AI_MESSAGES[selected.score];
  const cfg = STATUS_CFG[selected.status];

  return (
    <div className="p-4 space-y-4 h-full overflow-y-auto scrollbar-hide">
      <p className="text-white font-bold text-sm">AI Coaching Engine</p>

      {/* User selector */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {DEMO_USERS.map(u => {
          const c = STATUS_CFG[u.status];
          return (
            <button key={u.id} onClick={() => setSelected(u)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold whitespace-nowrap transition-all ${
                selected.id === u.id
                  ? `${c.border} ${c.bg} ${c.color}`
                  : 'border-white/8 text-white/35 hover:border-white/15'
              }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${c.bar}`} />
              {u.name.split(' ')[0]}
            </button>
          );
        })}
      </div>

      {/* User card */}
      <div className={`p-4 rounded-2xl ${cfg.bg} border ${cfg.border}`}>
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${selected.gradient} flex items-center justify-center text-xs font-bold text-white`}>
            {selected.avatar}
          </div>
          <div>
            <p className="text-white font-bold text-sm">{selected.name}</p>
            <div className="flex items-center gap-2">
              <span className={`text-[9px] font-black ${cfg.color}`}>{selected.status}</span>
              {selected.streak > 0 && <span className="text-orange-400 text-[9px]">🔥 {selected.streak}d streak</span>}
            </div>
          </div>
          <p className={`ml-auto text-3xl font-black ${cfg.color}`}>{selected.score}</p>
        </div>
        <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
          <div className={`h-full ${cfg.bar} rounded-full transition-all duration-700`} style={{ width: `${selected.score}%` }} />
        </div>
      </div>

      {/* AI coaching message */}
      <div className={`p-4 rounded-2xl ${msg.bg} border ${msg.border}`}>
        <div className="flex items-center gap-2 mb-3">
          <span className="text-lg">{msg.personality.split(' ')[0]}</span>
          <div>
            <p className={`text-xs font-bold ${msg.color}`}>{msg.personality.split(' ').slice(1).join(' ')}</p>
            <p className="text-white/20 text-[9px]">AI Coach · Behavior Engine</p>
          </div>
          <span className={`ml-auto text-[8px] font-black px-2 py-0.5 rounded-full ${msg.bg} ${msg.color} border ${msg.border}`}>{msg.tag}</span>
        </div>
        <div className="space-y-2">
          <div>
            <p className="text-white/30 text-[9px] uppercase tracking-wider mb-1">Pattern Insight</p>
            <p className="text-white/70 text-xs leading-snug">{msg.insight}</p>
          </div>
          <div className={`mt-2 p-3 rounded-xl ${msg.bg} border ${msg.border}`}>
            <p className="text-white/25 text-[9px] uppercase tracking-wider mb-1">Coaching Action</p>
            <p className={`text-xs font-semibold ${msg.color} leading-snug`}>→ {msg.action}</p>
          </div>
        </div>
      </div>

      {/* Pattern tag */}
      <div className="flex flex-wrap gap-2">
        {selected.status === 'RED' && <span className="px-2 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-[9px] font-bold">Chronic Underperformer</span>}
        {selected.streak >= 5 && <span className="px-2 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-[9px] font-bold">Streak Builder</span>}
        {selected.change < 0 && <span className="px-2 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-[9px] font-bold">Week Fader</span>}
        {selected.change > 8 && <span className="px-2 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[9px] font-bold">Momentum Builder</span>}
      </div>
    </div>
  );
}

function AdminScreen() {
  const metrics = [
    { label: 'Execution Rate',    value: `${COMPANY.executionRate}%`, sub: '↑ 23% WoW',        color: 'text-indigo-400' },
    { label: 'GREEN Users',       value: '3/6',                       sub: '50% above target',   color: 'text-green-400' },
    { label: 'At Risk (YELLOW)',  value: '2',                         sub: 'Needs coaching',     color: 'text-yellow-400'},
    { label: 'Intervention (RED)',value: '1',                         sub: '2nd RED day',        color: 'text-red-400'   },
  ];

  return (
    <div className="p-4 space-y-4 h-full overflow-y-auto scrollbar-hide">
      <div className="flex items-center justify-between">
        <p className="text-white font-bold text-sm">Manager Dashboard</p>
        <span className="flex items-center gap-1 text-[9px] text-indigo-400/60 font-semibold">
          <Shield size={9} /> Admin
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {metrics.map(({ label, value, sub, color }) => (
          <div key={label} className="p-3 rounded-xl bg-white/3 border border-white/6">
            <p className={`text-xl font-black ${color} mb-0.5`}>{value}</p>
            <p className="text-white/30 text-[9px]">{label}</p>
            <p className={`text-[9px] font-semibold mt-0.5 ${color}`}>{sub}</p>
          </div>
        ))}
      </div>

      {/* At-risk alert */}
      <div className="p-3 rounded-xl bg-red-500/8 border border-red-500/20">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle size={12} className="text-red-400" />
          <p className="text-red-400 text-xs font-bold">Intervention Required</p>
        </div>
        <p className="text-white/50 text-xs">Jordan Williams — 2nd consecutive RED day. Pattern: strong start, collapses midweek.</p>
        <p className="text-red-400 text-[10px] font-semibold mt-1.5">Recommended: Direct manager check-in + coaching style switch to Motivation.</p>
      </div>

      {/* Trend line */}
      <div className="p-3 rounded-xl bg-white/3 border border-white/6">
        <p className="text-white/30 text-[9px] uppercase tracking-widest mb-2">30-Day Execution Trend</p>
        <div className="flex items-end gap-0.5 h-8">
          {[30,35,28,40,45,38,52,48,55,61,58,67,65,70,68,72,69,74,71,76,73,78,75,80,77,74,72,76,74,72].map((v, i) => (
            <div key={i} className="flex-1 rounded-t"
              style={{ height: `${(v / 80) * 100}%`, background: v >= 70 ? '#22c55e60' : v >= 50 ? '#eab30860' : '#ef444460' }} />
          ))}
        </div>
        <div className="flex justify-between text-white/15 text-[8px] mt-1">
          <span>30 days ago</span><span>Today</span>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function InvestorDemo() {
  const navigate = useNavigate();
  const [screen, setScreen] = useState('login');
  const [loggedIn, setLoggedIn] = useState(false);
  const [autoPlay, setAutoPlay] = useState(false);
  const autoRef = useRef(null);

  const screens = ['dashboard', 'leaderboard', 'ai_coach', 'admin'];

  // Auto-play demo mode
  useEffect(() => {
    if (!autoPlay || !loggedIn) return;
    let idx = screens.indexOf(screen);
    autoRef.current = setInterval(() => {
      idx = (idx + 1) % screens.length;
      setScreen(screens[idx]);
    }, 4000);
    return () => clearInterval(autoRef.current);
  }, [autoPlay, loggedIn, screen]);

  const handleLogin = () => {
    setLoggedIn(true);
    setScreen('dashboard');
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Play size={14} className="text-purple-400" />
              <p className="text-purple-400 text-xs font-bold uppercase tracking-widest">Investor Demo System</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Live Simulation Demo</h1>
            <p className="text-white/35 text-sm">Clickable product simulation. Show investors exactly what behavior change looks like.</p>
          </div>
          <button onClick={() => navigate('/pitch')}
            className="hidden lg:flex items-center gap-2 px-4 py-2 rounded-xl bg-white/4 border border-white/8 hover:border-white/15 text-white/50 hover:text-white/75 text-sm transition-all">
            View Pitch Deck <ChevronRight size={14} />
          </button>
        </div>

        {/* Context strip */}
        <div className="flex flex-wrap gap-3">
          {[
            { label: 'Company', value: COMPANY.name,           icon: Users   },
            { label: 'Plugin',  value: COMPANY.plugin,          icon: Zap     },
            { label: 'Users',   value: `${COMPANY.users} active`, icon: Activity },
            { label: 'Status',  value: 'LIVE DEMO',             icon: CheckCircle2 },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/3 border border-white/6">
              <Icon size={12} className="text-indigo-400 shrink-0" />
              <span className="text-white/30 text-xs">{label}:</span>
              <span className="text-white/70 text-xs font-semibold">{value}</span>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-[1fr_340px] gap-6 items-start">

          {/* LEFT — Explanation */}
          <div className="space-y-5">
            <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-5">
              <p className="text-white font-bold mb-3">Why This Demo Works for Investors</p>
              <div className="space-y-3">
                {[
                  { icon: '👁️', title: 'Visible behavior change',   desc: 'Investors see the GREEN/YELLOW/RED scoring system live — not on slides.' },
                  { icon: '🧠', title: 'AI coaching in action',      desc: 'Each user gets different coaching based on their pattern. Not generic tips.' },
                  { icon: '📊', title: 'Admin control layer',        desc: 'Shows the manager dashboard — who\'s executing, who needs intervention.' },
                  { icon: '🏆', title: 'Competitive leaderboard',    desc: 'The social layer that makes this addictive and viral.' },
                ].map(({ icon, title, desc }) => (
                  <div key={title} className="flex items-start gap-3">
                    <span className="text-xl shrink-0">{icon}</span>
                    <div>
                      <p className="text-white/80 text-sm font-semibold">{title}</p>
                      <p className="text-white/35 text-xs leading-snug">{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Investor talking points */}
            <div className="rounded-2xl border border-indigo-500/20 bg-indigo-500/5 p-5">
              <p className="text-indigo-400 font-bold text-sm mb-3">Investor Talking Points</p>
              <div className="space-y-2">
                {[
                  '"Every team has execution problems. We make them visible and fixable."',
                  '"Not another CRM. We track behavior — the root cause of CRM failure."',
                  '"3 coach personalities = personalization at scale, no extra cost."',
                  '"7-day pilot = zero friction to start. Teams see ROI before paying."',
                ].map(q => (
                  <p key={q} className="text-white/55 text-xs italic border-l-2 border-indigo-500/30 pl-3">{q}</p>
                ))}
              </div>
            </div>

            {/* Auto-play toggle */}
            {loggedIn && (
              <div className="flex items-center gap-3 p-4 rounded-xl bg-white/3 border border-white/6">
                <div className={`w-2 h-2 rounded-full ${autoPlay ? 'bg-green-400 animate-pulse' : 'bg-white/20'}`} />
                <span className="text-white/50 text-sm flex-1">Auto-cycle screens for demo</span>
                <button onClick={() => setAutoPlay(p => !p)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    autoPlay
                      ? 'bg-green-500/15 border border-green-500/25 text-green-400'
                      : 'bg-white/5 border border-white/10 text-white/40 hover:text-white/60'
                  }`}>
                  {autoPlay ? 'Auto-Playing' : 'Start Auto-Play'}
                </button>
              </div>
            )}
          </div>

          {/* RIGHT — Product mockup */}
          <div className="sticky top-6">
            {/* Phone frame */}
            <div className="relative mx-auto" style={{ maxWidth: '320px' }}>
              {/* Glow */}
              <div className="absolute -inset-4 bg-indigo-500/8 rounded-3xl blur-2xl pointer-events-none" />

              <div className="relative rounded-[2.5rem] border-[3px] border-white/10 bg-[#050810] overflow-hidden shadow-2xl"
                style={{ minHeight: '580px' }}>

                {/* Notch */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-6 bg-[#050810] rounded-b-2xl z-20 flex items-center justify-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-white/10" />
                </div>

                {/* Status bar */}
                <div className="flex items-center justify-between px-6 pt-8 pb-2">
                  <span className="text-white/25 text-[9px] font-semibold">9:41</span>
                  <div className="flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-white/20" />
                    <span className="w-1 h-1 rounded-full bg-white/20" />
                    <span className="w-1 h-1 rounded-full bg-white/20" />
                  </div>
                </div>

                {/* App header */}
                <div className="flex items-center gap-2 px-4 py-2 border-b border-white/5">
                  <div className="w-5 h-5 rounded-md bg-indigo-500 flex items-center justify-center">
                    <Zap size={10} className="text-white" />
                  </div>
                  <span className="text-white/60 text-[10px] font-bold">Behavior Engine</span>
                  {loggedIn && (
                    <span className="ml-auto flex items-center gap-1 text-[8px] text-green-400/60 font-semibold">
                      <span className="w-1 h-1 rounded-full bg-green-400 animate-pulse" /> LIVE
                    </span>
                  )}
                </div>

                {/* Screen nav */}
                {loggedIn && (
                  <div className="flex border-b border-white/5">
                    {DEMO_SCREENS.filter(s => s.id !== 'login').map(({ id, label, icon: Icon }) => (
                      <button key={id} onClick={() => { setAutoPlay(false); setScreen(id); }}
                        className={`flex-1 flex flex-col items-center py-2 gap-0.5 text-[8px] font-semibold transition-all ${
                          screen === id ? 'text-indigo-400 border-b border-indigo-500' : 'text-white/25 hover:text-white/50'
                        }`}>
                        <Icon size={11} />
                        {label}
                      </button>
                    ))}
                  </div>
                )}

                {/* Screen content */}
                <div className="overflow-hidden" style={{ height: '420px' }}>
                  {screen === 'login'       && <LoginScreen onLogin={handleLogin} />}
                  {screen === 'dashboard'   && <DashboardScreen />}
                  {screen === 'leaderboard' && <LeaderboardScreen />}
                  {screen === 'ai_coach'    && <AICoachScreen />}
                  {screen === 'admin'       && <AdminScreen />}
                </div>
              </div>
            </div>

            <p className="text-center text-white/15 text-[10px] mt-4">
              Simulated demo · All data fictional
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
