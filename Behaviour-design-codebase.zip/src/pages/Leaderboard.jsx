import { useState, useMemo } from 'react';
import { Crown, Medal, Award, ChevronRight, Users, TrendingUp } from 'lucide-react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatusConfig } from '../engine/core';
import StatusBadge from '../components/StatusBadge';
import ScoreRing from '../components/ScoreRing';
import MobileHeader from '../components/MobileHeader';

const RankIcon = ({ rank }) => {
  if (rank === 1) return <Crown size={13} className="text-yellow-400" />;
  if (rank === 2) return <Medal size={13} className="text-slate-300" />;
  if (rank === 3) return <Award size={13} className="text-amber-600" />;
  return <span className="text-white/20 text-xs font-mono">{rank}</span>;
};

const AVATAR_BG = [
  'from-indigo-500 to-purple-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-pink-500 to-rose-600',
  'from-cyan-500 to-blue-600',
  'from-violet-500 to-purple-600',
  'from-fuchsia-500 to-pink-600',
];

export default function Leaderboard() {
  const { leaderboard, activeUserId, getWeekScores, plugins, activePlugin } = useBehavior();
  const { user, tenantInfo } = useAuth();
  const [selected, setSelected] = useState(null);
  const plug = plugins[activePlugin];

  const top3 = leaderboard.slice(0, 3);

  // Summary stats
  const stats = useMemo(() => {
    if (!leaderboard.length) return {};
    const avgScore = Math.round(leaderboard.reduce((s, u) => s + u.score, 0) / leaderboard.length);
    const greenCount = leaderboard.filter((u) => u.status === 'GREEN').length;
    const topAvg = leaderboard[0]?.avg ?? 0;
    return { avgScore, greenCount, topAvg };
  }, [leaderboard]);

  const podiumOrder = [top3[1], top3[0], top3[2]].filter(Boolean);
  const podiumHeights = { 0: 'h-20', 1: 'h-28', 2: 'h-16' };
  const podiumRanks = { 0: 2, 1: 1, 2: 3 };

  return (
    <div className="max-w-4xl">
      <MobileHeader title="Leaderboard" />
    <div className="p-4 lg:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Leaderboard</h1>
          <p className="text-white/35 text-sm mt-0.5">
            {tenantInfo?.icon} {tenantInfo?.name} · Today's rankings
          </p>
        </div>
        <div className="flex items-center gap-1.5 glass px-3 py-1.5 rounded-xl">
          <Users size={12} className="text-white/40" />
          <span className="text-white/50 text-xs">{leaderboard.length} members</span>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Team Avg Score', value: stats.avgScore, color: 'text-indigo-400', icon: TrendingUp },
          { label: 'On Track (GREEN)', value: `${stats.greenCount}/${leaderboard.length}`, color: 'text-green-400', icon: Users },
          { label: 'Top 7-Day Avg', value: stats.topAvg, color: 'text-yellow-400', icon: Crown },
        ].map(({ label, value, color, icon: Icon }) => (
          <div key={label} className="glass rounded-xl p-3.5 flex items-center gap-3">
            <Icon size={14} className={color} />
            <div>
              <p className={`text-lg font-bold ${color}`}>{value}</p>
              <p className="text-white/30 text-xs">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Podium */}
      <div className="glass rounded-2xl p-6">
        <p className="text-white/25 text-xs uppercase tracking-widest text-center mb-6">Top Performers</p>
        <div className="flex items-end justify-center gap-6">
          {podiumOrder.map((u, idx) => {
            const cfg = getStatusConfig(u.status);
            const colorIdx = leaderboard.findIndex((l) => l.id === u.id) % AVATAR_BG.length;
            const isMe = u.id === activeUserId;
            const trueRank = podiumRanks[idx];
            return (
              <button
                key={u.id}
                onClick={() => setSelected(selected?.id === u.id ? null : u)}
                className={`flex flex-col items-center gap-2 transition-all hover:scale-105 ${selected?.id === u.id ? 'scale-105' : ''}`}
              >
                <div className="relative">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${AVATAR_BG[colorIdx]} flex items-center justify-center text-sm font-bold text-white shadow-xl ${isMe ? 'ring-2 ring-indigo-400' : ''}`}>
                    {u.avatar}
                  </div>
                  {trueRank === 1 && (
                    <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                      <Crown size={16} className="text-yellow-400" />
                    </div>
                  )}
                </div>
                <p className="text-white/80 text-xs font-semibold text-center">{u.name.split(' ')[0]}</p>
                <p className={`font-bold text-xl ${cfg.color}`}>{u.score}</p>
                <p className="text-white/20 text-xs">#{trueRank}</p>
                <div className={`w-20 ${podiumHeights[idx]} glass rounded-t-xl border-t-2 ${cfg.border} flex items-start justify-center pt-1`} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Expanded user card */}
      {selected && (() => {
        const weekData = getWeekScores(selected.id);
        const cfg = getStatusConfig(selected.status);
        return (
          <div className={`glass rounded-2xl p-5 border ${cfg.border}`}>
            <div className="flex items-center gap-4 mb-4">
              <ScoreRing score={selected.score} target={plug?.dailyTarget ?? 40} size={80} />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-white font-bold">{selected.name}</p>
                  {selected.id === activeUserId && <span className="text-indigo-400 text-xs bg-indigo-500/15 px-1.5 py-0.5 rounded-full">You</span>}
                  {selected.role === 'admin' && <span className="text-indigo-300 text-xs bg-indigo-500/15 px-1.5 py-0.5 rounded-full">Admin</span>}
                </div>
                <p className="text-white/40 text-xs mt-0.5">{selected.title} · {selected.pluginIcon} {selected.pluginName}</p>
                <div className="flex items-center gap-3 mt-2">
                  <StatusBadge status={selected.status} size="sm" />
                  <span className="text-white/25 text-xs">7-day avg: <span className="text-white/50 font-medium">{selected.avg} pts</span></span>
                </div>
              </div>
            </div>
            {/* Week sparkbar */}
            <div>
              <p className="text-white/20 text-[10px] uppercase tracking-widest mb-2">Weekly History</p>
              <div className="flex items-end gap-1.5 h-14">
                {weekData.map((d, i) => {
                  const s = d.score;
                  const sc = getStatusConfig(s >= 40 ? 'GREEN' : s >= 25 ? 'YELLOW' : 'RED');
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className={`w-full rounded-sm ${sc.bar} opacity-70`}
                        style={{ height: `${Math.max(3, (d.score / 60) * 44)}px` }}
                      />
                      <p className="text-white/15 text-[9px]">{d.label[0]}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        );
      })()}

      {/* Full table */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/6 grid grid-cols-12 gap-2 items-center">
          <span className="col-span-1" />
          <p className="col-span-5 text-white/30 text-xs font-semibold uppercase tracking-widest">Member</p>
          <p className="col-span-2 text-white/30 text-xs text-right">Score</p>
          <p className="col-span-2 text-white/30 text-xs text-right">7d Avg</p>
          <p className="col-span-2 text-white/30 text-xs text-right">Status</p>
        </div>
        <div className="divide-y divide-white/4">
          {leaderboard.map((u, i) => {
            const cfg = getStatusConfig(u.status);
            const colorIdx = i % AVATAR_BG.length;
            const isMe = u.id === activeUserId;
            return (
              <button
                key={u.id}
                onClick={() => setSelected(selected?.id === u.id ? null : u)}
                className={`w-full px-5 py-3 grid grid-cols-12 gap-2 items-center text-left transition-all hover:bg-white/3 ${isMe ? 'bg-indigo-500/6' : ''} ${selected?.id === u.id ? 'bg-white/4' : ''}`}
              >
                <div className="col-span-1 flex justify-center">
                  <RankIcon rank={u.rank} />
                </div>
                <div className="col-span-5 flex items-center gap-2.5">
                  <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${AVATAR_BG[colorIdx]} flex items-center justify-center text-xs font-bold text-white shrink-0`}>
                    {u.avatar}
                  </div>
                  <div className="min-w-0">
                    <p className={`text-sm font-medium truncate ${isMe ? 'text-indigo-300' : 'text-white/75'}`}>
                      {u.name}{isMe && <span className="text-indigo-400/50 ml-1.5 text-[10px]">(you)</span>}
                    </p>
                    <p className="text-white/25 text-xs truncate">{u.title}</p>
                  </div>
                </div>
                <p className={`col-span-2 font-bold text-right ${cfg.color}`}>{u.score}</p>
                <p className="col-span-2 text-white/35 text-sm text-right font-mono">{u.avg}</p>
                <div className="col-span-2 flex justify-end">
                  <StatusBadge status={u.status} size="xs" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
    </div>
  );
}
