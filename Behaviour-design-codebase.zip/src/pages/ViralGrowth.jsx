import { useState, useEffect } from 'react';
import { useBehavior } from '../store/BehaviorContext';
import { useAuth } from '../store/AuthContext';
import { getStatus, getStatusConfig } from '../engine/core';
import { generateExecutionCard } from '../engine/memory';
import {
  Share2, Copy, MessageCircle, Link2, Zap, Flame, TrendingUp,
  Users, ArrowRight, CheckCircle2, Star, BarChart2, Target, Gift,
  ExternalLink,
} from 'lucide-react';

// ── Acquisition Channel Cards ─────────────────────────────────────────────────
const CHANNELS = [
  {
    icon: MessageCircle,
    color: 'text-green-400',
    bg: 'bg-green-500/10',
    border: 'border-green-500/20',
    name: 'WhatsApp Groups',
    desc: 'Fastest channel in SA. Drop your execution card into sales teams, recruitment groups, and business circles.',
    steps: ['Screenshot your execution card', 'Post in 3 relevant WhatsApp groups', 'Include your referral link in bio'],
    template: '🔥 Testing a system that tracks daily execution and builds real consistency in teams. Onboarding 20 pilot users. Want in? → behaviorengine.io',
  },
  {
    icon: Link2,
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/20',
    name: 'LinkedIn Posts',
    desc: 'Share your team\'s execution improvement. Decision-makers scroll LinkedIn daily looking for edge.',
    steps: ['Post weekly execution improvement stats', 'Tag your team members', 'Include before/after score screenshot'],
    template: '🚀 We improved team execution by 23% in 7 days using a daily behavior tracking system.\n\nNot motivation. Not training. Just measurement.\n\n→ If you manage a team, DM me.',
  },
  {
    icon: Target,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    name: 'Direct Outreach',
    desc: 'Most powerful for first 100 users. Identify 20 sales managers or team leads and DM them personally.',
    steps: ['Find 20 sales managers on LinkedIn', 'Send personalized "pilot invitation" DM', 'Follow up in 48h with your execution card'],
    template: 'Hi [Name], I\'m running a 7-day pilot for a team execution tracker. No cost, 10 min setup. Your team gets a daily score + AI coaching. Worth a test?',
  },
];

const VIRAL_TRIGGERS = [
  { icon: TrendingUp, label: 'Score Improvement',   desc: 'Users share when they hit a new personal best or GREEN status',  color: 'text-emerald-400' },
  { icon: Users,      label: 'Leaderboard Ranking', desc: 'Social proof — everyone wants to show their team ranking',        color: 'text-indigo-400'  },
  { icon: Flame,      label: 'Streak Milestones',   desc: '3-day, 7-day, 14-day streak badges trigger automatic share prompts', color: 'text-orange-400' },
  { icon: Star,       label: 'Achievement Unlocks', desc: 'First GREEN day, top-3 finish, perfect week — all shareable moments', color: 'text-yellow-400' },
];

const ACQUISITION_PLAN = [
  { week: 'Week 1', target: '5 users',   tactic: 'Personal WhatsApp — friends who run or work on teams',    done: false },
  { week: 'Week 2', target: '20 users',  tactic: '3 WhatsApp groups + 2 LinkedIn posts with your score card',done: false },
  { week: 'Week 3', target: '50 users',  tactic: 'Direct outreach to 20 sales managers via LinkedIn DM',    done: false },
  { week: 'Week 4', target: '100 users', tactic: 'Referral loop activates — existing users invite teams',    done: false },
];

// ── Execution Card ─────────────────────────────────────────────────────────────
function ExecutionCard({ card, compact = false }) {
  const [copied, setCopied] = useState(false);
  const cfg = getStatusConfig(card.status);

  const handleCopy = () => {
    navigator.clipboard.writeText(card.shareText).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (compact) {
    return (
      <div className={`rounded-xl p-4 border ${cfg.border} ${cfg.glow} bg-[#0b0f1a]`}>
        <div className="flex items-center justify-between mb-1">
          <span className="text-white/25 text-[10px] uppercase tracking-widest">Execution Card</span>
          <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.color}`}>{card.status}</span>
        </div>
        <p className={`text-3xl font-black ${cfg.color}`}>{card.score} <span className="text-white/20 text-sm font-normal">pts</span></p>
        {card.streak > 0 && <p className="text-orange-400 text-xs mt-0.5">🔥 {card.streak}-day streak</p>}
      </div>
    );
  }

  return (
    <div className={`rounded-2xl border-2 ${cfg.border} bg-gradient-to-br from-[#0b0f1a] to-[#080c17] overflow-hidden`}
      style={{ boxShadow: `0 0 40px rgba(0,0,0,0.5), 0 0 20px ${cfg.border.includes('green') ? '#22c55e20' : cfg.border.includes('yellow') ? '#eab30820' : '#ef444420'}` }}>

      {/* Top bar */}
      <div className={`h-1 w-full ${cfg.bar}`} />

      <div className="p-6">
        {/* Brand */}
        <div className="flex items-center gap-2 mb-5">
          <div className="w-6 h-6 rounded-lg bg-indigo-500 flex items-center justify-center">
            <Zap size={12} className="text-white" />
          </div>
          <span className="text-white/60 text-xs font-semibold">Behavior Engine</span>
          <span className="text-white/15 text-xs mx-1">·</span>
          <span className="text-white/25 text-xs">{card.tenantName}</span>
        </div>

        {/* Score */}
        <div className="mb-5">
          <p className="text-white/30 text-xs uppercase tracking-widest mb-1">Today's Execution Score</p>
          <p className={`text-6xl font-black leading-none ${cfg.color}`}>{card.score}</p>
          <p className="text-white/20 text-sm mt-1">out of 100 pts</p>
        </div>

        {/* Metrics row */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className={`rounded-xl p-3 ${cfg.bg} border ${cfg.border} text-center`}>
            <p className={`text-lg font-black ${cfg.color}`}>{card.emoji}</p>
            <p className="text-white/35 text-[9px] uppercase tracking-wide mt-0.5">Status</p>
            <p className={`text-xs font-bold ${cfg.color}`}>{card.status}</p>
          </div>
          <div className="rounded-xl p-3 bg-orange-500/10 border border-orange-500/20 text-center">
            <p className="text-lg font-black text-orange-400">{card.streak > 0 ? '🔥' : '—'}</p>
            <p className="text-white/35 text-[9px] uppercase tracking-wide mt-0.5">Streak</p>
            <p className="text-xs font-bold text-orange-400">{card.streak > 0 ? `${card.streak}d` : 'None'}</p>
          </div>
          <div className="rounded-xl p-3 bg-indigo-500/10 border border-indigo-500/20 text-center">
            <p className="text-lg font-black text-indigo-400">#{card.rank}</p>
            <p className="text-white/35 text-[9px] uppercase tracking-wide mt-0.5">Rank</p>
            <p className="text-xs font-bold text-indigo-400">of {card.totalUsers}</p>
          </div>
        </div>

        {/* Share text preview */}
        <div className="rounded-xl bg-white/3 border border-white/6 p-3 mb-4 text-xs text-white/45 leading-relaxed whitespace-pre-line">
          {card.shareText}
        </div>

        {/* Share buttons */}
        <div className="grid grid-cols-3 gap-2">
          <button onClick={handleCopy}
            className="flex flex-col items-center gap-1 p-3 rounded-xl bg-white/4 border border-white/8 hover:border-white/15 transition-all">
            {copied ? <CheckCircle2 size={16} className="text-green-400" /> : <Copy size={16} className="text-white/40" />}
            <span className="text-white/35 text-[9px]">{copied ? 'Copied!' : 'Copy'}</span>
          </button>
          <a href={`https://wa.me/?text=${card.whatsAppText}`} target="_blank" rel="noopener noreferrer"
            className="flex flex-col items-center gap-1 p-3 rounded-xl bg-green-500/8 border border-green-500/20 hover:border-green-500/40 transition-all">
            <MessageCircle size={16} className="text-green-400" />
            <span className="text-green-400/60 text-[9px]">WhatsApp</span>
          </a>
          <a href={`https://www.linkedin.com/shareArticle?mini=true&summary=${card.linkedInText}`} target="_blank" rel="noopener noreferrer"
            className="flex flex-col items-center gap-1 p-3 rounded-xl bg-blue-500/8 border border-blue-500/20 hover:border-blue-500/40 transition-all">
            <Link2 size={16} className="text-blue-400" />
            <span className="text-blue-400/60 text-[9px]">LinkedIn</span>
          </a>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function ViralGrowth() {
  const { getTodayScore, getWeekScores, activeUserId, plugins, activePlugin } = useBehavior();
  const { user, allUsersInTenant, tenantInfo } = useAuth();
  const [activeChannel, setActiveChannel] = useState(0);
  const [plan, setPlan]   = useState(ACQUISITION_PLAN);
  const [copied, setCopied] = useState(null);

  const score   = getTodayScore(activeUserId);
  const status  = getStatus(score);
  const cfg     = getStatusConfig(status);
  const weekScores = getWeekScores(activeUserId);
  const streak  = weekScores.filter(Boolean).length; // simplified streak
  const allUsers = allUsersInTenant ?? [];
  const sorted  = [...allUsers].sort((a, b) =>
    getTodayScore(b.id) - getTodayScore(a.id)
  );
  const rank = sorted.findIndex(u => u.id === activeUserId) + 1;

  const card = generateExecutionCard(
    activeUserId,
    user?.name ?? 'You',
    tenantInfo?.name ?? 'My Team',
    score,
    status,
    streak,
    rank || 1,
    allUsers.length || 1
  );

  const copyTemplate = (text) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(text);
    setTimeout(() => setCopied(null), 2000);
  };

  const togglePlan = (i) => {
    setPlan(prev => prev.map((p, idx) => idx === i ? { ...p, done: !p.done } : p));
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-8">

        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Share2 size={16} className="text-indigo-400" />
            <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">Viral Growth System</p>
          </div>
          <h1 className="text-3xl font-black mb-1">Get Your First 100 Users</h1>
          <p className="text-white/35 text-sm">Execution cards + sharing loops + acquisition playbook — all in one place.</p>
        </div>

        {/* Two-column top section */}
        <div className="grid lg:grid-cols-2 gap-6">

          {/* LEFT — Execution Card */}
          <div>
            <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-3">Your Execution Card</p>
            <ExecutionCard card={card} />
          </div>

          {/* RIGHT — Viral Triggers */}
          <div>
            <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-3">Viral Triggers</p>
            <div className="space-y-3">
              {VIRAL_TRIGGERS.map(({ icon: Icon, label, desc, color }) => (
                <div key={label} className="flex items-start gap-3 p-4 rounded-xl bg-white/3 border border-white/6">
                  <div className={`w-8 h-8 rounded-lg bg-white/5 border border-white/8 flex items-center justify-center shrink-0`}>
                    <Icon size={15} className={color} />
                  </div>
                  <div>
                    <p className={`text-sm font-semibold ${color}`}>{label}</p>
                    <p className="text-white/35 text-xs leading-snug mt-0.5">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Acquisition Channels */}
        <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] overflow-hidden">
          <div className="border-b border-white/6 flex">
            {CHANNELS.map((ch, i) => {
              const Icon = ch.icon;
              return (
                <button key={ch.name} onClick={() => setActiveChannel(i)}
                  className={`flex-1 flex items-center justify-center gap-2 py-3.5 text-sm font-semibold transition-all ${
                    activeChannel === i
                      ? `${ch.color} border-b-2 ${ch.border.replace('border-', 'border-b-')}`
                      : 'text-white/30 hover:text-white/55'
                  }`}>
                  <Icon size={14} />
                  <span className="hidden sm:inline">{ch.name}</span>
                </button>
              );
            })}
          </div>

          <div className="p-5">
            {(() => {
              const ch = CHANNELS[activeChannel];
              const Icon = ch.icon;
              return (
                <div className="grid lg:grid-cols-2 gap-6">
                  <div>
                    <div className={`flex items-center gap-2 mb-3`}>
                      <Icon size={16} className={ch.color} />
                      <p className={`font-bold ${ch.color}`}>{ch.name}</p>
                    </div>
                    <p className="text-white/50 text-sm leading-relaxed mb-4">{ch.desc}</p>
                    <div className="space-y-2">
                      {ch.steps.map((step, i) => (
                        <div key={step} className="flex items-start gap-2.5">
                          <span className={`w-5 h-5 rounded-full ${ch.bg} ${ch.color} text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5`}>
                            {i + 1}
                          </span>
                          <p className="text-white/55 text-sm">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-white/30 text-xs uppercase tracking-widest mb-2">Message Template</p>
                    <div className={`p-4 rounded-xl ${ch.bg} border ${ch.border} text-sm text-white/70 leading-relaxed whitespace-pre-line mb-3`}>
                      {ch.template}
                    </div>
                    <button onClick={() => copyTemplate(ch.template)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${ch.bg} ${ch.color} border ${ch.border} hover:opacity-80`}>
                      {copied === ch.template
                        ? <><CheckCircle2 size={13} /> Copied!</>
                        : <><Copy size={13} /> Copy Template</>}
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>

        {/* Viral Message */}
        <div className="rounded-2xl border border-indigo-500/25 bg-indigo-500/5 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Gift size={15} className="text-indigo-400" />
            <p className="text-indigo-400 font-bold text-sm">The Viral Message That Works</p>
          </div>
          <div className="p-4 rounded-xl bg-white/4 border border-white/8 text-sm text-white/65 leading-relaxed mb-3 italic">
            "I'm testing a system that tracks daily execution and improves consistency in teams.
            I'm onboarding 20 pilot users — 7 days free, 10 min setup, real behavioral insights.
            Want in?"
          </div>
          <p className="text-white/30 text-xs">Send this to 10 people you know who manage or lead teams. 2–3 will say yes. Repeat.</p>
        </div>

        {/* 100-User Acquisition Plan */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Target size={15} className="text-emerald-400" />
            <p className="text-white font-bold">100-User Acquisition Plan</p>
            <span className="text-white/20 text-xs ml-auto">{plan.filter(p => p.done).length} / {plan.length} weeks done</span>
          </div>
          <div className="space-y-2">
            {plan.map((item, i) => (
              <div key={item.week}
                onClick={() => togglePlan(i)}
                className={`flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                  item.done ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/6 bg-white/2 hover:border-white/10'
                }`}>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                  item.done ? 'border-emerald-500 bg-emerald-500' : 'border-white/20'
                }`}>
                  {item.done && <CheckCircle2 size={11} className="text-white" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-0.5">
                    <p className={`text-xs font-bold uppercase tracking-wider ${item.done ? 'text-emerald-400' : 'text-white/30'}`}>{item.week}</p>
                    <p className={`text-sm font-black ${item.done ? 'text-emerald-400' : 'text-white'}`}>→ {item.target}</p>
                  </div>
                  <p className="text-white/40 text-sm">{item.tactic}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stats footer */}
        <div className="grid grid-cols-3 gap-4 text-center">
          {[
            { label: 'Your Current Score', value: score, color: cfg.color },
            { label: 'Team Members',        value: allUsers.length, color: 'text-white' },
            { label: 'Your Rank',            value: `#${rank || 1}`, color: 'text-indigo-400' },
          ].map(({ label, value, color }) => (
            <div key={label} className="p-4 rounded-xl bg-white/2 border border-white/6">
              <p className={`text-2xl font-black ${color}`}>{value}</p>
              <p className="text-white/25 text-xs mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
