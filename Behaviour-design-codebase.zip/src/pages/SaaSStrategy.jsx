import { useState } from 'react';
import {
  DollarSign, Users, Zap, Copy, CheckCircle2, MessageSquare,
  TrendingUp, Target, ArrowRight, Flame, Star, Building2,
  Phone, Mail, ChevronRight,
} from 'lucide-react';
import MobileHeader from '../components/MobileHeader';

const OUTREACH_TEMPLATES = [
  {
    id: 'cold_dm',
    label: 'Cold DM / WhatsApp',
    icon: MessageSquare,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    subject: null,
    body: `Hey [Name],

Quick question — does your team track daily sales activity or just results?

I built a system that forces daily execution and shows you who's actually doing the work.

Testing it with 2 pilot teams this month. Want in?`,
    tip: 'Send this to sales managers on LinkedIn or WhatsApp. Response rate: 15–25%.',
  },
  {
    id: 'cold_email',
    label: 'Cold Email',
    icon: Mail,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    subject: 'Quick question about your sales team',
    body: `Hi [Name],

I noticed your team at [Company] is hiring SDRs.

Most sales managers track revenue but not the daily actions that produce it.

I built a tool that tracks exactly that — outreach, conversations, follow-ups, closes — and shows a live leaderboard your team can see.

Would you be open to a 15-min call this week? I'm onboarding 2 teams this month at no cost to pilot.

[Your name]`,
    tip: 'Lead with the pain (activity not tracked), not the tool. Always offer a pilot.',
  },
  {
    id: 'linkedin',
    label: 'LinkedIn Message',
    icon: Users,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
    subject: null,
    body: `Hi [Name], I came across your profile while looking at sales leaders in [industry].

I'm running a 7-day execution pilot with 2 sales teams — a system that tracks daily actions (outreach, convos, closes) and produces a live team leaderboard.

No cost to pilot. Just need a team of 5–20 people.

Would you want to see how it works?`,
    tip: 'Connect first, then message after they accept. Keep it under 80 words.',
  },
  {
    id: 'follow_up',
    label: 'Follow-Up (Day 3)',
    icon: ArrowRight,
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/20',
    subject: 'Re: execution tracking system',
    body: `Hey [Name], just checking back in.

I know you're busy. I'll keep it simple:

→ 7-day pilot
→ 5–20 users
→ Free to try
→ Takes 10 minutes to set up

If this isn't a fit right now, no worries — but if you want to see the system, I can show you in 5 minutes today or tomorrow.`,
    tip: '80% of sales happen after the 5th follow-up. Most people stop after 1.',
  },
];

const REVENUE_MODEL = [
  {
    phase: 'Phase 1',
    label: 'First $500',
    emoji: '🎯',
    target: '10 users at $50/user',
    revenue: '$500',
    strategy: 'Pilot 2 teams of 5. Offer free month, then charge. Personal onboarding = higher close rate.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
  },
  {
    phase: 'Phase 2',
    label: 'First $1,000',
    emoji: '💰',
    target: '1 team at $500/mo',
    revenue: '$500+',
    strategy: 'Land a sales team of 10 at $50/user/month. Monthly recurring = real SaaS revenue.',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
  },
  {
    phase: 'Phase 3',
    label: 'First $5,000/mo',
    emoji: '🚀',
    target: '10 teams at $500/mo',
    revenue: '$5,000 MRR',
    strategy: 'Productize onboarding. Add referral system. Each team refers 1 more = exponential growth.',
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
  },
];

const TARGETS = [
  { name: 'Sales Teams', reason: 'Daily activity = direct revenue impact. They understand ROI instantly.', match: 'Perfect', icon: TrendingUp, color: 'text-indigo-400' },
  { name: 'Recruitment Agencies', reason: 'Outreach volume is their lifeblood. Easy to show before/after.', match: 'Great', icon: Users, color: 'text-emerald-400' },
  { name: 'Coaching Businesses', reason: 'Clients pay for accountability. This gives coaches proof of impact.', match: 'Great', icon: Star, color: 'text-yellow-400' },
  { name: 'Call Centers', reason: 'High volume, measurable KPIs. Easy pilot, easy sell.', match: 'Good', icon: Phone, color: 'text-cyan-400' },
  { name: 'SME Sales Ops', reason: 'No proper CRM, need visibility into team activity. Perfect entry point.', match: 'Good', icon: Building2, color: 'text-pink-400' },
];

const PRICING_TABLE = [
  { tier: 'Starter', price: '$20/user/mo', min: 5, team: '$100/team', best: 'Solo freelancers, coaches' },
  { tier: 'Pro',     price: '$35/user/mo', min: 5, team: '$175/team', best: 'SME sales teams'          },
  { tier: 'Growth',  price: '$50/user/mo', min: 5, team: '$250/team', best: 'Agencies, call centers'   },
];

function CopyButton({ text, className = '' }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
      className={`flex items-center gap-1.5 text-xs px-3 py-1.5 glass rounded-lg border border-white/8 hover:border-white/20 text-white/40 hover:text-white/70 transition-all ${className}`}
    >
      {copied ? <CheckCircle2 size={11} className="text-green-400" /> : <Copy size={11} />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

export default function SaaSStrategy() {
  const [activeTemplate, setActiveTemplate] = useState(0);

  const active = OUTREACH_TEMPLATES[activeTemplate];

  return (
    <div className="max-w-3xl mx-auto">
      <MobileHeader title="Strategy" />

      <div className="hidden lg:block px-6 pt-6 pb-4">
        <div className="flex items-center gap-2 mb-1">
          <DollarSign size={16} className="text-emerald-400" />
          <span className="text-emerald-400 text-xs font-semibold uppercase tracking-widest">First $1,000 SaaS Strategy</span>
        </div>
        <h1 className="text-2xl font-bold text-white">Get Paying Clients Fast</h1>
        <p className="text-white/35 text-sm mt-0.5">Positioning · Outreach · Revenue model · Step-by-step execution</p>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-6">
        {/* Positioning statement */}
        <div className="glass rounded-xl p-5 border border-emerald-500/20">
          <p className="text-white/30 text-[10px] uppercase tracking-widest mb-3 flex items-center gap-1.5">
            <Target size={10} /> Your Positioning
          </p>
          <blockquote className="text-white text-lg font-bold leading-snug">
            "I help teams execute daily actions that produce results."
          </blockquote>
          <div className="mt-3 pt-3 border-t border-white/6">
            <p className="text-white/40 text-xs">Don't say: "I built a SaaS app." Say: "I built a system." You're solving a behavior problem, not selling software.</p>
          </div>
        </div>

        {/* Revenue path */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3">Revenue Roadmap</p>
          <div className="space-y-3">
            {REVENUE_MODEL.map((r) => (
              <div key={r.phase} className={`glass rounded-xl p-4 border ${r.border}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">{r.emoji}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-white/30 text-[10px] uppercase tracking-widest">{r.phase}</span>
                        <span className={`text-xs font-bold ${r.color}`}>{r.label}</span>
                      </div>
                      <p className="text-white/50 text-xs mt-0.5">{r.target}</p>
                    </div>
                  </div>
                  <div className={`text-2xl font-black ${r.color}`}>{r.revenue}</div>
                </div>
                <p className="text-white/40 text-sm leading-snug">{r.strategy}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Outreach templates */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3">Outreach Templates</p>
          {/* Tab selector */}
          <div className="flex gap-1 p-1 bg-white/5 rounded-xl mb-4 overflow-x-auto scrollbar-hide">
            {OUTREACH_TEMPLATES.map((t, i) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  onClick={() => setActiveTemplate(i)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${activeTemplate === i ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}
                >
                  <Icon size={11} /> {t.label}
                </button>
              );
            })}
          </div>

          {/* Active template */}
          <div className={`glass rounded-xl p-5 border ${active.border}`}>
            {active.subject && (
              <div className="mb-3 pb-3 border-b border-white/6">
                <p className="text-white/30 text-[10px] uppercase tracking-widest mb-1">Subject Line</p>
                <div className="flex items-center justify-between gap-3">
                  <p className="text-white font-semibold text-sm">{active.subject}</p>
                  <CopyButton text={active.subject} />
                </div>
              </div>
            )}
            <div className="mb-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-white/30 text-[10px] uppercase tracking-widest">Message</p>
                <CopyButton text={active.body} />
              </div>
              <pre className="text-white/70 text-sm leading-relaxed whitespace-pre-wrap font-sans">
                {active.body}
              </pre>
            </div>
            <div className={`flex items-start gap-2 px-3 py-2.5 rounded-xl ${active.bg} border ${active.border}`}>
              <Flame size={11} className={`${active.color} mt-0.5 shrink-0`} />
              <p className={`text-xs ${active.color} leading-snug`}>{active.tip}</p>
            </div>
          </div>
        </div>

        {/* Target market */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3">Best Target Markets</p>
          <div className="glass rounded-xl overflow-hidden border border-white/8">
            {TARGETS.map((t, i) => (
              <div key={t.name} className={`flex items-start gap-3 px-4 py-3.5 ${i < TARGETS.length - 1 ? 'border-b border-white/5' : ''}`}>
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0 mt-0.5">
                  <t.icon size={14} className={t.color} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-white/80 text-sm font-semibold">{t.name}</p>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                      t.match === 'Perfect' ? 'text-green-400 bg-green-500/10 border border-green-500/20' :
                      t.match === 'Great' ? 'text-indigo-400 bg-indigo-500/10 border border-indigo-500/20' :
                      'text-white/40 bg-white/5 border border-white/10'
                    }`}>{t.match}</span>
                  </div>
                  <p className="text-white/35 text-xs mt-0.5 leading-snug">{t.reason}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pricing reference */}
        <div>
          <p className="text-white/25 text-[10px] uppercase tracking-widest px-1 mb-3">Pricing to Quote</p>
          <div className="glass rounded-xl overflow-hidden border border-white/8">
            <div className="grid grid-cols-[auto_auto_auto_1fr] text-[10px] text-white/25 uppercase tracking-widest px-4 py-2.5 border-b border-white/6 gap-4">
              <span>Tier</span>
              <span>Per User</span>
              <span>Min 5 Users</span>
              <span>Best For</span>
            </div>
            {PRICING_TABLE.map((p, i) => (
              <div
                key={p.tier}
                className={`grid grid-cols-[auto_auto_auto_1fr] gap-4 px-4 py-3 items-center ${i < PRICING_TABLE.length - 1 ? 'border-b border-white/4' : ''}`}
              >
                <span className="text-white font-bold text-sm">{p.tier}</span>
                <span className="text-indigo-400 text-sm font-semibold">{p.price}</span>
                <span className="text-emerald-400 text-sm font-semibold">{p.team}</span>
                <span className="text-white/35 text-xs">{p.best}</span>
              </div>
            ))}
          </div>
          <p className="text-white/20 text-xs px-1 mt-2">Start at Starter. Upsell to Pro after they see results at 30 days.</p>
        </div>

        {/* The 1K path */}
        <div className="glass rounded-xl p-5 border border-emerald-500/20">
          <p className="text-white font-bold text-sm mb-4">The Exact $1,000 Path</p>
          <div className="space-y-3">
            {[
              { step: 'Day 1–3', action: 'Send 20 outreach messages using Template 1', result: '3–5 responses expected' },
              { step: 'Day 3–7', action: 'Book 2–3 demo calls (15 min each)', result: 'Show live leaderboard + task system' },
              { step: 'Day 7', action: 'Close 1–2 pilots at $100–$300/team', result: 'First revenue' },
              { step: 'Day 14', action: 'Onboard pilots. Add users manually. Monitor execution.', result: 'Proof of results' },
              { step: 'Day 30', action: 'Show results report. Upsell to paid plan.', result: '$500/month recurring' },
              { step: 'Day 45', action: 'Ask for 1 referral from each happy client', result: '2nd team = $1,000 MRR' },
            ].map(({ step, action, result }, i) => (
              <div key={i} className="flex items-start gap-3">
                <span className="text-emerald-400/60 text-[10px] font-mono mt-1 shrink-0 w-14">{step}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-white/70 text-sm">{action}</p>
                  <p className="text-emerald-400/60 text-xs mt-0.5 flex items-center gap-1">
                    <ChevronRight size={9} /> {result}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-white/6 flex items-center gap-2">
            <Zap size={12} className="text-emerald-400" />
            <p className="text-emerald-300/70 text-xs font-medium">The product is already built. Your job now is outreach.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
