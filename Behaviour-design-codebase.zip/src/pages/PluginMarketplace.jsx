import { useState } from 'react';
import {
  Puzzle, TrendingUp, GraduationCap, Dumbbell, Truck,
  Heart, Code2, ShoppingCart, CheckCircle2, Lock, Globe,
  Star, Users, ChevronRight, Plus, Zap,
} from 'lucide-react';
import { useAuth } from '../store/AuthContext';
import MobileHeader from '../components/MobileHeader';

const ALL_PLUGINS = [
  {
    id: 'sales',
    name: 'Sales Execution Engine',
    description: 'A complete daily execution system for sales teams. Tracks outreach, conversations, follow-ups, and closes.',
    icon: '💼',
    lucideIcon: TrendingUp,
    category: 'Sales',
    tasks: 8,
    dailyTarget: 40,
    visibility: 'marketplace',
    active: true,
    rating: 4.9,
    installs: 1240,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    tags: ['sales', 'pipeline', 'CRM', 'outreach'],
    plan: 'starter',
  },
  {
    id: 'fitness',
    name: 'Fitness & Performance',
    description: 'Track workouts, nutrition, recovery, and sleep. Built for athletic performance and gym operators.',
    icon: '🏋️',
    lucideIcon: Dumbbell,
    category: 'Health',
    tasks: 8,
    dailyTarget: 40,
    visibility: 'marketplace',
    active: true,
    rating: 4.8,
    installs: 876,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    tags: ['fitness', 'gym', 'nutrition', 'health'],
    plan: 'starter',
  },
  {
    id: 'school',
    name: 'Academic Execution',
    description: 'Designed for students and academic institutions. Tracks study sessions, assignments, and attendance.',
    icon: '🎓',
    lucideIcon: GraduationCap,
    category: 'Education',
    tasks: 8,
    dailyTarget: 35,
    visibility: 'marketplace',
    active: true,
    rating: 4.7,
    installs: 542,
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/20',
    tags: ['school', 'study', 'education', 'students'],
    plan: 'starter',
  },
  {
    id: 'logistics',
    name: 'Logistics Operations',
    description: 'For logistics and supply chain teams. Track routes, deliveries, vehicle checks, and compliance.',
    icon: '🚛',
    lucideIcon: Truck,
    category: 'Operations',
    tasks: 9,
    dailyTarget: 45,
    visibility: 'marketplace',
    active: false,
    rating: 4.6,
    installs: 321,
    color: 'text-orange-400',
    bg: 'bg-orange-500/10',
    border: 'border-orange-500/20',
    tags: ['logistics', 'supply chain', 'operations'],
    plan: 'pro',
  },
  {
    id: 'dev',
    name: 'Developer Productivity',
    description: 'For engineering teams. Tracks PRs, code reviews, deployments, and standup participation.',
    icon: '⚡',
    lucideIcon: Code2,
    category: 'Tech',
    tasks: 7,
    dailyTarget: 35,
    visibility: 'marketplace',
    active: false,
    rating: 4.5,
    installs: 289,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
    tags: ['engineering', 'devops', 'coding', 'sprints'],
    plan: 'pro',
  },
  {
    id: 'ecommerce',
    name: 'E-Commerce Sales',
    description: 'For e-commerce operators. Tracks listings, ad spend review, conversion rate optimization tasks.',
    icon: '🛒',
    lucideIcon: ShoppingCart,
    category: 'Sales',
    tasks: 10,
    dailyTarget: 50,
    visibility: 'marketplace',
    active: false,
    rating: 4.4,
    installs: 198,
    color: 'text-pink-400',
    bg: 'bg-pink-500/10',
    border: 'border-pink-500/20',
    tags: ['ecommerce', 'DTC', 'shopify', 'ads'],
    plan: 'pro',
  },
  {
    id: 'custom_private',
    name: 'Custom Plugin',
    description: 'Build your own fully custom behavior module with tailored tasks, scoring rules, and AI feedback logic.',
    icon: '🔧',
    lucideIcon: Puzzle,
    category: 'Custom',
    tasks: 0,
    dailyTarget: null,
    visibility: 'private',
    active: false,
    rating: null,
    installs: null,
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    tags: ['custom', 'private', 'enterprise'],
    plan: 'enterprise',
  },
];

const CATEGORIES = ['All', 'Sales', 'Health', 'Education', 'Operations', 'Tech', 'Custom'];

const PLAN_BADGE = {
  starter: { label: 'Starter+', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' },
  pro: { label: 'Pro+', color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20' },
  enterprise: { label: 'Enterprise', color: 'text-purple-400 bg-purple-500/10 border-purple-500/20' },
};

export default function PluginMarketplace() {
  const { tenantInfo } = useAuth();
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [installedIds, setInstalledIds] = useState(['sales', 'fitness', 'school']);

  const filtered = ALL_PLUGINS.filter((p) => {
    const matchCat = category === 'All' || p.category === category;
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.tags.some(t => t.includes(search.toLowerCase()));
    return matchCat && matchSearch;
  });

  const activePlugins = ALL_PLUGINS.filter(p => installedIds.includes(p.id));
  const marketplacePlugins = filtered.filter(p => p.visibility === 'marketplace');
  const privatePlugins = filtered.filter(p => p.visibility === 'private');

  const toggle = (id) => {
    setInstalledIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <MobileHeader title="Plugins" />

      {/* Desktop header */}
      <div className="hidden lg:flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Puzzle size={16} className="text-indigo-400" />
            <span className="text-indigo-400 text-xs font-semibold uppercase tracking-widest">Plugin Marketplace</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Behavior Modules</h1>
          <p className="text-white/35 text-sm mt-0.5">{tenantInfo?.icon} {tenantInfo?.name} · Extend your execution OS</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-indigo-500/20 rounded-xl text-xs text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/30 transition-all">
          <Plus size={12} /> Request Custom Plugin
        </button>
      </div>

      <div className="px-4 lg:px-6 pb-8 space-y-5">
        {/* Active plugins summary */}
        <div className="glass rounded-xl p-4 border border-indigo-500/20">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Zap size={14} className="text-indigo-400" />
              <p className="text-white text-sm font-semibold">Active Plugins</p>
              <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/15 px-1.5 py-0.5 rounded-full">{activePlugins.length}</span>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {activePlugins.map(p => (
              <div key={p.id} className={`flex items-center gap-2 px-3 py-1.5 rounded-xl ${p.bg} border ${p.border}`}>
                <span className="text-sm leading-none">{p.icon}</span>
                <span className={`text-xs font-semibold ${p.color}`}>{p.name.split(' ')[0]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Search + filter */}
        <div className="flex flex-col lg:flex-row gap-3">
          <input
            type="text"
            placeholder="Search plugins..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="flex-1 glass rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 border border-white/8 outline-none focus:border-indigo-500/40 bg-transparent"
          />
          <div className="flex gap-1 p-1 bg-white/5 rounded-xl overflow-x-auto scrollbar-hide">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${category === cat ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Marketplace plugins */}
        {marketplacePlugins.length > 0 && (
          <div>
            <div className="flex items-center gap-2 px-1 mb-3">
              <Globe size={12} className="text-white/25" />
              <p className="text-white/25 text-[10px] uppercase tracking-widest">Marketplace</p>
            </div>
            <div className="grid lg:grid-cols-2 gap-3">
              {marketplacePlugins.map((plug) => {
                const installed = installedIds.includes(plug.id);
                const planBadge = PLAN_BADGE[plug.plan];
                return (
                  <div
                    key={plug.id}
                    className={`glass rounded-xl p-4 border transition-all ${installed ? plug.border : 'border-white/8'}`}
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div className={`w-11 h-11 rounded-xl ${plug.bg} border ${plug.border} flex items-center justify-center text-xl shrink-0`}>
                        {plug.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-white font-semibold text-sm">{plug.name}</p>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${planBadge.color}`}>
                            {planBadge.label}
                          </span>
                          {installed && (
                            <CheckCircle2 size={12} className="text-green-400" />
                          )}
                        </div>
                        <p className="text-white/35 text-xs mt-0.5 line-clamp-2">{plug.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 mb-3">
                      <div className="flex items-center gap-1">
                        <Star size={10} className="text-yellow-400" />
                        <span className="text-white/50 text-xs">{plug.rating}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users size={10} className="text-white/25" />
                        <span className="text-white/35 text-xs">{plug.installs?.toLocaleString()} installs</span>
                      </div>
                      <span className={`text-[10px] font-semibold ${plug.color}`}>{plug.category}</span>
                    </div>

                    <div className="flex flex-wrap gap-1 mb-3">
                      {plug.tags.slice(0, 3).map(tag => (
                        <span key={tag} className="text-[9px] text-white/30 bg-white/5 px-1.5 py-0.5 rounded">#{tag}</span>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 pt-3 border-t border-white/5">
                      <div className="text-white/25 text-xs">{plug.tasks} tasks · {plug.dailyTarget}pt target</div>
                      <button
                        onClick={() => toggle(plug.id)}
                        className={`ml-auto px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                          installed
                            ? 'glass text-white/40 border border-white/8 hover:border-red-500/30 hover:text-red-400'
                            : `${plug.bg} ${plug.color} border ${plug.border} hover:opacity-80`
                        }`}
                      >
                        {installed ? 'Uninstall' : 'Install'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Private / custom plugins */}
        {privatePlugins.length > 0 && (
          <div>
            <div className="flex items-center gap-2 px-1 mb-3">
              <Lock size={12} className="text-white/25" />
              <p className="text-white/25 text-[10px] uppercase tracking-widest">Custom / Private</p>
            </div>
            <div className="glass rounded-xl p-5 border border-purple-500/20">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-2xl shrink-0">
                  🔧
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-white font-bold text-base">Build a Custom Plugin</p>
                    <span className="text-[9px] font-bold text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded-full border border-purple-500/20">Enterprise</span>
                  </div>
                  <p className="text-white/45 text-sm leading-relaxed">
                    Create a fully custom behavior module for your specific workflow. Define your own tasks, scoring rules, AI feedback logic, and visibility settings.
                  </p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {['Custom tasks', 'Custom scoring', 'AI feedback rules', 'Private or marketplace', 'API webhook support'].map((f) => (
                      <span key={f} className="flex items-center gap-1 text-xs text-purple-300/70 bg-purple-500/8 border border-purple-500/15 px-2 py-1 rounded-lg">
                        <CheckCircle2 size={9} /> {f}
                      </span>
                    ))}
                  </div>
                  <button className="mt-4 flex items-center gap-2 px-5 py-2.5 bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-xl text-sm font-semibold hover:bg-purple-500/30 transition-all">
                    <Plus size={13} /> Request Custom Build <ChevronRight size={13} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stats bar */}
        <div className="glass rounded-xl p-4 border border-white/8 flex flex-wrap items-center gap-6">
          <div className="text-center">
            <p className="text-white font-bold text-lg">{ALL_PLUGINS.filter(p => p.visibility === 'marketplace').length}</p>
            <p className="text-white/30 text-[10px]">Marketplace plugins</p>
          </div>
          <div className="text-center">
            <p className="text-white font-bold text-lg">{installedIds.length}</p>
            <p className="text-white/30 text-[10px]">Installed</p>
          </div>
          <div className="text-center">
            <p className="text-white font-bold text-lg">
              {ALL_PLUGINS.filter(p => installedIds.includes(p.id)).reduce((s, p) => s + p.tasks, 0)}
            </p>
            <p className="text-white/30 text-[10px]">Total tasks available</p>
          </div>
          <div className="text-center ml-auto">
            <p className="text-indigo-400 font-bold text-sm">Plugin API</p>
            <p className="text-white/20 text-[10px]">Enterprise only</p>
          </div>
        </div>
      </div>
    </div>
  );
}
