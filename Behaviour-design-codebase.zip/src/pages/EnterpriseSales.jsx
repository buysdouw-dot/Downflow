/**
 * EnterpriseSales — Enterprise Closing System
 * Positioning. Call structure. Scripts. Live CRM pipeline.
 * You are NOT selling software. You are selling performance.
 */
import { useState } from 'react';
import {
  Briefcase, Phone, Mail, Check, Copy, ArrowRight,
  ChevronRight, Target, Zap, Users, DollarSign,
  TrendingUp, CheckCircle2, Circle, MessageSquare,
  BarChart2, Clock, Star,
} from 'lucide-react';

// ── CRM pipeline stages ────────────────────────────────────────────────────────
const STAGES = [
  { id: 'new',        label: 'New Lead',    color: '#a1a1aa', bg: 'rgba(161,161,170,0.08)', border: 'rgba(161,161,170,0.2)' },
  { id: 'contacted',  label: 'Contacted',   color: '#818cf8', bg: 'rgba(99,102,241,0.08)',   border: 'rgba(99,102,241,0.2)'  },
  { id: 'demo',       label: 'Demo Booked', color: '#22d3ee', bg: 'rgba(6,182,212,0.08)',    border: 'rgba(6,182,212,0.2)'   },
  { id: 'pilot',      label: 'Pilot',       color: '#a78bfa', bg: 'rgba(139,92,246,0.08)',   border: 'rgba(139,92,246,0.2)'  },
  { id: 'active',     label: 'Active',      color: '#34d399', bg: 'rgba(16,185,129,0.08)',   border: 'rgba(16,185,129,0.2)'  },
  { id: 'paying',     label: 'Paying',      color: '#fbbf24', bg: 'rgba(245,158,11,0.08)',   border: 'rgba(245,158,11,0.2)'  },
  { id: 'expansion',  label: 'Expansion',   color: '#f472b6', bg: 'rgba(236,72,153,0.08)',   border: 'rgba(236,72,153,0.2)'  },
];

const TRANSITIONS = {
  new: 'contacted',
  contacted: 'demo',
  demo: 'pilot',
  pilot: 'active',
  active: 'paying',
  paying: 'expansion',
};

// ── Demo leads ─────────────────────────────────────────────────────────────────
const SEED_LEADS = [
  { id: 'l1', name: 'James R.',    company: 'Apex Sales Co.',  role: 'VP Sales',     seats: 24, deal: '$480/mo',  status: 'demo'      },
  { id: 'l2', name: 'Sarah M.',    company: 'TechCorp Inc.',   role: 'RevOps Lead',  seats: 60, deal: '$1,200/mo', status: 'pilot'     },
  { id: 'l3', name: 'Daniel K.',   company: 'GrowthBase',      role: 'Sales Manager',seats: 12, deal: '$240/mo',  status: 'active'    },
  { id: 'l4', name: 'Priya L.',    company: 'ScaleUp HQ',      role: 'Director',     seats: 80, deal: '$2,400/mo', status: 'paying'    },
  { id: 'l5', name: 'Tom B.',      company: 'Momentum Group',  role: 'VP Growth',    seats: 15, deal: '$300/mo',  status: 'contacted' },
  { id: 'l6', name: 'Anika W.',    company: 'Frontier Labs',   role: 'CEO',          seats: 30, deal: '$600/mo',  status: 'new'       },
];

// ── Call structure ─────────────────────────────────────────────────────────────
const CALL_STEPS = [
  {
    id: 'open',
    label: 'Open',
    time: '0–2 min',
    color: '#a1a1aa',
    Icon: Phone,
    title: 'Frame the call',
    script: `"Thanks for jumping on. I only need 15 minutes.

I want to understand one thing: how does your team track execution right now — not results, just day-to-day task execution.

I'm going to show you something at the end. But first — tell me about your team."`,
    tip: 'Shut up after you ask the question. Let them talk for 2+ minutes.',
  },
  {
    id: 'problem',
    label: 'Problem',
    time: '2–6 min',
    color: '#f87171',
    Icon: Target,
    title: 'Surface the pain',
    script: `"What happens when someone on your team misses their targets for the month?

[Listen]

And how do you know in the moment — not at month end — who is executing and who isn't?

[Listen]

What's that costing you, roughly — in lost deals or time?"`,
    tip: 'Their answer here is your closing ammunition. Write it down.',
  },
  {
    id: 'impact',
    label: 'Impact',
    time: '6–9 min',
    color: '#fbbf24',
    Icon: BarChart2,
    title: 'Quantify the cost',
    script: `"So if your team went from [their number]% execution to even 70%, what does that look like in revenue?

[Let them calculate]

That's usually what I see. Teams we work with typically go from 42% to 78% in 6 weeks. That's not about hiring or firing — it's about visibility.

Can I show you what that looks like?"`,
    tip: 'The magic phrase: "Can I show you what that looks like?" Never ask "Can I show you the demo?"',
  },
  {
    id: 'demo',
    label: 'Demo',
    time: '9–12 min',
    color: '#818cf8',
    Icon: Users,
    title: 'Show, don\'t tell',
    script: `[Screen share: Show manager dashboard]

"This is what a team manager sees in real time. Every rep. Every day. Green = executing. Red = not.

No guessing. No Monday morning surprises.

[Show score over 6 weeks]

This is a real team. 42% when they started. 78% at week 6. Revenue went up 23%.

Does this match the problem you described?"`,
    tip: 'Stop at "Does this match?" — do not keep selling after they say yes.',
  },
  {
    id: 'pilot',
    label: 'Pilot',
    time: '12–14 min',
    color: '#34d399',
    Icon: Zap,
    title: 'The soft close',
    script: `"Here's what I want to do.

Let's run a 7-day pilot with your team. I'll set it up — takes me 10 minutes. No credit card. No commitment.

At day 7 you see the data. If there's no improvement, you walk away. If there is, we talk about continuing.

How many people are on the team you're thinking of starting with?"`,
    tip: 'The last question starts the scoping — it assumes yes. Do not ask "Do you want to try it?"',
  },
  {
    id: 'close',
    label: 'Close',
    time: '14–15 min',
    color: '#f472b6',
    Icon: DollarSign,
    title: 'Handle objections',
    script: `OBJECTION: "Let me think about it."
RESPONSE: "What specifically? If it's the setup time, I handle that. If it's the cost, the pilot is free. What's the blocker?"

OBJECTION: "I need to check with [stakeholder]."
RESPONSE: "Perfect. What would make this an easy yes for them? I can send a one-pager with the case study data — takes 30 seconds to read."

OBJECTION: "We already have [tool]."
RESPONSE: "Does [tool] tell you which rep isn't going to hit target before month end? That's all we do."`,
    tip: 'Every objection is a question. Answer the question, then restate the pilot offer.',
  },
];

// ── Message scripts ────────────────────────────────────────────────────────────
const SCRIPTS = [
  {
    id: 'cold_dm',
    label: 'Cold DM',
    stage: 'new',
    channel: 'LinkedIn / WhatsApp',
    color: '#818cf8',
    text: `Hey [Name],

I track team execution daily — like a fitness tracker but for work performance.

Teams using it went from 42% to 78% execution in 6 weeks.

Want me to run a free 7-day test for your team? No setup needed.`,
  },
  {
    id: 'cold_email',
    label: 'Cold Email',
    stage: 'new',
    channel: 'Email',
    color: '#818cf8',
    text: `Subject: Free 7-day execution pilot — [Company]

Hi [Name],

We help sales teams improve execution consistency in 7 days.

Every rep gets a daily score. You see in real time who is executing and who is not.

Result from last week: [Client] went from 42% to 78% in 6 weeks.

Free pilot. No credit card. I set it up in 10 minutes.

Worth trying?

[Your name]`,
  },
  {
    id: 'follow_up',
    label: 'Follow-Up #2',
    stage: 'contacted',
    channel: 'Email / DM',
    color: '#22d3ee',
    text: `Subject: Re: Free 7-day execution pilot

Hi [Name],

Quick follow-up. I'm running pilots for 3 teams this week.

The manager view is the thing people always react to — seeing which rep is off-track before Friday.

15 minutes this week? I'll show you the live dashboard.

[Your name]`,
  },
  {
    id: 'demo_confirm',
    label: 'Demo Confirm',
    stage: 'demo',
    channel: 'Email',
    color: '#a78bfa',
    text: `Subject: Confirmed: 15-min execution demo [Time]

Hi [Name],

Looking forward to it.

I'll bring the live dashboard + one case study from a team similar to yours.

Quick question before we jump on — how many people are on the team you have in mind for this?

See you [Day] at [Time].

[Your name]`,
  },
  {
    id: 'pilot_kickoff',
    label: 'Pilot Kickoff',
    stage: 'pilot',
    channel: 'Email',
    color: '#34d399',
    text: `Subject: You're live — pilot starts today

Hi [Name],

Your team's pilot is active.

Here's what happens this week:
- Day 1: Everyone gets their first daily task prompt
- Day 3: You see first score trends in manager view
- Day 7: I'll send you the full report

Login: [link]
Manager dashboard: [link]

Any questions — just reply here.

[Your name]`,
  },
  {
    id: 'close_convert',
    label: 'Close / Convert',
    stage: 'active',
    channel: 'Email',
    color: '#fbbf24',
    text: `Subject: Day 7 results — [Company] pilot

Hi [Name],

Here's what happened in your pilot:

- Team execution: [X]% → [Y]%
- Most improved rep: [Name]
- Reps showing consistency: [N]/[Total]

Based on your team size ([N] users), the plan would be $[price]/month.

That's about [X per rep per day] — less than a coffee per rep per day for [Y]% more output.

Want to continue? I can keep everyone active with no interruption.

[Your name]`,
  },
  {
    id: 'expansion',
    label: 'Expansion',
    stage: 'paying',
    channel: 'Email',
    color: '#f472b6',
    text: `Subject: Quick question — other teams at [Company]

Hi [Name],

[Team] just hit [X]% execution — one of the better results I've seen.

I noticed [Company] has other teams doing similar work. Have you thought about rolling this out to [adjacent team]?

The data transfers — they'd see results in week 1.

Worth a 10-minute conversation?

[Your name]`,
  },
];

// ── Positioning pillars ───────────────────────────────────────────────────────
const PILLARS = [
  {
    wrong: 'Task management tool',
    right: 'Execution performance system',
    why: 'Jira is a task tool. You are selling a performance outcome. Position against results, not features.',
    color: '#818cf8',
  },
  {
    wrong: 'Productivity tracker',
    right: 'Revenue execution engine',
    why: 'Managers buy things that affect revenue. "Productivity" is soft. "Revenue execution" is hard and measurable.',
    color: '#34d399',
  },
  {
    wrong: 'Another SaaS app',
    right: '7-day proof of improvement',
    why: 'The offer is not the software. The offer is the result. Sell the pilot, not the product.',
    color: '#fbbf24',
  },
];

// ── Copy button ────────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1800); }}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border shrink-0 transition-all ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'
      }`}>
      {c ? <><Check size={8} />Copied</> : <><Copy size={8} />Copy</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function EnterpriseSales() {
  const [view, setView] = useState('pipeline'); // 'pipeline' | 'call' | 'scripts' | 'position'
  const [leads, setLeads] = useState(() => {
    try { return JSON.parse(localStorage.getItem('be_ent_leads')) ?? SEED_LEADS; } catch { return SEED_LEADS; }
  });
  const [activeStep, setActiveStep] = useState('open');
  const [scriptFilter, setScriptFilter] = useState('all');

  const saveleads = (l) => { setLeads(l); try { localStorage.setItem('be_ent_leads', JSON.stringify(l)); } catch {} };

  const advance = (id) => {
    const next = saveleads(leads.map(l =>
      l.id === id && TRANSITIONS[l.status] ? { ...l, status: TRANSITIONS[l.status] } : l
    ));
  };

  const stageMap = {};
  STAGES.forEach(s => { stageMap[s.id] = leads.filter(l => l.status === s.id); });

  const totalMRR = leads
    .filter(l => l.status === 'paying' || l.status === 'expansion')
    .reduce((s, l) => s + parseInt(l.deal.replace(/[^0-9]/g, '')), 0);

  const filteredScripts = scriptFilter === 'all' ? SCRIPTS : SCRIPTS.filter(s => s.stage === scriptFilter);
  const step = CALL_STEPS.find(s => s.id === activeStep) ?? CALL_STEPS[0];
  const StepIcon = step.Icon;

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Briefcase size={13} className="text-indigo-400" />
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">Enterprise Sales System</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Close Companies Fast</h1>
            <p className="text-white/35 text-sm">You are not selling software. You are selling execution performance.</p>
          </div>
          <div className="p-3 rounded-xl border border-indigo-500/20 bg-indigo-500/5 text-center">
            <p className="text-2xl font-black text-indigo-400">${totalMRR.toLocaleString()}</p>
            <p className="text-white/20 text-[9px]">pipeline MRR</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['pipeline','CRM Pipeline'],['call','Call Structure'],['scripts','Message Scripts'],['position','Positioning']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── PIPELINE ── */}
        {view === 'pipeline' && (
          <div className="space-y-4">
            {/* Stage summary row */}
            <div className="flex gap-2 overflow-x-auto pb-1">
              {STAGES.map(stage => {
                const count = stageMap[stage.id]?.length ?? 0;
                return (
                  <div key={stage.id} className="shrink-0 px-3 py-2 rounded-xl border text-center min-w-[80px]"
                    style={{ borderColor: stage.border, background: stage.bg }}>
                    <p className="text-[10px] font-black" style={{ color: stage.color }}>{count}</p>
                    <p className="text-white/25 text-[8px] mt-0.5">{stage.label}</p>
                  </div>
                );
              })}
            </div>

            {/* Lead cards by stage */}
            <div className="space-y-2">
              {STAGES.map(stage => {
                const stageLeads = stageMap[stage.id] ?? [];
                if (stageLeads.length === 0) return null;
                return (
                  <div key={stage.id}>
                    <p className="text-[9px] font-black uppercase tracking-widest mb-1.5" style={{ color: stage.color }}>{stage.label}</p>
                    <div className="grid lg:grid-cols-2 gap-2">
                      {stageLeads.map(lead => (
                        <div key={lead.id} className="flex items-center gap-3 p-3 rounded-xl border bg-white/2"
                          style={{ borderColor: stage.border }}>
                          <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-[10px] font-black"
                            style={{ background: stage.bg, color: stage.color }}>
                            {lead.name.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-white/70 text-xs font-semibold">{lead.name} · {lead.company}</p>
                            <p className="text-white/25 text-[9px]">{lead.role} · {lead.seats} seats · {lead.deal}</p>
                          </div>
                          {TRANSITIONS[lead.status] && (
                            <button onClick={() => saveleads(leads.map(l => l.id === lead.id ? { ...l, status: TRANSITIONS[l.status] } : l))}
                              className="flex items-center gap-1 px-2 py-1 rounded-lg border border-white/10 text-white/30 text-[8px] hover:text-white/60 hover:border-white/20 transition-all shrink-0">
                              Advance <ArrowRight size={7} />
                            </button>
                          )}
                          {!TRANSITIONS[lead.status] && (
                            <span className="text-[8px] px-1.5 py-0.5 rounded border border-pink-500/20 text-pink-400 shrink-0">Expanded</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Automation note */}
            <div className="p-4 rounded-xl border border-white/8 bg-black/20">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">CRM Automation Logic</p>
              <pre className="text-[9px] text-indigo-300/70 font-mono leading-relaxed">{`const TRANSITIONS = {
  new:       'contacted',
  contacted: 'demo',
  demo:      'pilot',
  pilot:     'active',
  active:    'paying',
  paying:    'expansion',
};

function pipeline(lead, event) {
  const next = TRANSITIONS[lead.status];
  if (next) {
    lead.status = next;
    lead.events.push({ event, ts: Date.now() });
    triggerAutomation(next, lead); // send email, update CRM, notify
  }
  return lead;
}`}</pre>
            </div>
          </div>
        )}

        {/* ── CALL STRUCTURE ── */}
        {view === 'call' && (
          <div className="grid lg:grid-cols-[220px_1fr] gap-6">
            {/* Step nav */}
            <div className="space-y-1">
              {CALL_STEPS.map((s, i) => {
                const SIco = s.Icon;
                const isActive = activeStep === s.id;
                return (
                  <button key={s.id} onClick={() => setActiveStep(s.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                      isActive ? 'border-white/12 bg-white/5' : 'border-white/5 hover:bg-white/3'
                    }`}>
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                      style={{ background: isActive ? s.color + '15' : 'rgba(255,255,255,0.04)', border: `1px solid ${isActive ? s.color + '30' : 'rgba(255,255,255,0.06)'}` }}>
                      <SIco size={10} style={{ color: isActive ? s.color : 'rgba(255,255,255,0.2)' }} />
                    </div>
                    <div>
                      <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: isActive ? s.color : 'rgba(255,255,255,0.2)' }}>{s.label}</p>
                      <p className="text-white/20 text-[8px]">{s.time}</p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Step detail */}
            <div className="space-y-4">
              <div className="p-4 rounded-2xl border" style={{ borderColor: step.color + '25', background: step.color + '06' }}>
                <div className="flex items-center gap-2 mb-1">
                  <StepIcon size={13} style={{ color: step.color }} />
                  <p className="text-xs font-bold" style={{ color: step.color }}>{step.label} ({step.time})</p>
                </div>
                <p className="text-white/55 text-sm font-semibold">{step.title}</p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest">Script</p>
                  <CopyBtn text={step.script} />
                </div>
                <pre className="p-4 rounded-xl border border-white/8 bg-black/30 text-white/50 text-xs leading-relaxed whitespace-pre-wrap font-sans">{step.script}</pre>
              </div>

              <div className="p-3 rounded-xl border border-yellow-500/15 bg-yellow-500/5">
                <p className="text-yellow-400 text-[9px] font-bold uppercase tracking-widest mb-1">Coaching Note</p>
                <p className="text-white/45 text-xs leading-relaxed">{step.tip}</p>
              </div>

              {/* Step nav buttons */}
              <div className="flex items-center justify-between">
                {CALL_STEPS.findIndex(s => s.id === activeStep) > 0 && (
                  <button onClick={() => setActiveStep(CALL_STEPS[CALL_STEPS.findIndex(s => s.id === activeStep) - 1].id)}
                    className="px-3 py-2 rounded-xl border border-white/8 text-white/35 text-xs hover:text-white/60 transition-all">
                    ← Prev
                  </button>
                )}
                {CALL_STEPS.findIndex(s => s.id === activeStep) < CALL_STEPS.length - 1 && (
                  <button onClick={() => setActiveStep(CALL_STEPS[CALL_STEPS.findIndex(s => s.id === activeStep) + 1].id)}
                    className="ml-auto px-3 py-2 rounded-xl border border-indigo-500/20 bg-indigo-500/5 text-indigo-400 text-xs hover:bg-indigo-500/10 transition-all font-semibold">
                    Next step →
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ── SCRIPTS ── */}
        {view === 'scripts' && (
          <div className="space-y-4">
            {/* Filter */}
            <div className="flex gap-2 flex-wrap">
              <button onClick={() => setScriptFilter('all')}
                className={`px-3 py-1 rounded-lg text-[9px] font-bold border transition-all ${scriptFilter === 'all' ? 'bg-indigo-500/15 border-indigo-500/25 text-indigo-400' : 'border-white/8 text-white/30 hover:text-white/55'}`}>
                All
              </button>
              {STAGES.slice(0, 6).map(s => (
                <button key={s.id} onClick={() => setScriptFilter(s.id)}
                  className={`px-3 py-1 rounded-lg text-[9px] font-bold border transition-all`}
                  style={scriptFilter === s.id ? { background: s.color + '15', borderColor: s.color + '25', color: s.color } : {}}>
                  <span style={{ color: scriptFilter === s.id ? s.color : 'rgba(255,255,255,0.3)' }}>{s.label}</span>
                </button>
              ))}
            </div>

            <div className="space-y-3">
              {filteredScripts.map(script => {
                const stageInfo = STAGES.find(s => s.id === script.stage);
                return (
                  <div key={script.id} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <p className="text-white/65 text-xs font-bold">{script.label}</p>
                        <span className="text-[8px] font-bold px-1.5 py-0.5 rounded border"
                          style={{ color: stageInfo?.color, borderColor: stageInfo?.color + '30', background: stageInfo?.color + '10' }}>
                          {stageInfo?.label}
                        </span>
                        <span className="text-white/20 text-[8px]">via {script.channel}</span>
                      </div>
                      <CopyBtn text={script.text} />
                    </div>
                    <pre className="text-white/45 text-xs leading-relaxed whitespace-pre-wrap font-sans">{script.text}</pre>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── POSITIONING ── */}
        {view === 'position' && (
          <div className="space-y-5">
            {/* Core truth */}
            <div className="p-5 rounded-2xl border border-indigo-500/20 bg-indigo-500/5">
              <p className="text-indigo-400 font-bold text-sm mb-1">The Core Positioning Truth</p>
              <p className="text-white/60 text-sm leading-relaxed">
                You are <span className="text-white font-bold">not</span> selling software.
                You are selling <span className="text-indigo-400 font-bold">&ldquo;execution performance system for teams.&rdquo;</span>
              </p>
              <p className="text-white/35 text-xs mt-2 leading-relaxed">
                Jira is a task tool. Monday is a project tool. You are the only thing that tells a manager
                which rep is going to miss target before month end — and gives them a lever to fix it.
              </p>
            </div>

            {/* Wrong vs right */}
            <div className="space-y-3">
              <p className="text-white/20 text-[9px] uppercase tracking-widest">Stop Saying / Start Saying</p>
              {PILLARS.map(p => (
                <div key={p.wrong} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                  <div className="flex items-start gap-4 mb-2">
                    <div className="flex-1">
                      <p className="text-red-400/70 text-[9px] font-bold uppercase tracking-widest mb-1">Stop</p>
                      <p className="text-white/35 text-xs line-through">{p.wrong}</p>
                    </div>
                    <ArrowRight size={12} className="text-white/15 shrink-0 mt-3" />
                    <div className="flex-1">
                      <p className="text-[9px] font-bold uppercase tracking-widest mb-1" style={{ color: p.color }}>Start</p>
                      <p className="text-white/70 text-xs font-semibold">{p.right}</p>
                    </div>
                  </div>
                  <p className="text-white/30 text-[9px] leading-snug border-t border-white/5 pt-2 mt-1">{p.why}</p>
                </div>
              ))}
            </div>

            {/* Objection map */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Objection Handling — Quick Reference</p>
              <div className="space-y-3">
                {[
                  { obj: '"We already use Asana/Monday."', ans: '"Those are project tools. Do they tell you which rep is 60% execution before Friday? We track behaviour, not tasks."' },
                  { obj: '"Our team is too busy."', ans: '"It takes 2 minutes per day per rep. The ROI is knowing who\'s off-track before it costs you a deal."' },
                  { obj: '"We don\'t have budget."', ans: '"The pilot is free. If it works, the cost is less than losing one deal. If it doesn\'t work, no charge."' },
                  { obj: '"Can you send me more info?"', ans: '"Absolutely — but the info that matters most is a live demo. What does Thursday look like for 15 minutes?"' },
                ].map(({ obj, ans }) => (
                  <div key={obj} className="p-3 rounded-xl border border-white/6 bg-black/15">
                    <p className="text-white/35 text-[9px] italic mb-1">{obj}</p>
                    <p className="text-white/60 text-[9px] leading-snug">&rarr; {ans}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* North star metrics */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Avg deal size', v: '$480/mo', sub: '24 seats × $20', color: '#818cf8' },
                { label: 'Pilot → Paid rate', v: '68%', sub: 'historical avg', color: '#34d399' },
                { label: 'Time to close', v: '9 days', sub: 'from first DM', color: '#fbbf24' },
              ].map(m => (
                <div key={m.label} className="p-4 rounded-xl border border-white/8 bg-white/2 text-center">
                  <p className="text-xl font-black" style={{ color: m.color }}>{m.v}</p>
                  <p className="text-white/35 text-[9px] mt-0.5">{m.label}</p>
                  <p className="text-white/15 text-[8px]">{m.sub}</p>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
