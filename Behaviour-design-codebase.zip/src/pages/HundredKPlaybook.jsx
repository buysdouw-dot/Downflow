/**
 * HundredKPlaybook — $0 → $100K/month Execution System
 * Daily playbook with exact actions, weekly milestones, live progress tracking.
 */
import { useState } from 'react';
import {
  CheckCircle2, Circle, DollarSign, TrendingUp, Target,
  Calendar, Clock, Zap, Users, Mail, MessageSquare,
  BarChart2, Star, ArrowRight, ChevronDown, ChevronUp,
  Rocket, Brain, Shield, Activity, Play,
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

// ── Revenue milestones ────────────────────────────────────────────────────────
const MILESTONES = [
  { mrr: '$1K',   label: 'First Revenue',   days: 14,  color: '#818cf8', target: 1000 },
  { mrr: '$5K',   label: 'Product-Market',  days: 45,  color: '#22d3ee', target: 5000 },
  { mrr: '$10K',  label: 'Repeatable',      days: 75,  color: '#a78bfa', target: 10000 },
  { mrr: '$25K',  label: 'Scaling',         days: 105, color: '#f472b6', target: 25000 },
  { mrr: '$50K',  label: 'Half-way',        days: 135, color: '#fbbf24', target: 50000 },
  { mrr: '$100K', label: 'Target',          days: 180, color: '#34d399', target: 100000 },
];

// ── Projection data ───────────────────────────────────────────────────────────
const PROJECTION = [
  { month: 'M0',  mrr: 0 },
  { month: 'M1',  mrr: 1000 },
  { month: 'M2',  mrr: 4000 },
  { month: 'M3',  mrr: 10000 },
  { month: 'M4',  mrr: 21000 },
  { month: 'M5',  mrr: 42000 },
  { month: 'M6',  mrr: 100000 },
];

// ── Phases ────────────────────────────────────────────────────────────────────
const PHASES = [
  {
    id: 'phase1',
    label: 'Phase 1',
    title: '$0 → $1K MRR',
    timeline: 'Days 1–14',
    color: '#818cf8',
    goal: 'Validate: 3 paying customers at $20/mo each.',
    weeks: [
      {
        week: 'Days 1–3',
        focus: 'Foundation',
        daily: [
          { time: '7:00am', action: 'Post 1 execution tip on LinkedIn (copy from templates below)', category: 'Growth' },
          { time: '9:00am', action: 'DM 10 people in your niche: "Are you tracking team performance manually?"', category: 'Sales' },
          { time: '11:00am', action: 'Send product to 3 warm contacts — ask for a 20-min feedback call', category: 'Sales' },
          { time: '2:00pm', action: 'Refine onboarding based on any feedback. Fix any UX friction.', category: 'Product' },
          { time: '5:00pm', action: 'Reply to every comment, DM, and email. Response time = trust.', category: 'Growth' },
        ],
      },
      {
        week: 'Days 4–7',
        focus: 'First Sales',
        daily: [
          { time: '7:00am', action: 'Post 1 case study: "How [Name] improved their team execution by X%"', category: 'Growth' },
          { time: '9:00am', action: 'Cold email 20 sales managers. Subject: "Is your team\'s execution score above 70?"', category: 'Sales' },
          { time: '11:00am', action: 'Follow up all previous DMs with: "Any questions about the demo?"', category: 'Sales' },
          { time: '2:00pm', action: 'Add 1 new feature from beta user feedback', category: 'Product' },
          { time: '4:00pm', action: 'Create shareable "score card" template for LinkedIn', category: 'Growth' },
        ],
      },
      {
        week: 'Days 8–14',
        focus: 'Close $1K MRR',
        daily: [
          { time: '7:00am', action: 'Post team leaderboard screenshot (blurred user names) — social proof', category: 'Growth' },
          { time: '9:00am', action: 'Book 3 demo calls per day using Calendly link', category: 'Sales' },
          { time: '11:00am', action: 'Run demo → offer 14-day trial → close same call with $20/mo', category: 'Sales' },
          { time: '2:00pm', action: 'Onboard every new user personally via Loom video', category: 'Product' },
          { time: '5:00pm', action: 'Track: # demos booked, # trials started, # converted', category: 'Metrics' },
        ],
      },
    ],
  },
  {
    id: 'phase2',
    label: 'Phase 2',
    title: '$1K → $10K MRR',
    timeline: 'Days 15–75',
    color: '#22d3ee',
    goal: 'Scale: 50 paying users or 10 team plans.',
    weeks: [
      {
        week: 'Week 3–4',
        focus: 'Content Engine',
        daily: [
          { time: '7:00am', action: 'LinkedIn post: share a user win (with permission). Tag them.', category: 'Growth' },
          { time: '8:00am', action: 'Send AI-generated weekly reports to all users. Makes them sticky.', category: 'Product' },
          { time: '10:00am', action: 'Reach out to 15 potential users in your ICP (ideal customer profile)', category: 'Sales' },
          { time: '1:00pm', action: 'Improve AI coaching quality — better messages = better retention', category: 'Product' },
          { time: '4:00pm', action: 'Track MRR daily. Update your revenue dashboard.', category: 'Metrics' },
        ],
      },
      {
        week: 'Week 5–8',
        focus: 'Team Plans',
        daily: [
          { time: '7:00am', action: 'Email all individual users (5+ active): propose team upgrade at $99/mo', category: 'Revenue' },
          { time: '9:00am', action: 'Build referral prompt: "Share your score → earn 1 month free"', category: 'Growth' },
          { time: '11:00am', action: '3 demo calls — pitch team plan specifically to managers', category: 'Sales' },
          { time: '2:00pm', action: 'Create case study: "Team X improved score by 22% in 30 days"', category: 'Growth' },
          { time: '5:00pm', action: 'Weekly metrics review: MRR, churn, activation rate, NPS', category: 'Metrics' },
        ],
      },
    ],
  },
  {
    id: 'phase3',
    label: 'Phase 3',
    title: '$10K → $50K MRR',
    timeline: 'Days 76–135',
    color: '#f472b6',
    goal: 'Systematize: automated growth + sales funnels.',
    weeks: [
      {
        week: 'Week 11–14',
        focus: 'Automation',
        daily: [
          { time: '7:00am', action: 'Launch paid LinkedIn ads: $50/day, target "team leads" and "sales managers"', category: 'Growth' },
          { time: '9:00am', action: 'Activate email drip sequence: trial → paid → expansion (Mailchimp or Resend)', category: 'Sales' },
          { time: '11:00am', action: 'Enterprise outreach: 5 companies with 20+ employees per day', category: 'Sales' },
          { time: '2:00pm', action: 'Set up referral program: in-app + email at score milestones', category: 'Growth' },
          { time: '4:00pm', action: 'Run weekly product experiment (1 A/B test at all times)', category: 'Product' },
        ],
      },
      {
        week: 'Week 15–18',
        focus: 'Enterprise Tier',
        daily: [
          { time: '8:00am', action: 'Cold email 10 enterprise contacts (500+ employee companies)', category: 'Sales' },
          { time: '10:00am', action: 'Run enterprise demo with custom ROI calculation', category: 'Sales' },
          { time: '1:00pm', action: 'Build enterprise-specific features: SSO, reporting, SLA docs', category: 'Product' },
          { time: '3:00pm', action: 'Publish 1 thought leadership article (LinkedIn / Medium)', category: 'Growth' },
          { time: '5:00pm', action: 'Board metric update: MRR, NRR, CAC, LTV — model weekly', category: 'Metrics' },
        ],
      },
    ],
  },
  {
    id: 'phase4',
    label: 'Phase 4',
    title: '$50K → $100K MRR',
    timeline: 'Days 136–180',
    color: '#34d399',
    goal: 'Scale: enterprise + partnerships + team hiring.',
    weeks: [
      {
        week: 'Week 20–22',
        focus: 'Hiring',
        daily: [
          { time: '8:00am', action: 'Hire first SDR (sales dev rep). Give them a 30-day ramp plan.', category: 'Ops' },
          { time: '10:00am', action: 'Hire first customer success manager. Assign all enterprise accounts.', category: 'Ops' },
          { time: '1:00pm', action: 'Launch partner / reseller program for consultants and agencies', category: 'Growth' },
          { time: '3:00pm', action: 'Build integration marketplace: Slack, Salesforce, HubSpot', category: 'Product' },
          { time: '5:00pm', action: 'Prepare Series A materials: deck, data room, exec summary', category: 'Finance' },
        ],
      },
      {
        week: 'Week 23–26',
        focus: 'Crossing $100K',
        daily: [
          { time: '8:00am', action: 'SDR daily: 50 outreach touchpoints. Review pipeline every morning.', category: 'Sales' },
          { time: '10:00am', action: 'Close 2 enterprise deals per week ($499/mo each)', category: 'Sales' },
          { time: '1:00pm', action: 'Growth team: 2 content pieces per day across LinkedIn + YouTube', category: 'Growth' },
          { time: '3:00pm', action: 'Launch referral "Super User" program: top performers become advocates', category: 'Growth' },
          { time: '5:00pm', action: 'CEO: investor updates, Series A conversations, strategic partnerships', category: 'Finance' },
        ],
      },
    ],
  },
];

// ── Category colors ───────────────────────────────────────────────────────────
const CAT_COLORS = {
  Growth: '#f472b6',
  Sales: '#22d3ee',
  Product: '#a78bfa',
  Metrics: '#fbbf24',
  Revenue: '#34d399',
  Ops: '#818cf8',
  Finance: '#fb923c',
};

function getCatColor(cat) { return CAT_COLORS[cat] || '#6366f1'; }

export default function HundredKPlaybook() {
  const [activePhase, setActivePhase] = useState('phase1');
  const [expandedWeek, setExpandedWeek] = useState(null);
  const [checked, setChecked] = useState({});
  const [view, setView] = useState('playbook');

  const toggleCheck = (key) => setChecked(c => ({ ...c, [key]: !c[key] }));
  const toggleWeek = (key) => setExpandedWeek(e => e === key ? null : key);

  const phase = PHASES.find(p => p.id === activePhase);
  const totalTasks = phase?.weeks.reduce((acc, w) => acc + w.daily.length, 0) || 0;
  const doneTasks = Object.entries(checked).filter(([k, v]) => v && k.startsWith(activePhase)).length;
  const pct = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <DollarSign size={13} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">$0 → $100K Playbook</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Daily Execution System</h1>
            <p className="text-white/35 text-sm">
              Exact actions, exact times, exact order.{' '}
              <span className="text-emerald-400 font-semibold">180 days to $100K MRR.</span>
            </p>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-lg font-black text-emerald-400">$100K</p>
              <p className="text-white/20 text-[8px]">MRR target</p>
            </div>
            <div className="text-center p-3 rounded-xl border border-indigo-500/20 bg-indigo-500/5">
              <p className="text-lg font-black text-indigo-400">180</p>
              <p className="text-white/20 text-[8px]">days</p>
            </div>
            <div className="text-center p-3 rounded-xl border border-white/10 bg-white/3">
              <p className="text-lg font-black text-white/70">{pct}%</p>
              <p className="text-white/20 text-[8px]">done</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['playbook', 'Daily Playbook'], ['milestones', 'Milestones'], ['projection', 'Revenue Projection'], ['rules', 'Execution Rules']].map(([v, l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-emerald-500 text-black font-bold' : 'text-white/35 hover:text-white/60'}`}>{l}</button>
          ))}
        </div>

        {/* ── PLAYBOOK ── */}
        {view === 'playbook' && (
          <div className="space-y-4">
            {/* Phase selector */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
              {PHASES.map(p => (
                <button key={p.id} onClick={() => setActivePhase(p.id)}
                  className={`p-3 rounded-xl border text-left transition-all ${activePhase === p.id ? 'border-opacity-50' : 'border-white/6 bg-white/2 hover:bg-white/4'}`}
                  style={activePhase === p.id ? { borderColor: p.color + '40', background: p.color + '08' } : {}}>
                  <p className="text-[8px] font-bold uppercase tracking-widest mb-0.5" style={{ color: p.color }}>{p.label}</p>
                  <p className="text-white/70 text-[10px] font-bold">{p.title}</p>
                  <p className="text-white/20 text-[8px]">{p.timeline}</p>
                </button>
              ))}
            </div>

            {/* Phase goal */}
            <div className="p-4 rounded-2xl border" style={{ borderColor: phase.color + '25', background: phase.color + '06' }}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target size={12} style={{ color: phase.color }} />
                  <span className="text-xs font-bold" style={{ color: phase.color }}>Phase Goal</span>
                </div>
                <span className="text-white/20 text-[9px]">{doneTasks}/{totalTasks} actions done</span>
              </div>
              <p className="text-white/60 text-xs">{phase.goal}</p>
              <div className="mt-3 h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: phase.color }} />
              </div>
            </div>

            {/* Week blocks */}
            {phase.weeks.map((w, wi) => {
              const wKey = `${activePhase}-w${wi}`;
              const isOpen = expandedWeek === wKey || expandedWeek === null;
              return (
                <div key={wKey} className="rounded-2xl border border-white/8 bg-white/2 overflow-hidden">
                  <button className="w-full flex items-center justify-between p-4 text-left"
                    onClick={() => toggleWeek(wKey)}>
                    <div>
                      <p className="text-white/60 text-xs font-bold">{w.week} — {w.focus}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-white/20 text-[9px]">{w.daily.length} daily actions</span>
                      {isOpen ? <ChevronUp size={12} className="text-white/30" /> : <ChevronDown size={12} className="text-white/30" />}
                    </div>
                  </button>
                  {isOpen && (
                    <div className="border-t border-white/5">
                      {w.daily.map((task, ti) => {
                        const key = `${activePhase}-w${wi}-t${ti}`;
                        const done = !!checked[key];
                        return (
                          <div key={key} className={`flex items-start gap-3 px-4 py-3 border-b border-white/4 last:border-0 cursor-pointer hover:bg-white/2 transition-all ${done ? 'opacity-50' : ''}`}
                            onClick={() => toggleCheck(key)}>
                            <div className="shrink-0 mt-0.5">
                              {done
                                ? <CheckCircle2 size={14} style={{ color: phase.color }} />
                                : <Circle size={14} className="text-white/20" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className={`text-xs leading-snug ${done ? 'line-through text-white/25' : 'text-white/70'}`}>{task.action}</p>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-white/20 text-[8px] font-mono">{task.time}</span>
                              <span className="text-[7px] px-1.5 py-0.5 rounded font-bold"
                                style={{ color: getCatColor(task.category), background: getCatColor(task.category) + '15', border: `1px solid ${getCatColor(task.category)}25` }}>
                                {task.category}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ── MILESTONES ── */}
        {view === 'milestones' && (
          <div className="space-y-3">
            <p className="text-white/25 text-[9px] uppercase tracking-widest">Revenue Milestones — 180-Day Plan</p>
            {MILESTONES.map((m, i) => (
              <div key={m.mrr} className="flex items-center gap-4 p-4 rounded-2xl border border-white/8 bg-white/2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 text-sm font-black"
                  style={{ background: m.color + '10', border: `1px solid ${m.color}20`, color: m.color }}>
                  {i + 1}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-white/70 text-xs font-bold">{m.mrr} MRR — {m.label}</p>
                    <span className="text-white/25 text-[8px]">Day {m.days}</span>
                  </div>
                  <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(m.target / 100000) * 100}%`, background: m.color }} />
                  </div>
                </div>
              </div>
            ))}
            <div className="p-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-xs mb-2">Key insight: It's not linear</p>
              <p className="text-white/40 text-[10px] leading-relaxed">
                $0 → $10K takes 75 days. $10K → $100K takes 105 days.
                The hard part is the first $10K. Once you have 50+ users,
                the system compounds — referrals, upgrades, and team plans do most of the work.
              </p>
            </div>
          </div>
        )}

        {/* ── PROJECTION ── */}
        {view === 'projection' && (
          <div className="space-y-5">
            <div className="p-5 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">MRR Projection — 6 Months</p>
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={PROJECTION} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
                    <defs>
                      <linearGradient id="projGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#34d399" stopOpacity={0.25} />
                        <stop offset="100%" stopColor="#34d399" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="month" tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}K`} />
                    <Tooltip contentStyle={{ background: '#0c1018', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 10 }} formatter={v => [`$${v.toLocaleString()}`, 'MRR']} />
                    <Area type="monotone" dataKey="mrr" stroke="#34d399" strokeWidth={2} fill="url(#projGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
              {PROJECTION.slice(1).map(({ month, mrr }) => (
                <div key={month} className="p-3 rounded-xl border border-white/8 bg-white/2 text-center">
                  <p className="text-emerald-400 font-black text-lg">${(mrr / 1000).toFixed(0)}K</p>
                  <p className="text-white/30 text-[9px]">{month} MRR</p>
                </div>
              ))}
            </div>
            <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/40 text-[9px] uppercase tracking-widest mb-3">Assumptions</p>
              <div className="space-y-1.5">
                {[
                  '23% month-over-month growth (conservative based on current rate)',
                  'Mix: 40% individual ($20), 45% team ($99), 15% enterprise ($499)',
                  '88% monthly retention (current rate)',
                  'No paid acquisition — organic content + referral only',
                  'Team plan launch Month 2 accelerates growth',
                ].map((a, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <CheckCircle2 size={9} className="text-emerald-400/60 shrink-0 mt-0.5" />
                    <p className="text-white/35 text-[9px]">{a}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── EXECUTION RULES ── */}
        {view === 'rules' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-sm mb-3">10 Rules That Separate $10K Founders from $100K Founders</p>
              <div className="space-y-3">
                {[
                  { n: '1', rule: 'Ship daily, not perfectly', detail: 'An imperfect feature live beats a perfect feature in staging. Ship at 80%, improve with users.' },
                  { n: '2', rule: 'Talk to 3 users every week, forever', detail: 'After 100 users, 300 users, 3,000 users. The product is never done. The user is always changing.' },
                  { n: '3', rule: 'Revenue > Metrics', detail: 'MRR is real. Users, signups, DAU — vanity until they convert. Optimize for money in bank.' },
                  { n: '4', rule: 'One channel until it\'s done', detail: 'LinkedIn OR cold email OR SEO. Not all three. Master one to $50K MRR, then diversify.' },
                  { n: '5', rule: 'Retention is product-market fit', detail: 'Growing at 25% churn = filling a leaky bucket. Fix churn before scaling spend.' },
                  { n: '6', rule: 'Automate before you hire', detail: 'Every system that can be automated should be, before you pay a human to do it manually.' },
                  { n: '7', rule: 'Show the number, not the feature', detail: '"Your team improved execution by 22%" converts better than "We have AI coaching." Lead with outcomes.' },
                  { n: '8', rule: 'Follow up 5x more than feels comfortable', detail: 'Most deals close on the 4th–7th follow-up. Most founders give up after 1.' },
                  { n: '9', rule: 'Weekly metrics review, non-negotiable', detail: 'MRR, churn, activation rate, NPS. Every Friday. Build your own dashboard. Know your numbers cold.' },
                  { n: '10', rule: 'The system is the product', detail: 'At $100K MRR, you should not be essential. If it breaks without you, you haven\'t built a company.' },
                ].map(({ n, rule, detail }) => (
                  <div key={n} className="flex items-start gap-3 p-3 rounded-xl border border-white/6 bg-white/2">
                    <span className="text-emerald-400 font-black text-sm w-5 shrink-0">{n}.</span>
                    <div>
                      <p className="text-white/70 text-xs font-bold mb-0.5">{rule}</p>
                      <p className="text-white/30 text-[9px] leading-snug">{detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
