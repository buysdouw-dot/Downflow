/**
 * TenKPlan — First $10K/Month Execution Plan
 * Phase 1: $1K · Phase 2: $5K · Phase 3: $10K
 * Acquisition loop tracker. Outreach copy tool. Revenue live counter.
 */
import { useState } from 'react';
import {
  DollarSign, Target, Zap, Users, ArrowRight, CheckCircle2,
  Copy, Check, TrendingUp, MessageSquare, Play, ChevronRight,
  Flame, Clock, Star, RefreshCw,
} from 'lucide-react';

// ── Phases ────────────────────────────────────────────────────────────────────
const PHASES = [
  {
    id: 'phase1',
    label: 'Phase 1',
    goal: '$1,000 MRR',
    target: 1000,
    color: 'text-white/70',
    bg: 'bg-white/4',
    border: 'border-white/10',
    accent: '#a1a1aa',
    badge: 'First Revenue',
    description: '10 individual users paying $10–$50/mo. Manual everything. Validate the pain.',
    timeline: '2–4 weeks',
    channels: ['LinkedIn DMs (20/day)', 'WhatsApp outreach', 'Personal network', 'Reddit communities'],
    tasks: [
      { text: 'Set up Stripe + basic landing page', done: false },
      { text: 'DM 20 sales reps or team leads on LinkedIn', done: false },
      { text: 'Onboard first 3 users manually (Zoom call)', done: false },
      { text: 'Get 1 testimonial from first 10 users', done: false },
      { text: 'Post results on LinkedIn (social proof)', done: false },
    ],
    metrics: { users: '10', arpu: '$8–$50', churn: '<20%', conversion: '5–10%' },
    truth: 'You are not building a company yet. You are validating that someone will pay.',
  },
  {
    id: 'phase2',
    label: 'Phase 2',
    goal: '$5,000 MRR',
    target: 5000,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    accent: '#818cf8',
    badge: 'Real Traction',
    description: '5–10 small teams at $100–$500/mo. Introduce the pilot system. Start delegating.',
    timeline: '4–8 weeks',
    channels: ['Cold email (team leads)', 'LinkedIn content (case studies)', 'Pilot offer ($0 for 7 days)', 'Referrals from Phase 1'],
    tasks: [
      { text: 'Launch 7-day pilot landing page', done: false },
      { text: 'Build email sequence (5 emails over 7 days)', done: false },
      { text: 'Close 5 paying teams ($500 total MRR)', done: false },
      { text: 'Set up basic onboarding checklist (async)', done: false },
      { text: 'Collect 3 case study results (% improvement)', done: false },
      { text: 'Start LinkedIn content (1 post/day)', done: false },
    ],
    metrics: { users: '25–50', arpu: '$100–$200', churn: '<10%', conversion: '20–30%' },
    truth: 'You need proof, not features. One 72% \u2192 78% execution stat is worth 100 landing pages.',
  },
  {
    id: 'phase3',
    label: 'Phase 3',
    goal: '$10,000 MRR',
    target: 10000,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/8',
    border: 'border-emerald-500/20',
    accent: '#34d399',
    badge: 'Fundable',
    description: '20–50 paying teams. Systemized outreach. Product sells itself through results.',
    timeline: '8–16 weeks',
    channels: ['Outbound sales (dedicated role)', 'Content-led growth (YouTube, LinkedIn)', 'Partner channel (sales coaches)', 'Referral program (1 free month)'],
    tasks: [
      { text: 'Hire or assign 1 sales person (commission-only)', done: false },
      { text: 'Build referral program ($50/referral or 1 free month)', done: false },
      { text: 'Post 3 case studies with real % improvement data', done: false },
      { text: 'Launch annual plan (2 months free = -16% churn)', done: false },
      { text: 'Hit 30 paying teams = $10K/mo validation', done: false },
      { text: 'Document all processes for scale', done: false },
    ],
    metrics: { users: '100–200', arpu: '$200–$300', churn: '<5%', conversion: '30–40%' },
    truth: 'At $10K MRR you have a real business. At $50K MRR you have leverage. Focus on $10K first.',
  },
];

// ── Acquisition loop ───────────────────────────────────────────────────────────
const LOOP = [
  { id: 'lead',   label: 'Lead',        desc: 'LinkedIn / cold email / referral',         color: 'text-white/60',   border: 'border-white/15' },
  { id: 'demo',   label: 'Demo',        desc: '15-min Zoom — show the dashboard',          color: 'text-indigo-400', border: 'border-indigo-500/30' },
  { id: 'pilot',  label: '7-Day Pilot', desc: 'Free trial — they run it on their team',   color: 'text-purple-400', border: 'border-purple-500/30' },
  { id: 'result', label: 'Result',      desc: 'Show them: score improved X%',             color: 'text-yellow-400', border: 'border-yellow-500/30' },
  { id: 'sub',    label: 'Subscription',desc: 'They pay — monthly or annual',              color: 'text-emerald-400',border: 'border-emerald-500/30' },
];

// ── Outreach messages ──────────────────────────────────────────────────────────
const MESSAGES = [
  {
    id: 'dm1',
    label: 'LinkedIn DM — Cold',
    tag: 'Phase 1',
    text: `Hi [Name],

I noticed you manage a sales team at [Company]. Quick question:

How do you currently track whether your reps are executing consistently day-to-day?

We built a system that gives each rep a daily execution score. Teams using it went from 42% to 78% execution rate in 6 weeks.

Would you be open to a 15-minute call to see if it fits your team?`,
  },
  {
    id: 'dm2',
    label: 'LinkedIn DM \u2014 Warm (mutual connection)',
    tag: 'Phase 1',
    text: `Hey [Name],

[Mutual] mentioned you run the sales team at [Company].

We built a performance tool that turns daily rep behavior into a score (like a fitness tracker for sales reps). One team went from 42% \u2192 78% execution in 6 weeks.

I\u2019d love to show you a quick demo \u2014 free pilot for your team, no commitment.

15 mins this week?`,
  },
  {
    id: 'pilot',
    label: 'Pilot Offer Email',
    tag: 'Phase 2',
    text: `Subject: Free 7-day pilot for your sales team

Hi [Name],

I want to offer your team a 7-day pilot of Behavior Engine \u2014 completely free.

Here\u2019s what happens:
\u2022 Each rep gets a daily execution score (like a fitness tracker)
\u2022 You see who\u2019s executing and who isn\u2019t, in real time
\u2022 AI coach sends personalized nudges based on each person\u2019s pattern

One team saw execution go from 42% \u2192 78% in 6 weeks. That\u2019s more closed deals.

No credit card. No setup call needed. Just reply and I\u2019ll send you the link.

Worth 7 days?`,
  },
  {
    id: 'followup',
    label: 'Follow-Up (no reply)',
    tag: 'Phase 1+2',
    text: `Hey [Name],

Just following up on my last message.

One sentence: we help sales teams improve execution consistency in 7 days using daily tracking + AI coaching.

If it\u2019s not relevant right now, totally fine \u2014 just let me know.

If it is, I\u2019ll set up your team for free this week.`,
  },
  {
    id: 'close',
    label: 'Closing Message (after pilot)',
    tag: 'Phase 2+3',
    text: `Hi [Name],

Your team\u2019s pilot results are in:

\u2022 Execution rate: [X]% \u2192 [Y]%
\u2022 Most consistent rep: [Name]
\u2022 At-risk pattern flagged for: [Name]

To keep the momentum going, the Pro plan is $[price]/user/month.

Annual plan = 2 months free.

Want me to send the invoice?`,
  },
];

// ── Revenue tracker ────────────────────────────────────────────────────────────
function loadRevenue() {
  try { return JSON.parse(localStorage.getItem('be_10k_revenue')) ?? { phase: 0, mrr: 0, customers: [] }; }
  catch { return { phase: 0, mrr: 0, customers: [] }; }
}
function saveRevenue(s) {
  try { localStorage.setItem('be_10k_revenue', JSON.stringify(s)); } catch {}
}

// ── Copy button ────────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1800); }}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
        copied ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/40 hover:text-white/65'
      }`}>
      {copied ? <><Check size={10} /> Copied!</> : <><Copy size={10} /> Copy</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function TenKPlan() {
  const [view,      setView]      = useState('phases'); // 'phases' | 'loop' | 'outreach'
  const [activeMsg, setActiveMsg] = useState(MESSAGES[0]);
  const [rev,       setRev_]      = useState(loadRevenue);
  const [newMRR,    setNewMRR]    = useState('');
  const [tasks,     setTasks]     = useState(() => {
    try { return JSON.parse(localStorage.getItem('be_10k_tasks')) ?? {}; } catch { return {}; }
  });

  const setRev = (s) => { setRev_(s); saveRevenue(s); };

  const toggleTask = (phaseId, idx) => {
    const key = `${phaseId}_${idx}`;
    const updated = { ...tasks, [key]: !tasks[key] };
    setTasks(updated);
    try { localStorage.setItem('be_10k_tasks', JSON.stringify(updated)); } catch {}
  };

  const addMRR = () => {
    const val = parseInt(newMRR, 10);
    if (!val || val <= 0) return;
    const updated = { ...rev, mrr: rev.mrr + val };
    setRev(updated);
    setNewMRR('');
  };

  const currentPhase = rev.mrr < 1000 ? 0 : rev.mrr < 5000 ? 1 : 2;
  const mrrPct       = Math.min(100, Math.round((rev.mrr / 10000) * 100));
  const nextMilestone = rev.mrr < 1000 ? 1000 : rev.mrr < 5000 ? 5000 : 10000;
  const toNext        = Math.max(0, nextMilestone - rev.mrr);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <DollarSign size={14} className="text-emerald-400" />
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest">Revenue Execution</p>
            </div>
            <h1 className="text-3xl font-black mb-1">First $10K/Month Plan</h1>
            <p className="text-white/35 text-sm">
              You don&apos;t scale code first. You scale behavior + teams + subscriptions.
            </p>
          </div>

          {/* MRR live counter */}
          <div className="p-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/5 min-w-[180px]">
            <p className="text-white/30 text-[9px] uppercase tracking-widest mb-1">Current MRR</p>
            <p className="text-3xl font-black text-emerald-400">${rev.mrr.toLocaleString()}</p>
            <div className="mt-2 h-1.5 bg-white/8 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400 rounded-full transition-all duration-700" style={{ width: `${mrrPct}%` }} />
            </div>
            <p className="text-white/25 text-[9px] mt-1">${toNext.toLocaleString()} to ${nextMilestone.toLocaleString()}</p>
          </div>
        </div>

        {/* Add MRR */}
        <div className="flex items-center gap-3">
          <input
            type="number"
            value={newMRR}
            onChange={e => setNewMRR(e.target.value)}
            placeholder="Add MRR ($)"
            className="w-36 px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-sm outline-none placeholder-white/20 focus:border-emerald-500/40"
          />
          <button onClick={addMRR}
            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-sm rounded-xl transition-all">
            + Log MRR
          </button>
          {rev.mrr > 0 && (
            <button onClick={() => setRev({ phase: 0, mrr: 0, customers: [] })}
              className="px-3 py-2 bg-white/4 border border-white/8 text-white/30 text-xs rounded-xl hover:text-white/50 transition-all">
              Reset
            </button>
          )}
          <span className="text-white/20 text-xs">Phase: <span className="text-white/50 font-semibold">{PHASES[currentPhase].label}</span></span>
        </div>

        {/* View toggle */}
        <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
          {[['phases','Phases'],['loop','Acquisition Loop'],['outreach','Outreach Scripts']].map(([v, l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view === v ? 'bg-emerald-500 text-black' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── PHASES ───────────────────────────────────────────────── */}
        {view === 'phases' && (
          <div className="space-y-4">
            {PHASES.map((phase, pi) => {
              const isActive  = pi === currentPhase;
              const isDone    = rev.mrr >= phase.target;
              const tasksDone = phase.tasks.filter((_, ti) => tasks[`${phase.id}_${ti}`]).length;
              return (
                <div key={phase.id} className={`rounded-2xl border transition-all ${
                  isActive ? `${phase.border} ${phase.bg}` : isDone ? 'border-emerald-500/20 bg-emerald-500/4' : 'border-white/6 bg-white/2'
                }`}>
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm ${
                          isDone ? 'bg-emerald-500 text-white' : isActive ? `${phase.bg} ${phase.border} border ${phase.color}` : 'bg-white/5 border border-white/8 text-white/30'
                        }`}>
                          {isDone ? <CheckCircle2 size={16} /> : pi + 1}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className={`font-bold ${isActive ? phase.color : isDone ? 'text-emerald-400' : 'text-white/50'}`}>{phase.label} — {phase.goal}</p>
                            <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full border uppercase ${
                              isDone ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : isActive ? `${phase.bg} ${phase.border} ${phase.color}` : 'bg-white/5 border-white/8 text-white/25'
                            }`}>{isDone ? 'DONE' : isActive ? 'ACTIVE' : phase.badge}</span>
                          </div>
                          <p className="text-white/35 text-xs mt-0.5">{phase.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-white/25">
                        <Clock size={10} />
                        <span>{phase.timeline}</span>
                        <span>{tasksDone}/{phase.tasks.length} tasks</span>
                      </div>
                    </div>

                    <div className="mt-5 grid lg:grid-cols-[1fr_auto] gap-6">
                      {/* Tasks */}
                      <div className="space-y-2">
                        <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Execution Tasks</p>
                        {phase.tasks.map((t, ti) => {
                          const done = !!tasks[`${phase.id}_${ti}`];
                          return (
                            <button key={ti} onClick={() => toggleTask(phase.id, ti)}
                              className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                                done ? 'bg-emerald-500/6 border-emerald-500/20' : 'bg-white/2 border-white/6 hover:border-white/12'
                              }`}>
                              <div className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 transition-all ${
                                done ? 'bg-emerald-500' : 'border border-white/20'
                              }`}>
                                {done && <Check size={10} className="text-white" />}
                              </div>
                              <span className={`text-xs flex-1 ${done ? 'line-through text-white/25' : 'text-white/60'}`}>{t.text}</span>
                            </button>
                          );
                        })}
                      </div>

                      {/* Channels + metrics */}
                      <div className="space-y-4 lg:w-56">
                        <div>
                          <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Channels</p>
                          {phase.channels.map((c, i) => (
                            <div key={i} className="flex items-center gap-2 mb-1.5">
                              <div className="w-1 h-1 rounded-full bg-white/20 shrink-0" />
                              <span className="text-white/40 text-xs">{c}</span>
                            </div>
                          ))}
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries(phase.metrics).map(([k, v]) => (
                            <div key={k} className="p-2 rounded-lg bg-white/3 border border-white/6">
                              <p className={`text-xs font-bold ${phase.color}`}>{v}</p>
                              <p className="text-white/20 text-[8px] capitalize">{k.replace('_', ' ')}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Truth */}
                    <div className={`mt-4 p-3 rounded-xl border ${phase.border} ${phase.bg}`}>
                      <p className={`text-xs font-semibold ${phase.color}`}>{phase.truth}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── ACQUISITION LOOP ─────────────────────────────────────── */}
        {view === 'loop' && (
          <div className="space-y-6">
            {/* Visual loop */}
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0b0f1a]">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-5">Acquisition Loop</p>
              <div className="flex items-center gap-2 flex-wrap">
                {LOOP.map((step, i) => (
                  <div key={step.id} className="flex items-center gap-2">
                    <div className={`px-4 py-3 rounded-2xl border ${step.border} bg-white/2`}>
                      <p className={`text-xs font-bold ${step.color}`}>{step.label}</p>
                      <p className="text-white/25 text-[9px] mt-0.5 max-w-[120px]">{step.desc}</p>
                    </div>
                    {i < LOOP.length - 1 && <ArrowRight size={14} className="text-white/20 shrink-0" />}
                  </div>
                ))}
                <div className="flex items-center gap-2">
                  <ArrowRight size={14} className="text-white/20" />
                  <div className="px-3 py-3 rounded-2xl border border-white/8 bg-white/2">
                    <p className="text-xs font-bold text-white/30">Repeat</p>
                    <p className="text-white/15 text-[9px] mt-0.5">upsell + referral</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Loop breakdown */}
            <div className="grid lg:grid-cols-2 gap-4">
              {[
                {
                  title: 'Lead Generation',
                  color: 'text-white/60',
                  steps: [
                    ['LinkedIn DMs', '20/day to sales team leads, VPs of Sales, revenue managers'],
                    ['Cold Email', 'Targeted list: companies 10–100 people, B2B SaaS, professional services'],
                    ['Content', 'Post daily execution stats on LinkedIn. Let results do the talking.'],
                    ['Referrals', 'Ask every happy user: "Who else runs a team like yours?"'],
                  ],
                },
                {
                  title: 'Conversion System',
                  color: 'text-indigo-400',
                  steps: [
                    ['The Demo', '15 minutes. Show live dashboard. Ask: "What would this mean for your team?"'],
                    ['The Pilot', 'Free 7 days. No credit card. Get 3+ reps using it. Results show themselves.'],
                    ['The Close', 'Show them their pilot stats. "Your team went from X% to Y%. To keep it: $Z/mo."'],
                    ['Annual Offer', 'Offer 2 months free on annual. Reduces churn 40%. Improves cashflow.'],
                  ],
                },
              ].map(({ title, color, steps }) => (
                <div key={title} className="p-5 rounded-2xl border border-white/8 bg-white/2 space-y-3">
                  <p className={`text-xs font-bold uppercase tracking-widest ${color}`}>{title}</p>
                  {steps.map(([step, desc]) => (
                    <div key={step} className="flex gap-2">
                      <ChevronRight size={12} className={`${color} shrink-0 mt-0.5`} />
                      <div>
                        <span className="text-white/60 text-xs font-semibold">{step}: </span>
                        <span className="text-white/35 text-xs">{desc}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>

            {/* Core rule */}
            <div className="p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
              <p className="text-emerald-400 font-bold text-sm mb-2">The Core Rule</p>
              <p className="text-white/55 text-sm leading-relaxed">
                You do <span className="text-white font-semibold">NOT</span> sell software.
                You sell <span className="text-emerald-400 font-semibold">performance improvement</span>.
                The pitch is not &quot;here are our features&quot;. The pitch is:
                &quot;Teams using this improve execution by 30–50% in 7 days. Want to see?&quot;
              </p>
            </div>
          </div>
        )}

        {/* ── OUTREACH SCRIPTS ─────────────────────────────────────── */}
        {view === 'outreach' && (
          <div className="grid lg:grid-cols-[220px_1fr] gap-6">
            {/* Message list */}
            <div className="space-y-1.5">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Templates</p>
              {MESSAGES.map(m => (
                <button key={m.id} onClick={() => setActiveMsg(m)}
                  className={`w-full text-left p-3 rounded-xl border transition-all ${
                    activeMsg.id === m.id ? 'border-indigo-500/25 bg-indigo-500/10 text-indigo-300' : 'border-white/6 bg-white/2 text-white/40 hover:text-white/60 hover:bg-white/4'
                  }`}>
                  <p className="text-xs font-semibold leading-snug">{m.label}</p>
                  <span className={`text-[8px] font-bold mt-1 inline-block px-1.5 py-0.5 rounded border ${
                    m.tag.includes('1') ? 'bg-white/5 border-white/10 text-white/30' : 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400'
                  }`}>{m.tag}</span>
                </button>
              ))}
            </div>

            {/* Message editor */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-white/60 text-sm font-semibold">{activeMsg.label}</p>
                <CopyBtn text={activeMsg.text} />
              </div>
              <div className="p-5 rounded-2xl border border-white/8 bg-[#0b0f1a]">
                <pre className="text-white/55 text-xs leading-relaxed whitespace-pre-wrap font-sans">{activeMsg.text}</pre>
              </div>
              <div className="p-4 rounded-xl border border-indigo-500/15 bg-indigo-500/5">
                <p className="text-indigo-400 text-xs font-semibold mb-1">How to use this</p>
                <p className="text-white/35 text-xs leading-relaxed">
                  Fill in the [brackets] with real data. Send this manually at first. Track replies in a simple Google Sheet.
                  Your goal is 1–2 demos per day. After 10 demos, you will have your first 3 paying customers.
                </p>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
