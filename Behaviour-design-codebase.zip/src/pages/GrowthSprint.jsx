/**
 * GrowthSprint — "100 Users in 7 Days" Execution Plan
 * Day-by-day operational playbook with live task tracking,
 * progress meters, and copy-ready message templates.
 */
import { useState, useEffect } from 'react';
import {
  Rocket, CheckCircle2, Circle, Copy, MessageCircle, Link2,
  Flame, Target, Users, TrendingUp, Calendar, Zap, ArrowRight,
  ChevronDown, ChevronUp, Star, DollarSign, BarChart2, Share2, Activity,
} from 'lucide-react';

// ── Design tokens ─────────────────────────────────────────────────────────────
const DAY_COLORS = {
  1: { dot: 'bg-emerald-500', text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/25', label: 'Setup'    },
  2: { dot: 'bg-yellow-500',  text: 'text-yellow-400',  bg: 'bg-yellow-500/10',  border: 'border-yellow-500/25',  label: 'Blast'     },
  3: { dot: 'bg-blue-500',    text: 'text-blue-400',    bg: 'bg-blue-500/10',    border: 'border-blue-500/25',    label: 'Launch'    },
  4: { dot: 'bg-orange-500',  text: 'text-orange-400',  bg: 'bg-orange-500/10',  border: 'border-orange-500/25',  label: 'Viral'     },
  5: { dot: 'bg-purple-500',  text: 'text-purple-400',  bg: 'bg-purple-500/10',  border: 'border-purple-500/25',  label: 'Scale'     },
  6: { dot: 'bg-pink-500',    text: 'text-pink-400',    bg: 'bg-pink-500/10',    border: 'border-pink-500/25',    label: 'Group'     },
  7: { dot: 'bg-red-500',     text: 'text-red-400',     bg: 'bg-red-500/10',     border: 'border-red-500/25',     label: 'Close'     },
};

const DAYS = [
  {
    day: 1,
    title: 'Setup + Offer Ready',
    target: '0 users → 5 users',
    goal: 'Get the system live and your first 5 friends signed up.',
    tasks: [
      { id: 'd1t1', text: 'Set landing page live (or share direct link)',             pts: 10 },
      { id: 'd1t2', text: 'Write your pilot offer message (template below)',          pts: 5  },
      { id: 'd1t3', text: 'Send to 10 personal contacts via WhatsApp',               pts: 10 },
      { id: 'd1t4', text: 'Post in 1 business WhatsApp group',                       pts: 10 },
      { id: 'd1t5', text: 'Send LinkedIn connection request to 5 sales managers',    pts: 5  },
    ],
    message: '"Hey [Name], I\'m running a 7-day pilot for a daily execution tracking system for teams. I\'m onboarding 100 people this week. Want to try it free? Takes 10 mins to set up."',
    metric: '5 signups',
    emoji: '🟢',
  },
  {
    day: 2,
    title: 'Outreach Blast Day',
    target: '5 → 20 users',
    goal: 'Send 50 direct messages across all channels. This is a volume day.',
    tasks: [
      { id: 'd2t1', text: 'Send 20 DMs on WhatsApp (use template)',                  pts: 20 },
      { id: 'd2t2', text: 'Send 10 LinkedIn DMs to managers/sales leads',            pts: 15 },
      { id: 'd2t3', text: 'Post in 3 different WhatsApp business groups',            pts: 10 },
      { id: 'd2t4', text: 'Follow up with everyone from Day 1 who didn\'t reply',    pts: 10 },
      { id: 'd2t5', text: 'Share your own execution score on LinkedIn',              pts: 5  },
    ],
    message: '"I\'m testing a system that improves daily execution in teams. We measure, score, and coach behavior in real-time. Want in for 7 days free?"',
    metric: '20 signups',
    emoji: '🟡',
  },
  {
    day: 3,
    title: 'First Users Live',
    target: '20 → 35 users',
    goal: 'Manually guide your first 10–20 users through the system. Hold their hand.',
    tasks: [
      { id: 'd3t1', text: 'DM every new signup and ask if they completed first task', pts: 15 },
      { id: 'd3t2', text: 'Send a "how it works in 3 steps" voice note / video',     pts: 10 },
      { id: 'd3t3', text: 'Create a WhatsApp pilot group for your first users',      pts: 10 },
      { id: 'd3t4', text: 'Send the leaderboard screenshot to the group',            pts: 10 },
      { id: 'd3t5', text: 'Onboard 15 more new users today',                        pts: 15 },
    ],
    message: '"Welcome to the pilot! 🔥 Here\'s how to get started: 1) Log into the system 2) Complete your first task 3) Check your score. Reply if you need help — I\'m watching the dashboard."',
    metric: '35 signups',
    emoji: '🟡',
  },
  {
    day: 4,
    title: 'Viral Loop Activation',
    target: '35 → 55 users',
    goal: 'Push social sharing. Every execution card shared = referral channel.',
    tasks: [
      { id: 'd4t1', text: 'Ask top 3 users to share their execution card',           pts: 10 },
      { id: 'd4t2', text: 'Post "Day 4 results" update on LinkedIn with team stats', pts: 15 },
      { id: 'd4t3', text: 'Screenshot leaderboard and post in WhatsApp groups',      pts: 10 },
      { id: 'd4t4', text: 'Send "are you still in?" re-engagement to Day 1 drops',  pts: 10 },
      { id: 'd4t5', text: 'Onboard 20 new users from referrals + new outreach',     pts: 20 },
    ],
    message: '"Day 4 update: our pilot team has [X] people executing daily. The top scorer is at [score] pts. If you want to see what this looks like for your team — reply now."',
    metric: '55 signups',
    emoji: '🟠',
  },
  {
    day: 5,
    title: 'Scale Outreach',
    target: '55 → 80 users',
    goal: '100 total messages sent. Push to 80 active users.',
    tasks: [
      { id: 'd5t1', text: 'Send 30 new outreach messages (new contacts only)',       pts: 30 },
      { id: 'd5t2', text: 'DM 10 business owners on LinkedIn with pilot offer',     pts: 15 },
      { id: 'd5t3', text: 'Ask every active user to invite 1 colleague',            pts: 10 },
      { id: 'd5t4', text: 'Post a "we\'re at [X] users" milestone update',          pts: 5  },
      { id: 'd5t5', text: 'Re-engage every silent user with a personal message',    pts: 10 },
    ],
    message: '"Hey — quick check-in. You joined the pilot but haven\'t logged yet. Your team is already on the leaderboard. Takes 60 seconds to start. Link: [link]"',
    metric: '80 signups',
    emoji: '🟠',
  },
  {
    day: 6,
    title: 'Group Effect + Competition',
    target: '80 → 100 users',
    goal: 'Create social pressure. Show public rankings. Let competition do the work.',
    tasks: [
      { id: 'd6t1', text: 'Send live leaderboard update to your pilot group',        pts: 10 },
      { id: 'd6t2', text: 'Tag top 3 performers publicly (with their permission)',   pts: 10 },
      { id: 'd6t3', text: 'Post "Final 20 spots left in pilot" urgency message',     pts: 10 },
      { id: 'd6t4', text: 'Send personal voice notes to top-10 to lock them in',    pts: 15 },
      { id: 'd6t5', text: 'Onboard final 20 users',                                 pts: 20 },
    ],
    message: '"🏆 Day 6 Leaderboard Update:\n1. [Name]: [score]\n2. [Name]: [score]\n3. [Name]: [score]\n\nWhere are you? Tomorrow we close the pilot. Last chance to climb."',
    metric: '100 signups',
    emoji: '🔴',
  },
  {
    day: 7,
    title: 'Close + Convert to Paying',
    target: '100 users → 10–20 paying',
    goal: 'This is revenue day. Ask every active user to continue as a paying subscriber.',
    tasks: [
      { id: 'd7t1', text: 'Message every user: "Pilot ends today — continue monthly?"', pts: 20 },
      { id: 'd7t2', text: 'Create a "results summary" post (% improved, avg score)', pts: 10 },
      { id: 'd7t3', text: 'Send payment link to everyone who says yes',              pts: 20 },
      { id: 'd7t4', text: 'Offer 1-month free to teams with 3+ members who convert', pts: 10 },
      { id: 'd7t5', text: 'Book a call with any company that wants a team plan',     pts: 15 },
    ],
    message: '"The 7-day pilot ends today. Your team has improved execution by measurable %. Do you want to continue this system monthly? Reply YES and I\'ll send you a link. Takes 2 minutes."',
    metric: '10–20 paying',
    emoji: '🔴',
  },
];

const RESULT_TARGETS = [
  { label: 'Total Signups',    target: '100',     icon: Users,      color: 'text-indigo-400'  },
  { label: 'Active Users',     target: '30–60',   icon: Activity,   color: 'text-emerald-400' },
  { label: 'Paying Users',     target: '10–20',   icon: DollarSign, color: 'text-yellow-400'  },
  { label: 'Est. MRR',         target: '$490–980',icon: TrendingUp, color: 'text-pink-400'    },
];



function DayCard({ dayData, completedTasks, onToggleTask, isExpanded, onToggleExpand, currentDay }) {
  const { day, title, target, goal, tasks, message, metric, emoji } = dayData;
  const c = DAY_COLORS[day];
  const completedCount = tasks.filter(t => completedTasks.has(t.id)).length;
  const pct = Math.round((completedCount / tasks.length) * 100);
  const isPast    = day < currentDay;
  const isCurrent = day === currentDay;
  const [copied, setCopied]   = useState(false);

  const copyMsg = () => {
    navigator.clipboard.writeText(message.replace(/"/g, '')).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`rounded-2xl border transition-all ${isCurrent ? `${c.border} ${c.bg}` : isPast ? 'border-white/6 bg-white/1' : 'border-white/5 bg-transparent opacity-60'}`}>

      {/* Header */}
      <button onClick={onToggleExpand}
        className="w-full flex items-center gap-4 p-5 text-left">
        {/* Day badge */}
        <div className={`w-10 h-10 rounded-xl ${c.bg} border ${c.border} flex items-center justify-center shrink-0`}>
          <span className="text-lg leading-none">{emoji}</span>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2.5 mb-1">
            <span className={`text-[10px] font-black uppercase tracking-widest ${c.text}`}>Day {day}</span>
            {isCurrent && (
              <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${c.bg} ${c.text} border ${c.border} animate-pulse`}>
                TODAY
              </span>
            )}
            {isPast && pct === 100 && <CheckCircle2 size={11} className="text-emerald-400" />}
          </div>
          <p className={`text-sm font-bold ${isPast || isCurrent ? 'text-white' : 'text-white/40'}`}>{title}</p>
          <p className={`text-xs mt-0.5 ${c.text}`}>{target}</p>
        </div>

        {/* Progress ring */}
        <div className="flex flex-col items-end gap-1.5 shrink-0">
          <p className={`text-sm font-black ${c.text}`}>{completedCount}/{tasks.length}</p>
          <div className="w-20 h-1 bg-white/8 rounded-full overflow-hidden">
            <div className={`h-full ${c.dot} rounded-full transition-all`} style={{ width: `${pct}%` }} />
          </div>
          {isExpanded ? <ChevronUp size={13} className="text-white/25" /> : <ChevronDown size={13} className="text-white/25" />}
        </div>
      </button>

      {/* Expanded content */}
      {isExpanded && (
        <div className="px-5 pb-5 space-y-4 border-t border-white/5 pt-4">
          <p className="text-white/40 text-sm">{goal}</p>

          {/* Task checklist */}
          <div className="space-y-2">
            {tasks.map(task => {
              const done = completedTasks.has(task.id);
              return (
                <button key={task.id} onClick={() => onToggleTask(task.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                    done ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/6 bg-white/2 hover:border-white/10'
                  }`}>
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                    done ? 'border-emerald-500 bg-emerald-500' : 'border-white/20'
                  }`}>
                    {done && <CheckCircle2 size={11} className="text-white" />}
                  </div>
                  <span className={`text-sm flex-1 ${done ? 'text-white/40 line-through' : 'text-white/70'}`}>{task.text}</span>
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full shrink-0 ${done ? 'bg-emerald-500/15 text-emerald-400' : 'bg-white/5 text-white/20'}`}>
                    +{task.pts}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Message template */}
          <div className={`p-4 rounded-xl ${c.bg} border ${c.border}`}>
            <div className="flex items-center justify-between mb-2">
              <p className={`text-[9px] font-bold uppercase tracking-widest ${c.text}`}>Message Template · Day {day}</p>
              <button onClick={copyMsg}
                className={`flex items-center gap-1 text-[9px] font-semibold px-2 py-1 rounded-lg transition-all ${c.bg} ${c.text} border ${c.border}`}>
                {copied ? <><CheckCircle2 size={9} /> Copied!</> : <><Copy size={9} /> Copy</>}
              </button>
            </div>
            <p className="text-white/55 text-xs leading-relaxed italic">{message}</p>
          </div>

          <div className="flex items-center gap-2">
            <Target size={11} className={c.text} />
            <p className={`text-xs font-semibold ${c.text}`}>Day target: {metric}</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function GrowthSprint() {
  const [completedTasks, setCompletedTasks] = useState(() => {
    try { return new Set(JSON.parse(localStorage.getItem('be_sprint_tasks') ?? '[]')); } catch { return new Set(); }
  });
  const [expandedDay, setExpandedDay]   = useState(1);
  const [currentDay,  setCurrentDay]    = useState(1);
  const [sprintStart, setSprintStart]   = useState(() => {
    return localStorage.getItem('be_sprint_start') || null;
  });

  // Auto-advance current day based on sprint start date
  useEffect(() => {
    if (!sprintStart) return;
    const start = new Date(sprintStart);
    const today = new Date();
    const diff  = Math.floor((today - start) / (1000 * 60 * 60 * 24)) + 1;
    setCurrentDay(Math.min(7, Math.max(1, diff)));
  }, [sprintStart]);

  const startSprint = () => {
    const now = new Date().toISOString();
    localStorage.setItem('be_sprint_start', now);
    setSprintStart(now);
    setCurrentDay(1);
    setExpandedDay(1);
  };

  const toggleTask = (taskId) => {
    setCompletedTasks(prev => {
      const next = new Set(prev);
      next.has(taskId) ? next.delete(taskId) : next.add(taskId);
      localStorage.setItem('be_sprint_tasks', JSON.stringify([...next]));
      return next;
    });
  };

  const allTasks = DAYS.flatMap(d => d.tasks);
  const totalDone = allTasks.filter(t => completedTasks.has(t.id)).length;
  const totalPts  = allTasks.filter(t => completedTasks.has(t.id)).reduce((s, t) => s + t.pts, 0);
  const sprintPct = Math.round((totalDone / allTasks.length) * 100);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-8">

        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Rocket size={16} className="text-red-400" />
            <p className="text-red-400 text-xs font-bold uppercase tracking-widest">Growth Sprint</p>
          </div>
          <h1 className="text-3xl font-black mb-1">100 Users in 7 Days</h1>
          <p className="text-white/35 text-sm">
            Day-by-day execution plan. Not a strategy doc — a live checklist you run.
          </p>
        </div>

        {/* Sprint Status Bar */}
        <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-5">
          {!sprintStart ? (
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <p className="text-white font-bold mb-1">Sprint not started</p>
                <p className="text-white/35 text-sm">Hit the button to start your 7-day clock. Day 1 begins today.</p>
              </div>
              <button onClick={startSprint}
                className="flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-400 rounded-xl text-sm font-bold text-white transition-all shadow-lg shadow-red-500/25 whitespace-nowrap">
                <Rocket size={14} /> Start Sprint Now
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-bold">Sprint Active — Day {currentDay} of 7</p>
                  <p className="text-white/30 text-xs mt-0.5">Started {new Date(sprintStart).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</p>
                </div>
                <div className="text-right">
                  <p className="text-white font-black text-2xl">{sprintPct}%</p>
                  <p className="text-white/25 text-xs">complete</p>
                </div>
              </div>

              {/* Day progress track */}
              <div className="flex gap-1">
                {DAYS.map(({ day }) => {
                  const c = DAY_COLORS[day];
                  const dayTasks = DAYS.find(d => d.day === day)?.tasks ?? [];
                  const dayDone = dayTasks.filter(t => completedTasks.has(t.id)).length;
                  const dayPct  = dayDone / dayTasks.length;
                  return (
                    <div key={day} className="flex-1 space-y-1">
                      <div className="h-2 bg-white/8 rounded-full overflow-hidden">
                        <div className={`h-full ${c.dot} rounded-full transition-all`} style={{ width: `${dayPct * 100}%` }} />
                      </div>
                      <p className={`text-[8px] text-center font-bold ${day === currentDay ? c.text : 'text-white/15'}`}>{day}</p>
                    </div>
                  );
                })}
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: 'Tasks Done',   value: `${totalDone}/${allTasks.length}`, color: 'text-white'        },
                  { label: 'Sprint Points',value: totalPts,                          color: 'text-indigo-400'   },
                  { label: 'Current Day',  value: `Day ${currentDay}`,               color: 'text-red-400'      },
                ].map(({ label, value, color }) => (
                  <div key={label} className="p-3 rounded-xl bg-white/3 border border-white/6 text-center">
                    <p className={`text-lg font-black ${color}`}>{value}</p>
                    <p className="text-white/25 text-[9px]">{label}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Result Targets */}
        <div>
          <p className="text-white/30 text-xs font-bold uppercase tracking-widest mb-3">Sprint Targets</p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {RESULT_TARGETS.map(({ label, target, icon: Icon, color }) => (
              <div key={label} className="p-4 rounded-xl bg-white/2 border border-white/6 text-center">
                <Icon size={14} className={`${color} mx-auto mb-2`} />
                <p className={`text-xl font-black ${color}`}>{target}</p>
                <p className="text-white/25 text-[10px] mt-0.5">{label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Day-by-day plan */}
        <div className="space-y-3">
          <p className="text-white/30 text-xs font-bold uppercase tracking-widest">Day-by-Day Plan</p>
          {DAYS.map(dayData => (
            <DayCard
              key={dayData.day}
              dayData={dayData}
              completedTasks={completedTasks}
              onToggleTask={toggleTask}
              isExpanded={expandedDay === dayData.day}
              onToggleExpand={() => setExpandedDay(prev => prev === dayData.day ? null : dayData.day)}
              currentDay={currentDay}
            />
          ))}
        </div>

        {/* Core rules */}
        <div className="rounded-2xl border border-red-500/20 bg-red-500/4 p-5 space-y-3">
          <div className="flex items-center gap-2">
            <Flame size={14} className="text-red-400" />
            <p className="text-red-400 font-bold text-sm">The 3 Rules That Make This Work</p>
          </div>
          {[
            { n: '01', rule: 'Volume beats quality on Day 1–3. Send 50 messages. Not 5 perfect ones.' },
            { n: '02', rule: 'First task completion is everything. If a user doesn\'t complete task #1 — they never come back. Follow up personally.' },
            { n: '03', rule: 'Show the leaderboard early. Social comparison is the most powerful retention mechanic you have.' },
          ].map(({ n, rule }) => (
            <div key={n} className="flex items-start gap-3">
              <span className="text-red-400/50 font-black text-xs font-mono shrink-0 mt-0.5">{n}</span>
              <p className="text-white/55 text-sm">{rule}</p>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
