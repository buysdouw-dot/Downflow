/**
 * FirstThousand — Exact 30-Day First 1000 Users System
 * Daily actions. Phase checkpoints. Viral loop tracker. No theory.
 */
import { useState } from 'react';
import {
  Users, CheckCircle2, Circle, TrendingUp, MessageSquare,
  Zap, Repeat, Target, ArrowRight, BarChart2,
  Play, Star, Share2, CalendarDays,
} from 'lucide-react';

// ── Phases ────────────────────────────────────────────────────────────────────
const PHASES = [
  {
    id: 'p1', days: 'Days 1–3', label: 'Setup', target: 'Product live + offer clear',
    color: '#a1a1aa', bg: 'rgba(161,161,170,0.06)',
    Icon: Zap,
    north: 'You are not building features. You are building proof of concept.',
    actions: [
      'Deploy MVP to production URL (Railway + Vercel — 20 min)',
      'Create landing page: 1 headline "Improve team execution in 7 days"',
      'Set up Stripe payment link ($20/user or $200/team)',
      'Write your offer: "Free 7-day pilot. No credit card. I set it up."',
      'Build demo account with fake but realistic data',
      'Identify 50 target buyers (LinkedIn / WhatsApp contacts)',
      'Write your cold message (see Scripts tab)',
    ],
    kpi: 'Product URL live. Stripe working. 50 targets identified.',
  },
  {
    id: 'p2', days: 'Days 4–7', label: 'First 50', target: '10–50 users',
    color: '#fbbf24', bg: 'rgba(245,158,11,0.06)',
    Icon: MessageSquare,
    north: 'Stop building. Start selling. Every hour on the product is an hour not selling.',
    actions: [
      'Send 20 WhatsApp messages/day (personal, not broadcast)',
      'Send 10 LinkedIn DMs/day (decision-makers: VP Sales, RevOps, Managers)',
      'Post 1 piece of content/day (execution insight + data)',
      'Do 2–3 demo calls every day. Same-day callbacks only.',
      'Offer 7-day pilot on every call. Close pilot, not annual plan.',
      'Charge first user by Day 5. Even if it feels too early.',
      'Write 1 raw case study after every pilot.',
    ],
    kpi: '10 paying users or 3 teams. First testimonial collected.',
  },
  {
    id: 'p3', days: 'Days 8–15', label: 'Pilot Phase', target: '5–10 teams',
    color: '#f472b6', bg: 'rgba(236,72,153,0.06)',
    Icon: Target,
    north: 'You are not growing yet. You are collecting proof. Proof is your growth engine.',
    actions: [
      'Manually onboard every pilot team — 15-min setup call',
      'Check in with every active user on Day 3 and Day 7',
      'Document every result: before/after execution %, revenue impact',
      'Get 1 video testimonial or LinkedIn post from best pilot user',
      'Build 3-slide case study: Problem → Solution → Result',
      'Keep sending 20 DMs/day even during active pilots',
      'Identify which channel converts best — double down on it',
    ],
    kpi: '5 case studies. 1 video testimonial. Pilot-to-paid rate > 50%.',
  },
  {
    id: 'p4', days: 'Days 16–25', label: 'Scale Loop', target: '100–200 users',
    color: '#818cf8', bg: 'rgba(99,102,241,0.06)',
    Icon: TrendingUp,
    north: 'Automation starts here. You earned the right to automate by proving it works.',
    actions: [
      'Automate onboarding: loom video + setup guide + email sequence',
      'Launch leaderboard — public rankings create social proof + retention',
      'Add shareable score cards: "My execution score this week: 38/45"',
      'Ask every paying user: "Who else in your network runs a sales team?"',
      'Post case study results every 3 days — specific numbers only',
      'Start LinkedIn content batch: 7 posts scheduled for the week',
      'Set up AI Coach automation (WhatsApp coaching via Twilio)',
    ],
    kpi: '100+ users. Referral loop active. 1+ inbound lead per day.',
  },
  {
    id: 'p5', days: 'Days 26–30', label: '1000 Push', target: '500–1000 users',
    color: '#34d399', bg: 'rgba(16,185,129,0.06)',
    Icon: Star,
    north: 'This phase only works because you built proof in weeks 1-3. Without that, ads fail.',
    actions: [
      'Run targeted LinkedIn ads: case study post → landing page ($50/day)',
      'Launch referral program: 1 free month per referred paying team',
      'Publish 2–3 case study posts — most viral content you have',
      'Cold email 100 VP Sales/RevOps contacts with subject "Re: execution rate"',
      'Reach out to 10 communities/Slack groups your buyers are in',
      'Partner with 1 sales tool or coach (co-promotion)',
      'Track pipeline daily: leads → demos → pilots → paying',
    ],
    kpi: '1000 user pipeline started. $5K–$10K MRR in sight.',
  },
];

// ── Daily non-negotiables ─────────────────────────────────────────────────────
const DAILY = [
  { icon: MessageSquare, time: 'Morning',   action: '20 outreach messages (WhatsApp + LinkedIn). 10 new contacts. 10 follow-ups.' },
  { icon: Play,          time: 'Mid-morning', action: '1-2 demo calls booked same-day or next-day. Use exact call structure.' },
  { icon: Share2,        time: 'Midday',      action: '1 content post (LinkedIn or Twitter). Execution insight with real data.' },
  { icon: Target,        time: 'Afternoon',   action: 'Follow up with all demos not responded in 24h. No ghosting allowed.' },
  { icon: BarChart2,     time: 'Evening',     action: 'Check your own execution score. Are YOU executing at 80%+?' },
];

// ── Viral loop steps ──────────────────────────────────────────────────────────
const LOOP = [
  { id: 'lead',    label: 'Lead In',       desc: 'Cold DM or inbound → demo booked',   color: '#a1a1aa' },
  { id: 'trial',   label: 'Free Pilot',    desc: '7-day pilot → proof of improvement',  color: '#818cf8' },
  { id: 'result',  label: 'Result',        desc: 'Execution rate improves 20–40%',      color: '#22d3ee' },
  { id: 'proof',   label: 'Proof',         desc: 'Case study + testimonial created',    color: '#fbbf24' },
  { id: 'scale',   label: 'Share',         desc: 'User posts score → others ask about it', color: '#f472b6' },
  { id: 'repeat',  label: 'Referral',      desc: 'Referred lead enters pipeline',       color: '#34d399' },
];

// ── Scripts ────────────────────────────────────────────────────────────────────
const SCRIPTS = [
  { label: 'Cold WhatsApp DM', channel: 'WhatsApp', color: '#34d399',
    text: `Hey [Name],

I track team execution daily — like a performance score for your reps.

Teams using it went from 42% to 78% execution in 6 weeks.

Want me to run a free 7-day test for your team? Takes 10 minutes to set up.` },
  { label: 'Cold LinkedIn', channel: 'LinkedIn', color: '#818cf8',
    text: `Hi [Name],

I help sales teams improve execution consistency in 7 days.

Every rep gets a daily execution score — you see in real time who is on track.

Free pilot. No credit card. Worth 15 minutes?` },
  { label: 'Follow-Up #2', channel: 'Email / DM', color: '#22d3ee',
    text: `Subject: Re: team execution pilot

Hi [Name],

Following up on the pilot offer.

[Company similar to theirs] went from 42% to 78% execution in 6 weeks with this.

15 minutes this week? I'll show you the live dashboard.` },
  { label: 'Referral Ask', channel: 'WhatsApp (existing user)', color: '#fbbf24',
    text: `Hey [Name],

Your team execution score this week was [X]. Really strong.

Quick ask — do you know 2–3 other managers running sales teams? I'm doing free pilots this month.

If they sign up, you get 1 free month. Just send me their number.` },
];

function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1600); }}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border shrink-0 transition-all ${c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'}`}>
      {c ? <><CheckCircle2 size={8}/>Copied</> : <>Copy</>}
    </button>
  );
}

export default function FirstThousand() {
  const [view,   setView]  = useState('phases');
  const [phase,  setPhase] = useState('p1');
  const [tasks,  setTasks] = useState(() => { try { return JSON.parse(localStorage.getItem('be_1k_tasks')) ?? {}; } catch { return {}; } });
  const [day,    setDay]   = useState(() => { try { return Number(localStorage.getItem('be_1k_day') ?? 1); } catch { return 1; } });

  const saveTasks = t => { setTasks(t); try { localStorage.setItem('be_1k_tasks', JSON.stringify(t)); } catch {} };
  const toggleTask = k => saveTasks({ ...tasks, [k]: !tasks[k] });
  const incDay = () => { const n = Math.min(day + 1, 30); setDay(n); try { localStorage.setItem('be_1k_day', n); } catch {} };

  const activePhase = PHASES.find(p => p.id === phase);
  const PhaseIcon = activePhase?.Icon;

  const overallPct = Math.round((day / 30) * 100);
  const currentPhaseObj = PHASES.find(p => {
    const [s, e] = p.days.replace('Days ', '').split('–').map(Number);
    return day >= s && day <= e;
  }) ?? PHASES[0];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Users size={13} className="text-violet-400" />
              <p className="text-violet-400 text-xs font-bold uppercase tracking-widest">30-Day First 1000 Users System</p>
            </div>
            <h1 className="text-3xl font-black mb-1">0 → 1,000 Users</h1>
            <p className="text-white/35 text-sm">Daily actions. Phase checkpoints. No theory. Just execution.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl border border-violet-500/20 bg-violet-500/5 text-center">
              <p className="text-xl font-black text-violet-400">Day {day}</p>
              <p className="text-white/20 text-[8px]">of 30</p>
            </div>
            <button onClick={incDay} disabled={day >= 30}
              className="px-3 py-2 rounded-xl bg-violet-500 hover:bg-violet-400 text-white text-xs font-bold transition-all disabled:opacity-40">
              Mark Day Done →
            </button>
          </div>
        </div>

        {/* 30-day progress */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-white/20 text-[9px] uppercase tracking-widest">30-Day Progress</p>
            <p className="text-white/30 text-[9px]">{overallPct}%</p>
          </div>
          <div className="h-2 bg-white/6 rounded-full overflow-hidden flex">
            {PHASES.map(p => {
              const [s, e] = p.days.replace('Days ', '').split('–').map(Number);
              const w = ((e - s + 1) / 30) * 100;
              const filled = Math.max(0, Math.min(e - s + 1, day - s + 1));
              const filledPct = (filled / (e - s + 1)) * 100;
              return (
                <div key={p.id} className="relative h-full" style={{ width: `${w}%` }}>
                  <div className="absolute inset-0 h-full rounded" style={{ background: p.color + '15' }} />
                  <div className="absolute inset-y-0 left-0 h-full rounded" style={{ width: `${filledPct}%`, background: p.color }} />
                </div>
              );
            })}
          </div>
          <div className="flex mt-1.5">
            {PHASES.map(p => (
              <div key={p.id} className="text-center" style={{ flex: '1' }}>
                <p className="text-[7px]" style={{ color: p.color }}>{p.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Current phase chip */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border"
          style={{ borderColor: currentPhaseObj.color + '25', background: currentPhaseObj.color + '08' }}>
          <div className="w-2 h-2 rounded-full" style={{ background: currentPhaseObj.color }} />
          <p className="text-[10px] font-bold" style={{ color: currentPhaseObj.color }}>You are in: {currentPhaseObj.days} — {currentPhaseObj.label}</p>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['phases','Phase Plan'],['daily','Daily Rules'],['scripts','Message Scripts'],['loop','Viral Loop']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-violet-500 text-white' : 'text-white/35 hover:text-white/60'}`}>{l}</button>
          ))}
        </div>

        {/* ── PHASES ── */}
        {view === 'phases' && (
          <div className="grid lg:grid-cols-[190px_1fr] gap-5">
            <div className="space-y-1.5">
              {PHASES.map(p => {
                const done  = p.actions.filter((_, i) => tasks[`${p.id}_${i}`]).length;
                const total = p.actions.length;
                const isAct = phase === p.id;
                return (
                  <button key={p.id} onClick={() => setPhase(p.id)}
                    className={`w-full p-3 rounded-xl border text-left transition-all ${isAct ? 'border-white/12 bg-white/5' : 'border-white/5 hover:bg-white/3'}`}>
                    <p className="text-[8px] font-black uppercase tracking-widest mb-0.5" style={{ color: isAct ? p.color : 'rgba(255,255,255,0.2)' }}>{p.days}</p>
                    <p className="text-white/50 text-[10px] font-semibold">{p.label}</p>
                    <div className="flex items-center justify-between mt-1.5">
                      <p className="text-[8px] font-bold" style={{ color: p.color }}>{p.target}</p>
                      <span className="text-white/15 text-[8px]">{done}/{total}</span>
                    </div>
                    <div className="h-0.5 bg-white/5 rounded-full mt-1 overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${total ? (done/total)*100 : 0}%`, background: p.color }} />
                    </div>
                  </button>
                );
              })}
            </div>

            {activePhase && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl border" style={{ borderColor: activePhase.color + '20', background: activePhase.bg }}>
                  <div className="flex items-center gap-2 mb-1">
                    {PhaseIcon && <PhaseIcon size={12} style={{ color: activePhase.color }} />}
                    <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: activePhase.color }}>{activePhase.days} — {activePhase.label}</p>
                  </div>
                  <p className="text-white/55 text-sm font-semibold">{activePhase.target}</p>
                </div>

                <div className="p-3 rounded-xl border border-yellow-500/15 bg-yellow-500/5">
                  <p className="text-yellow-400 text-[8px] font-bold uppercase tracking-widest mb-1">Phase Truth</p>
                  <p className="text-white/45 text-xs leading-snug italic">{activePhase.north}</p>
                </div>

                <div className="space-y-2">
                  <p className="text-white/20 text-[8px] uppercase tracking-widest">Actions</p>
                  {activePhase.actions.map((action, i) => {
                    const key = `${activePhase.id}_${i}`;
                    const done = !!tasks[key];
                    return (
                      <button key={i} onClick={() => toggleTask(key)}
                        className="w-full flex items-start gap-3 p-3 rounded-xl border border-white/6 hover:bg-white/3 text-left transition-all">
                        {done ? <CheckCircle2 size={13} style={{ color: activePhase.color }} className="shrink-0 mt-0.5" />
                               : <Circle     size={13} className="text-white/15 shrink-0 mt-0.5" />}
                        <p className={`text-xs leading-snug ${done ? 'text-white/25 line-through' : 'text-white/60'}`}>{action}</p>
                      </button>
                    );
                  })}
                </div>

                <div className="p-3 rounded-xl border border-white/8 bg-white/2">
                  <p className="text-white/20 text-[8px] uppercase tracking-widest mb-1">Phase KPI</p>
                  <p className="text-white/60 text-xs">{activePhase.kpi}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── DAILY ── */}
        {view === 'daily' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl border border-violet-500/20 bg-violet-500/5">
              <p className="text-violet-400 font-bold text-sm mb-1">The Iron Daily Rule</p>
              <p className="text-white/50 text-xs leading-relaxed">
                Every single day for 30 days: 20 messages, 1 post, 1 demo.
                Miss one day — fine. Miss three — the pipeline dies.
                The compound effect of 20 messages/day = 600 touches in 30 days.
                At 1% conversion = 6 paying teams. At $200/team = $1,200 MRR from cold outreach alone.
              </p>
            </div>

            <div className="space-y-2">
              {DAILY.map(({ icon: DIcon, time, action }, i) => {
                const key = `daily_${i}_${day}`;
                const done = !!tasks[key];
                return (
                  <button key={i} onClick={() => toggleTask(key)}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl border border-white/6 bg-white/2 hover:bg-white/3 text-left transition-all">
                    <span className="text-violet-400 text-[10px] font-bold w-20 shrink-0">{time}</span>
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 bg-violet-500/8 border border-violet-500/15">
                      <DIcon size={12} className="text-violet-400/70" />
                    </div>
                    <p className={`flex-1 text-xs leading-snug ${done ? 'text-white/25 line-through' : 'text-white/60'}`}>{action}</p>
                    {done ? <CheckCircle2 size={13} className="text-violet-400 shrink-0" />
                           : <Circle size={13} className="text-white/15 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-3 gap-3">
              {[
                { l: 'DMs needed for 1 paying team', v: '~100', c: '#818cf8' },
                { l: 'Days to 100 DMs at 20/day',   v: '5',   c: '#34d399' },
                { l: 'Teams from 30 days × $200',    v: '$1.2K MRR', c: '#fbbf24' },
              ].map(m => (
                <div key={m.l} className="p-3 rounded-xl border border-white/8 bg-white/2 text-center">
                  <p className="text-lg font-black" style={{ color: m.c }}>{m.v}</p>
                  <p className="text-white/25 text-[8px] mt-0.5 leading-snug">{m.l}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── SCRIPTS ── */}
        {view === 'scripts' && (
          <div className="space-y-4">
            {SCRIPTS.map(s => (
              <div key={s.label} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <p className="text-white/65 text-xs font-bold">{s.label}</p>
                    <span className="text-[8px] font-bold px-1.5 py-0.5 rounded border" style={{ color: s.color, borderColor: s.color + '25', background: s.color + '10' }}>{s.channel}</span>
                  </div>
                  <CopyBtn text={s.text} />
                </div>
                <pre className="text-white/45 text-xs leading-relaxed whitespace-pre-wrap font-sans">{s.text}</pre>
              </div>
            ))}
          </div>
        )}

        {/* ── LOOP ── */}
        {view === 'loop' && (
          <div className="space-y-5">
            <div className="p-6 rounded-2xl border border-white/8 bg-[#0c1018]">
              <p className="text-white/20 text-[9px] uppercase tracking-widest mb-5">Viral Growth Loop</p>
              <div className="flex items-center gap-2 flex-wrap">
                {LOOP.map((step, i) => (
                  <div key={step.id} className="flex items-center gap-2">
                    <div className="flex flex-col items-center gap-1 px-3 py-2.5 rounded-xl border border-white/8 bg-white/2">
                      <div className="w-2 h-2 rounded-full" style={{ background: step.color }} />
                      <span className="text-[9px] font-bold whitespace-nowrap text-white/60">{step.label}</span>
                    </div>
                    {i < LOOP.length - 1 && <ArrowRight size={8} className="text-white/15" />}
                  </div>
                ))}
                <ArrowRight size={8} className="text-white/15" />
                <div className="px-3 py-2.5 rounded-xl border border-white/8 flex items-center gap-1.5">
                  <Repeat size={9} className="text-white/20" />
                  <span className="text-[9px] text-white/20 font-bold">∞</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              {LOOP.map(step => (
                <div key={step.id} className="flex items-start gap-4 p-4 rounded-xl border border-white/6 bg-white/2">
                  <div className="w-2.5 h-2.5 rounded-full mt-1 shrink-0" style={{ background: step.color }} />
                  <div>
                    <p className="text-white/65 text-xs font-bold mb-0.5">{step.label}</p>
                    <p className="text-white/30 text-[10px]">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl border border-violet-500/20 bg-violet-500/5">
              <p className="text-violet-400 font-bold text-sm mb-2">The K-Coefficient</p>
              <p className="text-white/45 text-xs leading-relaxed">
                At K = 0.5 (each user refers 0.5 others): 10 users → 15 → 17 → 18 (plateau).
                At K = 1.0 (each user refers 1 other): 10 → 20 → 40 → 80 → 160 (exponential).
                Target: <span className="text-violet-400 font-bold">K &gt; 0.5 by week 3</span>. Achieved by making scores shareable and results visible.
              </p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
