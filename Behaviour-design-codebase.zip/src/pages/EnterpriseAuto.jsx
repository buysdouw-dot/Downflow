/**
 * EnterpriseAuto — Enterprise Closing Automation System
 * Fully scripted. CRM pipeline. Automated trigger logic. No guessing.
 */
import { useState } from 'react';
import {
  Briefcase, Copy, Check, ArrowRight, CheckCircle2,
  Phone, Mail, MessageSquare, Users, DollarSign,
  Target, Zap, TrendingUp, Play, BarChart2,
  Star, Clock, ChevronRight, AlertCircle,
} from 'lucide-react';

// ── Pipeline stages ────────────────────────────────────────────────────────────
const STAGES = [
  { id: 'new',        label: 'New Lead',     color: '#a1a1aa', bg: 'rgba(161,161,170,0.06)', border: 'rgba(161,161,170,0.15)' },
  { id: 'contacted',  label: 'Contacted',    color: '#818cf8', bg: 'rgba(99,102,241,0.06)',   border: 'rgba(99,102,241,0.18)'  },
  { id: 'demo',       label: 'Demo Booked',  color: '#22d3ee', bg: 'rgba(6,182,212,0.06)',    border: 'rgba(6,182,212,0.18)'   },
  { id: 'pilot',      label: 'Pilot',        color: '#a78bfa', bg: 'rgba(139,92,246,0.06)',   border: 'rgba(139,92,246,0.18)'  },
  { id: 'active',     label: 'Active',       color: '#34d399', bg: 'rgba(16,185,129,0.06)',   border: 'rgba(16,185,129,0.18)'  },
  { id: 'paying',     label: 'Paying',       color: '#fbbf24', bg: 'rgba(245,158,11,0.06)',   border: 'rgba(245,158,11,0.18)'  },
  { id: 'expansion',  label: 'Expansion',    color: '#f472b6', bg: 'rgba(236,72,153,0.06)',   border: 'rgba(236,72,153,0.18)'  },
];
const NEXT = { new:'contacted', contacted:'demo', demo:'pilot', pilot:'active', active:'paying', paying:'expansion' };

const SEED_LEADS = [
  { id: 'l1', name: 'James R.',  company: 'Apex Co.',     role: 'VP Sales',   seats: 24, status: 'demo'      },
  { id: 'l2', name: 'Sarah M.',  company: 'TechCorp',     role: 'RevOps',     seats: 60, status: 'pilot'     },
  { id: 'l3', name: 'Daniel K.', company: 'GrowthBase',   role: 'Sales Mgr',  seats: 12, status: 'active'    },
  { id: 'l4', name: 'Priya L.',  company: 'ScaleUp HQ',   role: 'Director',   seats: 80, status: 'paying'    },
  { id: 'l5', name: 'Tom B.',    company: 'Momentum Grp', role: 'VP Growth',  seats: 15, status: 'contacted' },
  { id: 'l6', name: 'Anika W.',  company: 'Frontier Labs', role: 'CEO',       seats: 30, status: 'new'       },
];

// ── Complete close scripts ────────────────────────────────────────────────────
const SCRIPTS = [
  {
    id: 'first_msg', stage: 'new', label: 'First Message', channel: 'WhatsApp / LinkedIn',
    color: '#818cf8',
    text: `Hey [Name],

We help teams improve execution consistency in 7 days using structured daily tracking.

Every rep gets a daily execution score. Manager sees real-time who is on track.

Want to test it? Free pilot, 7 days, I set it up — takes 10 minutes.`,
    why: 'Lead with the outcome, not the product. "Execution consistency" is a pain every sales manager has.',
  },
  {
    id: 'follow_up1', stage: 'contacted', label: 'Follow-Up #1 (Day 2)', channel: 'Email / DM',
    color: '#22d3ee',
    text: `Subject: [Company] execution pilot

Hi [Name],

Following up on the pilot offer.

One thing I can show you: [Similar company] went from 42% to 78% execution rate in 6 weeks.

The manager could see who was off-track before Friday — not at month end.

15 minutes this week?`,
    why: 'Lead with social proof (specific numbers). Specific numbers > testimonials > features.',
  },
  {
    id: 'follow_up2', stage: 'contacted', label: 'Follow-Up #2 (Day 5)', channel: 'WhatsApp',
    color: '#22d3ee',
    text: `Hey [Name], still open to the pilot?

Running 3 new ones this week. Takes 10 minutes to set up, 7 days to see results.

If it shows no improvement: you walk away. If it does: we talk about continuing.

Worth trying?`,
    why: 'The breakup message. Creates urgency without being pushy. Always generates replies.',
  },
  {
    id: 'demo_confirm', stage: 'demo', label: 'Demo Confirmation', channel: 'Email',
    color: '#a78bfa',
    text: `Subject: Confirmed: 15-min execution demo [Time]

Hi [Name],

Looking forward to it.

Quick question before we jump on — how many people are on the team you have in mind?

I'll tailor the demo to your exact team size.

See you [Day] at [Time].`,
    why: 'The pre-demo question starts the scoping. Now they are thinking about rollout before the call.',
  },
  {
    id: 'pilot_launch', stage: 'pilot', label: 'Pilot Kickoff', channel: 'Email',
    color: '#34d399',
    text: `Subject: Your team is live — pilot starts now

Hi [Name],

Done. Your team's pilot is active.

Here's what happens this week:
- Day 1: Each rep gets their first daily execution prompt
- Day 3: You can see first score trends in the manager dashboard
- Day 7: I'll send you the full performance report

Manager login: [link]
Team dashboard: [link]

Any questions — reply here. I check this daily.`,
    why: 'Speed creates credibility. Pilot launch same day as demo = highest conversion to paid.',
  },
  {
    id: 'close_convert', stage: 'active', label: 'Day 7 Close', channel: 'Email',
    color: '#fbbf24',
    text: `Subject: Day 7 results — [Company] pilot

Hi [Name],

Here's what happened in your 7-day pilot:

Execution rate: [before]% → [after]%
Most consistent rep: [name]
Reps showing daily consistency: [X] of [total]

Based on your team size ([N] users), continuing is [price]/month.

That's roughly [X per rep per day] — less than a coffee per rep for measurable execution improvement.

Want to continue? I can keep everyone active with no interruption.

Just reply "yes" and I'll send the invoice.`,
    why: 'Use their own data to close. The pilot proves value. You just present the numbers.',
  },
  {
    id: 'expansion', stage: 'paying', label: 'Expansion Ask', channel: 'Email',
    color: '#f472b6',
    text: `Subject: Other teams at [Company]?

Hi [Name],

[Team] hit [X]% execution this week — one of the best results I've seen.

I noticed [Company] has other teams doing similar work. Have you thought about rolling this out to [adjacent team]?

The data transfers — they'd see results in week 1.

Worth a 10-minute conversation?`,
    why: 'Expansion is 5x cheaper to acquire than new customers. Always ask after the first strong week.',
  },
];

// ── Demo call script ──────────────────────────────────────────────────────────
const CALL_STEPS = [
  { id: 'open',    time: '0–2 min',  color: '#a1a1aa', label: 'Open',
    script: `"Thanks for jumping on. I only need 15 minutes.\n\nI want to understand one thing first: how does your team track execution right now — not results, just day-to-day task execution?\n\n[Listen for 2 minutes]"`,
    note: 'Ask the question and shut up. The longer they talk, the closer you are to closing.' },
  { id: 'problem', time: '2–6 min',  color: '#f87171', label: 'Problem',
    script: `"What happens when someone misses their targets for the month?\n\n[Listen]\n\nAnd how do you know in the moment — not at month end — who is executing and who is not?\n\n[Listen]\n\nWhat does that cost you roughly?"`,
    note: 'Their answer is your closing ammunition. Write it down word for word.' },
  { id: 'impact',  time: '6–9 min',  color: '#fbbf24', label: 'Impact',
    script: `"If your team went from [their number]% execution to 70%, what does that look like in revenue?\n\n[Let them calculate]\n\nThat's what I see. Teams go from 42% to 78% execution in 6 weeks. Not by hiring — by visibility.\n\nCan I show you what that looks like?"`,
    note: `Never say "Can I show you the demo?" Say "Can I show you what that looks like?"` },
  { id: 'demo',    time: '9–12 min', color: '#818cf8', label: 'Demo',
    script: `[Screen share: Manager dashboard]\n\n"This is what you see. Every rep. Every day. Green = executing. Red = not. No guessing.\n\n[Show 6-week trend]\n\n42% to 78%. This is a real team.\n\nDoes this match the problem you described?"`,
    note: 'Stop at "Does this match the problem?" Do NOT keep selling after they say yes.' },
  { id: 'close',   time: '12–15 min', color: '#34d399', label: 'Close',
    script: `"Here's what I want to do. Let's run a 7-day pilot with your team. I set it up — takes 10 minutes. No credit card. No commitment.\n\nAt day 7 you see the data. No improvement: walk away. Improvement: we talk.\n\nHow many people are on the team you're thinking of starting with?"`,
    note: 'The last question assumes yes and starts scoping. Never ask "do you want to try it?"' },
];

// ── CRM automation code ────────────────────────────────────────────────────────
const CRM_CODE = `// crmService.js — Full pipeline automation

const TRANSITIONS = {
  new:       'contacted',
  contacted: 'demo',
  demo:      'pilot',
  pilot:     'active',
  active:    'paying',
  paying:    'expansion',
};

const AUTOMATIONS = {
  contacted: (lead) => sendEmail(lead, 'intro'),
  demo:      (lead) => sendCalendarLink(lead),
  pilot:     (lead) => createWorkspace(lead) && sendPilotKickoff(lead),
  active:    (lead) => enableDashboard(lead),
  paying:    (lead) => sendReceipt(lead) && scheduleWeeklyReport(lead),
  expansion: (lead) => scheduleExpansionCall(lead),
};

function pipeline(lead, event) {
  const next = TRANSITIONS[lead.status];

  if (next) {
    lead.status = next;
    lead.events.push({ event, ts: Date.now() });

    // Trigger automation for this stage
    AUTOMATIONS[next]?.(lead);

    // Log for audit trail
    console.log(\`[\${lead.company}] \${lead.status} → \${next}\`);
  }

  return lead;
}

// Key insight: enterprise closes when you show metrics, not features.
// The automation triggers ensure no lead falls through the cracks.
// Every stage transition fires an action automatically.

module.exports = { pipeline, TRANSITIONS };`;

function CopyBtn({ text }) {
  const [c, setC] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1600); }}
      className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border shrink-0 transition-all ${c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'}`}>
      {c ? <><Check size={8} />Copied</> : <>Copy</>}
    </button>
  );
}

export default function EnterpriseAuto() {
  const [view,  setView]  = useState('pipeline');
  const [leads, setLeads] = useState(() => { try { return JSON.parse(localStorage.getItem('be_entauto_leads')) ?? SEED_LEADS; } catch { return SEED_LEADS; } });
  const [step,  setStep]  = useState('open');
  const [sFilter, setSFilter] = useState('all');

  const saveLeads = l => { setLeads(l); try { localStorage.setItem('be_entauto_leads', JSON.stringify(l)); } catch {} };
  const advance = id => saveLeads(leads.map(l => l.id === id && NEXT[l.status] ? { ...l, status: NEXT[l.status] } : l));

  const curStep  = CALL_STEPS.find(s => s.id === step);
  const curIdx   = CALL_STEPS.findIndex(s => s.id === step);
  const filteredScripts = sFilter === 'all' ? SCRIPTS : SCRIPTS.filter(s => s.stage === sFilter);
  const mrrActive = leads.filter(l => l.status === 'paying' || l.status === 'expansion').reduce((s, l) => s + l.seats * 20, 0);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Briefcase size={13} className="text-amber-400" />
              <p className="text-amber-400 text-xs font-bold uppercase tracking-widest">Enterprise Closing Automation</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Close Companies Fast</h1>
            <p className="text-white/35 text-sm">Fully scripted. Every stage automated. Show metrics, not features.</p>
          </div>
          <div className="p-3 rounded-xl border border-amber-500/20 bg-amber-500/5 text-center">
            <p className="text-xl font-black text-amber-400">${mrrActive.toLocaleString()}</p>
            <p className="text-white/20 text-[9px]">pipeline MRR</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6 flex-wrap gap-0.5">
          {[['pipeline','CRM Pipeline'],['scripts','Close Scripts'],['call','Demo Call'],['code','CRM Code']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-amber-500 text-black font-bold' : 'text-white/35 hover:text-white/60'}`}>{l}</button>
          ))}
        </div>

        {/* ── PIPELINE ── */}
        {view === 'pipeline' && (
          <div className="space-y-4">
            {/* Stage summary */}
            <div className="flex gap-2 overflow-x-auto pb-1">
              {STAGES.map(s => (
                <div key={s.id} className="shrink-0 px-3 py-2 rounded-xl border text-center min-w-[70px]"
                  style={{ borderColor: s.border, background: s.bg }}>
                  <p className="text-[10px] font-black" style={{ color: s.color }}>{leads.filter(l => l.status === s.id).length}</p>
                  <p className="text-white/20 text-[7px] mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Cards */}
            <div className="space-y-3">
              {STAGES.map(stage => {
                const sl = leads.filter(l => l.status === stage.id);
                if (!sl.length) return null;
                return (
                  <div key={stage.id}>
                    <p className="text-[8px] font-black uppercase tracking-widest mb-1.5" style={{ color: stage.color }}>{stage.label}</p>
                    <div className="grid lg:grid-cols-2 gap-2">
                      {sl.map(lead => (
                        <div key={lead.id} className="flex items-center gap-3 p-3 rounded-xl border bg-white/2"
                          style={{ borderColor: stage.border }}>
                          <div className="w-8 h-8 rounded-xl flex items-center justify-center text-[9px] font-black shrink-0"
                            style={{ background: stage.bg, color: stage.color }}>
                            {lead.name.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-white/65 text-xs font-semibold truncate">{lead.name} · {lead.company}</p>
                            <p className="text-white/20 text-[8px]">{lead.role} · {lead.seats} seats</p>
                          </div>
                          {NEXT[lead.status] ? (
                            <button onClick={() => advance(lead.id)}
                              className="flex items-center gap-1 px-2 py-1 rounded-lg border border-white/10 text-white/25 text-[8px] hover:text-white/55 transition-all shrink-0">
                              Advance <ArrowRight size={7} />
                            </button>
                          ) : (
                            <span className="text-[7px] px-1.5 py-0.5 rounded border border-pink-500/20 text-pink-400 shrink-0">Expanded</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── SCRIPTS ── */}
        {view === 'scripts' && (
          <div className="space-y-4">
            {/* Key insight */}
            <div className="p-4 rounded-2xl border border-amber-500/20 bg-amber-500/5">
              <p className="text-amber-400 font-bold text-sm mb-1">The Core Closing Insight</p>
              <p className="text-white/50 text-xs leading-relaxed">
                Enterprise closes when you show <span className="text-white font-bold">metrics, not features.</span>
                Not promises. Not demos. Numbers. "<span className="text-amber-400">42% to 78% in 6 weeks.</span>"
                That one sentence closes more deals than any feature list.
              </p>
            </div>

            {/* Stage filter */}
            <div className="flex gap-2 flex-wrap">
              <button onClick={() => setSFilter('all')} className={`px-3 py-1 rounded-lg text-[9px] font-bold border transition-all ${sFilter==='all' ? 'bg-amber-500/15 border-amber-500/25 text-amber-400' : 'border-white/8 text-white/25 hover:text-white/50'}`}>All</button>
              {STAGES.slice(0, 6).map(s => (
                <button key={s.id} onClick={() => setSFilter(s.id)}
                  className={`px-3 py-1 rounded-lg text-[9px] font-bold border transition-all`}
                  style={sFilter===s.id ? { background: s.color+'12', borderColor: s.color+'25', color: s.color } : { borderColor: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.25)' }}>
                  {s.label}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              {filteredScripts.map(sc => {
                const si = STAGES.find(s => s.id === sc.stage);
                return (
                  <div key={sc.id} className="p-4 rounded-2xl border border-white/8 bg-white/2">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <p className="text-white/60 text-xs font-bold">{sc.label}</p>
                        <span className="text-[7px] font-bold px-1.5 py-0.5 rounded border" style={{ color: si?.color, borderColor: si?.color+'25', background: si?.color+'10' }}>{si?.label}</span>
                        <span className="text-white/15 text-[8px]">{sc.channel}</span>
                      </div>
                      <CopyBtn text={sc.text} />
                    </div>
                    <pre className="text-white/40 text-xs leading-relaxed whitespace-pre-wrap font-sans mb-2">{sc.text}</pre>
                    <div className="p-2 rounded-lg border border-yellow-500/10 bg-yellow-500/4">
                      <p className="text-yellow-400/70 text-[8px] leading-snug">{sc.why}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── CALL STRUCTURE ── */}
        {view === 'call' && (
          <div className="grid lg:grid-cols-[180px_1fr] gap-5">
            <div className="space-y-1">
              {CALL_STEPS.map((s, i) => (
                <button key={s.id} onClick={() => setStep(s.id)}
                  className={`w-full flex items-center gap-2 p-3 rounded-xl border text-left transition-all ${step===s.id ? 'border-white/12 bg-white/5' : 'border-white/5 hover:bg-white/3'}`}>
                  <div className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0"
                    style={{ background: step===s.id ? s.color+'15' : 'rgba(255,255,255,0.03)', border: `1px solid ${step===s.id ? s.color+'25' : 'rgba(255,255,255,0.06)'}` }}>
                    <span className="text-[8px] font-black" style={{ color: step===s.id ? s.color : 'rgba(255,255,255,0.2)' }}>{i+1}</span>
                  </div>
                  <div>
                    <p className="text-[9px] font-bold" style={{ color: step===s.id ? s.color : 'rgba(255,255,255,0.25)' }}>{s.label}</p>
                    <p className="text-white/15 text-[7px]">{s.time}</p>
                  </div>
                </button>
              ))}
            </div>

            {curStep && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl border" style={{ borderColor: curStep.color+'25', background: curStep.color+'06' }}>
                  <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: curStep.color }}>{curStep.label} — {curStep.time}</p>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-white/20 text-[9px] uppercase tracking-widest">Script</p>
                    <CopyBtn text={curStep.script} />
                  </div>
                  <pre className="p-4 rounded-xl border border-white/8 bg-black/30 text-white/50 text-xs leading-relaxed whitespace-pre-wrap font-sans">{curStep.script}</pre>
                </div>
                <div className="p-3 rounded-xl border border-yellow-500/12 bg-yellow-500/4">
                  <p className="text-yellow-400 text-[8px] font-bold uppercase tracking-widest mb-1">Coaching Note</p>
                  <p className="text-white/40 text-xs">{curStep.note}</p>
                </div>
                <div className="flex items-center justify-between">
                  {curIdx > 0 && (
                    <button onClick={() => setStep(CALL_STEPS[curIdx-1].id)}
                      className="px-3 py-2 rounded-xl border border-white/8 text-white/30 text-xs hover:text-white/55 transition-all">
                      ← Prev
                    </button>
                  )}
                  {curIdx < CALL_STEPS.length - 1 && (
                    <button onClick={() => setStep(CALL_STEPS[curIdx+1].id)}
                      className="ml-auto px-3 py-2 rounded-xl border border-amber-500/20 bg-amber-500/5 text-amber-400 text-xs hover:bg-amber-500/10 font-semibold transition-all">
                      Next step →
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── CODE ── */}
        {view === 'code' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">How It Works</p>
              <p className="text-white/50 text-xs leading-relaxed">
                Every time a lead advances a stage, the pipeline function fires an automation.
                No manual follow-up. No forgotten leads. Every stage triggers the right action automatically.
              </p>
            </div>
            <div className="rounded-2xl border border-white/8 bg-black/30 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2 border-b border-white/6 bg-white/2">
                <p className="text-white/35 text-xs font-mono">backend/src/services/crmService.js</p>
                <CopyBtn text={CRM_CODE} />
              </div>
              <pre className="p-4 text-[9.5px] text-white/55 font-mono leading-relaxed overflow-auto max-h-96">{CRM_CODE}</pre>
            </div>

            {/* Stage automation map */}
            <div className="space-y-2">
              <p className="text-white/20 text-[9px] uppercase tracking-widest">Automation Trigger Map</p>
              {[
                { stage: 'contacted',  trigger: 'Signal: lead status = contacted',   action: 'Send intro email via SendGrid' },
                { stage: 'demo',       trigger: 'Signal: lead advanced to demo',      action: 'Send Calendly link for 15-min call' },
                { stage: 'pilot',      trigger: 'Signal: demo completed',             action: 'Create team workspace + send kickoff email' },
                { stage: 'active',     trigger: 'Signal: first task completed',       action: 'Enable manager dashboard access' },
                { stage: 'paying',     trigger: 'Signal: day 7 pilot complete',       action: 'Send Stripe invoice + welcome kit' },
                { stage: 'expansion',  trigger: 'Signal: 3+ weeks consistent usage', action: 'Schedule expansion discovery call' },
              ].map(row => {
                const si = STAGES.find(s => s.id === row.stage);
                return (
                  <div key={row.stage} className="flex items-start gap-3 p-3 rounded-xl border border-white/6 bg-white/2">
                    <span className="text-[8px] font-black px-1.5 py-0.5 rounded border shrink-0" style={{ color: si?.color, borderColor: si?.color+'25', background: si?.color+'10' }}>{si?.label}</span>
                    <div className="flex-1">
                      <p className="text-white/30 text-[9px]">{row.trigger}</p>
                      <p className="text-white/55 text-[10px] font-semibold mt-0.5">→ {row.action}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
