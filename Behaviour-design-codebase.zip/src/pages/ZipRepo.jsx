/**
 * ZipRepo — Real ZIP Structure: File-by-file full repo dump
 * Every file shown in order. One-click copy per file.
 * Bash scaffold script recreates full folder structure from scratch.
 * No TypeScript. Pure Node.js + React.
 */
import { useState } from 'react';
import {
  FolderOpen, FileCode, Copy, Check, Download,
  Terminal, ChevronDown, ChevronRight, Archive,
  Package, Layers, GitBranch, Play,
} from 'lucide-react';

// ── Complete file manifest ─────────────────────────────────────────────────────
const MANIFEST = [
  // ── ROOT ──────────────────────────────────────────────────────────────────
  {
    path: 'package.json',
    section: 'root',
    lang: 'json',
    content: `{
  "name": "behavior-engine-saas",
  "version": "1.0.0",
  "private": true,
  "workspaces": ["backend", "frontend"],
  "scripts": {
    "dev:backend":  "npm run dev --workspace=backend",
    "dev:frontend": "npm run dev --workspace=frontend",
    "dev": "concurrently \\"npm:dev:backend\\" \\"npm:dev:frontend\\""
  },
  "devDependencies": {
    "concurrently": "^8.2.0"
  }
}`,
  },
  {
    path: '.gitignore',
    section: 'root',
    lang: 'bash',
    content: `node_modules/
dist/
build/
.env
.env.local
.env.production
*.log
.DS_Store
.vscode/
coverage/`,
  },
  {
    path: '.env.example',
    section: 'root',
    lang: 'bash',
    content: `# Copy to .env and fill in values
NODE_ENV=development
PORT=3001
JWT_SECRET=replace_with_long_random_string_minimum_32_chars

# Optional — swap in Postgres when ready
# DATABASE_URL=postgresql://user:pass@localhost:5432/behavior_engine

# Optional — Supabase
# SUPABASE_URL=https://xxxx.supabase.co
# SUPABASE_ANON_KEY=your_anon_key

# Frontend (create frontend/.env too)
VITE_API_URL=http://localhost:3001`,
  },
  {
    path: 'docker-compose.yml',
    section: 'root',
    lang: 'yaml',
    content: `version: '3.9'

services:
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    ports:
      - "3001:3001"
    environment:
      NODE_ENV: production
      PORT: 3001
      JWT_SECRET: \${JWT_SECRET}
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    ports:
      - "80:80"
    depends_on:
      - backend
    restart: unless-stopped

networks:
  default:
    driver: bridge`,
  },
  {
    path: 'README.md',
    section: 'root',
    lang: 'md',
    content: `# Behavior Engine SaaS

Self-improving team execution tracker with AI coaching, behavioral analytics, and CRM automation.

## Stack
| Layer | Technology |
|-------|-----------|
| Backend | Node.js + Express |
| Auth | JWT (bcryptjs) |
| Database | In-memory (swap to Postgres) |
| Frontend | React 18 + Vite + Tailwind |
| Deploy | Docker Compose / Railway / Render |

## Quick Start (local)
\`\`\`bash
git clone https://github.com/you/behavior-engine-saas
cd behavior-engine-saas

# Terminal 1: Backend
cd backend && cp ../.env.example .env
npm install && npm run dev

# Terminal 2: Frontend
cd frontend
npm install && npm run dev
\`\`\`
Open http://localhost:5173

## Docker Deploy
\`\`\`bash
cp .env.example .env
# Edit JWT_SECRET in .env
docker-compose up --build
\`\`\`
Open http://localhost

## API Reference
\`\`\`
POST /api/auth/register   { email, password, name }
POST /api/auth/login      { email, password }
GET  /api/tasks           Bearer token → tasks + score + coaching
POST /api/tasks           Bearer → { title, points?, category? }
PATCH /api/tasks/:id/complete  Bearer
GET  /api/crm/leads       Bearer
POST /api/crm/leads       Bearer → { name, email, company }
PATCH /api/crm/leads/:id/event Bearer → { event }
GET  /api/analytics/summary   Bearer
\`\`\``,
  },

  // ── BACKEND ────────────────────────────────────────────────────────────────
  {
    path: 'backend/package.json',
    section: 'backend',
    lang: 'json',
    content: `{
  "name": "behavior-engine-backend",
  "version": "1.0.0",
  "main": "src/server.js",
  "scripts": {
    "start": "node src/server.js",
    "dev":   "nodemon src/server.js"
  },
  "dependencies": {
    "bcryptjs":      "^2.4.3",
    "cors":          "^2.8.5",
    "dotenv":        "^16.0.3",
    "express":       "^4.18.2",
    "jsonwebtoken":  "^9.0.0",
    "uuid":          "^9.0.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}`,
  },
  {
    path: 'backend/.env.example',
    section: 'backend',
    lang: 'bash',
    content: `PORT=3001
JWT_SECRET=replace_this_with_32_plus_chars
NODE_ENV=development`,
  },
  {
    path: 'backend/Dockerfile',
    section: 'backend',
    lang: 'docker',
    content: `FROM node:20-alpine
WORKDIR /app
COPY package.json ./
RUN npm install --production
COPY src/ ./src/
EXPOSE 3001
CMD ["node", "src/server.js"]`,
  },
  {
    path: 'backend/src/server.js',
    section: 'backend',
    lang: 'js',
    content: `require('dotenv').config();
const app  = require('./app');
const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(\`[BE] Behavior Engine API on port \${PORT}\`);
  console.log(\`[BE] ENV: \${process.env.NODE_ENV || 'development'}\`);
});`,
  },
  {
    path: 'backend/src/app.js',
    section: 'backend',
    lang: 'js',
    content: `const express  = require('express');
const cors     = require('cors');
const { authenticate } = require('./middleware/auth');

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());

app.use('/api/auth',      require('./routes/auth'));
app.use('/api/tasks',     authenticate, require('./routes/tasks'));
app.use('/api/crm',       authenticate, require('./routes/crm'));
app.use('/api/analytics', authenticate, require('./routes/analytics'));

app.get('/health', (_, res) => res.json({ ok: true, ts: new Date().toISOString() }));

module.exports = app;`,
  },
  {
    path: 'backend/src/routes/auth.js',
    section: 'backend',
    lang: 'js',
    content: `const router   = require('express').Router();
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const store    = require('../db/memoryStore');

router.post('/register', async (req, res) => {
  const { email, password, name, role = 'user' } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email + password required' });
  if (store.getUser(email)) return res.status(409).json({ error: 'User exists' });

  const user = { id: uuid(), email, name: name || email, role, hash: await bcrypt.hash(password, 10) };
  store.saveUser(user);

  const token = jwt.sign({ id: user.id, email, role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.status(201).json({ token, user: { id: user.id, email, name: user.name, role } });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = store.getUser(email);
  if (!user || !(await bcrypt.compare(password, user.hash)))
    return res.status(401).json({ error: 'Invalid credentials' });

  const token = jwt.sign({ id: user.id, email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email, name: user.name, role: user.role } });
});

module.exports = router;`,
  },
  {
    path: 'backend/src/routes/tasks.js',
    section: 'backend',
    lang: 'js',
    content: `const router = require('express').Router();
const { v4: uuid } = require('uuid');
const store  = require('../db/memoryStore');
const { calculateScore } = require('../engine/score');
const { getCoachMessage } = require('../engine/ai');

router.get('/', (req, res) => {
  const tasks = store.getUserTasks(req.user.id);
  res.json({ tasks, score: calculateScore(tasks), coaching: getCoachMessage({ score: calculateScore(tasks) }) });
});

router.post('/', (req, res) => {
  const { title, points = 10, category = 'general' } = req.body;
  if (!title) return res.status(400).json({ error: 'Title required' });
  const task = { id: uuid(), userId: req.user.id, title, points, category, completed: false, createdAt: Date.now() };
  store.saveTask(task);
  res.status(201).json(task);
});

router.patch('/:id/complete', (req, res) => {
  const task = store.getUserTasks(req.user.id).find(t => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: 'Not found' });
  Object.assign(task, { completed: true, completedAt: Date.now() });
  store.saveTask(task);
  res.json(task);
});

module.exports = router;`,
  },
  {
    path: 'backend/src/routes/crm.js',
    section: 'backend',
    lang: 'js',
    content: `const router = require('express').Router();
const { v4: uuid } = require('uuid');
const store  = require('../db/memoryStore');
const { pipeline } = require('../services/crmService');

router.get('/leads', (req, res) => res.json({ leads: store.getLeads(req.user.id) }));

router.post('/leads', (req, res) => {
  const { name, email, company, source = 'manual' } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Name + email required' });
  const lead = { id: uuid(), ownerId: req.user.id, name, email, company, source, status: 'new', events: [], createdAt: Date.now() };
  store.saveLead(lead);
  res.status(201).json(lead);
});

router.patch('/leads/:id/event', (req, res) => {
  const lead = store.getLeads(req.user.id).find(l => l.id === req.params.id);
  if (!lead) return res.status(404).json({ error: 'Not found' });
  store.saveLead(pipeline(lead, req.body.event));
  res.json(lead);
});

module.exports = router;`,
  },
  {
    path: 'backend/src/routes/analytics.js',
    section: 'backend',
    lang: 'js',
    content: `const router = require('express').Router();
const store  = require('../db/memoryStore');
const { calculateScore, behaviorStatus, streakDays } = require('../engine/score');
const { analyzeBehavior } = require('../engine/behavior');

router.get('/summary', (req, res) => {
  const tasks = store.getUserTasks(req.user.id);
  const leads = store.getLeads(req.user.id);
  const score = calculateScore(tasks);
  res.json({
    score, status: behaviorStatus(score),
    behavior: analyzeBehavior(tasks),
    streak: streakDays(tasks),
    taskCount: tasks.length,
    completedCount: tasks.filter(t => t.completed).length,
    leadCount: leads.length,
    convertedLeads: leads.filter(l => l.status === 'converted').length,
    ts: new Date().toISOString(),
  });
});

module.exports = router;`,
  },
  {
    path: 'backend/src/engine/score.js',
    section: 'backend',
    lang: 'js',
    content: `function calculateScore(tasks) {
  if (!tasks?.length) return 0;
  const earned = tasks.reduce((s, t) => s + (t.completed ? (t.points || 10) : 0), 0);
  const total  = tasks.reduce((s, t) => s + (t.points || 10), 0);
  return total > 0 ? Math.round((earned / total) * 100) : 0;
}

function behaviorStatus(score) {
  if (score >= 75) return 'HIGH_PERFORMANCE';
  if (score >= 40) return 'MEDIUM_PERFORMANCE';
  return 'LOW_PERFORMANCE';
}

function streakDays(tasks) {
  const days = new Set(
    tasks.filter(t => t.completed && t.completedAt)
         .map(t => new Date(t.completedAt).toDateString())
  );
  return days.size;
}

module.exports = { calculateScore, behaviorStatus, streakDays };`,
  },
  {
    path: 'backend/src/engine/ai.js',
    section: 'backend',
    lang: 'js',
    content: `function getCoachMessage({ score, dropRate = 0 }) {
  if (score < 20)      return { message: 'Reduce scope. Execute 1 task only today.', type: 'intervention' };
  if (dropRate > 0.5)  return { message: 'Inconsistency detected. Fix routine first.', type: 'pattern_alert' };
  if (score >= 80)     return { message: 'Strong execution. Time to increase output.', type: 'growth_signal' };
  if (score >= 50)     return { message: 'Good momentum. Prioritise high-point tasks.', type: 'guidance' };
  return { message: 'Build consistency before adding complexity.', type: 'guidance' };
}

function generateInsight({ score, streakDays, completionRate }) {
  const out = [];
  if (streakDays >= 7)       out.push({ type: 'strength',  text: streakDays + '-day streak active.' });
  if (completionRate < 0.5)  out.push({ type: 'risk',      text: 'Sub-50% completion — action needed.' });
  if (score >= 80)           out.push({ type: 'milestone', text: 'Top-performer threshold reached.' });
  return out;
}

module.exports = { getCoachMessage, generateInsight };`,
  },
  {
    path: 'backend/src/engine/behavior.js',
    section: 'backend',
    lang: 'js',
    content: `function analyzeBehavior(tasks) {
  const done = tasks.filter(t => t.completed);
  const rate = tasks.length ? done.length / tasks.length : 0;

  const hours = {};
  done.filter(t => t.completedAt).forEach(t => {
    const h = new Date(t.completedAt).getHours();
    hours[h] = (hours[h] || 0) + 1;
  });
  const peakHour = Object.keys(hours).sort((a, b) => hours[b] - hours[a])[0];

  const byDay = {};
  tasks.forEach(t => {
    const d = new Date(t.createdAt).toDateString();
    if (!byDay[d]) byDay[d] = { total: 0, done: 0 };
    byDay[d].total++;
    if (t.completed) byDay[d].done++;
  });
  const recent = Object.values(byDay).slice(-3);
  const burnoutRisk = recent.length === 3 && recent.every(d => d.done / d.total < 0.3);

  return { completionRate: Math.round(rate * 100) / 100, peakHour: peakHour ? +peakHour : null, burnoutRisk };
}

module.exports = { analyzeBehavior };`,
  },
  {
    path: 'backend/src/middleware/auth.js',
    section: 'backend',
    lang: 'js',
    content: `const jwt = require('jsonwebtoken');

function authenticate(req, res, next) {
  const h = req.headers.authorization;
  if (!h?.startsWith('Bearer ')) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(h.slice(7), process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

module.exports = { authenticate };`,
  },
  {
    path: 'backend/src/db/memoryStore.js',
    section: 'backend',
    lang: 'js',
    content: `/**
 * Zero-dependency in-memory store.
 * Swap this file for a Postgres/Supabase adapter in production.
 * Interface is identical — just replace the Map operations with DB queries.
 */
const users = new Map();
const tasks = new Map();
const leads = new Map();

module.exports = {
  getUser:       (email)   => users.get(email),
  saveUser:      (u)       => users.set(u.email, u),
  getUserTasks:  (uid)     => [...tasks.values()].filter(t => t.userId === uid),
  saveTask:      (t)       => tasks.set(t.id, t),
  getLeads:      (oid)     => [...leads.values()].filter(l => l.ownerId === oid),
  saveLead:      (l)       => leads.set(l.id, l),
};`,
  },
  {
    path: 'backend/src/services/crmService.js',
    section: 'backend',
    lang: 'js',
    content: `const TRANSITIONS = {
  signup:        'contacted',
  demo_booked:   'demo',
  demo_done:     'pilot',
  first_task:    'active',
  day7_complete: 'converted',
  upsell:        'expansion',
  churned:       'lost',
};

function pipeline(lead, event) {
  if (!TRANSITIONS[event]) return lead;
  return {
    ...lead,
    status:    TRANSITIONS[event],
    updatedAt: Date.now(),
    events:    [...(lead.events || []), { event, ts: Date.now() }],
  };
}

function scoreLead(lead) {
  const ev = new Set((lead.events || []).map(e => e.event));
  return (ev.has('demo_booked') ? 20 : 0) + (ev.has('demo_done') ? 30 : 0) +
         (ev.has('first_task')  ? 25 : 0) + (ev.has('day7_complete') ? 25 : 0);
}

module.exports = { pipeline, scoreLead };`,
  },
  {
    path: 'backend/src/services/aiService.js',
    section: 'backend',
    lang: 'js',
    content: `const { getCoachMessage, generateInsight } = require('../engine/ai');
const { calculateScore, streakDays }  = require('../engine/score');
const { analyzeBehavior } = require('../engine/behavior');

function runAIPipeline(user, tasks) {
  const score    = calculateScore(tasks);
  const behavior = analyzeBehavior(tasks);
  const streaks  = streakDays(tasks);
  return {
    score,
    coaching:  getCoachMessage({ score, dropRate: 1 - behavior.completionRate }),
    insights:  generateInsight({ score, streakDays: streaks, completionRate: behavior.completionRate }),
    behavior,
    streaks,
  };
}

module.exports = { runAIPipeline };`,
  },

  // ── FRONTEND ───────────────────────────────────────────────────────────────
  {
    path: 'frontend/package.json',
    section: 'frontend',
    lang: 'json',
    content: `{
  "name": "behavior-engine-frontend",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev":     "vite --port 5173",
    "build":   "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react":            "^18.2.0",
    "react-dom":        "^18.2.0",
    "react-router-dom": "^6.14.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.0.3",
    "autoprefixer":         "^10.4.14",
    "postcss":              "^8.4.27",
    "tailwindcss":          "^3.3.3",
    "vite":                 "^4.4.5"
  }
}`,
  },
  {
    path: 'frontend/vite.config.js',
    section: 'frontend',
    lang: 'js',
    content: `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': { target: 'http://localhost:3001', changeOrigin: true },
    },
  },
});`,
  },
  {
    path: 'frontend/tailwind.config.js',
    section: 'frontend',
    lang: 'js',
    content: `export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {} },
  plugins: [],
};`,
  },
  {
    path: 'frontend/index.html',
    section: 'frontend',
    lang: 'html',
    content: `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Behavior Engine</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>`,
  },
  {
    path: 'frontend/src/main.jsx',
    section: 'frontend',
    lang: 'jsx',
    content: `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
);`,
  },
  {
    path: 'frontend/src/index.css',
    section: 'frontend',
    lang: 'css',
    content: `@tailwind base;
@tailwind components;
@tailwind utilities;

body { background: #030712; color: white; }`,
  },
  {
    path: 'frontend/src/App.jsx',
    section: 'frontend',
    lang: 'jsx',
    content: `import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { createContext, useContext, useState } from 'react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Tasks from './pages/Tasks';
import Leaderboard from './pages/Leaderboard';

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);
const API = import.meta.env.VITE_API_URL || '';

function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('be_token'));
  const [user,  setUser]  = useState(() => JSON.parse(localStorage.getItem('be_user') || 'null'));

  const login = async (email, password) => {
    const res  = await fetch(API + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    localStorage.setItem('be_token', data.token);
    localStorage.setItem('be_user', JSON.stringify(data.user));
    setToken(data.token); setUser(data.user);
  };

  const logout = () => {
    localStorage.removeItem('be_token'); localStorage.removeItem('be_user');
    setToken(null); setUser(null);
  };

  return <AuthCtx.Provider value={{ token, user, login, logout, isAuthenticated: !!token }}>{children}</AuthCtx.Provider>;
}

const Guard = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login"       element={<Login />} />
          <Route path="/"            element={<Guard><Dashboard /></Guard>} />
          <Route path="/tasks"       element={<Guard><Tasks /></Guard>} />
          <Route path="/leaderboard" element={<Guard><Leaderboard /></Guard>} />
          <Route path="*"            element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}`,
  },
  {
    path: 'frontend/src/pages/Login.jsx',
    section: 'frontend',
    lang: 'jsx',
    content: `import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../App';

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);

  const submit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try { await login(email, password); nav('/'); }
    catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4">
        <h1 className="text-2xl font-bold text-white text-center mb-6">Behavior Engine</h1>
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" required
          className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 outline-none" />
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" required
          className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 outline-none" />
        {error && <p className="text-red-400 text-sm">{error}</p>}
        <button type="submit" disabled={loading}
          className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-white font-bold rounded-xl disabled:opacity-50 transition-all">
          {loading ? 'Signing in...' : 'Sign In'}
        </button>
      </form>
    </div>
  );
}`,
  },
  {
    path: 'frontend/src/pages/Dashboard.jsx',
    section: 'frontend',
    lang: 'jsx',
    content: `import { useEffect, useState } from 'react';
import { useAuth } from '../App';

const API = import.meta.env.VITE_API_URL || '';
const COLOR = s => s >= 75 ? '#34d399' : s >= 40 ? '#fbbf24' : '#f87171';
const LABEL = s => s >= 75 ? 'High Performance' : s >= 40 ? 'Building Momentum' : 'Needs Focus';

export default function Dashboard() {
  const { token, user, logout } = useAuth();
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch(API + '/api/tasks', { headers: { Authorization: 'Bearer ' + token } })
      .then(r => r.json()).then(setData).catch(console.error);
  }, [token]);

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6 max-w-xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Welcome, {user?.name}</h2>
        <button onClick={logout} className="text-white/30 text-sm hover:text-white/60">Logout</button>
      </div>
      {data ? (
        <>
          <div className="p-6 rounded-2xl border border-white/8 bg-white/2 mb-4">
            <p className="text-white/30 text-sm mb-1">Execution Score</p>
            <p className="text-5xl font-black" style={{ color: COLOR(data.score) }}>{data.score}%</p>
            <p className="text-white/30 text-xs mt-2">{LABEL(data.score)}</p>
          </div>
          {data.coaching && (
            <div className="p-4 rounded-xl border border-white/8 bg-white/2">
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest mb-1">AI Coach</p>
              <p className="text-white/60 text-sm">{data.coaching.message}</p>
            </div>
          )}
        </>
      ) : <p className="text-white/30">Loading...</p>}
    </div>
  );
}`,
  },
  {
    path: 'frontend/src/pages/Tasks.jsx',
    section: 'frontend',
    lang: 'jsx',
    content: `import { useEffect, useState } from 'react';
import { useAuth } from '../App';

const API = import.meta.env.VITE_API_URL || '';

export default function Tasks() {
  const { token } = useAuth();
  const [tasks, setTasks]   = useState([]);
  const [title, setTitle]   = useState('');

  const load = () => fetch(API + '/api/tasks', { headers: { Authorization: 'Bearer ' + token } })
    .then(r => r.json()).then(d => setTasks(d.tasks || []));

  useEffect(() => { load(); }, []);

  const add = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    await fetch(API + '/api/tasks', { method: 'POST', headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }, body: JSON.stringify({ title }) });
    setTitle(''); load();
  };

  const complete = async (id) => {
    await fetch(API + '/api/tasks/' + id + '/complete', { method: 'PATCH', headers: { Authorization: 'Bearer ' + token } });
    load();
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6 max-w-xl mx-auto">
      <h2 className="text-xl font-bold mb-6">Tasks</h2>
      <form onSubmit={add} className="flex gap-2 mb-4">
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Add task..."
          className="flex-1 px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 outline-none" />
        <button type="submit" className="px-4 py-2 bg-indigo-500 text-white font-bold rounded-xl">Add</button>
      </form>
      <div className="space-y-2">
        {tasks.map(t => (
          <div key={t.id} className={"flex items-center gap-3 p-3 rounded-xl border " + (t.completed ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/8 bg-white/2')}>
            <button onClick={() => complete(t.id)} disabled={t.completed}
              className={"w-5 h-5 rounded-md border shrink-0 " + (t.completed ? 'bg-emerald-500 border-emerald-500' : 'border-white/20')}>
              {t.completed && <span className="text-white text-xs flex items-center justify-center">&#10003;</span>}
            </button>
            <span className={"flex-1 text-sm " + (t.completed ? 'line-through text-white/25' : 'text-white/65')}>{t.title}</span>
            <span className="text-white/20 text-xs">{t.points}pts</span>
          </div>
        ))}
      </div>
    </div>
  );
}`,
  },
  {
    path: 'frontend/src/pages/Leaderboard.jsx',
    section: 'frontend',
    lang: 'jsx',
    content: `const TEAM = [
  { name: 'Alex Chen',  score: 94, streak: 12 },
  { name: 'Maria G.',   score: 87, streak: 9  },
  { name: 'James P.',   score: 81, streak: 7  },
  { name: 'You',        score: 74, streak: 5  },
];

export default function Leaderboard() {
  return (
    <div className="min-h-screen bg-gray-950 text-white p-6 max-w-xl mx-auto">
      <h2 className="text-xl font-bold mb-6">Leaderboard</h2>
      {TEAM.map((u, i) => (
        <div key={u.name} className={"flex items-center gap-4 p-4 rounded-xl border mb-2 " + (u.name === 'You' ? 'border-indigo-500/30 bg-indigo-500/8' : 'border-white/8 bg-white/2')}>
          <span className="text-white/30 text-sm w-4">{i + 1}</span>
          <span className="font-semibold flex-1">{u.name}</span>
          <span className="text-white/40 text-sm">{u.streak}d</span>
          <span className="font-bold text-indigo-400">{u.score}%</span>
        </div>
      ))}
    </div>
  );
}`,
  },

  // ── INFRA ──────────────────────────────────────────────────────────────────
  {
    path: 'infra/docker-compose.yml',
    section: 'infra',
    lang: 'yaml',
    content: `version: '3.9'
services:
  backend:
    build: ../backend
    ports: ["3001:3001"]
    environment: { NODE_ENV: production, PORT: 3001, JWT_SECRET: \${JWT_SECRET} }
    restart: unless-stopped

  frontend:
    build: ../frontend
    ports: ["80:80"]
    depends_on: [backend]
    restart: unless-stopped`,
  },
  {
    path: 'infra/nginx.conf',
    section: 'infra',
    lang: 'nginx',
    content: `server {
    listen 80;
    root /usr/share/nginx/html;
    index index.html;
    location /         { try_files $uri $uri/ /index.html; }
    location /api/     { proxy_pass http://backend:3001; proxy_set_header Host $host; }
    location ~* \\.(js|css|png|ico|svg)$ { expires 1y; add_header Cache-Control "public,immutable"; }
}`,
  },
  {
    path: 'infra/railway.json',
    section: 'infra',
    lang: 'json',
    content: `{
  "$schema": "https://railway.app/railway.schema.json",
  "build": { "builder": "NIXPACKS" },
  "deploy": {
    "startCommand": "node src/server.js",
    "healthcheckPath": "/health",
    "restartPolicyType": "ON_FAILURE"
  }
}`,
  },
];

// ── Scaffold bash script (creates entire folder structure) ────────────────────
const SCAFFOLD = `#!/usr/bin/env bash
# behavior-engine-saas scaffold
# Run: bash scaffold.sh
# Creates the full folder structure and empty files.

set -e
ROOT="behavior-engine-saas"
mkdir -p $ROOT/{backend/src/{routes,engine,middleware,db,services},frontend/src/{pages,components},infra}

# Root
touch $ROOT/{package.json,.gitignore,.env.example,docker-compose.yml,README.md}

# Backend
touch $ROOT/backend/{package.json,.env.example,Dockerfile}
touch $ROOT/backend/src/{server.js,app.js}
touch $ROOT/backend/src/routes/{auth.js,tasks.js,crm.js,analytics.js}
touch $ROOT/backend/src/engine/{score.js,ai.js,behavior.js}
touch $ROOT/backend/src/middleware/auth.js
touch $ROOT/backend/src/db/memoryStore.js
touch $ROOT/backend/src/services/{crmService.js,aiService.js}

# Frontend
touch $ROOT/frontend/{package.json,vite.config.js,tailwind.config.js,index.html}
touch $ROOT/frontend/src/{main.jsx,App.jsx,index.css}
touch $ROOT/frontend/src/pages/{Login.jsx,Dashboard.jsx,Tasks.jsx,Leaderboard.jsx}

# Infra
touch $ROOT/infra/{docker-compose.yml,nginx.conf,railway.json}

echo "✅ Structure created at ./$ROOT"
echo "👉 Now paste file contents from the repo viewer"
echo "👉 Or: git clone https://github.com/you/behavior-engine-saas"`;

// ── Helpers ────────────────────────────────────────────────────────────────────
const SECTION_META = {
  root:     { color: '#a1a1aa', label: 'Root',     Icon: Archive   },
  backend:  { color: '#34d399', label: 'Backend',  Icon: Package   },
  frontend: { color: '#818cf8', label: 'Frontend', Icon: Layers    },
  infra:    { color: '#fbbf24', label: 'Infra',    Icon: Play      },
};

const SECTIONS = ['root', 'backend', 'frontend', 'infra'];

function CopyBtn({ text, size }) {
  const [c, setC] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setC(true); setTimeout(() => setC(false), 1800); }}
      className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold border transition-all shrink-0 ${
        c ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' : 'bg-white/5 border-white/10 text-white/35 hover:text-white/65'
      }`}>
      {c ? <><Check size={9} /> Copied</> : <><Copy size={9} /> Copy</>}
    </button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function ZipRepo() {
  const [openSections, setOpenSections] = useState(new Set(SECTIONS));
  const [selected,     setSelected]     = useState(MANIFEST[0].path);
  const [view,         setView]         = useState('files'); // 'files' | 'scaffold'

  const toggleSection = (s) => {
    const n = new Set(openSections);
    n.has(s) ? n.delete(s) : n.add(s);
    setOpenSections(n);
  };

  const activeFile = MANIFEST.find(f => f.path === selected) ?? MANIFEST[0];

  const copyAll = () => {
    const out = MANIFEST.map(f => `// ===== ${f.path} =====\n${f.content}`).join('\n\n');
    navigator.clipboard.writeText(out);
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white flex flex-col" style={{ height: '100vh' }}>

      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 py-2.5 border-b border-white/6 bg-[#0b0f1a] flex-wrap shrink-0">
        <Archive size={13} className="text-white/30" />
        <span className="text-white/50 text-xs font-mono font-semibold">behavior-engine-saas.zip</span>
        <span className="text-[9px] border border-white/10 text-white/25 px-1.5 py-0.5 rounded">{MANIFEST.length} files</span>
        <div className="flex-1" />
        {/* View toggle */}
        <div className="inline-flex p-0.5 bg-white/5 rounded-lg">
          {[['files','File Viewer'],['scaffold','Scaffold Script']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-3 py-1 rounded-md text-[10px] font-semibold transition-all ${view===v ? 'bg-white/10 text-white/80' : 'text-white/30 hover:text-white/55'}`}>
              {l}
            </button>
          ))}
        </div>
        <button onClick={copyAll} className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500 hover:bg-indigo-400 text-white text-[10px] font-bold rounded-lg transition-all">
          <Copy size={9} /> Copy All ({MANIFEST.length} files)
        </button>
      </div>

      {view === 'scaffold' ? (
        /* ── SCAFFOLD VIEW ── */
        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-2xl mx-auto space-y-4">
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">bash scaffold.sh</p>
              <p className="text-white/40 text-xs">Run this once to create the full folder structure. Then paste file contents from the viewer.</p>
            </div>
            <div className="relative">
              <div className="absolute top-3 right-3">
                <CopyBtn text={SCAFFOLD} />
              </div>
              <pre className="p-5 rounded-2xl border border-white/8 bg-black/40 text-[10px] text-emerald-300/80 font-mono leading-relaxed overflow-x-auto pr-16">{SCAFFOLD}</pre>
            </div>
            <div className="p-4 rounded-xl border border-indigo-500/20 bg-indigo-500/5">
              <p className="text-indigo-400 text-xs font-bold mb-1">Quick start after scaffolding</p>
              <div className="space-y-1 text-[10px] font-mono text-white/45">
                {[
                  'bash scaffold.sh',
                  'cd behavior-engine-saas',
                  '# Paste file contents from viewer (or git clone)',
                  'cd backend && npm install && npm run dev',
                  'cd ../frontend && npm install && npm run dev',
                ].map(l => <p key={l}>{l.startsWith('#') ? <span className="text-white/20">{l}</span> : <><span className="text-emerald-400">$</span> {l}</>}</p>)}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ── FILE VIEWER ── */
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar */}
          <div className="w-52 shrink-0 border-r border-white/6 bg-[#0b0f1a] overflow-y-auto">
            {SECTIONS.map(sec => {
              const meta = SECTION_META[sec];
              const SIcon = meta.Icon;
              const files = MANIFEST.filter(f => f.section === sec);
              const isOpen = openSections.has(sec);
              return (
                <div key={sec}>
                  <button onClick={() => toggleSection(sec)}
                    className="w-full flex items-center gap-2 px-3 py-2 hover:bg-white/4 transition-all">
                    {isOpen ? <ChevronDown size={9} className="text-white/20" /> : <ChevronRight size={9} className="text-white/20" />}
                    <SIcon size={10} style={{ color: meta.color }} />
                    <span className="text-[10px] font-bold" style={{ color: meta.color }}>{meta.label}</span>
                    <span className="ml-auto text-white/15 text-[8px]">{files.length}</span>
                  </button>
                  {isOpen && files.map(f => (
                    <button key={f.path} onClick={() => setSelected(f.path)}
                      className={`w-full flex items-center gap-2 pl-7 pr-3 py-1.5 text-left transition-all ${
                        selected === f.path ? 'bg-indigo-500/12 text-indigo-300' : 'text-white/35 hover:text-white/60 hover:bg-white/3'
                      }`}>
                      <FileCode size={9} className={selected === f.path ? 'text-indigo-400' : 'text-white/20'} />
                      <span className="text-[10px] truncate">{f.path.split('/').pop()}</span>
                    </button>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Code panel */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2 border-b border-white/6 bg-[#0c1018] shrink-0">
              <div className="flex items-center gap-2">
                <span style={{ color: SECTION_META[activeFile.section]?.color }} className="text-[8px] font-black uppercase">{activeFile.section}</span>
                <span className="text-white/20">/</span>
                <code className="text-white/40 text-[10px] font-mono">{activeFile.path}</code>
              </div>
              <CopyBtn text={activeFile.content} />
            </div>
            <div className="flex-1 overflow-auto p-5 bg-[#080c15]">
              <pre className="text-[10px] leading-relaxed text-emerald-300/75 font-mono whitespace-pre-wrap break-words">{activeFile.content}</pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
