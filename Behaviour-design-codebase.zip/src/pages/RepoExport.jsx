/**
 * RepoExport — GitHub-Ready Production Starter
 * Full file tree with copy-paste code for every critical file.
 * Structure: backend / frontend / mobile / shared / infra / docs
 */
import { useState } from 'react';
import {
  GitMerge, Copy, CheckCircle2, ChevronRight, ChevronDown,
  FolderOpen, Folder, FileCode, FileText, Zap, Terminal,
  Package, Shield, Database, Server, Cpu,
} from 'lucide-react';

// ── File tree + code ──────────────────────────────────────────────────────────
const REPO = [
  {
    name: 'backend',
    icon: Server,
    color: 'text-indigo-400',
    desc: 'Express + TypeScript API — production-ready',
    files: [
      {
        path: 'backend/src/server.ts',
        desc: 'Entry point — starts the HTTP server',
        code: `import app from "./app";
import { connectDB } from "./config/database";

const PORT = process.env.PORT || 3000;

async function bootstrap() {
  await connectDB();
  app.listen(PORT, () => {
    console.log(\`🔥 Behavior Engine API running on port \${PORT}\`);
    console.log(\`   Env: \${process.env.NODE_ENV ?? 'development'}\`);
  });
}

bootstrap().catch(console.error);`,
      },
      {
        path: 'backend/src/app.ts',
        desc: 'Express app setup with routes + middleware',
        code: `import express from "express";
import cors from "cors";
import helmet from "helmet";
import authRoutes from "./auth/routes";
import engineRoutes from "./engine/routes";
import taskRoutes from "./tasks/routes";
import analyticsRoutes from "./analytics/routes";
import crmRoutes from "./crm/routes";
import { errorHandler } from "./middleware/errorHandler";
import { rateLimiter } from "./middleware/rateLimiter";
import { authMiddleware } from "./auth/middleware";

const app = express();

// Security
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL }));
app.use(rateLimiter);

// Parsing
app.use(express.json({ limit: '10kb' }));

// Public routes
app.use("/auth",      authRoutes);

// Protected routes
app.use(authMiddleware);
app.use("/engine",    engineRoutes);
app.use("/tasks",     taskRoutes);
app.use("/analytics", analyticsRoutes);
app.use("/crm",       crmRoutes);

// Error handler (always last)
app.use(errorHandler);

export default app;`,
      },
      {
        path: 'backend/src/engine/core.ts',
        desc: 'Behavior scoring engine — calculateScore + status',
        code: `export interface ActionLog {
  userId: string;
  taskId: string;
  points: number;
  loggedAt: Date;
  tenantId: string;
}

export type BehaviorStatus = "GREEN" | "YELLOW" | "RED";

export function calculateScore(logs: ActionLog[]): number {
  return logs.reduce((sum, l) => sum + l.points, 0);
}

export function getStatus(score: number, target = 40): BehaviorStatus {
  if (score >= target)           return "GREEN";
  if (score >= target * 0.5)     return "YELLOW";
  return "RED";
}

export function detectDropPattern(weekScores: number[]): string {
  const badDays = weekScores
    .map((s, i) => ({ day: i, score: s }))
    .filter(d => d.score < 20);

  if (!badDays.length) return "none";
  const avgBadDay = badDays.reduce((s, d) => s + d.day, 0) / badDays.length;
  if (avgBadDay <= 1)  return "monday";
  if (avgBadDay >= 4)  return "end-of-week";
  return "midweek";
}

export function calcStreak(weekScores: number[], target = 40): number {
  let streak = 0;
  for (let i = weekScores.length - 1; i >= 0; i--) {
    if (weekScores[i] >= target * 0.5) streak++;
    else break;
  }
  return streak;
}`,
      },
      {
        path: 'backend/src/auth/routes.ts',
        desc: 'JWT authentication — register + login',
        code: `import { Router } from "express";
import { z } from "zod";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "../config/database";

const router = Router();

const RegisterSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(8),
  tenantId: z.string(),
  role:     z.enum(["user", "manager", "admin"]).default("user"),
});

router.post("/register", async (req, res) => {
  const body = RegisterSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json(body.error);

  const hash = await bcrypt.hash(body.data.password, 12);
  const user = await db.user.create({
    data: { ...body.data, password: hash }
  });

  const token = jwt.sign(
    { userId: user.id, tenantId: user.tenantId, role: user.role },
    process.env.JWT_SECRET!,
    { expiresIn: "7d" }
  );

  res.json({ token, user: { id: user.id, email: user.email, role: user.role } });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await db.user.findUnique({ where: { email } });
  if (!user || !(await bcrypt.compare(password, user.password)))
    return res.status(401).json({ error: "Invalid credentials" });

  const token = jwt.sign(
    { userId: user.id, tenantId: user.tenantId, role: user.role },
    process.env.JWT_SECRET!,
    { expiresIn: "7d" }
  );

  res.json({ token });
});

export default router;`,
      },
      {
        path: 'backend/src/ai/coach.ts',
        desc: 'AI coaching service — single + multi-agent',
        code: `import { BehaviorStatus } from "../engine/core";

interface UserContext {
  score: number;
  status: BehaviorStatus;
  weekScores: number[];
  streak: number;
  coachingStyle: "discipline" | "strategy" | "motivation";
  dropPattern?: string;
}

// Single-agent coach (v1)
export function coach(ctx: UserContext): string {
  if (ctx.score < 20) return "Focus on 1 action only today.";
  if (ctx.streak === 0) return "Streak broken. Reset and execute 1 task now.";
  return "Maintain execution rhythm. You are on track.";
}

// Multi-agent orchestrator (v2)
export async function runAgents(ctx: UserContext) {
  const [coaching, analysis, risk, performance] = await Promise.all([
    coachAgent(ctx),
    analystAgent(ctx),
    riskAgent(ctx),
    performanceAgent(ctx),
  ]);

  // Orchestrator priority logic
  const priority = risk.riskLevel === "critical" ? risk :
                   coaching.status === "RED"     ? coaching : coaching;

  return { coaching, analysis, risk, performance, priority };
}

async function coachAgent(ctx: UserContext) {
  // Personality-based coaching logic
  return { message: "Execution confirmed.", action: "Maintain pace.", riskLevel: "low" };
}

async function analystAgent(ctx: UserContext) {
  const avg = ctx.weekScores.reduce((s, v) => s + v, 0) / ctx.weekScores.length;
  const trend = ctx.weekScores.slice(-1)[0] > avg ? "improving" : "declining";
  return { avg, trend, pattern: ctx.dropPattern };
}

async function riskAgent(ctx: UserContext) {
  const riskScore = (ctx.status === "RED" ? 30 : 0) + (ctx.streak === 0 ? 25 : 0);
  const riskLevel = riskScore >= 50 ? "critical" : riskScore >= 25 ? "high" : "low";
  return { riskScore, riskLevel };
}

async function performanceAgent(ctx: UserContext) {
  const adj = ctx.score > 60 ? "increase" : ctx.score < 20 ? "reduce" : "maintain";
  return { difficultyAdj: adj };
}`,
      },
      {
        path: 'backend/package.json',
        desc: 'Node.js dependencies for production backend',
        code: `{
  "name": "behavior-engine-api",
  "version": "1.0.0",
  "scripts": {
    "dev":   "tsx watch src/server.ts",
    "build": "tsc",
    "start": "node dist/server.js",
    "db:push":    "prisma db push",
    "db:migrate": "prisma migrate deploy"
  },
  "dependencies": {
    "express":      "^4.18.2",
    "cors":         "^2.8.5",
    "helmet":       "^7.1.0",
    "bcryptjs":     "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "zod":          "^3.22.4",
    "@prisma/client": "^5.10.0",
    "express-rate-limit": "^7.1.5"
  },
  "devDependencies": {
    "typescript": "^5.3.3",
    "tsx":        "^4.7.0",
    "prisma":     "^5.10.0",
    "@types/express":      "^4.17.21",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/bcryptjs":     "^2.4.6"
  }
}`,
      },
    ],
  },
  {
    name: 'frontend',
    icon: FileCode,
    color: 'text-purple-400',
    desc: 'Vite + React + Tailwind — production UI',
    files: [
      {
        path: 'frontend/src/store/AuthContext.tsx',
        desc: 'JWT auth context — login, register, logout, tenants',
        code: `import React, { createContext, useContext, useState, useCallback } from "react";
import axios from "axios";

interface User { id: string; name: string; email: string; role: string; tenantId: string; }
interface AuthContextType {
  user: User | null;
  token: string | null;
  login:    (email: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout:   () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>(null!);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user,  setUser]  = useState<User | null>(() => {
    try { return JSON.parse(localStorage.getItem("be_user") ?? "null"); } catch { return null; }
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("be_token"));

  const login = useCallback(async (email: string, password: string) => {
    const res = await axios.post("/auth/login", { email, password });
    localStorage.setItem("be_token", res.data.token);
    localStorage.setItem("be_user",  JSON.stringify(res.data.user));
    axios.defaults.headers.common.Authorization = \`Bearer \${res.data.token}\`;
    setToken(res.data.token);
    setUser(res.data.user);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("be_token");
    localStorage.removeItem("be_user");
    delete axios.defaults.headers.common.Authorization;
    setToken(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isAuthenticated: !!token, register: async () => {} }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);`,
      },
      {
        path: 'frontend/.env.example',
        desc: 'Environment variables needed for deployment',
        code: `# Frontend environment variables
VITE_API_URL=https://api.behaviorengine.io
VITE_APP_NAME=Behavior Engine
VITE_STRIPE_KEY=pk_live_...

# Copy to .env.local and fill in values`,
      },
      {
        path: 'frontend/vite.config.ts',
        desc: 'Vite config with proxy for local dev',
        code: `import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      "/auth":      "http://localhost:3000",
      "/engine":    "http://localhost:3000",
      "/tasks":     "http://localhost:3000",
      "/analytics": "http://localhost:3000",
    },
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ["react", "react-dom", "react-router-dom"],
          charts: ["recharts"],
        },
      },
    },
  },
});`,
      },
    ],
  },
  {
    name: 'shared',
    icon: Package,
    color: 'text-emerald-400',
    desc: 'Shared types + constants used by all packages',
    files: [
      {
        path: 'shared/types/index.ts',
        desc: 'All shared TypeScript interfaces',
        code: `export type BehaviorStatus = "GREEN" | "YELLOW" | "RED";
export type CoachingStyle = "discipline" | "strategy" | "motivation";
export type UserRole = "user" | "manager" | "admin";
export type LeadStatus = "new" | "contacted" | "pilot" | "paid" | "churned";

export interface User {
  id:          string;
  name:        string;
  email:       string;
  role:        UserRole;
  tenantId:    string;
  pluginId:    string;
  coachStyle?: CoachingStyle;
  joinedAt:    Date;
}

export interface ActionLog {
  id:       string;
  userId:   string;
  taskId:   string;
  points:   number;
  date:     string;
  loggedAt: Date;
}

export interface BehaviorProfile {
  consistency:        "low" | "medium" | "high";
  dropPattern:        string;
  bestTime:           string | null;
  paceType:           string;
  responseToPressure: "positive" | "neutral" | "negative";
}

export interface Lead {
  id:         string;
  name:       string;
  company:    string;
  email:      string;
  status:     LeadStatus;
  source:     string;
  value:      number;
  lastAction: Date;
  tenantId:   string;
}

export interface AgentResult {
  agentId:    string;
  message?:   string;
  action?:    string;
  riskLevel?: string;
  confidence: number;
  timestamp:  string;
}`,
      },
    ],
  },
  {
    name: 'infra',
    icon: Database,
    color: 'text-orange-400',
    desc: 'Docker + deployment configuration',
    files: [
      {
        path: 'infra/docker-compose.yml',
        desc: 'Docker Compose for local dev (API + Postgres + Redis)',
        code: `version: "3.9"

services:
  api:
    build: ./backend
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://postgres:password@db:5432/behaviorengine
      REDIS_URL:    redis://redis:6379
      JWT_SECRET:   your-secret-here
      NODE_ENV:     development
    depends_on:
      - db
      - redis

  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_PASSWORD: password
      POSTGRES_DB:       behaviorengine
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  pgdata:`,
      },
      {
        path: 'infra/Dockerfile.backend',
        desc: 'Production Docker image for the API',
        code: `FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./
EXPOSE 3000
CMD ["node", "dist/server.js"]`,
      },
    ],
  },
  {
    name: 'docs',
    icon: FileText,
    color: 'text-cyan-400',
    desc: 'README + deployment guide',
    files: [
      {
        path: 'README.md',
        desc: 'Root README — setup instructions',
        code: `# Behavior Engine SaaS

> The Execution Operating System for Teams

## What This Is

Behavior Engine converts daily team actions into measurable performance through
structured behavior systems and AI coaching.

## Quick Start

\`\`\`bash
# 1. Clone
git clone https://github.com/yourorg/behavior-engine.git
cd behavior-engine

# 2. Install
npm install        # root (workspaces)
# or manually:
cd backend && npm install
cd ../frontend && npm install

# 3. Configure
cp infra/.env.example backend/.env
# Fill in: DATABASE_URL, JWT_SECRET, STRIPE_KEY

# 4. Database
cd backend
npx prisma migrate deploy

# 5. Start
# Terminal 1:
cd backend && npm run dev

# Terminal 2:
cd frontend && npm run dev
\`\`\`

## Stack

| Layer    | Tech                          |
|----------|-------------------------------|
| Frontend | React 18 + Vite + Tailwind v4 |
| Backend  | Express + TypeScript          |
| Database | PostgreSQL + Prisma ORM       |
| Cache    | Redis                         |
| AI       | Multi-agent engine (built-in) |
| Auth     | JWT + bcrypt                  |
| Payments | Stripe                        |

## Architecture

\`\`\`
frontend (React SPA)
  ↕ REST API
backend (Express API)
  ↕
  ├── engine/     (scoring, patterns, streak)
  ├── ai/         (coach + multi-agent)
  ├── auth/       (JWT, roles, tenants)
  ├── crm/        (leads, pipeline, automation)
  └── analytics/  (trends, reports)
  ↕
PostgreSQL + Redis
\`\`\`

## Deployment

See \`infra/\` for Docker Compose setup.
Deploy to: Railway, Render, Fly.io, or VPS.

## License
MIT`,
      },
    ],
  },
];

// ── Component ─────────────────────────────────────────────────────────────────
function FileNode({ file, isOpen, onToggle }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(file.code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`rounded-xl border overflow-hidden transition-all ${isOpen ? 'border-indigo-500/25 bg-indigo-500/4' : 'border-white/6 bg-white/1 hover:border-white/10'}`}>
      <button onClick={onToggle}
        className="w-full flex items-center gap-3 px-4 py-3 text-left">
        <FileCode size={13} className="text-white/30 shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-white/80 text-xs font-mono">{file.path}</p>
          <p className="text-white/25 text-[10px] mt-0.5">{file.desc}</p>
        </div>
        {isOpen ? <ChevronDown size={12} className="text-white/25 shrink-0" /> : <ChevronRight size={12} className="text-white/25 shrink-0" />}
      </button>
      {isOpen && (
        <div className="border-t border-white/5">
          <div className="flex items-center justify-between px-4 py-2 bg-black/20">
            <span className="text-white/20 text-[9px] font-mono">{file.path}</span>
            <button onClick={copy}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-[9px] font-semibold transition-all hover:bg-indigo-500/20">
              {copied ? <><CheckCircle2 size={9} /> Copied!</> : <><Copy size={9} /> Copy</>}
            </button>
          </div>
          <pre className="px-4 py-3 text-[10px] text-emerald-400/80 leading-relaxed overflow-x-auto scrollbar-hide max-h-64 font-mono">
            {file.code}
          </pre>
        </div>
      )}
    </div>
  );
}

export default function RepoExport() {
  const [openSection, setOpenSection] = useState('backend');
  const [openFile, setOpenFile]       = useState(null);

  const allFiles = REPO.flatMap(s => s.files);
  const [copiedAll, setCopiedAll] = useState(false);

  const copyAll = () => {
    const all = allFiles.map(f => `// === ${f.path} ===\n${f.code}`).join('\n\n');
    navigator.clipboard.writeText(all).catch(() => {});
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <GitMerge size={15} className="text-white/60" />
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest">GitHub-Ready Repo</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Production Starter Kit</h1>
            <p className="text-white/35 text-sm">Copy-paste production code for every layer of the stack.</p>
          </div>
          <button onClick={copyAll}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:border-white/20 text-white/50 hover:text-white/75 text-xs transition-all">
            {copiedAll ? <><CheckCircle2 size={12} className="text-green-400" /> Copied All</> : <><Copy size={12} /> Copy All Files</>}
          </button>
        </div>

        {/* Repo tree overview */}
        <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-5">
          <div className="flex items-center gap-2 mb-3">
            <FolderOpen size={14} className="text-indigo-400" />
            <p className="text-white font-bold text-sm">behavior-engine-saas/</p>
            <span className="ml-auto text-white/20 text-[10px]">{allFiles.length} files · production-ready</span>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
            {REPO.map(({ name, icon: Icon, color, desc, files }) => (
              <button key={name} onClick={() => setOpenSection(openSection === name ? null : name)}
                className={`flex items-start gap-3 p-3 rounded-xl border text-left transition-all ${
                  openSection === name ? `border-${color.replace('text-', '').replace('-400', '-500/30')} bg-${color.replace('text-', '').replace('-400', '-500/8')}` : 'border-white/6 bg-white/2 hover:border-white/10'
                }`}>
                <Icon size={14} className={`${color} mt-0.5 shrink-0`} />
                <div className="min-w-0">
                  <p className={`text-xs font-bold ${openSection === name ? color : 'text-white/70'}`}>{name}/</p>
                  <p className="text-white/20 text-[9px] mt-0.5 leading-snug">{desc}</p>
                  <p className={`text-[8px] mt-1 ${color}`}>{files.length} files</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Section files */}
        {REPO.map(section => (
          openSection === section.name && (
            <div key={section.name} className="space-y-2">
              <div className="flex items-center gap-2 px-1">
                <section.icon size={13} className={section.color} />
                <p className={`text-xs font-bold uppercase tracking-widest ${section.color}`}>{section.name}/</p>
                <span className="text-white/15 text-[9px]">{section.desc}</span>
              </div>
              {section.files.map(file => (
                <FileNode
                  key={file.path}
                  file={file}
                  isOpen={openFile === file.path}
                  onToggle={() => setOpenFile(openFile === file.path ? null : file.path)}
                />
              ))}
            </div>
          )
        ))}

        {/* Setup instructions */}
        <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/4 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Terminal size={13} className="text-emerald-400" />
            <p className="text-emerald-400 font-bold text-sm">Quick Setup Commands</p>
          </div>
          <div className="space-y-2">
            {[
              { cmd: 'git clone https://github.com/yourorg/behavior-engine.git', desc: '1. Clone the repo' },
              { cmd: 'cd behavior-engine && npm install',                         desc: '2. Install all deps' },
              { cmd: 'cp infra/.env.example backend/.env',                        desc: '3. Set environment vars' },
              { cmd: 'cd backend && npx prisma migrate deploy',                   desc: '4. Push DB schema' },
              { cmd: 'npm run dev',                                                desc: '5. Start dev servers' },
            ].map(({ cmd, desc }) => (
              <div key={cmd} className="flex items-center gap-3">
                <span className="text-white/20 text-[9px] w-28 shrink-0">{desc}</span>
                <code className="flex-1 text-[10px] bg-black/30 border border-white/6 rounded-lg px-3 py-1.5 text-emerald-400/80 font-mono">
                  {cmd}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* Stack overview */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Frontend',  value: 'React + Vite', color: 'text-purple-400',  icon: FileCode   },
            { label: 'Backend',   value: 'Express + TS',  color: 'text-indigo-400', icon: Server     },
            { label: 'Database',  value: 'PostgreSQL',    color: 'text-orange-400', icon: Database   },
            { label: 'AI Engine', value: 'Multi-Agent',   color: 'text-emerald-400',icon: Cpu        },
          ].map(({ label, value, color, icon: Icon }) => (
            <div key={label} className="p-4 rounded-xl bg-white/2 border border-white/6 text-center">
              <Icon size={15} className={`${color} mx-auto mb-2`} />
              <p className={`text-sm font-bold ${color}`}>{value}</p>
              <p className="text-white/25 text-[10px]">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
