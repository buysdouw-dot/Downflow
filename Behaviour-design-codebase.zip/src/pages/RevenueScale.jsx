/**
 * RevenueScale — Revenue Scaling Model to $100K/Month
 * MRR projections, pricing tiers, growth assumptions, cohort retention.
 * Interactive sliders. Visual milestones. Investor-ready metrics.
 */
import { useState, useMemo } from 'react';
import {
  DollarSign, TrendingUp, Users, Target, ArrowRight,
  Zap, CheckCircle2, ChevronRight, BarChart2, RefreshCw,
} from 'lucide-react';

// ── Milestones ─────────────────────────────────────────────────────────────────
const MILESTONES = [
  { mrr: 1000,   label: '$1K MRR',    badge: 'Ramen Profitable',   color: '#a1a1aa', border: 'border-white/10',        bg: 'bg-white/2',        users: 20,   teams: 2,   desc: 'Proof of concept. Someone pays you.' },
  { mrr: 5000,   label: '$5K MRR',    badge: 'Real Traction',      color: '#818cf8', border: 'border-indigo-500/20',   bg: 'bg-indigo-500/5',   users: 100,  teams: 10,  desc: 'You can pay yourself. Investors notice.' },
  { mrr: 10000,  label: '$10K MRR',   badge: 'Fundable',           color: '#a78bfa', border: 'border-purple-500/20',   bg: 'bg-purple-500/5',   users: 200,  teams: 20,  desc: 'YC application territory. Press starts.' },
  { mrr: 25000,  label: '$25K MRR',   badge: 'Series Seed',        color: '#22d3ee', border: 'border-cyan-500/20',     bg: 'bg-cyan-500/5',     users: 500,  teams: 50,  desc: '$300K ARR. Seed round possible.' },
  { mrr: 50000,  label: '$50K MRR',   badge: '$600K ARR',          color: '#34d399', border: 'border-emerald-500/20',  bg: 'bg-emerald-500/5',  users: 1000, teams: 100, desc: 'Series A conversations begin.' },
  { mrr: 100000, label: '$100K MRR',  badge: '$1.2M ARR',          color: '#fbbf24', border: 'border-yellow-500/20',   bg: 'bg-yellow-500/5',   users: 2000, teams: 200, desc: 'Series A territory. Hire a team.' },
];

// ── Pricing tiers ─────────────────────────────────────────────────────────────
const TIERS = [
  { id: 'starter',    label: 'Starter',    price: 10, seats: 1,   features: ['Daily score','AI coaching','Basic tasks','Mobile app'],                    color: '#a1a1aa' },
  { id: 'pro',        label: 'Pro',        price: 30, seats: 1,   features: ['Everything in Starter','Team leaderboard','Analytics','CRM integration'],   color: '#818cf8' },
  { id: 'team',       label: 'Team',       price: 20, seats: 'up to 25 seats', features: ['Everything in Pro','Admin dashboard','Custom tasks','Priority support'], color: '#34d399', perSeat: true, minSeats: 5 },
  { id: 'enterprise', label: 'Enterprise', price: 500, seats: 'unlimited',      features: ['Everything in Team','SLA','Custom AI model','Dedicated CSM'], color: '#fbbf24' },
];

// ── Growth levers ─────────────────────────────────────────────────────────────
const LEVERS = [
  {
    id: 'viral',
    label: 'Viral Coefficient K',
    desc: 'How many new users each user brings in',
    impact: 'Doubles growth speed at K=0.5',
    low: 0, high: 1, step: 0.05, fmt: (v) => v.toFixed(2),
    effect: (mrr, k) => mrr * (1 + k),
  },
  {
    id: 'churn',
    label: 'Monthly Churn Rate',
    desc: 'Percentage of users who cancel each month',
    impact: '5% churn = 60% annual retention',
    low: 1, high: 20, step: 0.5, fmt: (v) => v.toFixed(1) + '%',
    effect: (mrr, c) => mrr * (1 - c / 100),
  },
  {
    id: 'expansion',
    label: 'Expansion Revenue',
    desc: 'Extra MRR from upsells/upgrades each month',
    impact: '10% NRR boost = massive LTV change',
    low: 0, high: 20, step: 1, fmt: (v) => v + '%',
    effect: (mrr, e) => mrr * (1 + e / 100),
  },
  {
    id: 'arpu',
    label: 'ARPU ($/user/mo)',
    desc: 'Average revenue per user monthly',
    impact: '$10 → $50 ARPU = 5x revenue same users',
    low: 5, high: 100, step: 5, fmt: (v) => '$' + v,
    effect: null,
  },
];

// ── Month projector ────────────────────────────────────────────────────────────
function projectMRR({ startUsers, monthlyNewUsers, arpu, churn, viral, expansion, months = 24 }) {
  const rows = [];
  let users = startUsers;
  let mrr   = users * arpu;

  for (let m = 1; m <= months; m++) {
    const newUsers     = Math.round(monthlyNewUsers * (1 + viral));
    const churned      = Math.round(users * (churn / 100));
    users              = Math.max(0, users + newUsers - churned);
    const baseMRR      = users * arpu;
    mrr                = baseMRR * (1 + expansion / 100);
    rows.push({ month: m, users: Math.round(users), mrr: Math.round(mrr), new: newUsers, churned });
  }
  return rows;
}

// ── Bar component ─────────────────────────────────────────────────────────────
function Bar({ value, max, color }) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="flex-1 h-1.5 bg-white/8 rounded-full overflow-hidden">
      <div className="h-full rounded-full transition-all duration-500" style={{ width: pct + '%', background: color }} />
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function RevenueScale() {
  const [view, setView] = useState('model'); // 'model' | 'milestones' | 'playbook'

  // Model params
  const [startUsers,      setStartUsers]      = useState(10);
  const [monthlyNewUsers, setMonthlyNewUsers]  = useState(20);
  const [arpu,            setArpu]             = useState(25);
  const [churn,           setChurn]            = useState(5);
  const [viral,           setViral]            = useState(0.2);
  const [expansion,       setExpansion]        = useState(5);

  const rows = useMemo(() =>
    projectMRR({ startUsers, monthlyNewUsers, arpu, churn, viral, expansion }),
    [startUsers, monthlyNewUsers, arpu, churn, viral, expansion]
  );

  const maxMRR = Math.max(...rows.map(r => r.mrr));
  const month12 = rows[11];
  const month24 = rows[23];
  const currentMilestone = MILESTONES.filter(m => month24.mrr >= m.mrr).pop() ?? MILESTONES[0];

  const keyMetrics = [
    { label: 'Month 12 MRR',  value: '$' + (month12?.mrr ?? 0).toLocaleString(), color: 'text-indigo-400' },
    { label: 'Month 24 MRR',  value: '$' + (month24?.mrr ?? 0).toLocaleString(), color: 'text-emerald-400' },
    { label: 'Month 24 Users',value: (month24?.users ?? 0).toLocaleString(),       color: 'text-cyan-400'    },
    { label: '24-mo ARR',     value: '$' + ((month24?.mrr ?? 0) * 12).toLocaleString(), color: 'text-yellow-400' },
  ];

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <DollarSign size={14} className="text-yellow-400" />
              <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest">Revenue Model</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Scale to $100K/Month</h1>
            <p className="text-white/35 text-sm">Adjust your assumptions. See the 24-month projection instantly.</p>
          </div>

          {/* Headline metric */}
          <div className="p-4 rounded-2xl border border-yellow-500/20 bg-yellow-500/5">
            <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">Month 24 MRR</p>
            <p className="text-3xl font-black text-yellow-400">${(month24?.mrr ?? 0).toLocaleString()}</p>
            <p className="text-white/25 text-[9px] mt-1">{currentMilestone.badge}</p>
          </div>
        </div>

        {/* View tabs */}
        <div className="inline-flex p-1 bg-white/4 rounded-xl border border-white/6">
          {[['model','Revenue Model'],['milestones','Milestones'],['playbook','Playbook']].map(([v,l]) => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${view===v ? 'bg-yellow-500 text-black' : 'text-white/35 hover:text-white/60'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* ── MODEL ──────────────────────────────────────────────── */}
        {view === 'model' && (
          <div className="space-y-6">
            {/* KPI row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {keyMetrics.map(m => (
                <div key={m.label} className="p-4 rounded-xl border border-white/8 bg-white/2">
                  <p className="text-white/25 text-[9px] uppercase tracking-widest mb-1">{m.label}</p>
                  <p className={`text-xl font-black ${m.color}`}>{m.value}</p>
                </div>
              ))}
            </div>

            {/* Sliders */}
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="p-5 rounded-2xl border border-white/8 bg-white/2 space-y-4">
                <p className="text-white/25 text-[9px] uppercase tracking-widest">Growth Assumptions</p>
                {[
                  { label: `Starting users: ${startUsers}`,           min:1,  max:200, val:startUsers,      set:setStartUsers,      color:'#818cf8' },
                  { label: `New users/month: ${monthlyNewUsers}`,     min:1,  max:500, val:monthlyNewUsers,  set:setMonthlyNewUsers,  color:'#34d399' },
                  { label: `ARPU: $${arpu}/user/mo`,                  min:5,  max:200, val:arpu,             set:setArpu,             color:'#fbbf24' },
                  { label: `Monthly churn: ${churn}%`,                min:0.5,max:20,  val:churn,            set:setChurn,            color:'#f87171', step:0.5 },
                  { label: `Viral coefficient: ${viral.toFixed(2)}x`, min:0,  max:1,   val:viral,            set:setViral,            color:'#a78bfa', step:0.05 },
                  { label: `Monthly expansion: +${expansion}%`,       min:0,  max:20,  val:expansion,        set:setExpansion,        color:'#22d3ee' },
                ].map(({ label, min, max, val, set, color, step = 1 }) => (
                  <div key={label}>
                    <div className="flex justify-between mb-0.5">
                      <span className="text-white/40 text-[10px]">{label}</span>
                    </div>
                    <input type="range" min={min} max={max} step={step} value={val} onChange={e => set(+e.target.value)}
                      className="w-full cursor-pointer" style={{ accentColor: color }} />
                  </div>
                ))}
              </div>

              {/* Mini chart — bar chart of MRR growth */}
              <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
                <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">MRR Projection (24 months)</p>
                <div className="flex items-end gap-1 h-36">
                  {rows.map((r, i) => {
                    const pct = maxMRR > 0 ? (r.mrr / maxMRR) * 100 : 0;
                    const isMilestone = MILESTONES.some(m => Math.abs(r.mrr - m.mrr) < m.mrr * 0.1);
                    return (
                      <div key={i} className="flex-1 flex flex-col items-center gap-0.5 group relative">
                        <div
                          className="w-full rounded-sm transition-all duration-300"
                          style={{
                            height: `${Math.max(2, pct)}%`,
                            background: isMilestone ? '#fbbf24' : i < 6 ? '#818cf8' : i < 12 ? '#a78bfa' : '#34d399',
                            opacity: 0.7,
                          }}
                        />
                        {(i === 0 || i === 5 || i === 11 || i === 17 || i === 23) && (
                          <span className="text-white/20 text-[7px]">M{r.month}</span>
                        )}
                        {/* Tooltip */}
                        <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 bg-black/90 border border-white/10 rounded-lg px-2 py-1 text-[8px] text-white/80 font-mono whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-10 transition-all">
                          M{r.month}: ${r.mrr.toLocaleString()}
                          <br />{r.users} users
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="flex justify-between mt-2">
                  <span className="text-white/20 text-[8px]">Month 1</span>
                  <span className="text-white/20 text-[8px]">Month 24</span>
                </div>
              </div>
            </div>

            {/* Monthly table (first 12 months) */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Month-by-Month (first 12)</p>
              <div className="overflow-x-auto">
                <table className="w-full text-[10px]">
                  <thead>
                    <tr className="border-b border-white/6">
                      {['Mo','MRR','vs prev','Users','New','Churned'].map(h => (
                        <th key={h} className="text-left py-2 px-3 text-white/25 font-semibold uppercase tracking-widest text-[8px]">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.slice(0, 12).map((r, i) => {
                      const prev  = i > 0 ? rows[i - 1].mrr : startUsers * arpu;
                      const delta = r.mrr - prev;
                      const pct   = prev > 0 ? Math.round((delta / prev) * 100) : 0;
                      const milestone = MILESTONES.find(m => r.mrr >= m.mrr && (i === 0 || rows[i-1].mrr < m.mrr));
                      return (
                        <tr key={r.month} className={`border-b border-white/4 ${milestone ? 'bg-yellow-500/5' : 'hover:bg-white/2'}`}>
                          <td className="py-2 px-3 text-white/30 font-mono">{r.month}</td>
                          <td className="py-2 px-3 text-white/70 font-bold">${r.mrr.toLocaleString()}</td>
                          <td className={`py-2 px-3 font-semibold ${delta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                            {delta >= 0 ? '+' : ''}{pct}%
                          </td>
                          <td className="py-2 px-3 text-white/50">{r.users.toLocaleString()}</td>
                          <td className="py-2 px-3 text-emerald-400/70">+{r.new}</td>
                          <td className="py-2 px-3 text-red-400/70">-{r.churned}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ── MILESTONES ─────────────────────────────────────────── */}
        {view === 'milestones' && (
          <div className="space-y-4">
            {MILESTONES.map(m => {
              const reached = month24.mrr >= m.mrr;
              const nearPct = Math.min(100, Math.round((month24.mrr / m.mrr) * 100));
              return (
                <div key={m.mrr} className={`p-5 rounded-2xl border transition-all ${reached ? `${m.border} ${m.bg}` : 'border-white/6 bg-white/2'}`}>
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-2xl font-black" style={{ color: reached ? m.color : 'rgba(255,255,255,0.25)' }}>{m.label}</p>
                        <span className="text-[8px] font-black px-1.5 py-0.5 rounded border"
                          style={{ color: m.color, borderColor: m.color + '30', background: m.color + '10' }}>{m.badge}</span>
                        {reached && <CheckCircle2 size={14} style={{ color: m.color }} />}
                      </div>
                      <p className={`text-xs ${reached ? 'text-white/55' : 'text-white/25'}`}>{m.desc}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-white/25 mb-1">~{m.users} users · {m.teams} teams</p>
                      {!reached && (
                        <div className="w-28">
                          <div className="flex justify-between text-[8px] text-white/20 mb-0.5">
                            <span>Progress</span><span>{nearPct}%</span>
                          </div>
                          <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                            <div className="h-full rounded-full transition-all" style={{ width: nearPct + '%', background: m.color }} />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── PLAYBOOK ───────────────────────────────────────────── */}
        {view === 'playbook' && (
          <div className="space-y-5">
            {[
              {
                phase: '$0 → $10K MRR',
                color: '#818cf8',
                border: 'border-indigo-500/20',
                bg: 'bg-indigo-500/5',
                moves: [
                  ['Do things that don\'t scale', 'Onboard every user manually. Learn their exact pain. This is your product roadmap.'],
                  ['Charge from day 1', 'Even $10/mo. People who pay are 10x more engaged than free users.'],
                  ['ARPU > user count', 'One team at $500/mo beats 50 individual $10/mo users. Go B2B early.'],
                  ['Obsess over churn', 'Losing 10% of users monthly means you\'re refilling a leaking bucket.'],
                ],
              },
              {
                phase: '$10K → $50K MRR',
                color: '#34d399',
                border: 'border-emerald-500/20',
                bg: 'bg-emerald-500/5',
                moves: [
                  ['Build a sales motion', 'Document what works: outreach → demo → pilot → close. Hire someone to run it.'],
                  ['Raise prices on new customers', 'Your first 50 customers are paying alpha pricing. New customers pay 2x.'],
                  ['Add annual plans', 'Annual = 2 months free to customer = 30% less churn for you. Always offer it.'],
                  ['NRR > 100%', 'Net Revenue Retention above 100% means you grow even with zero new customers.'],
                ],
              },
              {
                phase: '$50K → $100K MRR',
                color: '#fbbf24',
                border: 'border-yellow-500/20',
                bg: 'bg-yellow-500/5',
                moves: [
                  ['Hire for distribution', 'Content, sales, partnerships. Your job shifts to hiring and strategy.'],
                  ['Land + expand', 'Start with 5 seats per company. Expand to 50. Enterprise tier unlocks.'],
                  ['Build a moat', '90 days of behavioral data per user = uncopiable. Make sure that data is yours.'],
                  ['Raise Series A', '$1.2M ARR at 3x+ growth = fundable. Put the model in front of investors.'],
                ],
              },
            ].map(({ phase, color, border, bg, moves }) => (
              <div key={phase} className={`p-5 rounded-2xl border ${border} ${bg}`}>
                <p className="text-sm font-black mb-4" style={{ color }}>{phase}</p>
                <div className="grid lg:grid-cols-2 gap-3">
                  {moves.map(([title, desc]) => (
                    <div key={title} className="flex gap-2">
                      <ChevronRight size={11} style={{ color }} className="shrink-0 mt-0.5" />
                      <div>
                        <span className="text-white/65 text-xs font-semibold">{title}: </span>
                        <span className="text-white/35 text-xs">{desc}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            {/* LTV / CAC */}
            <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">The Only Two Numbers That Matter</p>
              <div className="grid lg:grid-cols-2 gap-4">
                {[
                  { label: 'LTV (Lifetime Value)', formula: 'ARPU / Churn Rate', example: `$${arpu} / ${churn}% = $${Math.round(arpu / (churn / 100)).toLocaleString()} per user`, color: '#34d399' },
                  { label: 'CAC (Customer Acq. Cost)', formula: 'Sales + Marketing spend / New customers', example: 'Target: LTV / CAC > 3x for healthy SaaS', color: '#818cf8' },
                ].map(({ label, formula, example, color }) => (
                  <div key={label} className="p-4 rounded-xl border border-white/8 bg-black/20">
                    <p className="text-xs font-bold mb-1" style={{ color }}>{label}</p>
                    <code className="text-[10px] text-white/40 font-mono">{formula}</code>
                    <p className="text-white/55 text-xs mt-2 font-semibold">{example}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
