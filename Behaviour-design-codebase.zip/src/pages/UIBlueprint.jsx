/**
 * UIBlueprint — Figma-Level Screen Mockups for Dev Handoff
 * Every screen rendered as a pixel-accurate phone frame with annotations.
 */
import { useState } from 'react';
import {
  Smartphone, Monitor, LayoutDashboard, CheckSquare, Trophy,
  Bot, Users, Settings, LogIn, Zap, TrendingUp, BarChart2,
  Flame, Target, Star, ChevronRight, CheckCircle2, ArrowRight,
  Activity, Shield, Bell, Copy, CheckCircle,
} from 'lucide-react';

// ── Screen definitions ────────────────────────────────────────────────────────
const SCREENS = [
  {
    id: 'login',
    label: 'Login',
    icon: LogIn,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    annotations: ['Logo centered at top', 'Email + Password inputs', 'Primary CTA — full width', 'Forgot password link'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-4">
        <div className="flex-1 flex flex-col items-center justify-center space-y-5">
          {/* Logo */}
          <div className="w-12 h-12 rounded-xl bg-indigo-500 flex items-center justify-center shadow-lg shadow-indigo-500/30">
            <Zap size={20} className="text-white" />
          </div>
          <div className="text-center">
            <p className="text-white font-black text-lg">Behavior Engine</p>
            <p className="text-white/30 text-[10px] mt-0.5">Sign in to your account</p>
          </div>
          {/* Inputs */}
          <div className="w-full space-y-2">
            <div className="h-9 rounded-xl bg-white/5 border border-white/10 flex items-center px-3 gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400/40" />
              <span className="text-white/20 text-[9px]">you@company.com</span>
            </div>
            <div className="h-9 rounded-xl bg-white/5 border border-white/10 flex items-center px-3 gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400/40" />
              <span className="text-white/20 text-[9px]">••••••••••</span>
            </div>
          </div>
          {/* CTA */}
          <div className="w-full space-y-2">
            <div className="h-10 rounded-xl bg-indigo-500 flex items-center justify-center gap-1.5">
              <span className="text-white text-[10px] font-bold">Sign In</span>
              <ArrowRight size={10} className="text-white" />
            </div>
            <p className="text-white/20 text-[8px] text-center">Forgot password?</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'onboarding_role',
    label: 'Onboarding: Role',
    icon: Target,
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    annotations: ['Progress 1/3 at top', 'Role cards — full width tap targets', 'Continue disabled until selection', 'Emoji + title + desc per role'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-3 space-y-3">
        <div className="h-0.5 bg-white/8 rounded-full overflow-hidden">
          <div className="h-full w-1/3 bg-indigo-500 rounded-full" />
        </div>
        <p className="text-white/25 text-[8px] uppercase tracking-widest">Step 1 of 3</p>
        <p className="text-white font-black text-sm">What is your role?</p>
        <div className="space-y-1.5 flex-1">
          {[
            { emoji: '💼', title: 'Salesperson',   active: true  },
            { emoji: '📊', title: 'Manager',        active: false },
            { emoji: '⚙️', title: 'Operator',       active: false },
          ].map(({ emoji, title, active }) => (
            <div key={title} className={`flex items-center gap-2.5 p-2.5 rounded-lg border transition-all ${active ? 'border-indigo-500/30 bg-indigo-500/10' : 'border-white/6 bg-white/2'}`}>
              <span className="text-base">{emoji}</span>
              <p className={`text-[10px] font-semibold ${active ? 'text-indigo-400' : 'text-white/50'}`}>{title}</p>
              {active && <div className="ml-auto w-3 h-3 rounded-full bg-indigo-500 flex items-center justify-center"><CheckCircle2 size={7} className="text-white" /></div>}
            </div>
          ))}
        </div>
        <div className="h-9 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
          <span className="text-indigo-400 text-[10px] font-bold">Continue as Salesperson →</span>
        </div>
      </div>
    ),
  },
  {
    id: 'onboarding_goal',
    label: 'Onboarding: Goal',
    icon: Target,
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
    annotations: ['Progress 2/3', 'Goal cards with emoji + title + desc', 'AI uses this to adapt coaching style', 'Links to personality system'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-3 space-y-3">
        <div className="h-0.5 bg-white/8 rounded-full overflow-hidden">
          <div className="h-full w-2/3 bg-indigo-500 rounded-full" />
        </div>
        <p className="text-white/25 text-[8px] uppercase tracking-widest">Step 2 of 3</p>
        <p className="text-white font-black text-sm">What do you want to improve?</p>
        <div className="space-y-1.5 flex-1">
          {[
            { emoji: '🔥', title: 'Discipline',    active: false },
            { emoji: '🚀', title: 'Sales Output',  active: true  },
            { emoji: '📅', title: 'Consistency',   active: false },
          ].map(({ emoji, title, active }) => (
            <div key={title} className={`flex items-center gap-2.5 p-2.5 rounded-lg border ${active ? 'border-cyan-500/30 bg-cyan-500/10' : 'border-white/6 bg-white/2'}`}>
              <span className="text-base">{emoji}</span>
              <p className={`text-[10px] font-semibold ${active ? 'text-cyan-400' : 'text-white/50'}`}>{title}</p>
              {active && <div className="ml-auto w-3 h-3 rounded-full bg-cyan-500 flex items-center justify-center"><CheckCircle2 size={7} className="text-white" /></div>}
            </div>
          ))}
        </div>
        <div className="h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
          <span className="text-cyan-400 text-[10px] font-bold">Set Goal: Sales Output →</span>
        </div>
      </div>
    ),
  },
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/20',
    annotations: ['Score = primary number — largest element', 'Status pill (GREEN/YELLOW/RED)', 'Streak counter', 'Today\'s progress bar', 'Recent actions list'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-3 space-y-3">
        {/* Top bar */}
        <div className="flex items-center justify-between">
          <p className="text-white/50 text-[9px] font-bold">Thu · Apr 23</p>
          <Bell size={11} className="text-white/25" />
        </div>
        {/* Score card */}
        <div className="p-3 rounded-xl bg-emerald-500/8 border border-emerald-500/25">
          <p className="text-white/30 text-[8px] uppercase tracking-widest mb-1">Today's Score</p>
          <p className="text-3xl font-black text-emerald-400 leading-none">42</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">GREEN</span>
            <span className="text-orange-400 text-[8px]">🔥 5d streak</span>
          </div>
          <div className="h-1 bg-white/8 rounded-full overflow-hidden mt-2">
            <div className="h-full w-[78%] bg-emerald-500 rounded-full" />
          </div>
        </div>
        {/* Today execution */}
        <p className="text-white/30 text-[8px] uppercase tracking-widest">Today's Execution</p>
        <div className="space-y-1 flex-1">
          {[
            { label: 'Cold calls', pts: 10, done: true  },
            { label: 'Follow-ups', pts: 10, done: true  },
            { label: 'Demo booked',pts: 15, done: false },
          ].map(({ label, pts, done }) => (
            <div key={label} className={`flex items-center gap-2 p-2 rounded-lg border ${done ? 'border-emerald-500/15 bg-emerald-500/5' : 'border-white/6 bg-white/2'}`}>
              <div className={`w-3 h-3 rounded-full border flex items-center justify-center ${done ? 'bg-emerald-500 border-emerald-500' : 'border-white/20'}`}>
                {done && <CheckCircle2 size={8} className="text-white" />}
              </div>
              <span className={`text-[9px] flex-1 ${done ? 'text-white/40 line-through' : 'text-white/70'}`}>{label}</span>
              <span className={`text-[8px] font-bold ${done ? 'text-emerald-400' : 'text-white/20'}`}>+{pts}</span>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 'task',
    label: 'Task Screen',
    icon: CheckSquare,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    annotations: ['ONE task only — no distractions', 'Big DONE button = primary CTA', 'Points shown clearly', '90s urgency timer when applicable', 'No back button — forward-only'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-3 items-center justify-center space-y-4 text-center">
        <p className="text-white/25 text-[8px] uppercase tracking-widest">Task #1 · 💼 Sales</p>
        <div className="w-full p-4 rounded-xl bg-indigo-500/8 border border-indigo-500/20">
          <p className="text-white font-bold text-sm leading-snug">
            Send 1 outreach message to a new prospect
          </p>
          <div className="flex items-center justify-center gap-1.5 mt-2">
            <span className="text-indigo-400 text-[9px] font-bold">+10 pts</span>
          </div>
        </div>
        <div className="w-full h-12 rounded-xl bg-emerald-500 flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25">
          <CheckCircle2 size={15} className="text-white" />
          <span className="text-white font-black text-sm">DONE</span>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/15">
          <span className="text-[8px] text-orange-400 font-semibold">⏱ 72s remaining</span>
        </div>
      </div>
    ),
  },
  {
    id: 'feedback',
    label: 'AI Feedback',
    icon: Bot,
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    annotations: ['Coach emoji + name visible', '1–2 lines max — no walls of text', 'Action line always ends with a →', 'Personality color matches user setting', 'Auto-dismisses in 5s or tap to close'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-3 justify-end space-y-3">
        <div className="flex-1 flex flex-col justify-center items-center opacity-30">
          <div className="w-full p-3 rounded-xl bg-white/3 border border-white/6">
            <p className="text-white/40 text-[9px]">Dashboard content behind…</p>
          </div>
        </div>
        {/* Toast */}
        <div className="rounded-2xl border border-red-500/25 bg-[#0b0f1a] overflow-hidden shadow-2xl">
          <div className="h-0.5 w-3/4 bg-red-500" />
          <div className="p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center text-sm">🔥</div>
              <div>
                <p className="text-red-400 text-[8px] font-bold uppercase tracking-wider">The Disciplinarian</p>
                <p className="text-[7px] font-bold px-1.5 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 w-fit">At Risk</p>
              </div>
            </div>
            <p className="text-white/60 text-[9px] leading-snug">Below standard. You know what's expected.</p>
            <p className="text-red-400 text-[9px] font-semibold">→ Complete 3 tasks you skipped this morning.</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 'leaderboard',
    label: 'Leaderboard',
    icon: Trophy,
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/20',
    annotations: ['Team name + date in header', 'Rank medal for top 3', 'Name + score + status per row', 'Progress bar per user', 'Streak badge if active'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-3 space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-white font-bold text-[10px]">Team Leaderboard</p>
          <p className="text-white/20 text-[8px]">Today</p>
        </div>
        {[
          { rank: '🥇', name: 'Alex R.', score: 82, status: 'GREEN',  color: 'text-green-400',  bg: 'bg-green-500/10',  bar: 82, streak: 7  },
          { rank: '🥈', name: 'Casey N.',score: 74, status: 'GREEN',  color: 'text-green-400',  bg: 'bg-green-500/10',  bar: 74, streak: 3  },
          { rank: '🥉', name: 'Sam O.',  score: 61, status: 'YELLOW', color: 'text-yellow-400', bg: 'bg-yellow-500/10', bar: 61, streak: 0  },
          { rank: '#4', name: 'Jamie C.',score: 38, status: 'YELLOW', color: 'text-yellow-400', bg: 'bg-yellow-500/10', bar: 38, streak: 0  },
          { rank: '#5', name: 'Morgan', score: 18, status: 'RED',    color: 'text-red-400',    bg: 'bg-red-500/10',    bar: 18, streak: 0  },
        ].map(({ rank, name, score, status, color, bg, bar, streak }) => (
          <div key={name} className={`flex items-center gap-2 p-2 rounded-lg border ${bg} border-${color.replace('text-', '').replace('-400', '-500/20')}`}>
            <span className="text-[10px] w-5 text-center">{rank}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <p className="text-white text-[9px] font-semibold truncate">{name}</p>
                {streak > 0 && <span className="text-orange-400 text-[7px]">🔥{streak}</span>}
              </div>
              <div className="h-0.5 bg-white/8 rounded-full overflow-hidden mt-0.5">
                <div className={`h-full ${color.replace('text-', 'bg-')} rounded-full`} style={{ width: `${bar}%` }} />
              </div>
            </div>
            <span className={`text-sm font-black ${color}`}>{score}</span>
          </div>
        ))}
      </div>
    ),
  },
  {
    id: 'admin_crm',
    label: 'Admin: CRM',
    icon: Shield,
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/20',
    annotations: ['Admin-only — role guard required', 'Pipeline stage tabs', 'Lead rows with status pill', 'MRR + conversion KPIs at top', 'Quick action: move stage / edit'],
    render: () => (
      <div className="flex flex-col h-full bg-[#05080f] p-3 space-y-2">
        <div className="flex items-center gap-1">
          <Shield size={9} className="text-red-400" />
          <p className="text-white font-bold text-[10px]">CRM Pipeline</p>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {[
            { l: 'MRR',    v: '$1,890',  c: 'text-emerald-400' },
            { l: 'Pipeline', v: '14 leads', c: 'text-indigo-400' },
          ].map(({ l, v, c }) => (
            <div key={l} className="p-2 rounded-lg bg-white/3 border border-white/6 text-center">
              <p className={`text-sm font-black ${c}`}>{v}</p>
              <p className="text-white/20 text-[7px]">{l}</p>
            </div>
          ))}
        </div>
        <div className="flex gap-1">
          {['Lead', 'Pilot', 'Paid'].map((s, i) => (
            <div key={s} className={`flex-1 text-center py-1 rounded-lg text-[8px] font-bold ${i === 1 ? 'bg-indigo-500/15 text-indigo-400 border border-indigo-500/20' : 'bg-white/4 text-white/25'}`}>{s}</div>
          ))}
        </div>
        <div className="space-y-1 flex-1">
          {[
            { name: 'Marcus T.',   company: 'NovaSales', status: 'pilot', c: 'text-purple-400' },
            { name: 'Sarah K.',    company: 'LogiCore',  status: 'pilot', c: 'text-purple-400' },
            { name: 'James W.',    company: 'Apex',      status: 'lead',  c: 'text-indigo-400' },
          ].map(({ name, company, status, c }) => (
            <div key={name} className="flex items-center gap-2 p-2 rounded-lg bg-white/2 border border-white/5">
              <div className="w-5 h-5 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-[7px] font-bold text-white">{name[0]}</div>
              <div className="flex-1 min-w-0">
                <p className="text-white/70 text-[9px] font-semibold truncate">{name}</p>
                <p className="text-white/25 text-[7px]">{company}</p>
              </div>
              <span className={`text-[7px] font-bold px-1.5 py-0.5 rounded-full bg-white/5 ${c}`}>{status}</span>
            </div>
          ))}
        </div>
      </div>
    ),
  },
];

// ── View modes ────────────────────────────────────────────────────────────────
export default function UIBlueprint() {
  const [active, setActive] = useState('dashboard');
  const [viewMode, setViewMode] = useState('phone'); // 'phone' | 'grid'
  const [copied, setCopied]   = useState(null);

  const screen = SCREENS.find(s => s.id === active);

  const copyAnnotations = (s) => {
    navigator.clipboard.writeText(s.annotations.join('\n')).catch(() => {});
    setCopied(s.id);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Smartphone size={14} className="text-pink-400" />
              <p className="text-pink-400 text-xs font-bold uppercase tracking-widest">UI Blueprint</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Figma-Level Screen Specs</h1>
            <p className="text-white/35 text-sm">Every screen with annotations for dev handoff.</p>
          </div>
          <div className="inline-flex p-1 bg-white/5 rounded-xl border border-white/6">
            {[['phone', 'Phone'], ['grid', 'Grid']].map(([v, l]) => (
              <button key={v} onClick={() => setViewMode(v)}
                className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${viewMode === v ? 'bg-indigo-500 text-white' : 'text-white/35 hover:text-white/60'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>

        {viewMode === 'phone' ? (
          <div className="grid lg:grid-cols-[200px_1fr_240px] gap-6">

            {/* Screen list */}
            <div className="space-y-1.5">
              <p className="text-white/25 text-[9px] uppercase tracking-widest px-1 mb-2">Screens</p>
              {SCREENS.map(s => {
                const Icon = s.icon;
                return (
                  <button key={s.id} onClick={() => setActive(s.id)}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl border text-left transition-all ${
                      active === s.id ? `${s.border} ${s.bg}` : 'border-white/5 hover:border-white/10 bg-transparent'
                    }`}>
                    <Icon size={12} className={active === s.id ? s.color : 'text-white/25'} />
                    <span className={`text-xs ${active === s.id ? `font-semibold ${s.color}` : 'text-white/40'}`}>{s.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Phone mockup */}
            <div className="flex justify-center">
              {screen && (
                <div className="relative" style={{ width: '240px' }}>
                  <div className="absolute -inset-4 bg-indigo-500/6 rounded-3xl blur-2xl pointer-events-none" />
                  <div className="relative rounded-[2.5rem] border-[3px] border-white/10 bg-[#050810] overflow-hidden shadow-2xl"
                    style={{ height: '480px' }}>
                    {/* Notch */}
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-5 bg-[#050810] rounded-b-xl z-20" />
                    {/* Status bar */}
                    <div className="flex items-center justify-between px-5 pt-6 pb-1">
                      <span className="text-white/20 text-[7px]">9:41</span>
                      <span className="text-white/20 text-[7px]">●●●</span>
                    </div>
                    {/* App bar */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 border-b border-white/5">
                      <div className="w-4 h-4 rounded-md bg-indigo-500 flex items-center justify-center">
                        <Zap size={8} className="text-white" />
                      </div>
                      <span className="text-white/40 text-[8px] font-bold">Behavior Engine</span>
                    </div>
                    {/* Screen content */}
                    <div className="overflow-hidden" style={{ height: '390px' }}>
                      {screen.render()}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Annotations */}
            {screen && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <p className={`text-xs font-bold ${screen.color}`}>{screen.label}</p>
                  <button onClick={() => copyAnnotations(screen)}
                    className={`flex items-center gap-1 text-[8px] font-semibold px-2 py-1 rounded-lg ${screen.bg} ${screen.color} border ${screen.border}`}>
                    {copied === screen.id ? <><CheckCircle size={8} /> Done</> : <><Copy size={8} /> Copy</>}
                  </button>
                </div>
                <div className="space-y-2">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest">Design Annotations</p>
                  {screen.annotations.map((note, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className={`text-[8px] font-black font-mono ${screen.color} mt-0.5 shrink-0`}>{String(i+1).padStart(2,'0')}</span>
                      <p className="text-white/50 text-xs leading-snug">{note}</p>
                    </div>
                  ))}
                </div>
                <div className="p-3 rounded-xl bg-white/3 border border-white/6">
                  <p className="text-white/20 text-[9px] uppercase tracking-widest mb-1.5">Component Rules</p>
                  <div className="space-y-1">
                    {[
                      { l: 'Radius',  v: '2xl (16px)' },
                      { l: 'Spacing', v: 'p-4 / gap-3' },
                      { l: 'Font',    v: 'Inter Black for scores' },
                      { l: 'Colors',  v: 'Status-driven (G/Y/R)' },
                    ].map(({ l, v }) => (
                      <div key={l} className="flex items-center justify-between">
                        <span className="text-white/20 text-[8px]">{l}</span>
                        <span className="text-white/50 text-[8px] font-mono">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Grid view */
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {SCREENS.map(s => (
              <div key={s.id} className={`rounded-2xl border overflow-hidden cursor-pointer transition-all hover:scale-[1.02] ${s.border} ${s.bg}`}
                onClick={() => { setActive(s.id); setViewMode('phone'); }}>
                <div className={`px-3 py-2 border-b ${s.border} flex items-center gap-1.5`}>
                  <s.icon size={10} className={s.color} />
                  <p className={`text-[9px] font-bold ${s.color}`}>{s.label}</p>
                </div>
                <div className="relative overflow-hidden" style={{ height: '200px', transform: 'scale(0.65)', transformOrigin: 'top left', width: '154%' }}>
                  {s.render()}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Design system tokens */}
        <div className="rounded-2xl border border-white/8 bg-[#0b0f1a] p-5">
          <p className="text-white font-bold text-sm mb-4">Design System Tokens</p>
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Colors */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Status Colors</p>
              <div className="space-y-1.5">
                {[
                  { name: 'GREEN',  hex: '#22c55e', bg: 'bg-green-500',  border: 'border-green-500' },
                  { name: 'YELLOW', hex: '#eab308', bg: 'bg-yellow-500', border: 'border-yellow-500'},
                  { name: 'RED',    hex: '#ef4444', bg: 'bg-red-500',    border: 'border-red-500'   },
                  { name: 'Indigo', hex: '#6366f1', bg: 'bg-indigo-500', border: 'border-indigo-500'},
                ].map(({ name, hex, bg }) => (
                  <div key={name} className="flex items-center gap-2">
                    <div className={`w-4 h-4 rounded ${bg} shrink-0`} />
                    <span className="text-white/60 text-xs">{name}</span>
                    <code className="text-white/25 text-[9px] font-mono ml-auto">{hex}</code>
                  </div>
                ))}
              </div>
            </div>
            {/* Typography */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Typography Scale</p>
              <div className="space-y-1.5">
                {[
                  { name: 'Score / Hero',  class: 'text-4xl font-black', example: '42' },
                  { name: 'Section Head',  class: 'text-2xl font-black', example: 'Dashboard' },
                  { name: 'Body',          class: 'text-sm',             example: 'Send 1 outreach…' },
                  { name: 'Label / Badge', class: 'text-xs font-bold',   example: 'GREEN STATUS' },
                ].map(({ name, class: cls, example }) => (
                  <div key={name} className="flex items-center justify-between">
                    <span className="text-white/30 text-[9px]">{name}</span>
                    <code className="text-white/25 text-[8px] font-mono">{cls}</code>
                  </div>
                ))}
              </div>
            </div>
            {/* Components */}
            <div>
              <p className="text-white/25 text-[9px] uppercase tracking-widest mb-2">Component Rules</p>
              <div className="space-y-1.5">
                {[
                  { rule: 'Cards', val: 'rounded-2xl + glass border' },
                  { rule: 'CTAs',  val: 'full-width on mobile' },
                  { rule: 'Score', val: 'always 48px+ font-black' },
                  { rule: 'Toast', val: 'fixed bottom-20 lg:bottom-6' },
                  { rule: 'Nav',   val: 'hidden lg:flex sidebar' },
                ].map(({ rule, val }) => (
                  <div key={rule} className="flex items-center gap-2">
                    <span className="text-indigo-400/60 text-[9px] font-bold w-12 shrink-0">{rule}</span>
                    <span className="text-white/30 text-[9px]">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
