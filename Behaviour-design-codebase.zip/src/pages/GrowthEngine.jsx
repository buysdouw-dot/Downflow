/**
 * GrowthEngine — 100 → 10,000 Users Scaling Playbook
 * Three phases. Viral loop. Channel strategy. Live execution tracker.
 */
import { useState, useEffect } from 'react';
import {
  TrendingUp, Users, Zap, Share2, Target, ArrowRight,
  CheckCircle2, Circle, Flame, RefreshCw, BarChart2,
  MessageCircle, Link2, Star, Award, ChevronDown,
  ChevronRight, Plus, Rocket, Globe,
} from 'lucide-react';

// ── Growth phases ─────────────────────────────────────────────────────────────
const PHASES = [
  {
    id: 'p1',
    range: '0 → 100',
    label: 'Phase 1',
    title: 'Founder-Led Growth',
    color: 'text-white/60',
    bg: 'bg-white/4',
    border: 'border-white/10',
    bar: 'bg-white/30',
    dot: 'bg-white/40',
    target: 100,
    timeline: '30 days',
    channels: [
      { name: 'WhatsApp Groups',    icon: MessageCircle, desc: 'Message 50 people you know personally. 5-minute ask.', multiplier: '1:3', effort: 'High', color: 'text-emerald-400' },
      { name: 'Direct Outreach',    icon: Link2,         desc: 'LinkedIn DMs: "Can I get your feedback on this?"',      multiplier: '1:2', effort: 'High', color: 'text-blue-400'    },
      { name: 'Founder Posting',    icon: Star,          desc: 'Daily LinkedIn post about the problem you solve.',       multiplier: '1:5', effort: 'Med',  color: 'text-yellow-400'  },
    ],
    actions: [
      'List 50 people who manage teams (LinkedIn connections)',
      'Message each one: "Building something for sales managers. 15 min to see it?"',
      'Onboard every yes personally — do it with them on a call',
      'Get one testimonial from first 10 users',
      'Post daily on LinkedIn about behavior change / execution',
    ],
    metric: '2 pilot companies',
    north_star: 'First paying customer',
  },
  {
    id: 'p2',
    range: '100 → 1,000',
    label: 'Phase 2',
    title: 'Case Study Engine',
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/8',
    border: 'border-indigo-500/20',
    bar: 'bg-indigo-400',
    dot: 'bg-indigo-400',
    target: 1000,
    timeline: '90 days',
    channels: [
      { name: 'LinkedIn Case Studies', icon: BarChart2,  desc: '"Acme Sales Team went from 40% to 78% execution in 30 days."', multiplier: '1:12', effort: 'Med', color: 'text-indigo-400' },
      { name: 'Pilot Companies',       icon: Users,      desc: 'Close 3–5 companies. Each brings 10–50 users.',                multiplier: '1:30', effort: 'Med', color: 'text-purple-400' },
      { name: 'Referral System',       icon: Share2,     desc: 'Give existing users: "Get 1 month free per referral."',         multiplier: '1:8',  effort: 'Low', color: 'text-cyan-400'   },
    ],
    actions: [
      'Interview top 3 users — extract transformation story',
      'Write 1 LinkedIn case study every 2 weeks',
      'Build automated referral program (in-app share card)',
      'Close 3 more pilot companies at $99–$299/month',
      'Start content calendar: 3 posts/week',
    ],
    metric: '5 paying companies',
    north_star: '$5,000 MRR',
  },
  {
    id: 'p3',
    range: '1,000 → 10,000',
    label: 'Phase 3',
    title: 'System Scale',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/8',
    border: 'border-emerald-500/20',
    bar: 'bg-emerald-400',
    dot: 'bg-emerald-400',
    target: 10000,
    timeline: '12 months',
    channels: [
      { name: 'Paid Ads',            icon: Target,   desc: 'LinkedIn ads targeted at VP Sales + Team Managers.',         multiplier: '1:40', effort: 'Low', color: 'text-emerald-400' },
      { name: 'Partner Network',     icon: Globe,    desc: 'Partner with sales consultants who have existing audiences.', multiplier: '1:80', effort: 'Med', color: 'text-yellow-400'  },
      { name: 'Enterprise Outreach', icon: Rocket,   desc: 'Cold email 200 VP Sales at companies with 50–500 reps.',     multiplier: '1:200',effort: 'High',color: 'text-orange-400'  },
    ],
    actions: [
      'Hire 1 growth marketer — give them budget + clear KPIs',
      'Build integration with Salesforce CRM (unlock enterprise deals)',
      'Launch affiliate program: 30% rev share for partners',
      'Outbound: 50 enterprise prospects/week via automated sequences',
      'Raise seed round with traction data ($10k+ MRR)',
    ],
    metric: '50 paying companies',
    north_star: '$50,000 MRR',
  },
];

// ── Viral loop ────────────────────────────────────────────────────────────────
const VIRAL_LOOP = [
  { id: 1, label: 'User executes task',     color: 'text-indigo-400',  bg: 'bg-indigo-500/10',  border: 'border-indigo-500/20'  },
  { id: 2, label: 'Score increases',        color: 'text-cyan-400',    bg: 'bg-cyan-500/10',    border: 'border-cyan-500/20'    },
  { id: 3, label: 'Share card generated',   color: 'text-purple-400',  bg: 'bg-purple-500/10',  border: 'border-purple-500/20'  },
  { id: 4, label: 'Shared to network',      color: 'text-yellow-400',  bg: 'bg-yellow-500/10',  border: 'border-yellow-500/20'  },
  { id: 5, label: 'New user joins',         color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  { id: 6, label: 'Loop repeats ↩',         color: 'text-indigo-400',  bg: 'bg-indigo-500/10',  border: 'border-indigo-500/20'  },
];

// ── Tracker storage ───────────────────────────────────────────────────────────
function loadProgress()  { try { return JSON.parse(localStorage.getItem('be_growth_progress')) ?? {}; } catch { return {}; } }
function saveProgress(d) { try { localStorage.setItem('be_growth_progress', JSON.stringify(d)); } catch {} }

// ── Sub-components ────────────────────────────────────────────────────────────
function PhaseCard({ phase, expanded, onToggle }) {
  const [progress, setProgress] = useState(loadProgress);
  const done = phase.actions.filter((a) => progress[`${phase.id}_${a}`]).length;
  const pct  = Math.round((done / phase.actions.length) * 100);

  const toggle = (action) => {
    const k = `${phase.id}_${action}`;
    const next = { ...progress, [k]: !progress[k] };
    setProgress(next);
    saveProgress(next);
  };

  return (
    <div className={`rounded-2xl border ${phase.border} overflow-hidden`}>
      <div className={`p-5 cursor-pointer ${phase.bg}`} onClick={onToggle}>
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`px-2.5 py-1 rounded-full ${phase.bg} border ${phase.border}`}>
              <span className={`text-[9px] font-black ${phase.color}`}>{phase.label}</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className={`text-base font-black text-white`}>{phase.range} users</p>
                <span className="text-white/25 text-xs">·</span>
                <span className="text-white/30 text-xs">{phase.timeline}</span>
              </div>
              <p className={`text-sm font-semibold ${phase.color}`}>{phase.title}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right">
              <p className={`text-sm font-black ${phase.color}`}>{pct}%</p>
              <p className="text-white/20 text-[9px]">{done}/{phase.actions.length} done</p>
            </div>
            {expanded ? <ChevronDown size={14} className="text-white/25" /> : <ChevronRight size={14} className="text-white/25" />}
          </div>
        </div>
        <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
          <div className={`h-full ${phase.bar} rounded-full transition-all duration-700`} style={{ width: `${pct}%` }} />
        </div>
        <div className="flex items-center justify-between mt-2">
          <p className="text-white/25 text-[9px]">North Star: <span className={phase.color}>{phase.north_star}</span></p>
          <p className="text-white/25 text-[9px]">Milestone: {phase.metric}</p>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-white/8 p-5 space-y-5">
          {/* Channels */}
          <div>
            <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Growth Channels</p>
            <div className="grid lg:grid-cols-3 gap-3">
              {phase.channels.map((ch) => {
                const Icon = ch.icon;
                return (
                  <div key={ch.name} className={`p-4 rounded-xl ${phase.bg} border ${phase.border}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Icon size={13} className={ch.color} />
                      <span className={`text-xs font-bold ${ch.color}`}>{ch.name}</span>
                    </div>
                    <p className="text-white/40 text-xs leading-snug mb-3">{ch.desc}</p>
                    <div className="flex items-center gap-3">
                      <span className="text-[8px] text-white/25">Multiplier</span>
                      <span className={`text-[9px] font-bold ${ch.color}`}>{ch.multiplier}</span>
                      <span className="text-[8px] text-white/20 ml-auto">{ch.effort} effort</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action checklist */}
          <div>
            <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Execution Checklist</p>
            <div className="space-y-2">
              {phase.actions.map((action) => {
                const done = !!progress[`${phase.id}_${action}`];
                return (
                  <div key={action}
                    onClick={() => toggle(action)}
                    className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                      done ? `${phase.bg} ${phase.border}` : 'bg-white/2 border-white/6 hover:border-white/10'
                    }`}>
                    {done
                      ? <CheckCircle2 size={14} className={`${phase.color} shrink-0 mt-0.5`} />
                      : <Circle      size={14} className="text-white/20 shrink-0 mt-0.5" />}
                    <p className={`text-xs leading-snug ${done ? 'text-white/40 line-through' : 'text-white/65'}`}>
                      {action}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function GrowthEngine() {
  const [expanded, setExpanded] = useState('p1');
  const [loopStep, setLoopStep] = useState(0);

  // Animate viral loop
  useEffect(() => {
    const t = setInterval(() => setLoopStep(s => (s + 1) % VIRAL_LOOP.length), 1200);
    return () => clearInterval(t);
  }, []);

  const toggle = (id) => setExpanded(e => e === id ? null : id);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Rocket size={14} className="text-orange-400" />
            <p className="text-orange-400 text-xs font-bold uppercase tracking-widest">Growth Engine</p>
          </div>
          <h1 className="text-3xl font-black mb-1">100 → 10,000 Users</h1>
          <p className="text-white/35 text-sm">Three phases. One viral loop. No wasted moves.</p>
        </div>

        {/* Viral loop animation */}
        <div className="p-5 rounded-2xl border border-indigo-500/20 bg-indigo-500/4">
          <div className="flex items-center gap-2 mb-4">
            <RefreshCw size={13} className="text-indigo-400 animate-spin" style={{ animationDuration: '3s' }} />
            <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest">The Viral Loop</p>
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            {VIRAL_LOOP.map((step, i) => (
              <div key={step.id} className="flex items-center gap-1">
                <div className={`px-3 py-1.5 rounded-full border text-[10px] font-bold transition-all duration-500 ${
                  i === loopStep ? `${step.bg} ${step.border} ${step.color} scale-105 shadow-lg` : 'bg-white/3 border-white/8 text-white/30'
                }`}>
                  {step.label}
                </div>
                {i < VIRAL_LOOP.length - 1 && (
                  <ArrowRight size={10} className={i < loopStep ? 'text-indigo-400' : 'text-white/10'} />
                )}
              </div>
            ))}
          </div>
          <p className="text-white/25 text-xs mt-3">
            <span className="text-indigo-400 font-semibold">Critical insight: </span>
            Every score increase is a share trigger. Every share is a signup opportunity. Build the loop once — it runs forever.
          </p>
        </div>

        {/* KPI targets */}
        <div className="grid grid-cols-3 gap-3">
          {PHASES.map(p => (
            <div key={p.id} className={`p-4 rounded-xl ${p.bg} border ${p.border} text-center`}>
              <p className={`text-xl font-black ${p.color}`}>{p.range}</p>
              <p className="text-white/30 text-xs mt-0.5">{p.timeline}</p>
              <p className={`text-[9px] font-bold mt-1.5 ${p.color}`}>{p.north_star}</p>
            </div>
          ))}
        </div>

        {/* Phase cards */}
        <div className="space-y-4">
          {PHASES.map(p => (
            <PhaseCard key={p.id} phase={p} expanded={expanded === p.id} onToggle={() => toggle(p.id)} />
          ))}
        </div>

        {/* The one rule */}
        <div className="p-6 rounded-2xl border border-white/8 bg-white/2 text-center space-y-3">
          <Flame size={22} className="mx-auto text-orange-400" />
          <p className="text-white font-black text-lg">The Only Rule That Matters</p>
          <p className="text-white/50 text-sm leading-relaxed max-w-md mx-auto">
            Growth comes from <span className="text-white font-semibold">real users getting real results</span>.
            Every Phase 1 user who succeeds becomes your Phase 2 case study.
            Every Phase 2 case study becomes your Phase 3 sales engine.
            <br /><br />
            <span className="text-orange-400 font-semibold">Obsess over results. Growth follows.</span>
          </p>
        </div>

      </div>
    </div>
  );
}
