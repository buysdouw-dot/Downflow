/**
 * AIv2 — Fully Autonomous SaaS v2 (Self-Optimizing System)
 * The endgame architecture. Each session the system learns more.
 * After 30 days: no two companies get the same system.
 * After 90 days: more personalized than any human coach could be.
 */
import { useState, useEffect, useRef } from 'react';
import {
  Brain, TrendingUp, DollarSign, Users, Zap, RefreshCw,
  Play, CheckCircle2, ArrowRight, Activity, Cpu, Eye,
  Settings, Target, Flame, Lock, Unlock, Star,
} from 'lucide-react';

// ── 4 Agents ──────────────────────────────────────────────────────────────────
const AGENTS = [
  {
    id: 'coach',
    name: 'Coach Agent',
    desc: 'Talks to users',
    role: 'Adapts personality, tone, and timing per individual user based on response patterns.',
    icon: Brain,
    color: '#818cf8',
    bg: 'rgba(99,102,241,0.08)',
    border: 'rgba(99,102,241,0.2)',
    signals: ['engagement_score', 'streak_pattern', 'response_time'],
    outputs: [
      { score: 0,  action: 'Switch to Motivator mode — discipline is failing' },
      { score: 40, action: 'Increase nudge frequency — engagement dropping' },
      { score: 70, action: 'Reduce friction — user is self-motivated, trust them' },
      { score: 85, action: 'Switch to Strategist mode — user ready for challenge' },
    ],
  },
  {
    id: 'behavior',
    name: 'Behavior Agent',
    desc: 'Analyzes patterns',
    role: 'Detects behavioral fingerprints: burnout cycles, peak hours, consistency gaps, and churn signals.',
    icon: Activity,
    color: '#22d3ee',
    bg: 'rgba(6,182,212,0.08)',
    border: 'rgba(6,182,212,0.2)',
    signals: ['daily_score_pattern', 'task_completion_time', 'consecutive_red_days'],
    outputs: [
      { score: 0,  action: 'ALERT: Burnout pattern detected — 3 consecutive RED days' },
      { score: 30, action: 'Cognitive load too high — reduce daily task count by 2' },
      { score: 60, action: 'Peak performance window: 8–10AM — optimize task timing' },
      { score: 80, action: 'Flow state detected — extend streak, increase challenge' },
    ],
  },
  {
    id: 'growth',
    name: 'Growth Agent',
    desc: 'Improves onboarding',
    role: 'Optimizes the new user journey, identifies friction points, and improves trial-to-paid conversion.',
    icon: TrendingUp,
    color: '#34d399',
    bg: 'rgba(16,185,129,0.08)',
    border: 'rgba(16,185,129,0.2)',
    signals: ['trial_activation_rate', 'day1_retention', 'onboarding_completion'],
    outputs: [
      { score: 0,  action: 'Onboarding too complex — cut steps from 6 to 3' },
      { score: 25, action: 'Add value reveal at step 2 — users dropping before seeing score' },
      { score: 50, action: 'Upgrade trigger at Day 5 streak milestone' },
      { score: 75, action: 'Activate referral loop — users seeing value, ask to share' },
    ],
  },
  {
    id: 'revenue',
    name: 'Revenue Agent',
    desc: 'Optimizes pricing',
    role: 'Reads value-delivery signals to time upgrades, detect expansion revenue, and reduce involuntary churn.',
    icon: DollarSign,
    color: '#fbbf24',
    bg: 'rgba(245,158,11,0.08)',
    border: 'rgba(245,158,11,0.2)',
    signals: ['feature_usage_depth', 'team_size_growth', 'api_call_volume'],
    outputs: [
      { score: 0,  action: 'Churn risk: user not activating core feature — trigger coaching' },
      { score: 30, action: 'Add AI memory feature to Starter to increase perceived value' },
      { score: 60, action: 'Team expanded from 5 to 12 — upgrade prompt to Pro' },
      { score: 85, action: 'High value delivery — raise Pro price by 10% for new users' },
    ],
  },
];

// ── Evolution stages ───────────────────────────────────────────────────────────
const STAGES = [
  {
    id: 'static',
    day: 'Day 0',
    label: 'Static System',
    desc: 'One-size-fits-all rules. Same tasks for everyone. No memory.',
    color: 'text-white/30',
    border: 'border-white/8',
    bg: 'bg-white/2',
    locked: false,
  },
  {
    id: 'learning',
    day: 'Day 7',
    label: 'Learning System',
    desc: 'Agents read your team\'s patterns. Score calibration per user begins.',
    color: 'text-indigo-400',
    border: 'border-indigo-500/20',
    bg: 'bg-indigo-500/5',
    locked: false,
  },
  {
    id: 'adaptive',
    day: 'Day 30',
    label: 'Adaptive System',
    desc: 'No two users get the same experience. Coaching is personalized per behavior profile.',
    color: 'text-purple-400',
    border: 'border-purple-500/20',
    bg: 'bg-purple-500/5',
    locked: false,
  },
  {
    id: 'predictive',
    day: 'Day 90',
    label: 'Predictive System',
    desc: 'Predicts churn 7 days before it happens. Intervenes automatically. No human required.',
    color: 'text-cyan-400',
    border: 'border-cyan-500/20',
    bg: 'bg-cyan-500/5',
    locked: true,
  },
  {
    id: 'autonomous',
    day: 'Day 180',
    label: 'Fully Autonomous',
    desc: 'System improves itself. You review the output, not the input. This is the moat.',
    color: 'text-emerald-400',
    border: 'border-emerald-500/20',
    bg: 'bg-emerald-500/5',
    locked: true,
  },
];

// ── Self-improvement loop ──────────────────────────────────────────────────────
const LOOP_STEPS = [
  { id: 'observe',  label: 'Observe Behavior',    desc: 'User actions, timing, scores, response to coaching',  color: '#818cf8', Icon: Eye      },
  { id: 'detect',   label: 'Detect Patterns',     desc: 'AI finds fingerprints: burnout, peak hours, churn risk', color: '#22d3ee', Icon: Activity },
  { id: 'adjust',   label: 'Adjust Tasks',        desc: 'Daily task set changes per user profile',              color: '#a78bfa', Icon: Settings },
  { id: 'coach',    label: 'Change Coaching',     desc: 'Personality + tone shift based on what is working',    color: '#34d399', Icon: Brain    },
  { id: 'optimize', label: 'Optimize Engagement', desc: 'System finds what maximizes long-term retention',      color: '#fbbf24', Icon: Zap      },
];

// ── Persistence ────────────────────────────────────────────────────────────────
function loadState()  { try { return JSON.parse(localStorage.getItem('be_aiv2')) ?? { cycles: 0, log: [] }; } catch { return { cycles: 0, log: [] }; } }
function saveState(s) { try { localStorage.setItem('be_aiv2', JSON.stringify(s)); } catch {} }

// ── Agent card ────────────────────────────────────────────────────────────────
function AgentCard({ agent, score, active }) {
  const Icon = agent.icon;
  const output = agent.outputs.reduce((best, o) => score >= o.score ? o : best, agent.outputs[0]);

  return (
    <div style={{
      background: active ? agent.bg : 'rgba(255,255,255,0.02)',
      border: `1px solid ${active ? agent.border : 'rgba(255,255,255,0.06)'}`,
      borderRadius: 16,
      padding: 20,
      transition: 'all 0.4s ease',
      transform: active ? 'scale(1.01)' : 'scale(1)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: active ? agent.bg : 'rgba(255,255,255,0.04)',
          border: `1px solid ${active ? agent.border : 'rgba(255,255,255,0.08)'}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 0.4s',
        }}>
          <Icon size={15} style={{ color: active ? agent.color : 'rgba(255,255,255,0.2)' }} />
        </div>
        <div>
          <p style={{ color: active ? agent.color : 'rgba(255,255,255,0.5)', fontWeight: 700, fontSize: 12 }}>{agent.name}</p>
          <p style={{ color: 'rgba(255,255,255,0.25)', fontSize: 10 }}>{agent.desc}</p>
        </div>
        {active && (
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: agent.color, animation: 'pulse 1s infinite' }} />
            <span style={{ color: agent.color, fontSize: 8, fontWeight: 700 }}>ACTIVE</span>
          </div>
        )}
      </div>

      {active && (
        <>
          <div style={{ marginBottom: 10 }}>
            <p style={{ color: 'rgba(255,255,255,0.2)', fontSize: 8, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 6 }}>Signals Reading</p>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {agent.signals.map(sig => (
                <span key={sig} style={{
                  background: 'rgba(255,255,255,0.04)',
                  border: `1px solid ${agent.border}`,
                  borderRadius: 6,
                  padding: '2px 8px',
                  fontSize: 9,
                  color: agent.color,
                  fontFamily: 'monospace',
                }}>{sig}</span>
              ))}
            </div>
          </div>

          <div style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 10, padding: '10px 12px' }}>
            <p style={{ color: 'rgba(255,255,255,0.2)', fontSize: 8, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 4 }}>Adaptation Applied</p>
            <p style={{ color: agent.color, fontSize: 11, fontWeight: 600, lineHeight: 1.5 }}>{output.action}</p>
          </div>
        </>
      )}

      {!active && (
        <p style={{ color: 'rgba(255,255,255,0.25)', fontSize: 11, lineHeight: 1.5 }}>{agent.role}</p>
      )}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AIv2() {
  const [score,       setScore]       = useState(60);
  const [running,     setRunning]     = useState(false);
  const [activeStep,  setActiveStep]  = useState(-1);
  const [activeAgent, setActiveAgent] = useState(null);
  const [state,       setState_]      = useState(loadState);
  const [stageIdx,    setStageIdx]    = useState(2);
  const timerRef = useRef(null);

  const runLoop = () => {
    if (running) return;
    setRunning(true);
    setActiveAgent(null);

    let s = 0;
    setActiveStep(0);

    timerRef.current = setInterval(() => {
      s++;
      if (s < LOOP_STEPS.length) {
        setActiveStep(s);
      } else {
        // Activate agents one by one
        let ai = 0;
        const agentTimer = setInterval(() => {
          setActiveAgent(AGENTS[ai].id);
          ai++;
          if (ai >= AGENTS.length) {
            clearInterval(agentTimer);
            const newState = {
              cycles: state.cycles + 1,
              log: [
                { cycle: state.cycles + 1, score, ts: new Date().toLocaleTimeString() },
                ...state.log.slice(0, 7),
              ],
            };
            setState_(newState);
            saveState(newState);
            setRunning(false);
            clearInterval(timerRef.current);
          }
        }, 500);
      }
    }, 500);
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  return (
    <div className="min-h-screen bg-[#070b14] text-white p-4 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu size={14} className="text-purple-400" />
              <p className="text-purple-400 text-xs font-bold uppercase tracking-widest">Autonomous AI v2</p>
            </div>
            <h1 className="text-3xl font-black mb-1">Self-Optimizing System</h1>
            <p className="text-white/35 text-sm">
              Not a product that you improve. A product that improves itself. {state.cycles} cycles completed.
            </p>
          </div>
          <button onClick={runLoop} disabled={running}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
              running ? 'bg-purple-500/10 border border-purple-500/20 text-purple-400' : 'bg-purple-500 hover:bg-purple-400 text-white shadow-lg shadow-purple-500/25'
            }`}>
            {running ? <><RefreshCw size={13} className="animate-spin" /> Running loop…</> : <><Play size={13} /> Run AI Loop</>}
          </button>
        </div>

        {/* Self-improvement loop */}
        <div className="p-5 rounded-2xl border border-white/8 bg-[#0b0f1a]">
          <p className="text-white/25 text-[9px] uppercase tracking-widest mb-4">Self-Improvement Loop</p>
          <div className="flex items-center gap-2 flex-wrap">
            {LOOP_STEPS.map((step, i) => {
              const StepIcon = step.Icon;
              const active = running && activeStep === i;
              const done   = !running && state.cycles > 0 || activeStep > i;
              return (
                <div key={step.id} className="flex items-center gap-2">
                  <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border transition-all duration-300 ${
                    active ? 'scale-105 shadow-lg' : ''
                  }`} style={{
                    background: active ? `${step.color}15` : done ? 'rgba(16,185,129,0.06)' : 'rgba(255,255,255,0.02)',
                    borderColor: active ? step.color : done ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.06)',
                  }}>
                    {done && !active
                      ? <CheckCircle2 size={11} className="text-emerald-400" />
                      : <StepIcon size={11} style={{ color: active ? step.color : 'rgba(255,255,255,0.2)' }} />
                    }
                    <div>
                      <p className="text-xs font-semibold" style={{ color: active ? step.color : done ? 'rgba(16,185,129,0.8)' : 'rgba(255,255,255,0.3)' }}>
                        {step.label}
                      </p>
                      {active && <p className="text-[9px] mt-0.5 max-w-[140px] leading-snug" style={{ color: `${step.color}90` }}>{step.desc}</p>}
                    </div>
                    {active && <div className="w-1 h-1 rounded-full animate-pulse" style={{ background: step.color }} />}
                  </div>
                  {i < LOOP_STEPS.length - 1 && (
                    <ArrowRight size={10} className={done ? 'text-emerald-400/60' : 'text-white/10'} />
                  )}
                </div>
              );
            })}
            <div className="flex items-center gap-2">
              <ArrowRight size={10} className="text-white/10" />
              <div className="px-3 py-2.5 rounded-xl border border-white/6 bg-white/2">
                <p className="text-[10px] text-white/20 font-semibold">Repeat ∞</p>
              </div>
            </div>
          </div>
        </div>

        {/* Input signal + 4 agents */}
        <div className="space-y-4">
          {/* Score slider */}
          <div className="p-5 rounded-2xl border border-white/8 bg-white/2">
            <div className="flex items-center justify-between mb-3">
              <p className="text-white/30 text-[9px] uppercase tracking-widest">Team Health Signal</p>
              <span className={`text-lg font-black ${score >= 70 ? 'text-emerald-400' : score >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>{score}%</span>
            </div>
            <input type="range" min={0} max={100} value={score} onChange={e => setScore(Number(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer" />
            <div className="flex justify-between mt-1">
              <span className="text-red-400 text-[9px]">Crisis (0)</span>
              <span className="text-yellow-400 text-[9px]">At Risk (40)</span>
              <span className="text-emerald-400 text-[9px]">Healthy (70+)</span>
            </div>
          </div>

          {/* 4-agent grid */}
          <div className="grid lg:grid-cols-2 gap-4">
            {AGENTS.map(agent => (
              <AgentCard
                key={agent.id}
                agent={agent}
                score={score}
                active={activeAgent === agent.id || (!running && state.cycles > 0)}
              />
            ))}
          </div>
        </div>

        {/* Evolution stages */}
        <div>
          <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">System Evolution</p>
          <div className="space-y-2">
            {STAGES.map((stage, i) => {
              const isActive = i === stageIdx;
              return (
                <button key={stage.id} onClick={() => !stage.locked && setStageIdx(i)}
                  className={`w-full text-left p-4 rounded-xl border transition-all ${
                    isActive ? `${stage.border} ${stage.bg}` : 'border-white/6 bg-white/1 hover:bg-white/3'
                  } ${stage.locked ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 w-16 shrink-0">
                      {stage.locked ? <Lock size={10} className="text-white/20" /> : isActive ? <Unlock size={10} className={stage.color} /> : null}
                      <span className="text-white/25 text-[9px] font-mono">{stage.day}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className={`text-xs font-bold ${isActive ? stage.color : 'text-white/35'}`}>{stage.label}</p>
                        {isActive && <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: stage.color.replace('text-', '') }} />}
                      </div>
                      <p className="text-white/25 text-xs mt-0.5">{stage.desc}</p>
                    </div>
                    {!stage.locked && isActive && <ChevronRight size={12} className={stage.color} />}
                    {stage.locked && <span className="text-[8px] text-white/15 border border-white/8 rounded px-1.5 py-0.5">Unlocks with usage</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Orchestrator code + cycle log */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Architecture */}
          <div>
            <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Orchestrator Architecture</p>
            <div className="p-4 rounded-2xl bg-black/40 border border-white/8">
              <pre className="text-[9px] text-purple-400/75 leading-relaxed overflow-x-auto">{`// Autonomous SaaS v2
// Runs every session. Improves over time.

async function systemAI(liveData) {

  // Phase 1: Observe all signals
  const signals = await collectSignals(liveData)

  // Phase 2: All 4 agents run in parallel
  const [coach, behavior, growth, revenue] =
    await Promise.all([
      coachAgent.analyze(signals),
      behaviorAgent.analyze(signals),
      growthAgent.analyze(signals),
      revenueAgent.analyze(signals),
    ])

  // Phase 3: Orchestrator synthesizes
  const { priority, adaptations } =
    orchestrator.synthesize({
      coach, behavior, growth, revenue
    })

  // Phase 4: Deploy adaptations live
  await applyAdaptations(adaptations)

  // Phase 5: Store to memory
  await memory.store({ signals, adaptations })

  // Repeat next session — system is smarter
  return { priority, health: calcHealth(signals) }
}`}</pre>
            </div>
          </div>

          {/* Cycle log */}
          <div>
            <p className="text-white/25 text-[9px] uppercase tracking-widest mb-3">Cycle Log</p>
            {state.log.length === 0 ? (
              <div className="p-6 rounded-2xl border border-white/6 text-center">
                <Cpu size={20} className="mx-auto text-white/10 mb-2" />
                <p className="text-white/20 text-sm">No cycles yet</p>
                <p className="text-white/10 text-xs">Click &quot;Run AI Loop&quot; to start</p>
              </div>
            ) : (
              <div className="space-y-2">
                {state.log.map((entry, i) => (
                  <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border ${
                    i === 0 ? 'border-purple-500/20 bg-purple-500/5' : 'border-white/5 bg-white/1'
                  }`}>
                    <span className="text-white/20 text-[9px] font-mono w-6 shrink-0">#{entry.cycle}</span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-white/40 text-xs">Score signal: </span>
                        <span className={`text-xs font-bold ${entry.score >= 70 ? 'text-emerald-400' : entry.score >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>{entry.score}%</span>
                      </div>
                      <p className="text-white/20 text-[9px]">{entry.ts}</p>
                    </div>
                    {i === 0 && <span className="text-[8px] font-black text-purple-400 bg-purple-500/10 border border-purple-500/15 px-1.5 py-0.5 rounded-full shrink-0">LATEST</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Compound effect */}
        <div className="p-5 rounded-2xl border border-purple-500/20 bg-purple-500/5">
          <p className="text-purple-400 font-bold text-sm mb-3">The Compound Effect</p>
          <div className="grid lg:grid-cols-3 gap-4">
            {[
              ['Day 1',  'Static rules for everyone. System knows nothing about your team.', 'text-white/35'],
              ['Day 30', 'No two users get the same coaching. Behavior profiles built.', 'text-indigo-400'],
              ['Day 90', 'Predicts churn before it happens. More personalized than any human coach.', 'text-purple-400'],
            ].map(([day, desc, color]) => (
              <div key={day} className="p-4 rounded-xl bg-black/20 border border-white/6">
                <p className={`text-sm font-black ${color} mb-2`}>{day}</p>
                <p className="text-white/40 text-xs leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
          <p className="text-white/35 text-xs mt-4 leading-relaxed">
            <span className="text-white/60 font-semibold">This is the moat. </span>
            Your competitors can copy your features. They cannot copy 90 days of behavioral data
            + a system that has already adapted to your customers.
          </p>
        </div>

      </div>
    </div>
  );
}
